#!/usr/bin/env python3
"""
Computes the same silent --permit-key value the Android app derives in
runner/PermitKeyProvider.kt, so a server operator can configure a matching
`iperf -s ... --permit-key <value>` without hand-implementing the Kotlin
SHA-256+salt+host formula themselves.

The Android app hashes "<versionInfo>|<buildFor>|<salt>|<host>", or
"<versionInfo>|<salt>|<host>" when buildFor is empty, where:
  - versionInfo is the bundled binary's own `iperf -v` output (exactly as
    the ANDROID build prints it - this is normally NOT the same string
    your desktop/server build of iperf prints, since professional/
    community, branch suffix, and "(compiled by ...)" can all differ
    between the two builds). By default this script pulls it straight off
    a connected device itself (see --package/--serial below) via adb - no
    manual adb command needed. Pass --version-info to skip that and supply
    the string directly (e.g. when no device/adb is available: pull the
    APK's lib/<abi>/libiperf.so and run it with `-v` on a matching-arch
    machine, such as an Android emulator or a Linux/arm64 box).
  - buildFor is BuildConfig.PERMIT_KEY_BUILD_FOR, sourced from the gitignored
    android/local.properties `permitKeyBuildFor=` line (set by the build
    engineer after checkout, empty by default). It is NOT part of the native
    binary's own -v output. Read automatically from that file by default
    (see --build-for to override).
  - salt is BuildConfig.PERMIT_KEY_SALT, sourced from the gitignored
    android/local.properties `permitKeySalt=` line at build time. Read
    automatically from that file by default (see --salt to override).
  - host is BuildConfig.PERMIT_HOST, hardcoded in app/build.gradle.kts
    (default: responde.fi-wi.com).

Usage:
    ./compute_permit_key.py
    ./compute_permit_key.py --serial 57211FDCH006XJ
    ./compute_permit_key.py --version-info "iperf 2.2.2 (5 July 2026) pthreads (professional) (compiled by rjmcmahon)"
    ./compute_permit_key.py --version-info "$(cat version.txt)" --salt <hex> --host responde.fi-wi.com

Then start the server with the printed value:
    iperf -s --permit-key <printed-value>
"""
import argparse
import hashlib
import os
import re
import shutil
import subprocess
import sys

DEFAULT_HOST = "responde.fi-wi.com"
DEFAULT_PACKAGE = "com.rjmcmahon.iperf2client"
ADB_TIMEOUT = 20


def read_local_property(path, name):
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        for line in f:
            m = re.match(r"\s*" + re.escape(name) + r"\s*=\s*(.*?)\s*$", line)
            if m:
                return m.group(1)
    return None


def read_salt_from_local_properties(path):
    return read_local_property(path, "permitKeySalt") or None


def compute(version_info, build_for, salt, host):
    # Same rule as PermitKeyProvider.kt: an empty build-for is left out of
    # the hash entirely, not hashed as an empty field.
    if build_for:
        payload = f"{version_info}|{build_for}|{salt}|{host}".encode("utf-8")
    else:
        payload = f"{version_info}|{salt}|{host}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def find_adb():
    """Locate the adb binary: PATH first, then the usual SDK install spot."""
    adb = shutil.which("adb")
    if adb:
        return adb
    sdk_adb = os.path.expanduser("~/Android/Sdk/platform-tools/adb")
    if os.path.isfile(sdk_adb):
        return sdk_adb
    return None


def adb_run(adb, serial, *args):
    cmd = [adb] + (["-s", serial] if serial else []) + list(args)
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=ADB_TIMEOUT)
    except subprocess.TimeoutExpired:
        return None


def list_devices(adb):
    """Returns (authorized_serials, unauthorized_serials)."""
    result = adb_run(adb, None, "devices")
    if result is None or result.returncode != 0:
        return [], []
    authorized, unauthorized = [], []
    for line in result.stdout.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2:
            continue
        serial, state = parts[0], parts[1]
        if state == "device":
            authorized.append(serial)
        elif state == "unauthorized":
            unauthorized.append(serial)
    return authorized, unauthorized


def version_info_from_device(adb, serial, package):
    """
    Finds the app's bundled libiperf.so on-device and runs it with -v.
    Avoids `run-as` (unreliable across devices/OS versions for this - see
    the nested-shell `pm path` quirk this replaced) in favor of reading the
    already-extracted, world-readable native lib directory straight out of
    `dumpsys package`, then locating the binary in it with `find` (works
    regardless of the ABI-directory naming a given Android version uses).
    Returns (version_info, None) on success, or (None, error_message).
    """
    dump = adb_run(adb, serial, "shell", "dumpsys", "package", package)
    if dump is None:
        return None, "adb shell dumpsys package timed out"
    if dump.returncode != 0 or not dump.stdout.strip():
        return None, f"couldn't read package info for {package} (is it installed on this device?)"

    m = re.search(r"legacyNativeLibraryDir=(\S+)", dump.stdout) or re.search(r"nativeLibraryDir=(\S+)", dump.stdout)
    if not m:
        return None, f"couldn't find a native library directory for {package} in dumpsys output"
    libdir = m.group(1)

    found = adb_run(adb, serial, "shell", "find", libdir, "-name", "libiperf.so")
    if found is None:
        return None, "adb shell find timed out"
    libpath = next((l.strip() for l in found.stdout.splitlines() if l.strip()), None)
    if found.returncode != 0 or not libpath:
        return None, f"couldn't find libiperf.so under {libdir}"

    ver = adb_run(adb, serial, "shell", libpath, "-v")
    if ver is None:
        return None, f"running '{libpath} -v' timed out"
    version_info = ver.stdout.strip()
    if ver.returncode != 0 or not version_info:
        return None, f"running '{libpath} -v' on the device produced no output"
    return version_info, None


def auto_detect_version_info(package, serial):
    adb = find_adb()
    if not adb:
        print(
            "error: adb not found (checked PATH and ~/Android/Sdk/platform-tools) and no --version-info given.\n"
            "Install the Android SDK platform-tools, or pass --version-info directly.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not serial:
        authorized, unauthorized = list_devices(adb)
        if not authorized:
            if unauthorized:
                print(
                    f"error: device(s) attached but unauthorized: {', '.join(unauthorized)}\n"
                    "Unlock the phone and accept the 'Allow USB debugging?' prompt, then retry.",
                    file=sys.stderr,
                )
            else:
                print(
                    "error: no adb device attached/authorized. Connect the phone (with the app\n"
                    "installed) and unlock it, or pass --version-info directly.",
                    file=sys.stderr,
                )
            sys.exit(1)
        if len(authorized) > 1:
            print(
                "error: multiple adb devices attached - pass --serial to pick one:\n  "
                + "\n  ".join(authorized),
                file=sys.stderr,
            )
            sys.exit(1)
        serial = authorized[0]

    version_info, err = version_info_from_device(adb, serial, package)
    if err:
        print(
            f"error: couldn't auto-detect --version-info from device {serial}: {err}\n"
            "Pass --version-info explicitly instead.",
            file=sys.stderr,
        )
        sys.exit(1)
    print(f"(auto-detected from device {serial}: {version_info})", file=sys.stderr)
    return version_info


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    default_props = os.path.join(script_dir, "local.properties")

    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--version-info",
        help='The Android build\'s exact `iperf -v` output, e.g. "iperf 2.2.2 (5 July 2026) pthreads '
             '(professional) (compiled by rjmcmahon)". If omitted, this is auto-detected from a connected, '
             'authorized adb device running --package.',
    )
    parser.add_argument(
        "--package", default=DEFAULT_PACKAGE,
        help=f"Android application ID to inspect via adb when --version-info isn't given (default: {DEFAULT_PACKAGE})",
    )
    parser.add_argument(
        "--serial",
        help="adb device serial to target when more than one device is attached (see `adb devices`); "
             "ignored if --version-info is given",
    )
    parser.add_argument(
        "--salt",
        help=f"Override the salt instead of reading permitKeySalt= from {default_props}",
    )
    parser.add_argument("--host", default=DEFAULT_HOST, help=f"PERMIT_HOST (default: {DEFAULT_HOST})")
    parser.add_argument(
        "--build-for",
        help=f"Override permitKeyBuildFor= instead of reading it from {default_props} "
             '(pass --build-for "" to force it empty)',
    )
    parser.add_argument(
        "--properties", default=default_props,
        help="Path to local.properties to read permitKeySalt= from when --salt isn't given",
    )
    args = parser.parse_args()

    version_info = args.version_info or auto_detect_version_info(args.package, args.serial)

    salt = args.salt or read_salt_from_local_properties(args.properties)
    if not salt:
        print(
            f"error: no salt given and couldn't read permitKeySalt= from {args.properties}\n"
            "Pass --salt explicitly, or run this from a checkout with android/local.properties configured.",
            file=sys.stderr,
        )
        sys.exit(1)

    build_for = args.build_for
    if build_for is None:
        build_for = read_local_property(args.properties, "permitKeyBuildFor") or ""
    key = compute(version_info, build_for, salt, args.host)
    print(key)


if __name__ == "__main__":
    main()
