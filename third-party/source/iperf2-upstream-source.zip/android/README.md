# iperf2 Android client

A thin Kotlin/Compose wrapper around the existing iperf2 CLI (`../src`), run
as a subprocess. TCP client only - no server mode, no UDP.

Live meters shown during a test: throughput, RTT, bytes-in-flight (parsed
from `iperf -c ... -e -y C` CSV output).

## How the native binary gets into the app

There's no JNI, no C code changes needed to *build* this app (the one
upstream iperf2 change this app depends on - adding bytes/packets-in-flight
to the TCP enhanced CSV format - already lives in `../src/Locale.c` /
`../src/ReportOutputs.c`, not here).

Instead, `app/build.gradle.kts` registers a `BuildIperfNativeTask` per ABI
that shells out to the *same* `./configure && make` build used everywhere
else in this repo, cross-compiling with the Android NDK, and copies the
resulting `iperf` binary to `app/src/main/jniLibs/<abi>/libiperf.so`.
Naming it `.so` and placing it under `jniLibs` is what makes Android
willing to execute it at runtime (API 29+ blocks exec from an app's
private data dir, but binaries installed under
`ApplicationInfo.nativeLibraryDir` - which is exactly what `jniLibs`
becomes - are permitted). The app runs it via `ProcessBuilder`, not `System.loadLibrary`.

`app/src/main/jniLibs/` is generated output and is gitignored - don't hand-edit it.

## Building

Needs:
- Android SDK (platform 36+, this was developed against `compileSdk = 36`,
  required by the Compose BOM/AndroidX library versions in use)
- Android NDK r27c (pinned via `ndkVersion` in `app/build.gradle.kts`)
- A `local.properties` (copy `local.properties.sample`) pointing `sdk.dir`/`ndk.dir`
  at your install

```
./gradlew assembleDebug
```

First build will take longer than usual - the native-build task
cross-compiles iperf2 from source for each ABI (`arm64-v8a`, `armeabi-v7a`,
`x86_64`) before Gradle packages the APK.

## Testing without a Play Store / CI setup

This was validated end-to-end against a real device (adb over USB) tunneled
back to a TCP server on the dev machine via `adb reverse tcp:<port> tcp:<port>`,
since UDP-only adb tunnels don't apply here (TCP-only app, so this isn't a
concern the way it would be for a UDP test). See the top-level repo's
session notes / commit history around the CSV bytes-in-flight addition for
the exact verification steps used.
