package com.rjmcmahon.iperf2client.runner

/**
 * Always-available public iperf2 test servers (see
 * public_servers/PUBLIC_SERVERS_NOTES).
 * Shared between IperfScreen (the Host dropdown's fixed floor of options,
 * always present even on a fresh install with no history) and
 * TestConfigStore (recordHostUse skips adding these to the recent-hosts MRU
 * list - they're already always visible regardless of history, so counting
 * them there would let testing through the whole roster crowd out actually
 * custom/private hosts in a capped-size list).
 *
 * Per-host ports, not one shared pair, even though all eleven currently run
 * the same 5001/5002 (iperf2's traditional legacy default) - fremont/
 * vienna/newark were originally deployed on 5201/5202 before being moved to
 * match the rest, and keeping this per-host lets any future batch land on
 * its own ports again without restructuring.
 */
data class PublicServer(val host: String, val tcpPort: Int, val udpL4sPort: Int)

val PUBLIC_SERVERS = listOf(
    PublicServer("responde-fremont.fi-wi.com", 5001, 5002),
    PublicServer("responde-vienna.fi-wi.com", 5001, 5002),
    PublicServer("responde-newark.fi-wi.com", 5001, 5002),
    PublicServer("responde-london.fi-wi.com", 5001, 5002),
    PublicServer("responde-mumbai.fi-wi.com", 5001, 5002),
    PublicServer("responde-singapore.fi-wi.com", 5001, 5002),
    PublicServer("responde-sydney.fi-wi.com", 5001, 5002),
    PublicServer("responde-saopaulo.fi-wi.com", 5001, 5002),
    PublicServer("responde-lax.fi-wi.com", 5001, 5002),
    PublicServer("responde-chicago.fi-wi.com", 5001, 5002),
    PublicServer("responde-tokyo.fi-wi.com", 5001, 5002),
)
val DEFAULT_HOSTS = PUBLIC_SERVERS.map { it.host }
