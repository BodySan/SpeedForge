package com.rjmcmahon.iperf2client.ui

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rjmcmahon.iperf2client.R
import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import com.rjmcmahon.iperf2client.model.BouncebackTransport
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.L4SCongestionControl
import com.rjmcmahon.iperf2client.model.MeterStats
import com.rjmcmahon.iperf2client.model.NetworkPreference
import com.rjmcmahon.iperf2client.model.RunSnapshot
import com.rjmcmahon.iperf2client.model.TestConfig
import com.rjmcmahon.iperf2client.model.TestKind
import com.rjmcmahon.iperf2client.model.TestMode
import com.rjmcmahon.iperf2client.model.Transport
import com.rjmcmahon.iperf2client.model.WorkingLoadDirection
import com.rjmcmahon.iperf2client.runner.DEFAULT_HOSTS
import com.rjmcmahon.iperf2client.runner.NetworkTransport
import com.rjmcmahon.iperf2client.runner.PUBLIC_SERVERS
import com.rjmcmahon.iperf2client.ui.theme.ThemeMode
import com.rjmcmahon.iperf2client.runner.RawRunLogStore
import com.rjmcmahon.iperf2client.runner.availableForcableTransports
import com.rjmcmahon.iperf2client.stats.CwndInflightPoint
import com.rjmcmahon.iperf2client.stats.RttHistoryPoint
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.WindowInflightPoint
import com.rjmcmahon.iperf2client.stats.WindowedSnapshot
import com.rjmcmahon.iperf2client.ui.meters.BounceBackHistogramChart
import com.rjmcmahon.iperf2client.ui.meters.BytesInFlightMeter
import com.rjmcmahon.iperf2client.ui.meters.CeDurationPlaceholder
import com.rjmcmahon.iperf2client.ui.meters.CeMarksPerSecMeter
import com.rjmcmahon.iperf2client.ui.meters.L4sRttMeter
import com.rjmcmahon.iperf2client.ui.meters.LiveSparkline
import com.rjmcmahon.iperf2client.ui.meters.LossProbabilityMeter
import com.rjmcmahon.iperf2client.ui.meters.MarkingProbabilityMeter
import com.rjmcmahon.iperf2client.ui.meters.MiniSparkline
import com.rjmcmahon.iperf2client.ui.meters.PacketsPerSecMeter
import com.rjmcmahon.iperf2client.ui.meters.QueueDelayMeter
import com.rjmcmahon.iperf2client.ui.meters.RetriesMeter
import com.rjmcmahon.iperf2client.ui.meters.RttFloorChart
import com.rjmcmahon.iperf2client.ui.meters.RttMeter
import com.rjmcmahon.iperf2client.ui.meters.ThroughputMeter
import com.rjmcmahon.iperf2client.ui.meters.WorkingLoadDownChart
import com.rjmcmahon.iperf2client.ui.meters.WorkingLoadUpChart
import com.rjmcmahon.iperf2client.ui.meters.WriteBlockTimeMeter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.roundToInt

/**
 * Settings.Panel.ACTION_WIFI (API 29+) opens a lightweight floating WiFi
 * picker without leaving this app - falls back to the full WiFi settings
 * activity on older API levels, where the Panel API doesn't exist yet
 * (this app's own minSdk is 24). Either way, every security type (open,
 * WPA2/WPA3-Personal, Enterprise, hidden SSID) is handled by the system
 * UI itself - see the launch site's own doc comment for why that's
 * deliberate, not just the easy option.
 */
private fun wifiSettingsIntent(): Intent =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        Intent(Settings.Panel.ACTION_WIFI)
    } else {
        Intent(Settings.ACTION_WIFI_SETTINGS)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IperfScreen(
    viewModel: IperfViewModel = viewModel(),
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    onThemeModeChange: (ThemeMode) -> Unit = {},
) {
    val config by viewModel.config.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    val isWorkingLoadPaused by viewModel.isWorkingLoadPaused.collectAsState()
    val latestSample by viewModel.latestSample.collectAsState()
    val throughputStats by viewModel.throughputStats.collectAsState()
    val rttStats by viewModel.rttStats.collectAsState()
    val inFlightStats by viewModel.inFlightStats.collectAsState()
    val packetsInFlightStats by viewModel.packetsInFlightStats.collectAsState()
    val cwndStats by viewModel.cwndStats.collectAsState()
    val retryStats by viewModel.retryStats.collectAsState()
    val notSentStats by viewModel.notSentStats.collectAsState()
    val tcpExcessRttStats by viewModel.tcpExcessRttStats.collectAsState()
    val sndBufStats by viewModel.sndBufStats.collectAsState()
    val writeTimeStats by viewModel.writeTimeStats.collectAsState()
    val sndBufLimitedStats by viewModel.sndBufLimitedStats.collectAsState()
    val rwndLimitedStats by viewModel.rwndLimitedStats.collectAsState()
    val busyTimeStats by viewModel.busyTimeStats.collectAsState()
    val flowingStats by viewModel.flowingStats.collectAsState()
    val ceMarksStats by viewModel.ceMarksStats.collectAsState()
    val ceMarksWhenMarkingStats by viewModel.ceMarksWhenMarkingStats.collectAsState()
    val queueDelayStats by viewModel.queueDelayStats.collectAsState()
    val queueBytesStats by viewModel.queueBytesStats.collectAsState()
    val queuePacketsStats by viewModel.queuePacketsStats.collectAsState()
    val queueUnitsPackets by viewModel.queueUnitsPackets.collectAsState()
    val l4sRttStats by viewModel.l4sRttStats.collectAsState()
    val l4sPacketWindowStats by viewModel.l4sPacketWindowStats.collectAsState()
    val l4sInflightStats by viewModel.l4sInflightStats.collectAsState()
    val l4sMarkingProbStats by viewModel.l4sMarkingProbStats.collectAsState()
    val errPercentStats by viewModel.errPercentStats.collectAsState()
    val bbRequestsStats by viewModel.bbRequestsStats.collectAsState()
    val bbRttMinUs by viewModel.bbRttMinUs.collectAsState()
    val bbHistogram by viewModel.bbHistogram.collectAsState()
    val goldenHistogram by viewModel.goldenHistogram.collectAsState()
    val goldenSlot by viewModel.goldenSlot.collectAsState()
    val sparklineHistory by viewModel.sparklineHistoryFlow.collectAsState()
    val bbRequestsHistory by viewModel.bbRequestsHistoryFlow.collectAsState()
    val rttHistory by viewModel.rttHistoryFlow.collectAsState()
    val throughputHistory by viewModel.throughputHistoryFlow.collectAsState()
    val ceDurationHistory by viewModel.ceDurationHistoryFlow.collectAsState()
    val writeTimeHistory by viewModel.writeTimeHistoryFlow.collectAsState()
    val retryHistory by viewModel.retryHistoryFlow.collectAsState()
    val cwndInflightHistory by viewModel.cwndInflightHistoryFlow.collectAsState()
    val windowInflightHistory by viewModel.windowInflightHistoryFlow.collectAsState()
    val ppsHistory by viewModel.ppsHistoryFlow.collectAsState()
    val ceMarksPerSecHistory by viewModel.ceMarksPerSecHistoryFlow.collectAsState()
    val markProbHistory by viewModel.markProbHistoryFlow.collectAsState()
    val lossPercentHistory by viewModel.lossPercentHistoryFlow.collectAsState()
    val workingLoadUpMbps by viewModel.workingLoadUpMbps.collectAsState()
    val workingLoadUpStats by viewModel.workingLoadUpStats.collectAsState()
    val workingLoadDownMbps by viewModel.workingLoadDownMbps.collectAsState()
    val workingLoadDownStats by viewModel.workingLoadDownStats.collectAsState()
    val workingLoadUpHistory by viewModel.workingLoadUpHistoryFlow.collectAsState()
    val workingLoadDownHistory by viewModel.workingLoadDownHistoryFlow.collectAsState()
    val savedRuns by viewModel.savedRuns.collectAsState()
    val viewingSlot by viewModel.viewingSlot.collectAsState()
    val elapsedSecs by viewModel.elapsedSecs.collectAsState()
    val testProgress by viewModel.testProgress.collectAsState()
    val runStartedAtMillis by viewModel.runStartedAtMillis.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val activeTransport by viewModel.activeTransport.collectAsState()
    val transportMismatch by viewModel.transportMismatch.collectAsState()
    val transportMismatchPreference by viewModel.transportMismatchPreference.collectAsState()
    val l4sCeConfirmed by viewModel.l4sCeConfirmed.collectAsState()
    val l4sReplyBleachDetected by viewModel.l4sReplyBleachDetected.collectAsState()
    val l4sReqBleachDetected by viewModel.l4sReqBleachDetected.collectAsState()
    val l4sReplyConfirmed by viewModel.l4sReplyConfirmed.collectAsState()
    val l4sReqConfirmed by viewModel.l4sReqConfirmed.collectAsState()
    val capacityL4sConfirmed by viewModel.capacityL4sConfirmed.collectAsState()
    val capacityL4sBleachDetected by viewModel.capacityL4sBleachDetected.collectAsState()
    val bbStaleReplyDetected by viewModel.bbStaleReplyDetected.collectAsState()
    val versionInfo by viewModel.versionInfo.collectAsState()
    val versionParts = versionInfo?.let { parseVersionInfo(it) }
    val ccaOptions by viewModel.ccaOptions.collectAsState()
    val connectFailed by viewModel.connectFailed.collectAsState()
    val everConnected by viewModel.everConnected.collectAsState()
    val hadConnectRetry by viewModel.hadConnectRetry.collectAsState()
    val recentHosts by viewModel.recentHosts.collectAsState()
    val recentPorts by viewModel.recentPorts.collectAsState()

    // A field the user was still editing when Start was tapped (e.g. Host)
    // gets disabled or (for the write-prefetch/cca/reverse block) removed
    // from composition entirely once isRunning flips true, but Compose
    // doesn't reliably close the IME just because its focused field went
    // away - the keyboard session can linger invisibly until something else
    // disturbs the layout, then reappear covering the results right as a
    // run ends (see the isRunning-false LaunchedEffect below). Clearing
    // focus explicitly the moment a run starts closes it immediately
    // instead of leaving it to resurface later.
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    LaunchedEffect(isRunning) {
        if (isRunning) {
            focusManager.clearFocus()
            keyboardController?.hide()
        }
    }

    // Hands the user off to Android's own WiFi settings UI to switch
    // networks, rather than this app driving the switch itself
    // (WifiNetworkSpecifier was considered and rejected - it only lets
    // THIS app's own traffic use a separately-negotiated network in the
    // background, it never changes what network the device itself shows
    // as connected to, which doesn't match what a technician actually
    // wants when they ask to "switch networks"). This also means every
    // security type - open, WPA2/WPA3-Personal, Enterprise, hidden SSID -
    // is handled for free by the system UI instead of needing a whole
    // security-type picker built here. No result handling needed: once
    // the user returns, the existing NetworkPreference/AUTO flow already
    // re-reads whatever's now the active default network on its own.
    val context = LocalContext.current
    val wifiSettingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // App's own launcher icon (gauge with a green/yellow
                        // arc) rather than a generic Material icon - a plain
                        // "network" glyph like NetworkCheck read as a Wi-Fi
                        // symbol, unrelated to what this app actually does.
                        Image(
                            painter = painterResource(R.mipmap.ic_launcher_foreground),
                            contentDescription = null,
                            modifier = Modifier.size(42.dp),
                        )
                        // Own inner Row so "iperf2" and the version text
                        // baseline-align to *each other*, independent of
                        // the icon's height - aligning against the outer
                        // Row instead put the version text's bottom at the
                        // icon's own bottom edge (the tallest child sets
                        // the outer Row's height), well below "iperf2"'s
                        // actual baseline once the icon grew past a single
                        // text line's height.
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("iperf2", modifier = Modifier.alignByBaseline())
                            versionParts?.let {
                                Text(
                                    text = it.versionAndDate,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.alignByBaseline().padding(start = 8.dp),
                                )
                            }
                        }
                    }
                },
                actions = {
                    // effectiveDark resolves SYSTEM against the live system
                    // setting, not just themeMode itself, so this stays
                    // correct even before the user has ever touched the
                    // toggle. The icon shown is the *destination* a tap
                    // leads to, not the current state - a sun while dark
                    // ("tap for daylight"), a moon while light ("tap for
                    // night") - same convention most sun/moon toggles use.
                    // Tapping sets an explicit LIGHT/DARK override; there's
                    // no way back to SYSTEM from the UI once toggled (no
                    // settings screen exists yet to put that control), an
                    // accepted simplification since SYSTEM is still the
                    // default for anyone who's never touched this button.
                    val effectiveDark = when (themeMode) {
                        ThemeMode.SYSTEM -> isSystemInDarkTheme()
                        ThemeMode.LIGHT -> false
                        ThemeMode.DARK -> true
                    }
                    IconButton(onClick = { wifiSettingsLauncher.launch(wifiSettingsIntent()) }) {
                        Icon(WifiIcon, contentDescription = "Change WiFi network")
                    }
                    IconButton(onClick = { onThemeModeChange(if (effectiveDark) ThemeMode.LIGHT else ThemeMode.DARK) }) {
                        Icon(
                            if (effectiveDark) LightModeIcon else DarkModeIcon,
                            contentDescription = if (effectiveDark) "Switch to light theme" else "Switch to dark theme",
                        )
                    }
                    IconButton(onClick = { viewModel.resetToDefaults() }, enabled = !isRunning) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Reset to defaults")
                    }
                },
            )
        },
    ) { innerPadding ->
        val scrollState = rememberScrollState()
        // Positions (in root/window coordinates) of the scroll container and
        // the Start/Stop button, kept up to date on every layout pass so the
        // auto-scroll effect below can compute the button's fixed offset
        // within the scrollable content - see that effect for why.
        var columnTopInRoot by remember { mutableStateOf(0f) }
        var startButtonTopInRoot by remember { mutableStateOf(0f) }
        // Top of the results/meters section - used instead of the button's
        // own position specifically when a run just stopped, since the
        // collapsed config blocks (write-prefetch/cca/working-load/reverse)
        // re-expand on stop, inserting height *between* the button and the
        // meters that a button-anchored scroll doesn't account for. See the
        // auto-scroll effect below.
        var metersTopInRoot by remember { mutableStateOf(0f) }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp)
                .onGloballyPositioned { columnTopInRoot = it.positionInRoot().y }
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            ConfigTopFields(
                config = config,
                isRunning = isRunning,
                recentHosts = recentHosts,
                recentPorts = recentPorts,
                viewModel = viewModel,
            )

            // The test-type selector above already shows which mode is
            // selected, so the button itself doesn't need to repeat it.
            // isConfigValid guards against nonsensical values (port 0,
            // negative duration other than the -1 "run until Stop" sentinel,
            // zero/negative interval) reaching IperfCommandBuilder's argv
            // unchallenged - those wouldn't crash the app, but they'd hand
            // the native binary an argument it can only fail on.
            val isConfigValid = config.host.isNotBlank() &&
                config.port in 1..65535 &&
                (config.durationSecs == -1 || config.durationSecs > 0) &&
                config.intervalSecs > 0.0
            // Running but no sample yet - still waiting on the connect
            // watchdog (see IperfViewModel.startConnectWatchdog) to either
            // see real data arrive or give up. Button stays tappable
            // (onClick still routes to onStop()) so the user isn't stuck
            // waiting the full watchdog window if they want out sooner.
            val isConnecting = isRunning && latestSample == null
            // Ticks one extra "." per second so the button visibly moves
            // while waiting, instead of sitting on static "Connecting…" text
            // that looks identical whether it's about to succeed or hang.
            // Purely a UI animation - not tied to the watchdog's actual
            // timeout value, which lives in the ViewModel.
            var connectingDots by remember { mutableStateOf(0) }
            LaunchedEffect(isConnecting) {
                connectingDots = 0
                while (isConnecting) {
                    delay(1000)
                    connectingDots = (connectingDots + 1).coerceAtMost(5)
                }
            }
            // Both a run starting and a run ending change what's above the
            // button (config fields collapse on start, re-expand on stop -
            // see the "collapsed entirely while running" block below) and
            // can push the meters below the fold either way. Scroll so the
            // button's own top edge lands at the top of the viewport on
            // *every* isRunning transition, not just stop, so the meters are
            // visible from the moment a run begins instead of only once it
            // finishes. The button's offset within the scrollable content is
            // fixed regardless of run state (nothing above it ever
            // collapses), so a short delay to let this frame's layout settle
            // is all that's needed before reading it.
            //
            // isRunning flipping true isn't the only thing that can push
            // content below the button, though: the "Connected" LED row
            // (below) only appears once latestSample != null - i.e. once the
            // first CSV line actually arrives, which for a remote host lags
            // well past this effect's 50ms settle delay. That row's late
            // insertion shoves everything below it (the meters, including
            // CE marks/sec) down by its own height *after* the isRunning-
            // triggered scroll already ran, with nothing to re-trigger a
            // rescroll - so key this on the same condition that row's own
            // visibility uses, too.
            //
            // BOUNCEBACK's LiveSparkline is a third such late-growing
            // element, and a bigger one: it's a single "Waiting for data…"
            // line until the windowed stats' first render tick has
            // something to show (sparkline history non-empty), then
            // expands to its full ~220dp chart - well after
            // showConnectedRow already flipped true, since that only needs
            // one CSV line while the sparkline needs a second sample plus
            // its own 10Hz tick. Key on that too so the chart's own
            // expansion re-triggers a rescroll instead of leaving it (and
            // everything below it) sitting below the fold.
            val showConnectedRow = connectFailed || latestSample != null
            val sparklineExpanded = sparklineHistory.isNotEmpty()
            var wasRunning by remember { mutableStateOf(false) }
            var wasShowingConnected by remember { mutableStateOf(false) }
            var wasSparklineExpanded by remember { mutableStateOf(false) }
            LaunchedEffect(isRunning, showConnectedRow, sparklineExpanded) {
                if (wasRunning != isRunning || wasShowingConnected != showConnectedRow || wasSparklineExpanded != sparklineExpanded) {
                    delay(50)
                    // A run just stopping is its own case: the config
                    // blocks re-expanding below the button pushes the
                    // meters down by more than they moved during the run,
                    // so anchoring on the button (which is what every other
                    // transition here wants) would leave the final results
                    // below the fold instead of revealing them.
                    val justStopped = wasRunning && !isRunning
                    val anchorTopInRoot = if (justStopped) metersTopInRoot else startButtonTopInRoot
                    val target = (anchorTopInRoot - columnTopInRoot + scrollState.value).roundToInt()
                    scrollState.animateScrollTo(target.coerceIn(0, scrollState.maxValue))
                }
                wasRunning = isRunning
                wasShowingConnected = showConnectedRow
                wasSparklineExpanded = sparklineExpanded
            }
            Button(
                onClick = { if (isRunning) viewModel.onStop() else viewModel.onStart() },
                enabled = isRunning || isConfigValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .onGloballyPositioned { startButtonTopInRoot = it.positionInRoot().y },
            ) {
                Text(
                    when {
                        isConnecting -> "Connecting" + ".".repeat(connectingDots)
                        isRunning -> "Stop"
                        else -> "Start"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
            }

            // SIGUSR1/SIGUSR2 go to this app's own child process. For UP
            // (and bidir's own upload half) that process owns the writer
            // directly. For DOWN (and bidir's own download half) the real
            // writer is server-spawned and unreachable directly - but this
            // app's process still owns the *reader* for that direction
            // (the client locally reverses roles for -R-style directions),
            // and pausing the reader is what actually pauses the stream:
            // TCP via backpressure, UDP-L4S via a wire-relayed pause flag
            // the reader sets on its own ACKs (see IperfViewModel's own
            // doc comment on onToggleWorkingLoadPause). So every direction
            // is pausable from here.
            val canPauseWorkingLoad = config.mode == TestMode.BOUNCEBACK &&
                config.workingLoadEnabled
            if (isRunning && canPauseWorkingLoad) {
                OutlinedButton(
                    onClick = { viewModel.onToggleWorkingLoadPause() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                ) {
                    Text(if (isWorkingLoadPaused) "Resume working load" else "Pause working load")
                }
            }

            RunProgressAndConnectionStatus(
                isRunning = isRunning,
                elapsedSecs = elapsedSecs,
                config = config,
                testProgress = testProgress,
                runStartedAtMillis = runStartedAtMillis,
                connectFailed = connectFailed,
                everConnected = everConnected,
                hadConnectRetry = hadConnectRetry,
                latestSample = latestSample,
                activeTransport = activeTransport,
                transportMismatch = transportMismatch,
                l4sCeConfirmed = l4sCeConfirmed,
                l4sReplyBleachDetected = l4sReplyBleachDetected,
                l4sReqBleachDetected = l4sReqBleachDetected,
                l4sReplyConfirmed = l4sReplyConfirmed,
                l4sReqConfirmed = l4sReqConfirmed,
                capacityL4sConfirmed = capacityL4sConfirmed,
                capacityL4sBleachDetected = capacityL4sBleachDetected,
                bbStaleReplyDetected = bbStaleReplyDetected,
            )

            // Transport row - directly under Start/the connection status,
            // above Force IPv6 and everything else in CollapsedConfigRows -
            // for both kinds, so its position doesn't shift depending on
            // which one is selected (previously Capacity's own row sat
            // above Start via ConfigTopFields while Bounceback's sat below
            // Force IPv6 via CollapsedConfigRows - same control, two
            // different spots, read as "it's missing" when switching
            // between kinds). Exactly one of the two blocks below is ever
            // visible at a time (gated on testKind/mode), kept as two
            // separate blocks rather than one merged composable since they
            // key off genuinely different TestConfig fields (capacityTransport
            // vs bouncebackTransport) - see BouncebackTransport's own doc
            // comment for why that's a separate field, not a shared one.
            if (config.testKind == TestKind.CAPACITY && !isRunning) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Text("Transport", modifier = Modifier.weight(1f).align(Alignment.CenterVertically))
                    UdpL4sInfoIcon()
                    listOf(Transport.TCP to "TCP", Transport.UDP_L4S to "UDP L4S").forEach { (transport, label) ->
                        val selected = config.capacityTransport == transport
                        FilterChip(
                            selected = selected,
                            onClick = {
                                val wasL4SPort = config.usesL4SPort()
                                val newConfig = config.copy(capacityTransport = transport)
                                viewModel.updateConfig(newConfig.copy(port = config.port + portDelta(wasL4SPort, newConfig.usesL4SPort())))
                            },
                            label = { Text(label) },
                            enabled = !isRunning,
                            border = chipBorder(enabled = !isRunning, selected = selected),
                        )
                    }
                }
            }
            if (config.mode == TestMode.BOUNCEBACK && !isRunning) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Text("Transport", modifier = Modifier.weight(1f).align(Alignment.CenterVertically))
                    UdpL4sInfoIcon(includesPlainUdp = true)
                    listOf(BouncebackTransport.TCP to "TCP", BouncebackTransport.UDP_L4S to "UDP L4S", BouncebackTransport.UDP to "UDP").forEach { (transport, label) ->
                        val selected = config.bouncebackTransport == transport
                        FilterChip(
                            selected = selected,
                            onClick = {
                                val wasL4SPort = config.usesL4SPort()
                                val newConfig = config.copy(bouncebackTransport = transport)
                                viewModel.updateConfig(newConfig.copy(port = config.port + portDelta(wasL4SPort, newConfig.usesL4SPort())))
                            },
                            label = { Text(label) },
                            enabled = !isRunning,
                            border = chipBorder(enabled = !isRunning, selected = selected),
                        )
                    }
                }
            }

            // Network row - forces which physical interface this test's
            // traffic goes out over, via the native CLI's own `-c
            // host%device` (SO_BINDTODEVICE) - see NetworkPreference's own
            // doc comment. Shown for both kinds identically (unlike the
            // Transport row above, which is protocol-specific) since which
            // NIC to use is orthogonal to what's being tested. AUTO is the
            // default and leaves routing to Android's own default-route
            // selection - the same decision the WiFi/Ethernet/Cellular icon
            // next to the connection status already reads back.
            //
            // Gated on there being at least 2 transports actually up
            // (availableTransportsState, live via NetworkCallback) rather
            // than shown unconditionally - on the vast majority of devices
            // there's only ever WiFi, and a selector with nothing to
            // actually choose between would just be wasted screen space.
            // Only chips for transports that ARE up get rendered (plus
            // AUTO, always) - a WiFi-only device never sees a dead
            // "Ethernet"/"Cellular" chip it can't actually pick.
            val availableTransports by availableTransportsState()
            LaunchedEffect(availableTransports, config.networkPreference) {
                if (config.networkPreference != NetworkPreference.AUTO &&
                    config.networkPreference !in availableTransports
                ) {
                    viewModel.updateConfig(config.copy(networkPreference = NetworkPreference.AUTO))
                }
            }
            if (!isRunning && availableTransports.size >= 2) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    Text("Network", modifier = Modifier.weight(1f).align(Alignment.CenterVertically))
                    (listOf(NetworkPreference.AUTO to "Auto") + listOf(
                        NetworkPreference.CELLULAR to "Cellular",
                        NetworkPreference.ETHERNET to "Ethernet",
                        NetworkPreference.WIFI to "WiFi",
                    ).filter { (preference, _) -> preference in availableTransports })
                        .forEach { (preference, label) ->
                            val selected = config.networkPreference == preference
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.updateConfig(config.copy(networkPreference = preference)) },
                                label = { Text(label) },
                                enabled = !isRunning,
                                border = chipBorder(enabled = !isRunning, selected = selected),
                                // Row only shows once !isRunning (see above),
                                // so this always reflects the run that just
                                // finished, same "still visible right after"
                                // contract as the connect-status warning icon
                                // this mirrors - see IperfViewModel.
                                // transportMismatch's own doc comment. Keyed
                                // on transportMismatchPreference, NOT
                                // `selected` (== the live picker's current
                                // choice) - the live picker can be changed
                                // freely after a run completes without
                                // starting a new one, and the badge needs to
                                // stay on the chip that was actually tested,
                                // not silently "follow" whichever chip the
                                // user happens to be looking at afterward
                                // (confirmed on-device: Sebastian Moeller,
                                // 2026-08-11 - the badge was appearing on
                                // Cellular just from switching the picker to
                                // it, with no Cellular run ever having been
                                // tested).
                                trailingIcon = if (preference == transportMismatchPreference && transportMismatch) {
                                    {
                                        Icon(
                                            Icons.Filled.Warning,
                                            contentDescription = "$label wasn't honored by this device last run",
                                            modifier = Modifier.size(16.dp),
                                            tint = Color(0xFFFFA000),
                                        )
                                    }
                                } else null,
                            )
                        }
                }
            }

            // Collapsed entirely while a test is running: every control in
            // here is disabled then anyway, and leaving them expanded pushed
            // the live meters below the fold, forcing a scroll to see the
            // one thing that's actually changing during a run.
            //
            // TCP mode's own order (reverse, then congestion control, then
            // tcp_notsent_lowat) is deliberate, not just source order -
            // reverse changes which side does the writing at all, which is
            // the thing most likely to change what the rest of these
            // settings even mean, so it leads. Bounceback/UDP-L4S each only
            // ever show a subset of these rows (see each block's own mode
            // gate below), so this ordering is TCP-specific in practice
            // even though the blocks themselves are shared code.

            CollapsedConfigRows(
                config = config,
                isRunning = isRunning,
                ccaOptions = ccaOptions,
                viewModel = viewModel,
                onMetersPositioned = { metersTopInRoot = it },
            )

            // Preset compare (see IperfViewModel.saveCurrentAs()/viewingSlot,
            // RunSnapshot) - four independent preset slots, car-radio-preset
            // semantics: hold a slot in RunCompareTabs (rendered near the
            // bottom of this screen, above the version/edition text) to
            // freeze the live/just-finished run into it (full TestConfig -
            // mode, tcp-cca, everything - not just host/port/duration), tap
            // to recall it. No slot is tied to a particular test mode, so a
            // technician can hold a TCP run into one preset and a UDP-L4S
            // run into another and flip between them for a direct
            // comparison - each slot's own config.mode (via effConfig
            // below) drives which meters render, independent of whatever
            // mode the live config is currently set to.
            val effectiveSnapshot: RunSnapshot? = viewingSlot?.let { savedRuns[it] }
            val effectiveViewingSaved = effectiveSnapshot != null
            val effConfig = effectiveSnapshot?.config ?: config

            // Whether there's a live/just-finished run available to freeze
            // into a preset right now - gates the hold-to-save gesture
            // inside RunCompareTabs, and whether the row is shown at all
            // (it needs to appear the very first time there's anything to
            // save, before any slot has ever been used). Allowed mid-run
            // too, not just after stopping - RunCompareTabs uses a much
            // shorter hold while running (see PresetHoldTimeoutRunningMs) so
            // grabbing a live snapshot doesn't cost as much dead time as
            // deliberately overwriting a finished result. !connectFailed is
            // belt-and-suspenders alongside latestSample != null - a failed
            // TCP connect (Reporter.c's own connect-failure message, or the
            // app's own connect watchdog) shouldn't leave anything saveable
            // even in some edge case where a stray/partial sample still
            // made it through parsing - there's nothing meaningful to
            // freeze from a run that never actually connected.
            val canSaveRun = !connectFailed && latestSample != null

            // No Throughput or RTT dial for Bounceback: it's an RPS
            // (requests/sec) test, not a bandwidth one - the bbcnt/rps
            // field's own "speed" column is the tiny 100-byte bounce
            // packets' own bitrate, not a meaningful throughput number, and
            // would mislead next to a real bandwidth test's dial. RPS lives
            // in the BarGraphGauge below; bounce latency lives in
            // LiveSparkline below that.
            //
            // Every meter below reads from the eff* values, not the raw
            // live ones directly - when effectiveViewingSaved, those are
            // effectiveSnapshot's own frozen MeterStats with effIsRunning
            // forced false and effSample forced null, which is exactly the
            // state every meter already renders correctly for a completed
            // run (see e.g. RttMeter's own "!isRunning && finalMs != null"
            // branch) - no meter-level changes needed, just a different
            // data source.
            val effIsRunning = if (effectiveViewingSaved) false else isRunning
            val effSample = if (effectiveViewingSaved) null else latestSample
            val effThroughputStats = effectiveSnapshot?.throughputStats ?: throughputStats
            val effRttStats = effectiveSnapshot?.rttStats ?: rttStats
            val effInFlightStats = effectiveSnapshot?.inFlightStats ?: inFlightStats
            val effPacketsInFlightStats = effectiveSnapshot?.packetsInFlightStats ?: packetsInFlightStats
            val effCwndStats = effectiveSnapshot?.cwndStats ?: cwndStats
            val effRetryStats = effectiveSnapshot?.retryStats ?: retryStats
            val effNotSentStats = effectiveSnapshot?.notSentStats ?: notSentStats
            val effTcpExcessRttStats = effectiveSnapshot?.tcpExcessRttStats ?: tcpExcessRttStats
            val effSndBufStats = effectiveSnapshot?.sndBufStats ?: sndBufStats
            val effWriteTimeStats = effectiveSnapshot?.writeTimeStats ?: writeTimeStats
            val effSndBufLimitedStats = effectiveSnapshot?.sndBufLimitedStats ?: sndBufLimitedStats
            val effRwndLimitedStats = effectiveSnapshot?.rwndLimitedStats ?: rwndLimitedStats
            val effBusyTimeStats = effectiveSnapshot?.busyTimeStats ?: busyTimeStats
            val effFlowingStats = effectiveSnapshot?.flowingStats ?: flowingStats
            val effCeMarksStats = effectiveSnapshot?.ceMarksStats ?: ceMarksStats
            val effCeMarksWhenMarkingStats = effectiveSnapshot?.ceMarksWhenMarkingStats ?: ceMarksWhenMarkingStats
            val effQueueDelayStats = effectiveSnapshot?.queueDelayStats ?: queueDelayStats
            val effQueueBytesStats = effectiveSnapshot?.queueBytesStats ?: queueBytesStats
            val effQueuePacketsStats = effectiveSnapshot?.queuePacketsStats ?: queuePacketsStats
            val effL4sRttStats = effectiveSnapshot?.l4sRttStats ?: l4sRttStats
            val effL4sPacketWindowStats = effectiveSnapshot?.l4sPacketWindowStats ?: l4sPacketWindowStats
            val effL4sInflightStats = effectiveSnapshot?.l4sInflightStats ?: l4sInflightStats
            val effL4sMarkingProbStats = effectiveSnapshot?.l4sMarkingProbStats ?: l4sMarkingProbStats
            val effErrPercentStats = effectiveSnapshot?.errPercentStats ?: errPercentStats
            val effBbRequestsStats = effectiveSnapshot?.bbRequestsStats ?: bbRequestsStats
            val effBbHistogram = effectiveSnapshot?.bbHistogram ?: bbHistogram
            val effBbRttMinUs = effectiveSnapshot?.bbRttMinUs ?: bbRttMinUs
            val effWorkingLoadUpStats = effectiveSnapshot?.workingLoadUpStats ?: workingLoadUpStats
            val effWorkingLoadDownStats = effectiveSnapshot?.workingLoadDownStats ?: workingLoadDownStats
            val effWorkingLoadUpHistory = effectiveSnapshot?.workingLoadUpHistory ?: workingLoadUpHistory
            val effWorkingLoadDownHistory = effectiveSnapshot?.workingLoadDownHistory ?: workingLoadDownHistory
            val effSparklineHistory = effectiveSnapshot?.sparklineHistory ?: sparklineHistory
            val effBbRequestsHistory = effectiveSnapshot?.bbRequestsHistory ?: bbRequestsHistory
            val effRttHistory = effectiveSnapshot?.rttHistory ?: rttHistory
            val effThroughputHistory = effectiveSnapshot?.throughputHistory ?: throughputHistory
            val effCeDurationHistory = effectiveSnapshot?.ceDurationHistory ?: ceDurationHistory
            val effWriteTimeHistory = effectiveSnapshot?.writeTimeHistory ?: writeTimeHistory
            val effRetryHistory = effectiveSnapshot?.retryHistory ?: retryHistory
            val effCwndInflightHistory = effectiveSnapshot?.cwndInflightHistory ?: cwndInflightHistory
            val effWindowInflightHistory = effectiveSnapshot?.windowInflightHistory ?: windowInflightHistory
            val effPpsHistory = effectiveSnapshot?.ppsHistory ?: ppsHistory
            val effCeMarksPerSecHistory = effectiveSnapshot?.ceMarksPerSecHistory ?: ceMarksPerSecHistory
            val effMarkProbHistory = effectiveSnapshot?.markProbHistory ?: markProbHistory
            val effLossPercentHistory = effectiveSnapshot?.lossPercentHistory ?: lossPercentHistory

            // BounceBackHistogramChart's own golden-overlay toggles - hoisted
            // here (shared by MetersAndResultsSection's chart and
            // FooterSection's "Overlay CDF"/"Overlay PDF" buttons below,
            // which now live next to RunCompareTabs) rather than local state
            // inside the chart composable itself.
            var showGoldenCdf by remember { mutableStateOf(false) }
            var showGoldenPdf by remember { mutableStateOf(false) }
            var showEmd by remember { mutableStateOf(false) }
            var zoomTail by remember { mutableStateOf(false) }
            // Golden's own working-load state, for BounceBackHistogramChart's
            // "wl=<this run>/<golden>" comparison tag - derived from
            // whichever slot goldenSlot points to (see IperfViewModel.
            // goldenSlot's own doc comment), not goldenHistogram itself
            // (a parsed BounceBackHistogram carries no config). Live's own
            // config can never be goldenSlot (see promoteSlotToGolden's own
            // doc comment - only A/B/C/D can be promoted), so this is
            // always a savedRuns lookup, never the live config.
            val goldenWorkingLoadTag = goldenSlot?.let { savedRuns[it]?.config }?.let { workingLoadTag(it) } ?: "off"
            // Same idea as goldenWorkingLoadTag above, for CCA - see
            // ccaTag's own doc comment for why "default" rather than
            // omitting it.
            val goldenCcaTag = goldenSlot?.let { savedRuns[it]?.config }?.let { ccaTag(it) } ?: "default"

            MetersAndResultsSection(
                effConfig = effConfig,
                effSample = effSample,
                effIsRunning = effIsRunning,
                effectiveViewingSaved = effectiveViewingSaved,
                effThroughputStats = effThroughputStats,
                effRttStats = effRttStats,
                effInFlightStats = effInFlightStats,
                effPacketsInFlightStats = effPacketsInFlightStats,
                effCwndStats = effCwndStats,
                effRetryStats = effRetryStats,
                effNotSentStats = effNotSentStats,
                effTcpExcessRttStats = effTcpExcessRttStats,
                effSndBufStats = effSndBufStats,
                effWriteTimeStats = effWriteTimeStats,
                effSndBufLimitedStats = effSndBufLimitedStats,
                effRwndLimitedStats = effRwndLimitedStats,
                effBusyTimeStats = effBusyTimeStats,
                effFlowingStats = effFlowingStats,
                effCeMarksStats = effCeMarksStats,
                effCeMarksWhenMarkingStats = effCeMarksWhenMarkingStats,
                effQueueDelayStats = effQueueDelayStats,
                effQueueBytesStats = effQueueBytesStats,
                effQueuePacketsStats = effQueuePacketsStats,
                effL4sRttStats = effL4sRttStats,
                effL4sPacketWindowStats = effL4sPacketWindowStats,
                effL4sInflightStats = effL4sInflightStats,
                effL4sMarkingProbStats = effL4sMarkingProbStats,
                effErrPercentStats = effErrPercentStats,
                effBbRequestsStats = effBbRequestsStats,
                effBbHistogram = effBbHistogram,
                showGoldenCdf = showGoldenCdf,
                showGoldenPdf = showGoldenPdf,
                showEmd = showEmd,
                zoomTail = zoomTail,
                goldenHistogram = goldenHistogram,
                effWorkingLoadUpStats = effWorkingLoadUpStats,
                effWorkingLoadDownStats = effWorkingLoadDownStats,
                effWorkingLoadUpHistory = effWorkingLoadUpHistory,
                effWorkingLoadDownHistory = effWorkingLoadDownHistory,
                effSparklineHistory = effSparklineHistory,
                effBbRequestsHistory = effBbRequestsHistory,
                effRttHistory = effRttHistory,
                effThroughputHistory = effThroughputHistory,
                effCeDurationHistory = effCeDurationHistory,
                effWriteTimeHistory = effWriteTimeHistory,
                effRetryHistory = effRetryHistory,
                effCwndInflightHistory = effCwndInflightHistory,
                effWindowInflightHistory = effWindowInflightHistory,
                effPpsHistory = effPpsHistory,
                effCeMarksPerSecHistory = effCeMarksPerSecHistory,
                effMarkProbHistory = effMarkProbHistory,
                effLossPercentHistory = effLossPercentHistory,
                queueUnitsPackets = queueUnitsPackets,
                effBbRttMinUs = effBbRttMinUs,
                workingLoadUpMbps = workingLoadUpMbps,
                workingLoadDownMbps = workingLoadDownMbps,
                goldenWorkingLoadTag = goldenWorkingLoadTag,
                goldenCcaTag = goldenCcaTag,
                viewModel = viewModel,
            )

            FooterSection(
                statusMessage = statusMessage,
                viewingSlot = viewingSlot,
                savedRuns = savedRuns,
                canSaveRun = canSaveRun,
                isRunning = isRunning,
                config = config,
                versionInfo = versionInfo,
                versionParts = versionParts,
                scrollState = scrollState,
                viewModel = viewModel,
                goldenSlot = goldenSlot,
                showGoldenCdf = showGoldenCdf,
                onToggleGoldenCdf = { showGoldenCdf = !showGoldenCdf },
                showGoldenPdf = showGoldenPdf,
                onToggleGoldenPdf = { showGoldenPdf = !showGoldenPdf },
                showEmd = showEmd,
                onToggleEmd = { showEmd = !showEmd },
                zoomTail = zoomTail,
                onToggleZoomTail = { zoomTail = !zoomTail },
                histogramAvailable = effBbHistogram != null,
            )
        }
    }
}

/**
 * Host/Port row, Duration/Interval row, and the always-visible test-type
 * selector - extracted verbatim out of IperfScreen (see that composable's
 * own doc comment on why it was split up) purely to keep IperfScreen's own
 * compiled lambda well under ART's JIT instruction-count limit. Every local
 * text-field state here (portText/durationText/intervalText) is fully
 * self-contained to this block - never read or written anywhere else in
 * IperfScreen - so this extraction needed nothing threaded through beyond
 * config/isRunning/viewModel themselves.
 */
@Composable
private fun ConfigTopFields(
    config: TestConfig,
    isRunning: Boolean,
    recentHosts: List<String>,
    recentPorts: List<Int>,
    viewModel: IperfViewModel,
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        EditableDropdownField(
            value = config.host,
            onValueChange = { newHost ->
                val server = PUBLIC_SERVERS.firstOrNull { it.host == newHost }
                // NOT config.mode == TestMode.UDP_L4S - config.mode is
                // TestMode.BOUNCEBACK for every BOUNCEBACK transport (TCP,
                // UDP_L4S, and plain UDP alike; see TestConfig.mode's own
                // doc comment), so that check was only ever true for
                // CAPACITY-over-UDP_L4S. Picking a preset host while in
                // BOUNCEBACK mode with UDP_L4S or UDP selected always fell
                // through to server.tcpPort, silently pointing UDP traffic
                // at the TCP-only port. usesL4SPort() (below, shared with
                // the transport-switch handlers) already gets this right
                // for both TestKinds.
                val port = if (server != null) {
                    if (config.usesL4SPort()) server.udpL4sPort else server.tcpPort
                } else {
                    config.port
                }
                viewModel.updateConfig(config.copy(host = newHost, port = port))
            },
            label = "Host",
            recentValues = (DEFAULT_HOSTS + recentHosts).distinct(),
            enabled = !isRunning,
            modifier = Modifier.weight(2f),
        )
        // Local raw text, same reasoning as durationText/intervalText
        // below: binding straight to config.port.toString() means
        // clearing the field to retype it produces "" - which fails
        // toIntOrNull(), so updateConfig() never fires and the field
        // snaps back to the old digits instead of letting the user
        // finish typing a new one.
        var portText by remember(config.port) { mutableStateOf(config.port.toString()) }
        EditableDropdownField(
            value = portText,
            onValueChange = { text ->
                // No hostname-style lookups for a port - it's just a
                // 1-65535 number, so non-digit characters are
                // dropped outright rather than merely failing to
                // parse (which would still leave garbage visible in
                // the field, only silently not reach config).
                val digitsOnly = text.filter { it.isDigit() }
                portText = digitsOnly
                digitsOnly.toIntOrNull()?.let { p -> viewModel.updateConfig(config.copy(port = p)) }
            },
            label = "Port",
            recentValues = recentPorts.map { it.toString() },
            // Grayed out (not just re-populated) for the fixed
            // public servers - see PublicServers.kt's own doc
            // comment for why letting the user type a different
            // port for one of these hosts isn't a real choice.
            enabled = !isRunning && config.host !in DEFAULT_HOSTS,
            keyboardType = KeyboardType.Number,
            modifier = Modifier.weight(1f),
        )
    }
    // Collapsed by default (most users never need this) - keyed on
    // config.host so switching hosts re-derives the starting state: expanded
    // if that host already has a saved key (so a silently-applied override
    // is never invisible), collapsed otherwise. remember(config.host) means
    // a manual toggle mid-session still sticks across unrelated recompositions,
    // it only resets when the host itself actually changes.
    var permitKeyExpanded by remember(config.host) { mutableStateOf(config.manualPermitKey.isNotBlank()) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isRunning) { permitKeyExpanded = !permitKeyExpanded },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "Advanced",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Icon(
            imageVector = Icons.Filled.ArrowDropDown,
            contentDescription = if (permitKeyExpanded) "Collapse advanced options" else "Expand advanced options",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    if (permitKeyExpanded) {
        OutlinedTextField(
            value = config.manualPermitKey,
            onValueChange = { viewModel.updateConfig(config.copy(manualPermitKey = it)) },
            label = { Text("Permit key") },
            // Not a password field - the value is a non-secret hex digest
            // (SHA-256 of version+salt+host, same shape PermitKeyProvider
            // auto-computes - see TestConfig.manualPermitKey), and hiding it
            // would make typos harder to catch, not more secure.
            singleLine = true,
            enabled = !isRunning,
            // Backspacing through a full hex digest one character at a time
            // is tedious - a one-tap clear also removes the saved host->key
            // mapping (updateConfig treats a blank value the same as any
            // other edit, see TestConfigStore.savePermitKeyForHost), so this
            // doubles as "forget this host's key", not just "empty the box".
            trailingIcon = if (config.manualPermitKey.isNotEmpty() && !isRunning) {
                {
                    IconButton(onClick = { viewModel.updateConfig(config.copy(manualPermitKey = "")) }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear permit key")
                    }
                }
            } else null,
            modifier = Modifier.fillMaxWidth(),
        )
    }
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        // Local raw text, not derived straight from config.durationSecs:
        // -1 ("run until Stop is pressed" - iperf2's own "infinitetime"
        // mode, see -t handling in src/Settings.cpp) means this field
        // must accept a leading "-" while the user is still typing it,
        // which toIntOrNull() can't parse yet; deriving the displayed
        // value directly from config would snap back to the last valid
        // number on every keystroke of "-1" before the "1" lands.
        // (-1 = run until Stop is still supported, just not spelled
        // out in the label anymore - see the field comment above.)
        var durationText by remember(config.durationSecs) { mutableStateOf(config.durationSecs.toString()) }
        OutlinedTextField(
            value = durationText,
            onValueChange = { text ->
                durationText = text
                text.toIntOrNull()?.let { d -> viewModel.updateConfig(config.copy(durationSecs = d)) }
            },
            label = { Text("Duration (s)") },
            enabled = !isRunning,
            modifier = Modifier.weight(1f),
        )
        // Local raw text, same reasoning as durationText above: typing
        // "0.1" passes through invalid intermediate states ("0", "0.")
        // that toDoubleOrNull() can't parse yet, so the displayed value
        // can't be derived directly from config on every keystroke.
        var intervalText by remember(config.intervalSecs) { mutableStateOf(config.intervalSecs.toString()) }
        OutlinedTextField(
            value = intervalText,
            onValueChange = { text ->
                intervalText = text
                text.toDoubleOrNull()?.let { i -> viewModel.updateConfig(config.copy(intervalSecs = i)) }
            },
            label = { Text("Interval (s)") },
            enabled = !isRunning,
            modifier = Modifier.weight(1f),
        )
        // Parallel streams (-P) removed from the UI for now - RTT
        // and bytes-in-flight don't work correctly with more than
        // one stream (only one stream's TCP_INFO ends up reflected
        // in the meters). config.parallelStreams/IperfCommandBuilder
        // still exist but are pinned to 1 until this is fixed.
    }

    // Test type - a separate, always-visible selector (not baked into
    // Start) so the TCP-only options below (write-prefetch, tcp-cca)
    // can be seen and configured before ever tapping Start. Only two
    // top-level kinds (TestKind) - Capacity and Bounceback - each with
    // its own independent Transport chip row further down (Capacity's
    // own row is right below this selector; Bounceback's is under its
    // own section) rather than a single flat three-way TCP/UDP L4S/
    // Bounceback selector, which read as duplicated/conflicting choices
    // (the old selector's own TCP/UDP L4S options and Bounceback's
    // separate Transport row reused the exact same labels for two
    // different settings).
    TestKindSelector(
        kind = config.testKind,
        enabled = !isRunning,
        onKindChange = { newKind ->
            // Same port-shift reasoning as the Capacity/Bounceback
            // Transport rows below - see usesL4SPort's own doc comment.
            // Switching *kind* alone can also cross the L4S-port
            // boundary, e.g. leaving a Capacity-over-UDP-L4S selection
            // for Bounceback-over-TCP (bouncebackTransport's own prior
            // value, independent of capacityTransport).
            val wasL4SPort = config.usesL4SPort()
            val newConfig = config.copy(testKind = newKind)
            viewModel.updateConfig(newConfig.copy(port = config.port + portDelta(wasL4SPort, newConfig.usesL4SPort())))
        },
        modifier = Modifier.padding(vertical = 4.dp),
    )

    // Capacity's own probe transport row moved to IperfScreen's own body,
    // directly under the Start button - see that call site's own comment
    // for why (consistency with Bounceback's own Transport row, which
    // lives there too).
}

// Material3's default FilterChip border disappears once selected (relies
// on the filled background alone to show selection) - every FilterChip row
// on this screen (CCA, Bounceback transport, WorkingLoad transport/
// direction) wants the outline to stay visible even selected, so a
// selected chip still reads as a bordered toggle rather than turning into
// a plain filled pill.
@Composable
private fun chipBorder(enabled: Boolean, selected: Boolean): BorderStroke =
    FilterChipDefaults.filterChipBorder(
        enabled = enabled,
        selected = selected,
        selectedBorderColor = Color.Black,
        selectedBorderWidth = 1.dp,
    )

// Small "i" icon, placed between the row's own label and its transport
// chips (left of both, not right-aligned past them - a prior placement
// after the chips read as "belongs to the row generally" rather than
// clearly tied to either option) - direct feedback was that "UDP L4S"
// alone reads as opaque jargon to people who don't already know the term.
// Explains every option shown rather than just UDP L4S, since the real
// distinction for TCP vs UDP L4S isn't "which one has congestion control"
// (both do, each with a choice of algorithms) but where it's implemented -
// TCP's is kernel-level, UDP L4S's is this app's own userspace
// implementation (necessary since UDP itself has none at the kernel level
// to build on).
//
// includesPlainUdp: only Bounceback's own Transport row (IperfScreen) has
// a third, plain-UDP chip - Capacity's Transport row and Working Load's
// own WL transport row are both still TCP/UDP L4S only (see
// BouncebackTransport's own doc comment for why plain UDP only makes
// sense for Bounceback's discrete stop-and-wait round trip, not a
// continuous stream with a congestion-control loop to run). Rather than
// two near-duplicate composables, one flag picks between two tooltip
// bodies - the shorter one (false) deliberately still doesn't say "plain
// UDP" as if it were a real alternative where it isn't actually offered.
//
// isPersistent (stays open until tapped elsewhere/again, no auto-timeout)
// rather than a stock hover-style tooltip, since the point is to actually
// read a short explanation, not catch a vanishing hint.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UdpL4sInfoIcon(includesPlainUdp: Boolean = false) {
    val tooltipState = rememberTooltipState(isPersistent = true)
    val scope = rememberCoroutineScope()
    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = {
            PlainTooltip {
                Text(
                    if (includesPlainUdp) {
                        "TCP's congestion control runs in the kernel; UDP L4S implements its own at " +
                            "the app layer instead (Prague/Reno). Plain UDP sends the same discrete " +
                            "request/reply unmarked and with no congestion control at all - useful for " +
                            "comparing ECT(1) marking against the same path with it on vs. off. Marking " +
                            "only happens under real congestion, so it may not show up either way."
                    } else {
                        "TCP's congestion control runs in the kernel; UDP L4S implements its own at " +
                            "the app layer instead (Prague/Reno), since UDP itself has no built-in " +
                            "congestion control at the kernel level."
                    },
                    fontStyle = FontStyle.Italic,
                )
            }
        },
        state = tooltipState,
    ) {
        // A styled "i" character rather than Icons.Filled.Info - a vector
        // icon has no font-style property to italicize, and matching the
        // tooltip text's own italic (see above) was the point. Circled
        // (border, not filled - matches this row's own outlined chips
        // rather than looking like a third, separate button style) so it
        // reads as a self-contained info badge instead of a stray letter
        // floating next to the chips.
        IconButton(onClick = { scope.launch { tooltipState.show() } }, modifier = Modifier.size(24.dp)) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "i",
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.semantics { contentDescription = "About UDP L4S" },
                )
            }
        }
    }
}

// One row of ConnectionBadgeInfoIcon's own legend popup - the actual icon
// (rendered exactly as it appears in the real row, same size/tint) next
// to a short label, rather than describing its shape in prose. [icon] is
// a slot rather than a fixed Icon(...) call since entries need different
// content: a real Icon, a lettered circle Box, or (for the bleach/
// confirmed pair) two glyphs sharing one row.
@Composable
private fun BadgeLegendRow(icon: @Composable () -> Unit, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(modifier = Modifier.size(20.dp), contentAlignment = Alignment.Center) { icon() }
        Text(label, fontStyle = FontStyle.Italic, style = MaterialTheme.typography.bodySmall)
    }
}

// Same TooltipBox/persistent-"i" pattern as UdpL4sInfoIcon above (see that
// composable's own doc comment for why isPersistent and a styled "i"
// character rather than Icons.Filled.Info), one level down: this explains
// every symbol that can appear in this row - the transport icon
// (ConnectionStatusIndicator's own [transport]/[mismatch] params) as well
// as the UDP L4S bleach/confirmed/CE/stale-reply badges after it, since
// the "i" sits between the connection text and all of them. A legend
// (real icon next to a short label, one row each), not a prose paragraph
// - a symbol's shape is what a reader is trying to match against what
// they're actually seeing, and describing a shape in words forces a
// second translation step prose doesn't need. Placed once per row rather
// than one tooltip per badge - same reasoning as UdpL4sInfoIcon covering
// every transport chip in one go - since a user seeing an unfamiliar
// symbol for the first time doesn't yet know which one to tap, and the
// full set is short enough to read as one block. Prompted directly by a
// tester (Sebastian) asking what a new badge meant rather than guessing
// from the icon alone.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConnectionBadgeInfoIcon() {
    val tooltipState = rememberTooltipState(isPersistent = true)
    val scope = rememberCoroutineScope()
    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = {
            PlainTooltip {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BadgeLegendRow(
                        icon = {
                            Icon(
                                WifiIcon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFFFFA000),
                            )
                        },
                        label = "Active network transport - amber means it didn't match your selection",
                    )
                    BadgeLegendRow(
                        icon = {
                            Icon(
                                BottleIcon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFFE64A19),
                            )
                        },
                        label = "ECT(1) mark bleached (stripped) - upright = request, flipped = reply",
                    )
                    BadgeLegendRow(
                        icon = {
                            Box(
                                modifier = Modifier.size(16.dp).clip(CircleShape).background(Color(0xFF2E7D32)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("↑1", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        label = "ECT(1) mark confirmed intact - arrow shows direction, \"1\" for Capacity's single stream",
                    )
                    BadgeLegendRow(
                        icon = {
                            Box(
                                modifier = Modifier.size(16.dp).clip(CircleShape).background(Color(0xFF2E7D32)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("CE", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        label = "Path applied at least one congestion-experienced mark this run",
                    )
                    BadgeLegendRow(
                        icon = {
                            Icon(
                                Icons.Filled.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFFFFA000),
                            )
                        },
                        label = "Bounceback discarded a stale, out-of-order reply - routine under real load",
                    )
                }
            }
        },
        state = tooltipState,
    ) {
        IconButton(onClick = { scope.launch { tooltipState.show() } }, modifier = Modifier.size(24.dp)) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "i",
                    fontStyle = FontStyle.Italic,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.semantics { contentDescription = "About the connection status badges" },
                )
            }
        }
    }
}

// Does the currently-active test (mode, and for BOUNCEBACK its own
// bouncebackTransport) connect to the UDP L4S port or the TCP one - see
// portDelta's own doc comment for why this matters. Bounceback shares this
// concept with the top-level mode selector (not a TCP-only concern) since
// -u --bounceback (BouncebackTransport.UDP_L4S) connects to the same
// UDP L4S-deployed port a plain --udp-l4s Capacity test does.
private fun TestConfig.usesL4SPort(): Boolean = when (mode) {
    TestMode.UDP_L4S -> true
    // Both UDP bounceback variants (marked or not) are deployed on the
    // same server port - there's no separate "plain UDP" port, the server
    // decides marked-vs-not per-request from the wire (HEADER_BBL4S), not
    // from which port it's listening on. Name predates the plain-UDP
    // option existing; kept as-is (the concept was always "the
    // UDP-deployed port, not the TCP one") rather than renaming and
    // rippling through every call site below.
    TestMode.BOUNCEBACK -> bouncebackTransport != BouncebackTransport.TCP
    TestMode.TCP -> false
}

// Shared by both the TestMode selector and the Bounceback transport row -
// either one can flip whether the config as a whole usesL4SPort(), and
// either way the port should shift by exactly +1/-1 (never more, since
// it's a boolean state) so it stays correct without the user manually
// editing it.
private fun portDelta(wasL4SPort: Boolean, willBeL4SPort: Boolean): Int = when {
    !wasL4SPort && willBeL4SPort -> 1
    wasL4SPort && !willBeL4SPort -> -1
    else -> 0
}

/**
 * Run-progress bar (elapsed/duration) plus the LED-style connection status
 * row - extracted out of IperfScreen (see that composable's own doc
 * comment) as a small, purely-read-only chunk: nothing here writes any
 * state that another section needs to read.
 */
@Composable
private fun RunProgressAndConnectionStatus(
    isRunning: Boolean,
    elapsedSecs: Int,
    config: TestConfig,
    testProgress: Float,
    runStartedAtMillis: Long?,
    connectFailed: Boolean,
    everConnected: Boolean,
    hadConnectRetry: Boolean,
    latestSample: IntervalSample?,
    activeTransport: NetworkTransport?,
    transportMismatch: Boolean,
    l4sCeConfirmed: Boolean,
    l4sReplyBleachDetected: Boolean,
    l4sReqBleachDetected: Boolean,
    l4sReplyConfirmed: Boolean,
    l4sReqConfirmed: Boolean,
    capacityL4sConfirmed: Boolean,
    capacityL4sBleachDetected: Boolean,
    bbStaleReplyDetected: Boolean,
) {
    // How much longer until this run completes - common to all three
    // modes since they all share the same Duration field (see
    // IperfViewModel.elapsedSecs/testProgress doc comment). Shown
    // from Start through the end of the run and left in place after
    // stop/completion, same persistence convention as the meters
    // below. config.durationSecs == -1 is the "run until Stop"
    // sentinel (see isConfigValid above) - there's no total to show
    // progress against, so just the elapsed-seconds count, with an
    // indeterminate bar while running instead of a determinate one
    // that can never reach its end.
    if (isRunning || elapsedSecs > 0) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            if (config.durationSecs > 0) {
                LinearProgressIndicator(
                    progress = { testProgress },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        runStartedAtMillis?.let { "started ${formatSavedAt(it)}" } ?: "",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text(
                        "${elapsedSecs}s / ${config.durationSecs}s",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            } else {
                if (isRunning) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        runStartedAtMillis?.let { "started ${formatSavedAt(it)}" } ?: "",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text("${elapsedSecs}s elapsed", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    // Three-state LED-style connection indicator - red/yellow/green, not
    // just red/green: a lone retried connect() or a mid-test drop is a
    // meaningfully different outcome from either a clean connection or one
    // that never worked at all, and collapsing all three into "red unless
    // currently flowing" hid that distinction. Nothing shown while idle or
    // still connecting, since the button text already covers that phase.
    // Deliberately not gated on isRunning - once a real sample has arrived
    // this run, the row (and its L4S badges) stays up after Stop/completion
    // too, same persistence convention as the meters below; clearRunResults
    // resets latestSample to null on the next Start, so it still disappears
    // cleanly at the start of a fresh run.
    //
    // - Red: connectFailed but everConnected is still false - this run has
    //   never once reached a real sample (see IperfViewModel.connectFailed/
    //   everConnected's own doc comments).
    // - Yellow: connectFailed is true again *after* everConnected already
    //   latched - a connection that was genuinely up and then dropped
    //   mid-test (checked first, since connectFailed can be true again at
    //   this point even though the run once succeeded). Also yellow if
    //   hadConnectRetry latched before that first sample arrived - the
    //   connection needed more than one attempt, even though it's since
    //   recovered cleanly.
    // - Green: connected (or was, this run), no retry was ever needed to
    //   get there.
    //
    // Direction is always from this device's own point of view:
    // --reverse means the server is the writer, so this device is
    // downloading; the default (no --reverse) has this device writing,
    // i.e. uploading. Bounceback has no direction (see
    // IperfCommandBuilder), so it shows the actual request/reply payload
    // sizes instead - the one config choice that materially changes what's
    // being measured, and otherwise isn't visible anywhere once the config
    // fields collapse for the run.
    when {
        connectFailed && everConnected -> ConnectionStatusIndicator(color = Color(0xFFFFD600), text = "Connection dropped")
        connectFailed -> ConnectionStatusIndicator(color = Color(0xFFE53935), text = "Connect failed")
        latestSample != null -> ConnectionStatusIndicator(
            color = if (hadConnectRetry) Color(0xFFFFD600) else Color(0xFF2E7D32),
            text = if (config.mode == TestMode.BOUNCEBACK) {
                val req = if (config.bouncebackSizeEnabled) config.bouncebackRequestBytes else "100"
                val reply = if (config.bouncebackSizeEnabled) config.bouncebackReplyBytes else "100"
                "Connected (req/reply ${formatByteSize(req)}/${formatByteSize(reply)})"
            } else {
                "Connected (${if (config.reverseEnabled) "download" else "upload"})"
            },
            transport = activeTransport,
            mismatch = transportMismatch,
            l4sCeConfirmed = l4sCeConfirmed,
            l4sReplyBleachDetected = l4sReplyBleachDetected,
            l4sReqBleachDetected = l4sReqBleachDetected,
            l4sReplyConfirmed = l4sReplyConfirmed,
            l4sReqConfirmed = l4sReqConfirmed,
            capacityL4sConfirmed = capacityL4sConfirmed,
            capacityL4sBleachDetected = capacityL4sBleachDetected,
            bbStaleReplyDetected = bbStaleReplyDetected,
        )
    }
}

/**
 * Every config row that's collapsed entirely while a test is running
 * (Force IPv6, Reverse, congestion control, Bounceback working load and
 * request/reply size, tcp_notsent_lowat) - extracted out of IperfScreen
 * (see that composable's own doc comment). Ends with the zero-height
 * meters-position marker Box, whose onGloballyPositioned write needs to
 * reach the metersTopInRoot state hoisted in IperfScreen's own auto-scroll
 * effect - threaded through as a plain callback (onMetersPositioned)
 * rather than trying to split that single piece of mutable state across
 * two remember blocks in two different functions.
 */
@Composable
private fun CollapsedConfigRows(
    config: TestConfig,
    isRunning: Boolean,
    ccaOptions: List<String>,
    viewModel: IperfViewModel,
    onMetersPositioned: (Float) -> Unit,
) {
    // -V: forces IPv6 resolution/connection (see TestConfig.
    // forceIpv6's own doc comment). Mode-independent - shown above
    // the mode-specific rows below, same reasoning as Reverse
    // leading TCP's own ordering: address family is the thing most
    // likely to change whether the connection succeeds at all,
    // before any of the other settings even get a chance to matter.
    if (!isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Force IPv6 (-V)", modifier = Modifier.weight(1f))
            Switch(
                checked = config.forceIpv6,
                onCheckedChange = { viewModel.updateConfig(config.copy(forceIpv6 = it)) },
                enabled = !isRunning,
            )
        }
    }

    // -R: server becomes the writer, this device just receives -
    // supported for both TCP and UDP L4S (IperfCommandBuilder adds
    // -R outside the mode switch). For TCP, RTT/bytes-in-flight then
    // come from the server's own gettcpinfo() sample, relayed over
    // the wire (this device can never observe sender-side-only
    // TCP_INFO stats locally for a connection it's only receiving
    // on). For UDP L4S, CE stats instead come from this device
    // observing marks directly on packets it receives - see
    // reporter_handle_packet_server_udp, src/Reporter.c. Bounceback
    // is its own round-trip protocol, not a direction, so this
    // toggle doesn't apply there.
    if (!isRunning && config.mode != TestMode.BOUNCEBACK) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Reverse (-R, server sends)", modifier = Modifier.weight(1f))
            Switch(
                checked = config.reverseEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(reverseEnabled = it)) },
                enabled = !isRunning,
            )
        }
    }

    // --cca: sets the congestion control algorithm by name (see
    // TestConfig). REQUIRED_CCA_ALGORITHMS is always shown, in a fixed
    // order, so the row's shape doesn't change per device - CcaProbe
    // (actually probed against this device's kernel at startup, since
    // availability is kernel-specific, e.g. "prague" needs a patched
    // kernel most stock devices don't have) only decides which chips are
    // selectable, greying out the rest.
    if (config.mode == TestMode.TCP && !isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Congestion control (--cca)", modifier = Modifier.weight(1f))
            Switch(
                checked = config.tcpCcaEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(tcpCcaEnabled = it)) },
                enabled = !isRunning,
            )
        }
        if (config.tcpCcaEnabled) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                REQUIRED_CCA_ALGORITHMS.forEach { name ->
                    val available = name in ccaOptions
                    val selected = config.tcpCca == name
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.updateConfig(config.copy(tcpCca = name)) },
                        label = { Text(name) },
                        enabled = !isRunning && available,
                        border = chipBorder(enabled = !isRunning && available, selected = selected),
                    )
                }
            }
            if (ccaOptions.isEmpty()) {
                Text(
                    text = "Detecting available algorithms…",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }
        }
    }

    // UDP_L4S-only: --cca <prague|reno>, under --udp-l4s (see
    // L4SCongestionControl's own doc comment for why this doesn't extend
    // to Bounceback-over-UDP-L4S, which has no congestion-control loop to
    // switch). Same two-row "label row, then chip row" shape as the --cca
    // (TCP) block above - just without a Switch, since there's no "off"
    // here, only which of the two variants runs (Prague is the native
    // default, same as this app's own default).
    if (config.mode == TestMode.UDP_L4S && !isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Congestion control", modifier = Modifier.weight(1f))
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            listOf(L4SCongestionControl.PRAGUE to "Prague", L4SCongestionControl.RENO to "Reno").forEach { (cca, label) ->
                val selected = config.l4sCca == cca
                FilterChip(
                    selected = selected,
                    onClick = { viewModel.updateConfig(config.copy(l4sCca = cca)) },
                    label = { Text(label) },
                    enabled = !isRunning,
                    border = chipBorder(enabled = !isRunning, selected = selected),
                )
            }
        }
    }

    // Bounceback's own probe transport row moved to IperfScreen's own body,
    // directly under the Start button - see that call site's own comment.

    // Bounceback-over-TCP's own row for the same --cca/tcpCca field -
    // Switch-gated rather than a "default" chip: off (the default, and
    // after a Reset - see TestConfig.bouncebackCcaEnabled's own doc
    // comment) means "send no --cca flag", on shows the real-algorithm
    // chip row. The switch's own on/off is a dedicated field, independent
    // of tcpCca's value/default - toggling it doesn't touch tcpCca at all.
    // Only relevant while Bounceback's own transport above is still TCP -
    // neither UDP variant runs over a TCP socket, and neither has a
    // congestion-control loop to select in the first place (both are
    // discrete stop-and-wait, not a continuous PragueCC stream - see
    // BouncebackTransport's own doc comment), so this row is fully hidden
    // (not just disabled) for either one, not only UDP_L4S.
    if (config.mode == TestMode.BOUNCEBACK && config.bouncebackTransport == BouncebackTransport.TCP && !isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Congestion control", modifier = Modifier.weight(1f))
            Switch(
                checked = config.bouncebackCcaEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(bouncebackCcaEnabled = it)) },
                enabled = !isRunning,
            )
        }
        if (config.bouncebackCcaEnabled) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                REQUIRED_CCA_ALGORITHMS.forEach { name ->
                    val available = name in ccaOptions
                    val selected = config.tcpCca == name
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.updateConfig(config.copy(tcpCca = name)) },
                        label = { Text(name) },
                        enabled = !isRunning && available,
                        border = chipBorder(enabled = !isRunning && available, selected = selected),
                    )
                }
            }
            if (ccaOptions.isEmpty()) {
                Text(
                    text = "Detecting available algorithms…",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }
        }
    }

    // Bounceback-only: --working-load background traffic.
    if (config.mode == TestMode.BOUNCEBACK && !isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Working load", modifier = Modifier.weight(1f))
            Switch(
                checked = config.workingLoadEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(workingLoadEnabled = it)) },
                enabled = !isRunning,
            )
        }
        if (config.workingLoadEnabled) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                val directions = listOf(
                    WorkingLoadDirection.UP to "Upload",
                    WorkingLoadDirection.DOWN to "Download",
                    WorkingLoadDirection.BIDIR to "Both",
                )
                directions.forEach { (direction, label) ->
                    val selected = config.workingLoadDirection == direction
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.updateConfig(config.copy(workingLoadDirection = direction)) },
                        label = { Text(label) },
                        enabled = !isRunning,
                        border = chipBorder(enabled = !isRunning, selected = selected),
                    )
                }
            }
            // Stream-count control removed - pinned to 1 thread
            // (see IperfCommandBuilder's doc comment on why: >1
            // was found to fail almost immediately server-side).

            // Working load's own Transport - independent of the main
            // Bounceback flow's own transport above (see
            // TestConfig.workingLoadTransport's own doc comment) - e.g. a
            // TCP Bounceback probe can be background-loaded with a UDP L4S
            // stream or vice versa.
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                Text("WL transport", modifier = Modifier.weight(1f).align(Alignment.CenterVertically))
                UdpL4sInfoIcon()
                listOf(Transport.TCP to "TCP", Transport.UDP_L4S to "UDP L4S").forEach { (transport, label) ->
                    val selected = config.workingLoadTransport == transport
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.updateConfig(config.copy(workingLoadTransport = transport)) },
                        label = { Text(label) },
                        enabled = !isRunning,
                        border = chipBorder(enabled = !isRunning, selected = selected),
                    )
                }
            }
            // Working load's own congestion control - TCP algorithm name
            // when workingLoadTransport is TCP, or its own independent
            // Prague/Reno choice (workingLoadL4sCca) when UDP_L4S - not
            // tied to the main flow's own tcpCca/l4sCca (see TestConfig's
            // own doc comment for why they're kept independent).
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                Text("WL congestion control", modifier = Modifier.weight(1f))
            }
            if (config.workingLoadTransport == Transport.TCP) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    REQUIRED_CCA_ALGORITHMS.forEach { name ->
                        val available = name in ccaOptions
                        val selected = config.workingLoadCca == name
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.updateConfig(config.copy(workingLoadCca = name)) },
                            label = { Text(name) },
                            enabled = !isRunning && available,
                            border = chipBorder(enabled = !isRunning && available, selected = selected),
                        )
                    }
                }
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                ) {
                    listOf(L4SCongestionControl.PRAGUE to "prague", L4SCongestionControl.RENO to "reno").forEach { (cca, label) ->
                        val selected = config.workingLoadL4sCca == cca
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.updateConfig(config.copy(workingLoadL4sCca = cca)) },
                            label = { Text(label) },
                            enabled = !isRunning,
                            border = chipBorder(enabled = !isRunning, selected = selected),
                        )
                    }
                }
            }
        }

        // --bounceback-request/--bounceback-reply: payload size of
        // each bounce round trip (see TestConfig doc comment - both
        // default to iperf2's own 100-byte default if left off).
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("Custom request/reply size", modifier = Modifier.weight(1f))
            Switch(
                checked = config.bouncebackSizeEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(bouncebackSizeEnabled = it)) },
                enabled = !isRunning,
            )
        }
        if (config.bouncebackSizeEnabled) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            ) {
                OutlinedTextField(
                    value = config.bouncebackRequestBytes,
                    onValueChange = { viewModel.updateConfig(config.copy(bouncebackRequestBytes = it)) },
                    label = { Text("Request (bytes)") },
                    enabled = !isRunning,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = config.bouncebackReplyBytes,
                    onValueChange = { viewModel.updateConfig(config.copy(bouncebackReplyBytes = it)) },
                    label = { Text("Reply (bytes)") },
                    enabled = !isRunning,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }

    // --tcp-write-prefetch (TCP_NOTSENT_LOWAT): TCP-bulk-transfer
    // only (tunes how much unsent data queues before the app's
    // own writer blocks), on by default (see TestConfig) - not
    // meaningful for Bounceback's small round-trip messages, so
    // this one stays TCP-mode-only unlike --tcp-cca above. Last in
    // TCP's own row order - see this block's own comment further
    // up for why.
    if (config.mode == TestMode.TCP && !isRunning) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        ) {
            Text("tcp_notsent_lowat", modifier = Modifier.weight(1f))
            // Same row as the enable switch (not a separate row
            // below it) - narrow/single-line since it only ever
            // holds a short byte-size string ("128K" etc.), so it
            // fits comfortably alongside the switch instead of
            // claiming its own full-width row. Reuses
            // CompactDropdownField (same "type anything, or pick
            // a shortcut" pattern as Host/Port above, but sized to
            // match the Switch's own height - see that composable's
            // own doc comment for why EditableDropdownField/
            // OutlinedTextField couldn't do that) with a fixed
            // preset list rather than recent-use history - unlike
            // host/port there's no "recently used" concept worth
            // tracking here, just a handful of common sizes worth
            // one-tap access.
            if (config.writePrefetchEnabled) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
                    Text("Size", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(end = 4.dp))
                    CompactDropdownField(
                        value = config.writePrefetchBytes,
                        onValueChange = { viewModel.updateConfig(config.copy(writePrefetchBytes = it)) },
                        presets = WRITE_PREFETCH_SIZE_PRESETS,
                        enabled = !isRunning,
                        modifier = Modifier.width(110.dp),
                    )
                }
            }
            Switch(
                checked = config.writePrefetchEnabled,
                onCheckedChange = { viewModel.updateConfig(config.copy(writePrefetchEnabled = it)) },
                enabled = !isRunning,
            )
        }
    }

    // Zero-height marker for the auto-scroll effect above - see
    // metersTopInRoot's own doc comment.
    Box(modifier = Modifier.fillMaxWidth().onGloballyPositioned { onMetersPositioned(it.positionInRoot().y) })
}

/**
 * The big eff*-consuming meters/results region - four stacked dial+
 * sparkline rows (TCP/UDP-L4S only), BytesInFlightMeter, the Bounceback
 * LiveSparkline/histogram, and the working-load charts - extracted out of
 * IperfScreen (see that composable's own doc comment). Takes every eff*
 * value it reads as a parameter rather than recomputing
 * effectiveSnapshot?.xxx ?: xxx itself - that computation stays in
 * IperfScreen, right next to the collectAsState() reads it derives from.
 * The parameter list is long by nature of the data this region reads, not
 * by design choice.
 */
@Composable
private fun MetersAndResultsSection(
    effConfig: TestConfig,
    effSample: IntervalSample?,
    effIsRunning: Boolean,
    effectiveViewingSaved: Boolean,
    effThroughputStats: MeterStats?,
    effRttStats: MeterStats?,
    effInFlightStats: MeterStats?,
    effPacketsInFlightStats: MeterStats?,
    effCwndStats: MeterStats?,
    effRetryStats: MeterStats?,
    effNotSentStats: MeterStats?,
    effTcpExcessRttStats: MeterStats?,
    effSndBufStats: MeterStats?,
    effWriteTimeStats: MeterStats?,
    effSndBufLimitedStats: MeterStats?,
    effRwndLimitedStats: MeterStats?,
    effBusyTimeStats: MeterStats?,
    effFlowingStats: MeterStats?,
    effCeMarksStats: MeterStats?,
    effCeMarksWhenMarkingStats: MeterStats?,
    effQueueDelayStats: MeterStats?,
    effQueueBytesStats: MeterStats?,
    effQueuePacketsStats: MeterStats?,
    effL4sRttStats: MeterStats?,
    effL4sPacketWindowStats: MeterStats?,
    effL4sInflightStats: MeterStats?,
    effL4sMarkingProbStats: MeterStats?,
    effErrPercentStats: MeterStats?,
    effBbRequestsStats: MeterStats?,
    effBbHistogram: BounceBackHistogram?,
    // Overlay toggle state, hoisted up from BounceBackHistogramChart itself
    // (IperfScreen's own showGoldenCdf/showGoldenPdf) - the "Overlay CDF"/
    // "Overlay PDF" buttons that drive these now live next to RunCompareTabs
    // (see FooterSection), not down here next to the chart they affect, so
    // the state has to be shared across both rather than chart-local.
    showGoldenCdf: Boolean,
    showGoldenPdf: Boolean,
    showEmd: Boolean,
    zoomTail: Boolean,
    // Not an eff*-snapshot-derived value like effBbHistogram above - the
    // whole point of comparing A/B/C/D against golden (not just A against
    // B) is that every viewed slot compares against the *same*, currently-
    // saved golden reference, live or a preset alike. See
    // IperfViewModel.goldenHistogram's own doc comment.
    goldenHistogram: BounceBackHistogram?,
    effWorkingLoadUpStats: MeterStats?,
    effWorkingLoadDownStats: MeterStats?,
    effWorkingLoadUpHistory: List<TimeSeriesPoint>,
    effWorkingLoadDownHistory: List<TimeSeriesPoint>,
    effSparklineHistory: List<Timestamped<WindowedSnapshot>>,
    effBbRequestsHistory: List<TimeSeriesPoint>,
    effRttHistory: List<Timestamped<RttHistoryPoint>>,
    effThroughputHistory: List<TimeSeriesPoint>,
    effCeDurationHistory: List<TimeSeriesPoint>,
    effWriteTimeHistory: List<TimeSeriesPoint>,
    effRetryHistory: List<TimeSeriesPoint>,
    effCwndInflightHistory: List<Timestamped<CwndInflightPoint>>,
    effWindowInflightHistory: List<Timestamped<WindowInflightPoint>>,
    effPpsHistory: List<TimeSeriesPoint>,
    effCeMarksPerSecHistory: List<TimeSeriesPoint>,
    effMarkProbHistory: List<TimeSeriesPoint>,
    effLossPercentHistory: List<TimeSeriesPoint>,
    queueUnitsPackets: Boolean,
    effBbRttMinUs: Long?,
    workingLoadUpMbps: Double?,
    workingLoadDownMbps: Double?,
    // Golden's own "wl=on/off/bidir" tag (IperfScreen's own
    // goldenWorkingLoadTag) - threaded down here just to feed
    // BounceBackHistogramChart's own comparison line, see that
    // composable's own workingLoadTag/goldenWorkingLoadTag doc comment.
    goldenWorkingLoadTag: String,
    // Same idea, for CCA (IperfScreen's own goldenCcaTag) - see
    // BounceBackHistogramChart's own ccaTag/goldenCcaTag doc comment.
    goldenCcaTag: String,
    viewModel: IperfViewModel,
) {
    // Capacity-over-UDP_L4S with Reno only (see CeMarksPerSecMeter's own
    // pragueRequired doc comment for the full reasoning) - hoisted here,
    // above every row below that needs it, rather than recomputed
    // separately per row.
    val ceGreyedOut = effConfig.mode == TestMode.UDP_L4S && effConfig.l4sCca == L4SCongestionControl.RENO
    if (effConfig.mode != TestMode.BOUNCEBACK) {
        // Four stacked [small dial | MiniSparkline] rows, one per
        // metric, instead of the old two rows of two full-width
        // dials - people correlating measurements against each
        // other (e.g. "did that RTT spike happen at the same time
        // as a CE Duration spike?") need to see each metric's own
        // recent trend, not just its current reading. The dial
        // shrinks (SpeedometerGauge's compact=true) rather than
        // disappearing - it's still the fastest way to read
        // "what's the number right now," the sparkline beside it
        // answers "how did it get there." Same TCP/UDP-L4S A/B
        // parity as before: every mode gets the same four rows in
        // the same order, just fed from whichever data source
        // applies (see each row's own comment below).
        Row(modifier = Modifier.fillMaxWidth()) {
            ThroughputMeter(
                effSample,
                stats = effThroughputStats,
                isRunning = effIsRunning,
                compact = true,
                modifier = Modifier.weight(0.2f),
            )
            MiniSparkline(values = effThroughputHistory, color = Color(0xFF42A5F5), unit = " Mbps", durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
        }
        // RTT (smoothed) - TCP's own RttMeter for TCP, L4sRttMeter
        // (PragueCC::GetSmoothedRtt(), same "RTT"/"smoothed" label
        // and thresholds as TCP's dial) for UDP-L4S. Paired with
        // RttFloorChart, not a plain current-RTT MiniSparkline -
        // that would just be the current-RTT line RttFloorChart
        // already draws, alone instead of alongside its own floor
        // line, the same redundancy the old separate "Min RTT
        // (floor stability)" chart had against RttFloorChart's own
        // floor line (see that composable's own doc comment).
        Row(modifier = Modifier.fillMaxWidth()) {
            if (effConfig.mode == TestMode.UDP_L4S) {
                L4sRttMeter(effSample, stats = effL4sRttStats, isRunning = effIsRunning, compact = true, modifier = Modifier.weight(0.2f))
            } else {
                RttMeter(
                    effSample,
                    mode = effConfig.mode,
                    stats = effRttStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
            }
            RttFloorChart(history = effRttHistory, durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
        }
        // Load Delay (QueueDelayMeter, see that composable's own doc
        // comment) for *every* mode, not UDP-L4S-only - TCP already
        // computes the identical rtt - rtt_min number
        // (IperfViewModel.tcpExcessRttAcc). Its sparkline is
        // rttHistory's own currentRttMs - rttMinMs per point -
        // exactly the same formula this row's own loadDelayMs
        // below uses, just per-point instead of collapsed to the
        // latest sample, so no separate history buffer is needed
        // for this one.
        Row(modifier = Modifier.fillMaxWidth()) {
            val loadDelayMs = if (effConfig.mode == TestMode.UDP_L4S) {
                (effSample?.queueDelayUs ?: -1L).takeIf { it >= 0 }?.let { it / 1000.0 } ?: -1.0
            } else {
                val rtt = effSample?.rttMicros ?: -1L
                val rttMin = effSample?.rttMinMicros ?: -1L
                if (rtt >= 0 && rttMin >= 0) ((rtt - rttMin) / 1000.0).coerceAtLeast(0.0) else -1.0
            }
            val loadDelayStats = if (effConfig.mode == TestMode.UDP_L4S) effQueueDelayStats else effTcpExcessRttStats
            QueueDelayMeter(loadDelayMs, stats = loadDelayStats, isRunning = effIsRunning, compact = true, modifier = Modifier.weight(0.2f))
            MiniSparkline(
                values = effRttHistory.map { TimeSeriesPoint(it.value?.let { p -> p.currentRttMs - p.rttMinMs }, it.elapsedSecs) },
                color = Color(0xFFFFD600),
                unit = " ms",
                // The rtt_min this row's own plotted gap is derived
                // from isn't otherwise shown anywhere near this
                // chart - see MiniSparkline's own footnote doc
                // comment. Last *valid* reading, not necessarily
                // the chart's true latest interval - see
                // MiniSparkline's own lastValid doc comment.
                footnote = effRttHistory.lastOrNull { it.value != null }?.value?.let { "RTT min %.1f ms".format(it.rttMinMs) },
                durationSecs = effConfig.durationSecs,
                modifier = Modifier.weight(0.8f),
            )
        }
        // CE Duration is real (RttMeter itself in UDP-L4S mode) for
        // UDP-L4S with Prague; TCP, and Capacity-over-UDP_L4S with Reno
        // (ceGreyedOut, hoisted above - see CeMarksPerSecMeter's own
        // pragueRequired doc comment), show CeDurationPlaceholder instead
        // of omitting the slot - see that composable's own doc comment for
        // why a visible, always-N/A/grayed dial is more honest than a
        // blank spacer. No sparkline paired with the placeholder (there's
        // no real data to chart) - a same-width Spacer holds its place
        // instead, so the placeholder dial stays the same small size and
        // same left column as every other row's dial rather than
        // ballooning to fill the row on its own.
        Row(modifier = Modifier.fillMaxWidth()) {
            if (effConfig.mode == TestMode.UDP_L4S && !ceGreyedOut) {
                RttMeter(
                    effSample,
                    mode = effConfig.mode,
                    stats = effRttStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(values = effCeDurationHistory, color = Color(0xFFE53935), unit = " ms", durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
            } else {
                CeDurationPlaceholder(compact = true, modifier = Modifier.weight(0.2f))
                Spacer(modifier = Modifier.weight(0.8f))
            }
        }
        // Write Block Time and Retries, moved up here from
        // BytesInFlightMeter's own bar stack (see that composable's
        // own doc comment) into the same [dial | MiniSparkline]
        // treatment as every row above - TCP-only, no UDP-L4S/
        // BOUNCEBACK equivalent (unlike CE Duration above, which
        // keeps a same-size placeholder dial for A/B grid parity),
        // so these two rows simply don't render outside TCP mode
        // rather than reserving space with an empty placeholder.
        if (effConfig.mode == TestMode.TCP) {
            Row(modifier = Modifier.fillMaxWidth()) {
                WriteBlockTimeMeter(
                    effSample,
                    stats = effWriteTimeStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(values = effWriteTimeHistory, color = Color.White, unit = " ms", durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                RetriesMeter(
                    effSample,
                    stats = effRetryStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(values = effRetryHistory, color = Color.White, durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
            }
        }
        // Packets/sec, CE marks/sec, Marking Probability, and Loss
        // Probability, moved up here from BytesInFlightMeter's own
        // bar stack - same [dial | MiniSparkline] treatment as
        // TCP's Write Block Time/Retries above, and UDP-L4S-only
        // for the same "no TCP equivalent, don't reserve a
        // placeholder" reasoning those two used.
        if (effConfig.mode == TestMode.UDP_L4S) {
            Row(modifier = Modifier.fillMaxWidth()) {
                PacketsPerSecMeter(
                    effSample,
                    stats = effInFlightStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(values = effPpsHistory, color = Color(0xFF2E7D32), unit = " pps", durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                CeMarksPerSecMeter(
                    effSample,
                    stats = effCeMarksStats,
                    whenMarkingStats = effCeMarksWhenMarkingStats,
                    isRunning = effIsRunning,
                    compact = true,
                    pragueRequired = ceGreyedOut,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(
                    values = if (ceGreyedOut) emptyList() else effCeMarksPerSecHistory,
                    color = Color.White,
                    unit = "/s",
                    durationSecs = effConfig.durationSecs,
                    modifier = Modifier.weight(0.8f),
                )
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                MarkingProbabilityMeter(
                    effSample,
                    stats = effL4sMarkingProbStats,
                    isRunning = effIsRunning,
                    compact = true,
                    pragueRequired = ceGreyedOut,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(
                    values = if (ceGreyedOut) emptyList() else effMarkProbHistory,
                    color = Color.White,
                    unit = "%",
                    durationSecs = effConfig.durationSecs,
                    modifier = Modifier.weight(0.8f),
                )
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                LossProbabilityMeter(
                    effSample,
                    stats = effErrPercentStats,
                    isRunning = effIsRunning,
                    compact = true,
                    modifier = Modifier.weight(0.2f),
                )
                MiniSparkline(values = effLossPercentHistory, color = Color.White, unit = "%", durationSecs = effConfig.durationSecs, modifier = Modifier.weight(0.8f))
            }
        }
    }
    // Feeds LiveSparkline's own title suffix (see its rpsCcaLabel doc
    // comment) - BytesInFlightMeter's RPS bar used to show this too, but
    // dropped it once LiveSparkline's title already carried it, since a
    // technician looking at BOUNCEBACK meters always sees both together.
    // "L4S"/"UDP" rather than a CCA name when the probe transport is one
    // of the UDP variants - CCA doesn't apply there (see the
    // congestion-control row's own visibility gate), but the graph title
    // still wants a one-word tag identifying what's driving this run's
    // numbers, same as the CCA name does for TCP bounceback.
    val effRpsCcaLabel = when {
        effConfig.bouncebackTransport == BouncebackTransport.UDP_L4S -> "L4S"
        effConfig.bouncebackTransport == BouncebackTransport.UDP -> "UDP"
        !effConfig.bouncebackCcaEnabled -> null
        else -> effConfig.tcpCca
    }
    BytesInFlightMeter(
        effSample,
        mode = effConfig.mode,
        stats = effInFlightStats,
        packetsStats = effPacketsInFlightStats,
        cwndStats = effCwndStats,
        cwndInflightHistory = effCwndInflightHistory,
        notSentStats = effNotSentStats,
        sndBufStats = effSndBufStats,
        sndBufLimitedStats = effSndBufLimitedStats,
        rwndLimitedStats = effRwndLimitedStats,
        busyTimeStats = effBusyTimeStats,
        flowingStats = effFlowingStats,
        l4sPacketWindowStats = effL4sPacketWindowStats,
        l4sInflightStats = effL4sInflightStats,
        windowInflightHistory = effWindowInflightHistory,
        queueBytesStats = effQueueBytesStats,
        queuePacketsStats = effQueuePacketsStats,
        queueUnitsPackets = queueUnitsPackets,
        onToggleQueueUnits = { viewModel.setQueueUnitsPackets(!queueUnitsPackets) },
        bbRequestsStats = effBbRequestsStats,
        bbRttMinUs = effBbRttMinUs,
        isRunning = effIsRunning,
        durationSecs = effConfig.durationSecs,
    )
    // effSparklineHistory is effectiveSnapshot's own frozen list
    // when viewing a saved preset (RunSnapshot.sparklineHistory), same eff*
    // pattern as every other meter above - see that field's own
    // doc comment for why it's the one exception to "just final
    // min/avg/max" in RunSnapshot.
    if (effConfig.mode == TestMode.BOUNCEBACK) {
        LiveSparkline(
            history = effSparklineHistory,
            isSaved = effectiveViewingSaved,
            rttMinUs = effBbRttMinUs,
            durationSecs = effConfig.durationSecs,
            // Raw, unaveraged counterpart to the windowed mean/bands above
            // - overlaid on the same axis (see LiveSparkline's own
            // rawHistory doc comment) rather than a separate chart, so the
            // contrast between the smoothed line and the raw signal it's
            // hiding is directly visible in one view.
            rawHistory = effBbRequestsHistory,
            rpsCcaLabel = effRpsCcaLabel,
            workingLoadTag = workingLoadTag(effConfig),
        )
    }
    // Working load's own up/down throughput - moved out of
    // BytesInFlightMeter's own bar stack into a full-width chart
    // (see WorkingLoadUpChart/WorkingLoadDownChart's own doc
    // comment for why this is full-width rather than the usual
    // [dial | MiniSparkline] row: it sits directly under
    // LiveSparkline, the RPS graph, which is itself full-width with
    // no dial, so matching its shape keeps both graphs' time axes
    // visually aligned). Placed here, after LiveSparkline above (not
    // right after the BytesInFlightMeter call, and not up with the
    // other dial+sparkline rows before it), so the order
    // top-to-bottom is RPS gauge (BytesInFlightMeter's own bar) ->
    // RPS live graph (LiveSparkline) -> working load, which is
    // secondary background traffic and belongs underneath both.
    // Individually gated the same way the bars they replaced were:
    // both show for BIDIR, only the relevant one for UP/DOWN.
    if (effConfig.mode == TestMode.BOUNCEBACK && effConfig.workingLoadEnabled) {
        // The stream's real CCA - workingLoadL4sCca (prague/reno) under
        // UDP_L4S, else workingLoadCca (a plain TCP algorithm name).
        val workingLoadCcaLabel = if (effConfig.workingLoadTransport == Transport.UDP_L4S) {
            effConfig.workingLoadL4sCca.name.lowercase()
        } else {
            effConfig.workingLoadCca
        }
        if (effConfig.workingLoadDirection != WorkingLoadDirection.DOWN) {
            WorkingLoadUpChart(
                mbps = if (effectiveViewingSaved) null else workingLoadUpMbps,
                stats = effWorkingLoadUpStats,
                history = effWorkingLoadUpHistory,
                ccaLabel = workingLoadCcaLabel,
                isRunning = effIsRunning,
                durationSecs = effConfig.durationSecs,
            )
        }
        if (effConfig.workingLoadDirection != WorkingLoadDirection.UP) {
            WorkingLoadDownChart(
                mbps = if (effectiveViewingSaved) null else workingLoadDownMbps,
                stats = effWorkingLoadDownStats,
                history = effWorkingLoadDownHistory,
                ccaLabel = workingLoadCcaLabel,
                isRunning = effIsRunning,
                durationSecs = effConfig.durationSecs,
            )
        }
    }
    if (effConfig.mode == TestMode.BOUNCEBACK) {
        // A deeper look at the same request/reply time data LiveSparkline
        // above showed as a windowed time series - the full-run
        // distribution behind it, once the run's actually finished (see
        // IperfViewModel.bbHistogram's own doc comment for why this is
        // only ever a single terminal value, not something that grows
        // during the run the way sparklineHistory does). Placed below the
        // working-load section (secondary background traffic) rather than
        // right after LiveSparkline, so it ends up right above
        // FooterSection's own RunCompareTabs/"Overlay CDF"/"Overlay PDF"
        // buttons - those buttons act on this exact chart, so keeping them
        // close together means acting on a control and seeing its effect
        // don't require scrolling back and forth. Always rendered, not
        // gated on effBbHistogram being non-null - BounceBackHistogramChart
        // already renders its own fixed-height "Waiting for data…"
        // placeholder when null (it naturally stays null until iperf2
        // prints the histogram line at the very end of a completed run, or
        // for a config-only-restored preset - see TestConfigStore's own
        // doc comment). Gating this call on nullness would make the whole
        // chart area (heading included) disappear instead, shifting
        // everything below it and breaking scroll-position parity when
        // comparing two BOUNCEBACK presets that differ only in whether a
        // histogram was captured.
        BounceBackHistogramChart(
            histogram = effBbHistogram,
            golden = goldenHistogram,
            showGoldenCdf = showGoldenCdf,
            showGoldenPdf = showGoldenPdf,
            showEmd = showEmd,
            zoomTail = zoomTail,
            workingLoadTag = workingLoadTag(effConfig),
            goldenWorkingLoadTag = goldenWorkingLoadTag,
            ccaTag = ccaTag(effConfig),
            goldenCcaTag = goldenCcaTag,
        )
    }
}

/**
 * Status message line, the RunCompareTabs preset row, its live/saved
 * summary text, and the version/edition footer - extracted out of
 * IperfScreen (see that composable's own doc comment) as the last,
 * bottom-of-screen chunk.
 */
@Composable
private fun FooterSection(
    statusMessage: String?,
    viewingSlot: Char?,
    savedRuns: Map<Char, RunSnapshot?>,
    canSaveRun: Boolean,
    isRunning: Boolean,
    config: TestConfig,
    versionInfo: String?,
    versionParts: VersionParts?,
    scrollState: ScrollState,
    viewModel: IperfViewModel,
    // BOUNCEBACK's own golden-reference overlay controls - grouped here
    // next to RunCompareTabs (see its own class doc comment for why
    // reference now lives entirely in this tab row) rather than down next
    // to BounceBackHistogramChart itself. Feeds both RunCompareTabs' own
    // star and this composable's own overlayEnabled gate for the
    // "Overlay CDF"/"Overlay PDF" buttons (see its own doc comment) -
    // which A/B/C/D slot (if any) was explicitly promoted, not a raw-bytes
    // comparison (see IperfViewModel.goldenSlot's own doc comment for why).
    goldenSlot: Char?,
    showGoldenCdf: Boolean,
    onToggleGoldenCdf: () -> Unit,
    showGoldenPdf: Boolean,
    onToggleGoldenPdf: () -> Unit,
    // EMD-fill toggle (see BounceBackHistogramChart.showEmd's own doc
    // comment) - grouped in the same button row as the CDF/PDF overlay
    // toggles above since it's the same "what does this chart show"
    // control surface, not a separate concern.
    showEmd: Boolean,
    onToggleEmd: () -> Unit,
    // Zoom-to-tail toggle (see BounceBackHistogramChart.zoomTail's own doc
    // comment) - same button row as the rest, most useful paired with
    // showEmd but independently switchable.
    zoomTail: Boolean,
    onToggleZoomTail: () -> Unit,
    // Whether BounceBackHistogramChart actually has a histogram to zoom
    // into right now (effBbHistogram != null at the call site) - unlike
    // the other three buttons in this row, Zoom Tail isn't gated on a
    // *golden* reference (zooming into this run's own tail is useful with
    // no reference at all), but it still needs *some* histogram, the same
    // "don't offer a control with nothing to act on" reasoning overlayEnabled
    // already applies to the others. Without this, the button sat enabled
    // the whole time the chart itself was still showing its own "Waiting
    // for data…" placeholder (histogram only arrives once iperf2 prints it
    // at the very end of a completed run - see BounceBackHistogramChart's
    // own call site comment, IperfScreen).
    histogramAvailable: Boolean,
) {
    statusMessage?.let {
        Text(text = it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
    }

    // Preserves *where* in the scrollable content the user was looking
    // (as a 0f=top..1f=bottom fraction, not a raw pixel offset) across a
    // preset-tab switch. Two slots can legitimately differ in total content
    // height - different TestMode.mode renders a different row set, and a
    // config-only-restored preset (TestConfigStore.loadPreset, all
    // *Stats/history null) renders fewer/shorter meters than a fully
    // populated one - so leaving scrollState.value untouched would land the
    // same raw offset at a different logical spot in the new content (e.g.
    // scrolled to the very bottom of slot A, but only partway down slot
    // B's shorter content). Captured synchronously inside onTap below,
    // *before* setViewingSlot() changes what's rendered - reading
    // scrollState.maxValue after the switch would already reflect the new
    // content, not the one the fraction needs to be measured against.
    var pendingScrollFraction by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(viewingSlot) {
        val fraction = pendingScrollFraction ?: return@LaunchedEffect
        pendingScrollFraction = null
        // Same short settle delay as IperfScreen's own isRunning-transition
        // auto-scroll effect - lets this frame's layout (now reflecting the
        // newly-selected slot's content) finish before reading maxValue.
        delay(50)
        scrollState.scrollTo((fraction * scrollState.maxValue).roundToInt().coerceIn(0, scrollState.maxValue))
    }

    // Always shown, even before any test has ever run - a
    // technician should be able to see all four preset slots exist
    // (and hold one down the moment there's something live to
    // save) without needing to run a test first just to make the
    // row appear. RunCompareTabs' own "Hold to save results" hint
    // is still gated on canSave internally.
    RunCompareTabs(
        viewingSlot = viewingSlot,
        savedRuns = savedRuns,
        canSave = canSaveRun,
        isRunning = isRunning,
        onTap = { slot ->
            pendingScrollFraction = if (scrollState.maxValue > 0) scrollState.value.toFloat() / scrollState.maxValue else 0f
            // Tapping the already-selected slot again toggles back to the
            // live view too (in addition to RunCompareTabs' own explicit
            // Live tab) - if slot is already null (the Live tab itself),
            // this is a no-op, same as tapping the live tab while already
            // on it.
            viewModel.setViewingSlot(if (viewingSlot == slot) null else slot)
        },
        onHoldSave = { viewModel.saveCurrentAs(it) },
        onHoldSaveGolden = { viewModel.promoteSlotToGolden(it) },
        goldenSlot = goldenSlot,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
    )
    // Golden reference's own overlay controls - placed directly under the
    // tabs whose stars they relate to (see RunCompareTabs' own class doc
    // comment for why reference navigation lives entirely in that row now),
    // rather than down next to BounceBackHistogramChart itself. Always
    // shown (not hidden when there's no reference saved yet) - grayed out/
    // disabled instead, same "the control exists, there's just nothing to
    // point it at yet" convention as RunCompareTabs' own always-visible A/
    // B/C/D tabs. The star on each button is the same one RunCompareTabs
    // draws on whichever tab currently *is* the reference, so "this is
    // what gets overlaid" reads as the same concept in both places without
    // needing separate legend text.
    //
    // Gated on an A/B/C/D slot actually being the explicitly-designated
    // reference right now (goldenSlot), not just goldenHistogram being
    // non-null - GoldenHistogramStore's own file persists independently of
    // any slot designation, so a reference saved earlier can in principle
    // outlive the slot that produced it (see IperfViewModel.
    // resetToDefaults' own handling, which clears the designation
    // alongside A/B/C/D). Enabling these buttons with no visible star
    // anywhere would let a technician overlay something they have no way
    // to identify on screen. Also disabled while viewingSlot itself is the
    // starred slot - overlaying the reference on top of itself is a
    // trivial no-op (identical shapes, EMD always 0), not a real
    // comparison worth offering.
    val goldenColor = MaterialTheme.colorScheme.tertiary
    val overlayEnabled = goldenSlot != null && viewingSlot != goldenSlot
    // BOUNCEBACK-only - the reference/star mechanic itself (RunCompareTabs'
    // own three-state button) is mode-agnostic (see IperfViewModel.
    // promoteSlotToGolden's own doc comment), but CDF/PDF overlay is
    // specifically a BOUNCEBACK histogram concept with nothing to overlay
    // for a TCP/UDP-L4S reference - showing these buttons there would just
    // be dead controls next to a chart that isn't even on screen.
    if (config.mode == TestMode.BOUNCEBACK) {
        // FlowRow (not a plain Row) - a fixed-width Row let this exact
        // button set overflow on a narrower phone screen before (all 4
        // squeezed onto one line, the last button's text wrapping
        // letter-by-letter inside a crushed circle instead of its normal
        // pill shape - see feedback_multi_device_testing memory). FlowRow
        // wraps to a second line automatically instead, so it stays
        // correct on any screen width without having to hand-pick a
        // split point that could just as easily overflow again the next
        // time a button gets added here.
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 4.dp),
        ) {
            OutlinedButton(onClick = onToggleEmd, enabled = overlayEnabled) {
                Text(if (showEmd) "Hide EMD" else "Show EMD")
            }
            OutlinedButton(onClick = onToggleGoldenCdf, enabled = overlayEnabled) {
                Text(if (showGoldenCdf) "Hide " else "Overlay ")
                // Between the verb and "CDF" rather than leading the whole
                // label - reads as describing *which* CDF (the reference's),
                // not just decorating the button.
                Icon(
                    Icons.Filled.Star,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = if (overlayEnabled) goldenColor else LocalContentColor.current,
                )
                Text(" CDF")
            }
            OutlinedButton(onClick = onToggleGoldenPdf, enabled = overlayEnabled) {
                Text(if (showGoldenPdf) "Hide " else "Overlay ")
                Icon(
                    Icons.Filled.Star,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = if (overlayEnabled) goldenColor else LocalContentColor.current,
                )
                Text(" PDF")
            }
            // Unlike the other three buttons in this row, not gated on
            // overlayEnabled - zooming into this run's own tail is useful
            // on its own (a clearer look at the tail's PDF/CDF shape),
            // even with no golden reference to compare against yet. Still
            // gated on histogramAvailable though - see its own doc comment.
            OutlinedButton(onClick = onToggleZoomTail, enabled = histogramAvailable) {
                Text(if (zoomTail) "Un-zoom" else "Zoom Tail")
            }
        }
    }
    Text(
        text = viewingSlot?.let { slot ->
            savedRuns[slot]?.let { "$slot - saved ${formatSavedAt(it.savedAtMillis)}, ${configSummary(it.config)}" }
        } ?: "Live - ${configSummary(config)}",
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(bottom = 4.dp),
    )

    // "Dump diags" shares the edition line's own row, right-justified -
    // deliberately small/muted rather than a prominent button up by
    // Start: a full-width "Share log" button there got tapped reflexively
    // on every run, not just ones worth reporting, which would've meant
    // every ticket getting a log attached whether it added anything or
    // not. Still discoverable for someone who actually needs it (e.g.
    // attaching a log to a SourceForge ticket from a Google Play
    // internal-testing device with no adb access), just not competing for
    // attention otherwise. Gated on the log file actually existing
    // (nothing to share before a first run) and !isRunning (the file's
    // still being written mid-run).
    val context = LocalContext.current
    val logFileExists = remember(isRunning) { RawRunLogStore.file(context)?.exists() == true }
    versionInfo?.let {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        ) {
            Text(
                text = versionParts?.editionLabel ?: it,
                style = MaterialTheme.typography.labelSmall,
            )
            if (!isRunning && logFileExists) {
                Text(
                    "Dump diags",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.clickable {
                        val logFile = RawRunLogStore.file(context) ?: return@clickable
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", logFile)
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share test log"))
                    },
                )
            }
        }
    }
}

/**
 * "100" -> "100B"; "1K"/"2M" (byte_atoi's own K/M/G suffix form, src/stdio.c)
 * pass through as-is - only bare digit strings are missing a unit.
 */
private fun formatByteSize(raw: String): String =
    if (raw.isNotEmpty() && raw.last().isDigit()) "${raw}B" else raw

/** Wall-clock time-of-day for the A/B compare subtitle - just needs to distinguish "which run", not a full timestamp. */
private fun formatSavedAt(millis: Long): String =
    java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(millis))

/**
 * One-line settings summary for the A/B compare subtitle - mode first,
 * since a saved preset can be a different mode than the live config
 * (RunCompareTabs lets a technician hold a TCP run into one slot and a
 * UDP-L4S run into the other), then whichever mode-specific knobs actually
 * applied, so what was set - tcp-cca in particular - is visible without
 * reopening the settings panel or switching mode just to check.
 */
// Four flat states - off/up/down/bidir - not "on" collapsing UP and DOWN
// together: they're materially different traffic patterns (which
// direction working load is competing with the RPS probe on), not an
// interchangeable detail. Shared between configSummary's own "wl=..."
// part below and BounceBackHistogramChart's "wl=..." EMD-line tag, so the
// two read as the exact same four states everywhere they appear.
private fun workingLoadTag(cfg: TestConfig): String =
    if (!cfg.workingLoadEnabled) "off" else cfg.workingLoadDirection.name.lowercase()

// Same "always shown, plain state" convention as workingLoadTag above -
// "default" (matching cfg.bouncebackCcaEnabled being off - the CLI flag
// isn't sent at all) rather than omitting the tag entirely, since a
// technician comparing two presets needs to see at a glance whether they
// even used the same algorithm, including the case where one side
// deliberately left it unset. "udp-l4s"/"udp" instead when the probe
// transport itself is one of the UDP variants - CCA doesn't apply to
// either at all (see TestConfig.bouncebackTransport's own doc comment).
// Shared with BounceBackHistogramChart's "cca=..." EMD-line tag.
private fun ccaTag(cfg: TestConfig): String = when {
    cfg.bouncebackTransport == BouncebackTransport.UDP_L4S -> "udp-l4s"
    cfg.bouncebackTransport == BouncebackTransport.UDP -> "udp"
    !cfg.bouncebackCcaEnabled -> "default"
    else -> cfg.tcpCca
}

private fun configSummary(cfg: TestConfig): String {
    val parts = mutableListOf(cfg.mode.name, "${cfg.host}:${cfg.port}", "${cfg.durationSecs}s")
    if (cfg.forceIpv6) parts += "ipv6"
    when (cfg.mode) {
        TestMode.TCP -> {
            if (cfg.tcpCcaEnabled) parts += "cca=${cfg.tcpCca}"
            if (cfg.reverseEnabled) parts += "reverse"
        }
        TestMode.UDP_L4S -> {
            if (cfg.l4sCca == L4SCongestionControl.RENO) parts += "cca=reno"
            if (cfg.reverseEnabled) parts += "reverse"
        }
        TestMode.BOUNCEBACK -> {
            // cca= only when the probe transport is still TCP - matches
            // the congestion-control row's own visibility gate above,
            // since IperfCommandBuilder doesn't send --cca at all once
            // this is either UDP variant.
            when (cfg.bouncebackTransport) {
                BouncebackTransport.UDP_L4S -> parts += "udp-l4s"
                BouncebackTransport.UDP -> parts += "udp"
                BouncebackTransport.TCP -> if (cfg.bouncebackCcaEnabled) parts += "cca=${cfg.tcpCca}"
            }
            // Always shown (not omitted when off, unlike cca/reverse above)
            // - same "WL=on/off/bidir" tag BounceBackHistogramChart's own
            // EMD line uses (workingLoadTag below), and for the same
            // reason: a technician comparing two saved presets needs to
            // see at a glance whether working load's own background
            // traffic was even active for each one.
            parts += "wl=${workingLoadTag(cfg)}"
        }
    }
    return parts.joinToString(", ")
}

private data class VersionParts(val versionAndDate: String, val editionLabel: String)

/**
 * Splits the bundled binary's own "--version" output - e.g. "iperf 2.2.2
 * (7 July 2026) pthreads (professional) (compiled by rjmcmahon)" or a
 * community build's "iperf 2.2.2 (7 July 2026) pthreads (community)", which
 * never carries the trailing "(compiled by ...)" tag (see
 * include/version.h's IPERF_BUILD_USER_TAG) - into the version+date for the
 * title bar and an edition line (branch/threading/build-user, all read from
 * the string itself, never hardcoded) for the bottom of the screen. Returns
 * null on anything that doesn't match, so callers can fall back to showing
 * the raw string rather than a mangled partial parse.
 *
 * Some branch builds insert their own parenthesized tag between the version
 * number and the date (IPERF_VERSION_SUFFIX, include/version.h - e.g.
 * "iperf 2.2.2 (udp-l4s) (9 July 2026) pthreads ..."), so the date can't be
 * assumed to be the first "(...)" group - that would grab "(udp-l4s)"
 * instead and the title bar would silently show the branch tag with no
 * date at all. Match the date specifically by its own shape (day, month
 * name, year) instead.
 */
private fun parseVersionInfo(raw: String): VersionParts? {
    val trimmed = raw.trim().removePrefix("iperf ").trim()
    val dateMatch = Regex("""\(\d{1,2}\s+\S+\s+\d{4}\)""").find(trimmed) ?: return null
    val versionAndDate = trimmed.substring(0, dateMatch.range.last + 1).trim()
    val rest = trimmed.substring(dateMatch.range.last + 1).trim()
    val threads = rest.substringBefore("(").trim()
    val parens = Regex("""\(([^)]+)\)""").findAll(rest).map { it.groupValues[1] }.toList()
    val branch = parens.getOrNull(0)?.trim()?.takeIf { it.isNotBlank() } ?: return null
    val compiledBy = parens.getOrNull(1)?.removePrefix("compiled by")?.trim()?.takeIf { it.isNotBlank() }
    val editionLabel = buildString {
        append(branch.replaceFirstChar { it.uppercase() })
        append(" edition")
        if (threads.isNotBlank()) append(" ($threads)")
        compiledBy?.let { append(" compiled by $it") }
    }
    return VersionParts(versionAndDate, editionLabel)
}

/**
 * Reactively tracks which of WIFI/ETHERNET/CELLULAR are currently up, so
 * the Network row (below) can hide itself entirely - or hide individual
 * chips - when there's nothing to choose between. Showing an
 * always-visible Auto/WiFi/Ethernet/Cellular selector on a device that
 * only ever has WiFi would just be wasted UI space. Uses a live
 * NetworkCallback rather than a one-time snapshot (unlike
 * NetworkTransportProbe's own currentNetworkTransport()) because this is
 * specifically for the pre-run config screen, where a technician plugging
 * in a USB Ethernet adapter (or toggling mobile data) while the app is
 * already open is the exact scenario this whole feature exists for - it
 * should appear without needing an app restart. No transport filter on the
 * request (unlike a single-transport check would need) since any network
 * coming or going is worth recomputing the whole set for.
 */
@Composable
private fun availableTransportsState(): State<Set<NetworkPreference>> {
    val context = LocalContext.current
    return produceState(initialValue = availableForcableTransports(context), context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) return@produceState
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                value = availableForcableTransports(context)
            }
            override fun onLost(network: Network) {
                value = availableForcableTransports(context)
            }
        }
        val request = NetworkRequest.Builder().build()
        cm.registerNetworkCallback(request, callback)
        awaitDispose { cm.unregisterNetworkCallback(callback) }
    }
}

/**
 * Small colored dot + label - shared by the connected/connect-failed
 * states. [transport], when non-null (only passed at the "Connected" call
 * site - see RunProgressAndConnectionStatus), adds a small WiFi/Ethernet/
 * Cellular icon at the end of the row so it's visible at a glance which
 * interface this run is *believed* to be using. For AUTO this is a real,
 * live-sampled reading (NetworkTransportProbe.currentNetworkTransport's
 * own doc comment). For a forced WIFI/ETHERNET/CELLULAR preference it's
 * only the requested choice, optimistically assumed to have taken effect -
 * see [mismatch] for the actual verified check (IperfViewModel.
 * transportMismatch, compared against the CSV's own real srcaddress
 * column), which is what can tell you this icon itself is showing the
 * wrong thing.
 */
@Composable
private fun ConnectionStatusIndicator(
    color: Color,
    text: String,
    transport: NetworkTransport? = null,
    mismatch: Boolean = false,
    l4sCeConfirmed: Boolean = false,
    l4sReplyBleachDetected: Boolean = false,
    l4sReqBleachDetected: Boolean = false,
    l4sReplyConfirmed: Boolean = false,
    l4sReqConfirmed: Boolean = false,
    capacityL4sConfirmed: Boolean = false,
    capacityL4sBleachDetected: Boolean = false,
    bbStaleReplyDetected: Boolean = false,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(bottom = 4.dp),
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(text, style = MaterialTheme.typography.bodySmall)
        // Shown whenever this row renders at all, not gated on any badge
        // currently being lit - same reasoning as UdpL4sInfoIcon's own
        // placement (that composable's doc comment): a user should be
        // able to learn what a badge means before ever seeing one, not
        // only once one's already showing.
        ConnectionBadgeInfoIcon()
        // mismatch folds into this same icon's own tint rather than a
        // separate warning glyph - one icon, its color is the state
        // (neutral = matches selection, amber = doesn't). Confirmed real
        // (not just theoretical) failure mode this exists for: some
        // devices report a live Network object for the requested
        // transport via ConnectivityManager without the native `-c
        // host%device` SO_BINDTODEVICE bind actually taking effect at the
        // socket level, so traffic silently goes out over a different
        // interface than [transport] itself claims - this app's own
        // activeTransport just echoes the forced selection back in that
        // case (IperfViewModel.kt), it doesn't re-verify anything, so the
        // icon alone can't be trusted without this tint - see mismatch's
        // own doc comment (IperfViewModel) for how it's independently
        // derived from the CSV's real srcaddress instead.
        val transportTint = if (mismatch) Color(0xFFFFA000) else MaterialTheme.colorScheme.onSurfaceVariant
        when (transport) {
            NetworkTransport.WIFI -> Icon(
                WifiIcon,
                contentDescription = if (mismatch) {
                    "Selected network wasn't honored by this device - actual traffic used WiFi instead"
                } else {
                    "Connected via WiFi"
                },
                modifier = Modifier.size(16.dp),
                tint = transportTint,
            )
            NetworkTransport.ETHERNET -> Icon(
                CableIcon,
                contentDescription = if (mismatch) {
                    "Selected network wasn't honored by this device - actual traffic used Ethernet instead"
                } else {
                    "Connected via Ethernet"
                },
                modifier = Modifier.size(16.dp),
                tint = transportTint,
            )
            NetworkTransport.CELLULAR -> Icon(
                CellularIcon,
                contentDescription = if (mismatch) {
                    "Selected network wasn't honored by this device - actual traffic used Cellular instead"
                } else {
                    "Connected via Cellular"
                },
                modifier = Modifier.size(16.dp),
                tint = transportTint,
            )
            // Other/null: no icon - WiFi/Ethernet/Cellular is the
            // distinction this was actually built for, not a full
            // transport-type display.
            else -> {}
        }
        // Five sticky "ever true this run" signals from the native side's
        // own one-shot Reporter-thread log lines (IperfViewModel's
        // l4sCeConfirmed/l4sReply*/l4sReq*, see those flags' own doc
        // comment) - only ever true for BOUNCEBACK's UDP_L4S transport, so
        // no separate mode/transport gate needed here, same as [mismatch]
        // above needing no gate of its own.
        // One slot per direction, request(up) then reply(down) then CE
        // last, shown only once that direction has a clean read - see
        // l4sReplyConfirmed/l4sReplyBleachDetected's own doc comment
        // (IperfViewModel.kt) for why native only ever sets one or the
        // other, never both, so these two states within a slot are
        // mutually exclusive. The bottle shape (BleachBottle, NetworkIcons
        // .kt) is reserved for the negative/bleached case only - a bottle
        // silhouette inherently reads as "bleach", so tinting it green for
        // the *affirmative* case would be a contradictory icon (green
        // bleach bottle makes no sense regardless of color). Confirmed-
        // intact instead reuses the same circle-badge language as
        // l4sCeConfirmed below: solid green circle, this time with
        // "<arrow>1" lettering (the "1" is ECT(1), the mark this whole
        // feature is tracking - matches "CE" lettering's own naming-the-
        // signal convention rather than a bare direction glyph) instead of
        // "CE". Both states get a small direction arrow (down=reply/
        // downstream, up=request/upstream) since slot position alone isn't
        // legible without a legend.
        if (l4sReqConfirmed) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2E7D32)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Color(0xFF80DEEA))) { append("↑") }
                        withStyle(SpanStyle(color = Color.White)) { append("1") }
                    },
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.semantics {
                        contentDescription = "L4S request-direction ECN confirmed intact - server received your request unmolested"
                    },
                )
            }
        } else if (l4sReqBleachDetected) {
            // Upright - request/upstream is the bottle's natural
            // orientation, reply/downstream below is the same bottle
            // rotated 180°. Orientation carries direction instead of a
            // small overlaid arrow badge, which at 16dp kept either
            // landing off the bottle's actual visible footprint or
            // rendering too faint to see regardless of color - flipping
            // the whole shape is trivially visible at any size and needs
            // no extra element.
            Icon(
                BottleIcon,
                contentDescription = "L4S request-direction ECN bleaching detected - server received your request as Not-ECT",
                modifier = Modifier.size(16.dp),
                tint = Color(0xFFE64A19),
            )
        }
        if (l4sReplyConfirmed) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2E7D32)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Color(0xFF80DEEA))) { append("↓") }
                        withStyle(SpanStyle(color = Color.White)) { append("1") }
                    },
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.semantics {
                        contentDescription = "L4S reply-direction ECN confirmed intact - server marked ECT(1), arrived unmolested"
                    },
                )
            }
        } else if (l4sReplyBleachDetected) {
            Icon(
                BottleIcon,
                contentDescription = "L4S reply-direction ECN bleaching detected - server marked ECT(1), arrived Not-ECT",
                modifier = Modifier.size(16.dp).graphicsLayer(rotationZ = 180f),
                tint = Color(0xFFE64A19),
            )
        }
        if (l4sCeConfirmed) {
            // "CE" lettering in a solid circle, not a generic checkmark -
            // reads unambiguously as the specific signal (congestion-
            // experienced marks seen) rather than a vague "this is fine"
            // tick that could be mistaken for meaning something broader.
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2E7D32)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "CE",
                    color = Color.White,
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.semantics {
                        contentDescription = "L4S CE marking confirmed - this path's queue applied at least one congestion mark this run"
                    },
                )
            }
        }
        // Capacity's own UDP L4S stream (Client::RunUDPL4S) - a single
        // continuous flow, unlike Bounceback's discrete request/reply
        // pair above, so there's only one direction's worth of marking-
        // integrity to show: no arrow (nothing to disambiguate against)
        // on the confirmed circle, and the bottle stays in its natural
        // upright orientation (no 180° flip) for the same reason. See
        // IperfViewModel.capacityL4sConfirmed's own doc comment for why
        // these are separate StateFlows from the Bounceback ones above.
        if (capacityL4sConfirmed) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2E7D32)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "1",
                    color = Color.White,
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.semantics {
                        contentDescription = "L4S ECN confirmed intact - server received your data unmolested"
                    },
                )
            }
        } else if (capacityL4sBleachDetected) {
            Icon(
                BottleIcon,
                contentDescription = "L4S ECN bleaching detected - server received your data marked incorrectly",
                modifier = Modifier.size(16.dp),
                tint = Color(0xFFE64A19),
            )
        }
        // Bounceback UDP only (native only ever sets this from
        // RunBounceBackUDP - see bbStaleReplyDetected's own doc comment,
        // IperfViewModel.kt), no separate mode gate needed here, same as
        // every other flag in this row. A generic warning triangle, not
        // the bottle - the bottle shape is reserved for ECN bleaching
        // specifically (a bottle silhouette inherently reads as "bleach",
        // see l4sReqBleachDetected's own doc comment above); this is an
        // unrelated condition (a stale/out-of-order reply ID, not an ECN
        // mark) and reusing the same glyph for it would misattribute the
        // cause at a glance. Tinted amber (same 0xFFFFA000 as the
        // transport-mismatch tint above), not the bottles' red-orange -
        // a stale reply is a routine, expected consequence of loss/
        // reordering under real congestion (see RunBounceBackUDP's own
        // doc comment), not a failure the way ECN bleaching is, so it
        // gets the same lower-severity "notice" color already established
        // for that distinction elsewhere in this same row, rather than
        // inventing a third semantic color.
        if (bbStaleReplyDetected) {
            Icon(
                Icons.Filled.Warning,
                contentDescription = "Bounceback discarded one or more stale (out-of-order) UDP replies this run",
                modifier = Modifier.size(16.dp),
                tint = Color(0xFFFFA000),
            )
        }
    }
}

/** Big, unmistakable Capacity/Bounceback switch - the two top-level test kinds this app supports. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TestKindSelector(
    kind: TestKind,
    enabled: Boolean,
    onKindChange: (TestKind) -> Unit,
    modifier: Modifier = Modifier,
) {
    val options = listOf(TestKind.BOUNCEBACK, TestKind.CAPACITY)
    SingleChoiceSegmentedButtonRow(modifier = modifier.fillMaxWidth()) {
        options.forEachIndexed { index, option ->
            SegmentedButton(
                selected = kind == option,
                onClick = { onKindChange(option) },
                enabled = enabled,
                shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
                // No checkmark icon (M3's own default whenever selected) -
                // the selected segment's own background/border color
                // already shows selection clearly, same "color state is
                // enough, no separate icon" convention the CCA picker's
                // FilterChips already use just below. It also frees up
                // real horizontal room inside whichever segment is
                // selected, which matters most for Bounceback - the
                // longest label and the one most likely to be selected -
                // making the labelLarge fix above sturdier across phone
                // widths instead of "just barely fits".
                icon = {},
            ) {
                Text(
                    text = when (option) {
                        TestKind.CAPACITY -> "Capacity"
                        TestKind.BOUNCEBACK -> "Bounceback"
                    },
                    // labelLarge, not titleMedium - Material3's own
                    // recommended type-scale role for SegmentedButton
                    // content, and meaningfully smaller (14sp vs 16sp in
                    // the default scale). "Bounceback" is a single
                    // ten-letter word with no space to soft-wrap at, so at
                    // titleMedium it doesn't fit this row's two
                    // equal-width segments on some phone widths and
                    // mid-word-breaks into "Bouncebac"/"k" - the smaller,
                    // correct-for-this-role size gives it room to fit on
                    // one line instead.
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }
        }
    }
}

// Stopped: 1s - a deliberate, hard-to-trigger-by-accident hold, since
// overwriting a finished result is a bigger deal (that result took the
// whole test duration to produce). Running: a much shorter 250ms - a live
// snapshot is cheap to retake if you didn't mean to grab that instant, so
// the gesture shouldn't cost noticeable dead time out of the run itself.
private const val PresetHoldTimeoutStoppedMs = 1000L
private const val PresetHoldTimeoutRunningMs = 250L
private const val SavedFlashMs = 600L

// tcp_notsent_lowat's Size field dropdown - common TCP_NOTSENT_LOWAT values,
// not a "recently used" history (see EditableDropdownField's own doc
// comment on why Host/Port instead track recent use).
private val WRITE_PREFETCH_SIZE_PRESETS = listOf("1K", "16K", "128K", "256K", "512K", "1M", "2M", "4M")

// Always-available public servers - see PublicServers.kt (shared with
// TestConfigStore, which excludes these from the recent-hosts MRU list).
// Shown in the Host dropdown ahead of/alongside the usual recent-use
// history - unlike WRITE_PREFETCH_SIZE_PRESETS above, this isn't the
// field's only source of options (recentHosts still contributes
// actually-used entries too), just a fixed floor so these are always one
// tap away even on a fresh install with no history yet. Selecting any of
// these also snaps Port to the fixed port that host's deployment actually
// listens on for the current mode (UDP-L4S vs TCP/Bounceback - see the
// Host field's own onValueChange below) and disables the Port field
// entirely (see its own `enabled` below) - these servers don't listen on
// arbitrary ports, so letting the user type a different one would just
// produce a connection failure rather than a real choice.

/**
 * A/B compare "preset" tabs (see IperfViewModel.viewingSlot/saveCurrentAs())
 * - five navigable states, not four: the four A/B/C/D presets plus an
 * explicit Live tab for the live/last-completed run (viewingSlot == null),
 * so every one of the five is a single tap away from any of the others -
 * previously "live" was only reachable as an implicit fallback (tapping an
 * already-selected preset again, still supported below), not a state you
 * could see or tap into directly. Car-radio-preset semantics for A/B/C/D:
 * tap a slot to recall whatever's saved there, hold it down for
 * [PresetHoldTimeoutStoppedMs] (or [PresetHoldTimeoutRunningMs] mid-run) to
 * overwrite it with whatever's currently on screen right now (live, or
 * another already-viewed preset - see IperfViewModel.saveCurrentAs's own
 * doc comment). The Live tab has no hold gesture of its own - there's
 * nothing to save *into* it, saving is what A/B/C/D's own hold does.
 * Three-stage color feedback tracks each A/B/C/D tab's own hold gesture:
 * ready
 * (normal idle/selected look) while untouched, a muted primaryContainer
 * while held down, then solid primary plus a haptic tick and a "Saved"
 * label for [SavedFlashMs] once the hold actually completes. Deliberately
 * not a Material3 SegmentedButton like [TestKindSelector] - that owns its
 * own click handling, which would fight a second pointerInput layered on
 * top for the hold gesture - so this builds the same pill-row look by hand
 * with one gesture detector per tab. The hold is timed by hand
 * (awaitFirstDown + withTimeoutOrNull) rather than via detectTapGestures'
 * built-in onLongPress: that reads its threshold from the ambient
 * ViewConfiguration, which isn't guaranteed to actually pick up a locally
 * overridden value depending on the Compose UI version - timing it
 * directly here is what actually gives the exact hold duration and lets
 * the color respond to it.
 *
 * BOUNCEBACK's golden reference (see IperfViewModel.goldenHistogram) is
 * "make the slots the whole UI" too, rather than its own separate Save/
 * Show controls elsewhere (an earlier design that two rounds of on-device
 * feedback found unintuitive - a flat row of loosely-named buttons
 * bundling a storage action, a view-mode switch, and an overlay toggle).
 * Each A/B/C/D tab is really a three-state button - empty (grey) -> saved
 * (checkmark) -> reference (star) - and every transition costs exactly one
 * hold-time (holdTimeoutMs). Hold-time progress is state the slot itself
 * carries, not something tracked by how long a single continuous touch
 * lasts: an empty slot's first hold earns the checkmark; that same slot's
 * *next* hold, while it's the one currently on screen - whether that's a
 * continuation of the very same touch (a long, unbroken hold naturally
 * cascades through both transitions) or a wholly separate gesture minutes
 * or hours later - promotes it to the reference using its own already-
 * saved data, never whatever happens to be live at that later moment.
 * Holding a *different*, already-saved slot instead (while looking at Live
 * or at some other slot) stays the plain overwrite gesture from the
 * paragraph above, and if that slot happened to be the reference, the
 * overwrite demotes it back to a plain checkmark first - the star was
 * earned by the content that used to be there, not whatever just replaced
 * it, so it needs its own fresh promote hold to earn the star back (see
 * IperfViewModel.saveCurrentAs's own doc comment). Only ever one A/B/C/D
 * slot is the reference at a time (see IperfViewModel.goldenSlot's own doc
 * comment for why that's an explicit designation, not a raw-bytes
 * comparison) - promoting a new one always demotes whatever was previously
 * starred back down to a plain checkmark too, since it's still saved, just
 * no longer *the* one. Live can't become the reference directly; it has to
 * be saved into a slot first, same as every other "hold to save" gesture
 * here. Viewing the reference later is just tapping whichever tab is
 * currently starred, ordinary navigation with nothing extra to learn.
 */
@Composable
private fun RunCompareTabs(
    viewingSlot: Char?,
    savedRuns: Map<Char, RunSnapshot?>,
    canSave: Boolean,
    isRunning: Boolean,
    // Char? not Char - the five states a technician needs to move between
    // are the four presets *and* the live/last-completed run, not just the
    // four presets with "live" as an implicit, tab-less fallback you could
    // only reach by tapping an already-selected preset again (still
    // supported below, but no longer the only way back). null means live,
    // same convention as viewingSlot/setViewingSlot itself.
    onTap: (Char?) -> Unit,
    onHoldSave: (Char) -> Unit,
    // BOUNCEBACK's own reference (golden) promotion - "make the slots the
    // whole UI" for reference too, rather than a separate Save button
    // elsewhere: a checkmarked A/B/C/D slot's next hold-time (see this
    // composable's own class doc comment for the full three-state model)
    // promotes it to the reference. Only ever one A/B/C/D preset - Live
    // can't become the reference directly, it has to be saved into a slot
    // first, same as every other "hold to save" gesture on this row.
    onHoldSaveGolden: (Char) -> Unit = {},
    // Which A/B/C/D slot (if any) is currently the explicitly-designated
    // reference (IperfViewModel.goldenSlot) - drives the star directly
    // (slot == goldenSlot), see that field's own doc comment for why this
    // is a real designation rather than a raw-bytes comparison.
    goldenSlot: Char? = null,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val holdTimeoutMs = if (isRunning) PresetHoldTimeoutRunningMs else PresetHoldTimeoutStoppedMs
    // Theme-aware, not a hardcoded hex - a fixed pale amber read poorly
    // against a light theme's own surfaces (the same lesson learned
    // earlier this session from LiveSparkline's raw-RPS-line caption).
    // tertiary is otherwise unused by this row's own color states, so it
    // reads as its own distinct "this is the reference" signal.
    val goldenColor = MaterialTheme.colorScheme.tertiary
    Column(modifier = modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // The fifth state, ahead of the four presets - live/last-
            // completed run, no hold-to-save gesture of its own (there's
            // nothing to "save into" here, saving is what A/B/C/D's own
            // hold does), just a plain tap to switch back. Left-rounded
            // corner since it's now the row's own first tab.
            val liveSelected = viewingSlot == null
            Surface(
                color = if (liveSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 1.dp)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            val up = waitForUpOrCancellation()
                            if (up != null) onTap(null)
                        }
                    },
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                ) {
                    Text(text = "Live", style = MaterialTheme.typography.titleMedium)
                }
            }
            PRESET_SLOTS.forEachIndexed { index, slot ->
                val saved = savedRuns[slot]
                // The pointerInput below (see its own comment) isn't keyed
                // on saved, since saved changes mid-gesture the instant
                // onHoldSave(slot) fires - but its long-lived
                // awaitEachGesture loop still needs each *new* gesture
                // instance (a tap released before the hold threshold) to
                // see a current value, not whatever saved was when the
                // coroutine first started. rememberUpdatedState is exactly
                // this: always-current inside the closure, without forcing
                // a restart.
                val currentSaved by rememberUpdatedState(saved)
                // Same rememberUpdatedState reasoning as currentSaved above -
                // the gesture below needs the *current* golden slot inside
                // its own long-lived closure, not whatever it was when this
                // pointerInput last (re)started.
                val currentGoldenSlot by rememberUpdatedState(goldenSlot)
                val selected = viewingSlot == slot
                // Same rememberUpdatedState reasoning as currentSaved/
                // currentGoldenSlot above - the gesture below uses this to
                // tell "you're holding the slot you're already looking at"
                // (promote its own data) apart from "you're holding a
                // *different* slot than the one on screen" (overwrite with
                // whatever's on screen right now), and needs the current
                // value, not whatever it was when this pointerInput last
                // (re)started.
                val currentSelected by rememberUpdatedState(selected)
                var isHolding by remember(slot) { mutableStateOf(false) }
                // Brief flash right after a hold completes - selected+
                // secondaryContainer alone (what a plain tap-to-recall also
                // shows) doesn't clearly read as "this just got overwritten"
                // versus "you just switched to it", so this gets its own
                // distinct color/label for a moment before settling back to
                // the normal selected look.
                var justSaved by remember(slot) { mutableStateOf(false) }
                // Same idea, for the *second* hold time specifically -
                // confirms the reference promotion (distinct from
                // justSaved's own "just a preset" flash).
                var justSavedGolden by remember(slot) { mutableStateOf(false) }
                val isRef = goldenSlot == slot
                // Left-rounded corner moved to the new Live tab above -
                // only D (still the row's own last tab) keeps a rounded
                // corner here now.
                val shape = if (index == PRESET_SLOTS.lastIndex) {
                    RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp)
                } else {
                    RoundedCornerShape(0.dp)
                }
                Surface(
                    // This one tab's own five *color* states (a different
                    // "five" from the row's five navigable slots - Live
                    // plus A/B/C/D - above): empty/never-saved and not viewed
                    // (plain surfaceVariant) -> holds a saved run but isn't
                    // the one currently on screen (tertiaryContainer - a
                    // deliberately distinct third color, not just a dimmer
                    // version of "selected", so a technician can tell at a
                    // glance "there's something here" even while looking at
                    // the other slot) -> currently viewed (secondaryContainer)
                    // -> mid-hold (muted primaryContainer, "something's
                    // happening") -> just saved (solid primary, the actual
                    // confirmation). Each stage past "empty" reads as more
                    // urgent/relevant than the last rather than an arbitrary
                    // color swap.
                    color = when {
                        justSavedGolden -> goldenColor
                        justSaved -> MaterialTheme.colorScheme.primary
                        isHolding -> MaterialTheme.colorScheme.primaryContainer
                        selected -> MaterialTheme.colorScheme.secondaryContainer
                        saved != null -> MaterialTheme.colorScheme.tertiaryContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = shape,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 1.dp)
                        // Not keyed on saved - that changes the instant
                        // onHoldSave(slot) fires (a new RunSnapshot lands in
                        // savedRuns), which would cancel and restart this
                        // very coroutine mid-gesture, killing the second,
                        // longer golden-promotion tier below before it could
                        // ever complete. currentSaved (rememberUpdatedState
                        // above) is what the gesture logic reads instead,
                        // wherever it needs an up-to-date value without that
                        // restart.
                        .pointerInput(slot, canSave) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                if (canSave) {
                                    // Hold-time progress is state the slot
                                    // itself carries (currentSaved/
                                    // currentGoldenSlot), not something
                                    // tracked by how long a single
                                    // continuous touch lasts - "a long hold
                                    // is analogous to a short hold separated
                                    // in time". Every tier below waits the
                                    // exact same holdTimeoutMs, whichever
                                    // slot/state it's evaluating: an empty
                                    // slot's first hold earns a checkmark: a
                                    // checkmarked (or already-golden) slot's
                                    // next hold - whether that's a
                                    // continuation of the very same touch or
                                    // a wholly separate gesture, possibly
                                    // much later - promotes/refreshes it to
                                    // the reference. See IperfViewModel.
                                    // promoteSlotToGolden's own doc comment
                                    // for why a promotion here always
                                    // demotes whatever slot was previously
                                    // the reference back to a plain
                                    // checkmark (only one is ever the
                                    // reference at a time). The other branch
                                    // below (overwrite with the current
                                    // view) demotes too, for the same
                                    // reason, if it happens to land on the
                                    // slot that was the reference - see
                                    // IperfViewModel.saveCurrentAs's own doc
                                    // comment.
                                    isHolding = true
                                    val heldFirstTier = withTimeoutOrNull(holdTimeoutMs) {
                                        waitForUpOrCancellation()
                                        false
                                    } == null
                                    if (heldFirstTier) {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (currentSaved != null && currentSelected) {
                                            // You're already looking at this
                                            // exact slot's own saved content
                                            // (there's nothing "new" on
                                            // screen to capture - the view
                                            // itself is this slot's own
                                            // frozen snapshot), so a hold
                                            // here can only mean "promote/
                                            // refresh what I'm looking at",
                                            // using the slot's own already-
                                            // saved data (onHoldSaveGolden
                                            // reads straight from
                                            // IperfViewModel's own
                                            // _savedRuns, see its doc
                                            // comment), *not* onHoldSave -
                                            // this shouldn't silently
                                            // overwrite the preset with
                                            // whatever happens to be live
                                            // right now, which may have
                                            // changed or even stopped since
                                            // this slot was originally
                                            // saved.
                                            onHoldSaveGolden(slot)
                                            justSavedGolden = true
                                            scope.launch {
                                                delay(SavedFlashMs)
                                                justSavedGolden = false
                                            }
                                            waitForUpOrCancellation()
                                        } else {
                                            // Either a genuinely empty slot,
                                            // or a saved slot you're holding
                                            // while looking at something
                                            // *else* (Live, or a different
                                            // slot) - the general "hold to
                                            // save whatever's currently on
                                            // screen into this slot" gesture
                                            // (car-radio semantics),
                                            // unconditionally overwriting
                                            // whatever was here before.
                                            onHoldSave(slot)
                                            justSaved = true
                                            // Outside this gesture-detector's
                                            // own restricted suspend scope
                                            // (it can only call
                                            // AwaitPointerEventScope's own
                                            // members, not a plain delay())
                                            // - a separate coroutine to clear
                                            // the flash after SavedFlashMs.
                                            scope.launch {
                                                delay(SavedFlashMs)
                                                justSaved = false
                                            }
                                            // Keep watching the very same
                                            // continuous touch for a second
                                            // hold-time of the identical
                                            // duration - promotes this same
                                            // just-saved content straight to
                                            // the reference in one unbroken
                                            // gesture, the same outcome a
                                            // separate second hold later
                                            // would reach (once that second
                                            // hold sees currentSelected true,
                                            // having landed on this slot via
                                            // the just-saved switch below).
                                            // isHolding stays true through
                                            // this whole second wait
                                            // (cleared below either way) so
                                            // the tab keeps reading as
                                            // "still happening" rather than
                                            // dropping back to a duller
                                            // color the moment justSaved's
                                            // own brief flash ends.
                                            val heldSecondTier = withTimeoutOrNull(holdTimeoutMs) {
                                                waitForUpOrCancellation()
                                                false
                                            } == null
                                            if (heldSecondTier) {
                                                onHoldSaveGolden(slot)
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                justSaved = false
                                                justSavedGolden = true
                                                scope.launch {
                                                    delay(SavedFlashMs)
                                                    justSavedGolden = false
                                                }
                                                // Still held past the second
                                                // tier too - swallow the
                                                // eventual release so it
                                                // doesn't also register as a
                                                // tap. If heldSecondTier was
                                                // false instead, the release
                                                // already happened inside
                                                // that very
                                                // waitForUpOrCancellation()
                                                // call above - nothing left
                                                // to swallow.
                                                waitForUpOrCancellation()
                                            }
                                        }
                                    } else if (currentSaved != null) {
                                        onTap(slot)
                                    }
                                    isHolding = false
                                } else {
                                    val up = waitForUpOrCancellation()
                                    if (up != null && currentSaved != null) {
                                        onTap(slot)
                                    }
                                }
                            }
                        },
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    ) {
                        if (justSavedGolden) {
                            Text(text = "Reference!", style = MaterialTheme.typography.titleMedium)
                        } else if (justSaved) {
                            Text(text = "Saved", style = MaterialTheme.typography.titleMedium)
                        } else {
                            Text(text = slot.toString(), style = MaterialTheme.typography.titleMedium)
                            // Star instead of the plain checkmark once this
                            // slot *is* the golden reference - a strictly
                            // more specific state than "has a saved run", so
                            // it replaces rather than joins the checkmark.
                            // A plain tinted Icon here isn't enough: under
                            // Material You dynamic color (the default on
                            // API 31+, derived from the device's own
                            // wallpaper - see IperfTheme), tertiary and
                            // tertiaryContainer aren't a guaranteed-contrast
                            // "on"/container pair the way onTertiaryContainer
                            // is - some wallpapers collapse them close enough
                            // in dark mode that a tertiary-tinted star on a
                            // tertiaryContainer tab (the unselected-but-
                            // isRef background) visually disappears. Give the
                            // star its own small neutral `surface`-colored
                            // backdrop so it never sits directly on a
                            // same-hue container - `surface` (base/lowest
                            // elevation) and the tab's own elevated
                            // `tertiaryContainer`/`secondaryContainer` are
                            // far more reliably distinguishable than tertiary
                            // vs. tertiaryContainer are from each other.
                            if (isRef) {
                                Box(
                                    modifier = Modifier
                                        .padding(start = 4.dp)
                                        .size(18.dp)
                                        .background(MaterialTheme.colorScheme.surface, CircleShape),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        Icons.Filled.Star,
                                        contentDescription = if (selected) "Currently viewing $slot, the golden reference" else "$slot is the golden reference",
                                        modifier = Modifier.size(14.dp),
                                        tint = goldenColor,
                                    )
                                }
                            } else if (saved != null) {
                                // Same checkmark for both "has a saved run" and
                                // "is the one currently shown" - full opacity
                                // only for the latter - so an empty/free slot
                                // (no icon at all) is visually distinct from an
                                // occupied one even while looking at the other
                                // tab, not just via the fill color.
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = if (selected) "Currently viewing $slot" else "$slot has a saved run",
                                    modifier = Modifier.padding(start = 4.dp).size(18.dp),
                                    tint = LocalContentColor.current.copy(alpha = if (selected) 1f else 0.5f),
                                )
                            }
                        }
                    }
                }
            }
        }
        if (canSave) {
            Text(
                text = if (goldenSlot != null || savedRuns.values.any { it?.bbHistogramRawLine != null }) {
                    "Hold to save results, hold again to make it the reference"
                } else {
                    "Hold to save results"
                },
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

/**
 * Free-typed text field with a dropdown of recent values (see
 * TestConfigStore.recordHostUse/recordPortUse) - not a fixed-choice picker
 * like LabeledDropdown used to be for Parallel, since the user must be able
 * to type any host/port, not just pick from history. The dropdown is purely
 * a shortcut to re-select something already used.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditableDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    recentValues: List<String>,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    var expanded by remember { mutableStateOf(false) }
    val showMenu = expanded && enabled && recentValues.isNotEmpty()
    ExposedDropdownMenuBox(
        expanded = showMenu,
        onExpandedChange = { if (enabled) expanded = it },
        modifier = modifier,
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {
                onValueChange(it)
                expanded = true
            },
            label = { Text(label) },
            enabled = enabled,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            trailingIcon = if (recentValues.isNotEmpty()) {
                { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showMenu) }
            } else {
                null
            },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryEditable, enabled).fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = showMenu, onDismissRequest = { expanded = false }) {
            recentValues.forEach { recent ->
                DropdownMenuItem(
                    text = { Text(recent) },
                    onClick = {
                        onValueChange(recent)
                        expanded = false
                    },
                )
            }
        }
    }
}

// Free-typed field with a preset dropdown, same contract as
// EditableDropdownField above, but built on BasicTextField instead of
// Material3's OutlinedTextField - OutlinedTextField enforces a 56dp
// minimum height (for its floating label animation) that no modifier can
// shrink below, which read as badly oversized once this field's row (see
// tcp_notsent_lowat's Size field) needed to sit at the same height as the
// Switch beside it. No floating label here for the same reason; the
// caller places a plain caption above instead.
@Composable
private fun CompactDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    presets: List<String>,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    var expanded by remember { mutableStateOf(false) }
    val showMenu = expanded && enabled && presets.isNotEmpty()
    val borderColor = if (enabled) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outline.copy(alpha = 0.38f)
    val contentColor = if (enabled) LocalContentColor.current else LocalContentColor.current.copy(alpha = 0.38f)
    Box(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .height(32.dp)
                .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp),
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = contentColor),
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                cursorBrush = SolidColor(contentColor),
                modifier = Modifier.weight(1f),
            )
            if (presets.isNotEmpty()) {
                Icon(
                    Icons.Filled.ArrowDropDown,
                    contentDescription = "Presets",
                    tint = contentColor,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable(enabled = enabled) { expanded = true },
                )
            }
        }
        DropdownMenu(expanded = showMenu, onDismissRequest = { expanded = false }, modifier = Modifier.wrapContentSize()) {
            presets.forEach { preset ->
                DropdownMenuItem(
                    text = { Text(preset) },
                    onClick = {
                        onValueChange(preset)
                        expanded = false
                    },
                )
            }
        }
    }
}
