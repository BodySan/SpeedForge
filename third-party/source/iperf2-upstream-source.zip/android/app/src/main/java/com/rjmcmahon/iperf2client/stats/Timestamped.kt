package com.rjmcmahon.iperf2client.stats

// Generic counterpart to TimeSeriesPoint - same "real elapsed time plus a
// possibly-null reading" shape (see that data class's own doc comment for
// the full reasoning), but for a multi-field atomic point (RttHistoryPoint,
// CwndInflightPoint, WindowInflightPoint) rather than a single raw Double.
// elapsedSecs lives here, not on the wrapped point type, specifically so a
// missing interval can still carry its own real timestamp even though the
// point itself (all of whose fields are only ever appended together, see
// e.g. CwndInflightPoint's own doc comment) has nothing to report that
// interval - a null T can't carry a timestamp of its own the way a null
// Double inside TimeSeriesPoint doesn't need to (TimeSeriesPoint keeps
// elapsedSecs at the wrapper level too, for the same reason).
data class Timestamped<T>(val value: T?, val elapsedSecs: Double)
