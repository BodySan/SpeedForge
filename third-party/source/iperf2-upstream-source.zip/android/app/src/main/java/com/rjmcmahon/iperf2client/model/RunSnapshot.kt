package com.rjmcmahon.iperf2client.model

import com.rjmcmahon.iperf2client.stats.CwndInflightPoint
import com.rjmcmahon.iperf2client.stats.RttHistoryPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.WindowInflightPoint
import com.rjmcmahon.iperf2client.stats.WindowedSnapshot

/**
 * A frozen copy of one completed run's final meter stats, for the A/B
 * compare feature (IperfViewModel.saveCurrentAs()/viewingSlot, IperfScreen's
 * RunCompareTabs preset row - hold a slot to save into it, tap to recall).
 * Deliberately just the min/avg/max [MeterStats] each meter already shows
 * once a run stops - not the full interval-by-interval history - since
 * that's all the existing meter composables need (they already know how to
 * render a MeterStats with isRunning=false and no live sample, exactly the
 * state a saved run is always shown in).
 *
 * [sparklineHistory] is the one exception to that "just the final
 * min/avg/max" rule: BOUNCEBACK's LiveSparkline renders a whole windowed
 * time series (see IperfViewModel's sparklineHistoryFlow), not a single
 * collapsed reading, so a MeterStats snapshot alone would leave a saved
 * run's sparkline empty. Empty list (not null) for every other mode,
 * matching sparklineHistoryFlow's own "empty until BOUNCEBACK feeds it"
 * convention.
 *
 * [config] is the whole [TestConfig] the run used, not just the fields
 * that happen to matter today - cheap to store, and means a future new
 * config field the meters start reading automatically flows through here
 * too instead of silently going stale. Because it's the *whole* config
 * (mode included), a saved preset isn't tied to whatever mode the live
 * config is currently set to - a technician can hold a TCP run into one
 * slot and a UDP-L4S run into the other and flip between them; each slot's
 * own config drives which meters render (IperfScreen's effConfig) and the
 * saved-run subtitle (mode/host/port/duration/tcp-cca/etc, see
 * IperfScreen's configSummary()).
 *
 * Every *Stats field mirrors one of IperfViewModel's own StateFlow names
 * one-to-one - whichever ones the run's mode didn't produce are simply
 * null, the same "not applicable to this mode" convention IntervalSample
 * already uses (there as -1, here as null since these are already
 * nullable MeterStats?).
 */
data class RunSnapshot(
    val config: TestConfig,
    val savedAtMillis: Long,
    val throughputStats: MeterStats?,
    val rttStats: MeterStats?,
    val inFlightStats: MeterStats?,
    val packetsInFlightStats: MeterStats?,
    val cwndStats: MeterStats?,
    val retryStats: MeterStats?,
    val notSentStats: MeterStats?,
    val tcpExcessRttStats: MeterStats?,
    val sndBufStats: MeterStats?,
    val writeTimeStats: MeterStats?,
    val sndBufLimitedStats: MeterStats?,
    val rwndLimitedStats: MeterStats?,
    val busyTimeStats: MeterStats?,
    val flowingStats: MeterStats?,
    val ceMarksStats: MeterStats?,
    val ceMarksWhenMarkingStats: MeterStats?,
    val queueDelayStats: MeterStats?,
    val queueBytesStats: MeterStats?,
    val queuePacketsStats: MeterStats?,
    val l4sRttStats: MeterStats?,
    val l4sPacketWindowStats: MeterStats?,
    val l4sInflightStats: MeterStats?,
    val l4sMarkingProbStats: MeterStats?,
    val errPercentStats: MeterStats?,
    val bbRequestsStats: MeterStats?,
    // Same "single terminal value, not a growing history list" pattern as
    // bbRequestsStats above - BOUNCEBACK's one-per-run request/reply time distribution
    // histogram (see CsvLineParser.parseBounceBackHistogram and
    // IperfViewModel.bbHistogram's own doc comments), frozen as-is rather
    // than reduced to a MeterStats the way the *Stats fields above are:
    // there's no meaningful running min/avg/max of "the histogram," it's
    // already a single complete distribution by the time it arrives. Null
    // for every non-BOUNCEBACK run, and null even for a BOUNCEBACK run
    // saved before the histogram line actually arrived (e.g. a run stopped
    // early).
    val bbHistogram: BounceBackHistogram?,
    // The kernel's latest connection-lifetime rtt_min reading (microseconds)
    // at the moment this slot was saved - drives LiveSparkline's own
    // "theoretical RPS ceiling" caption (1000/rttMinMs) alongside
    // sparklineHistory above. Previously left out of RunSnapshot entirely
    // (treated as too transient to bother freezing, same reasoning
    // workingLoadUpMbps/workingLoadDownMbps still get live-only outside this
    // class), which meant every saved slot silently lost that line - worth
    // the one extra field to freeze given how cheap a single Long? is next
    // to the history lists already here.
    val bbRttMinUs: Long?,
    // The exact raw CSV line bbHistogram above was parsed from - lets
    // "Save as golden" (IperfViewModel.saveGoldenHistogram) work from a
    // saved A/B/C/D preset, not just the live view: reviewing which run
    // deserves to be golden is naturally something you do by looking back
    // at a saved preset, not necessarily while it's still live - see that
    // function's own doc comment. Null for a config-only-restored preset
    // (TestConfigStore's own doc comment) - same as bbHistogram itself,
    // never captured on a run this app never actually re-ran.
    val bbHistogramRawLine: String?,
    val workingLoadUpStats: MeterStats?,
    val workingLoadDownStats: MeterStats?,
    val sparklineHistory: List<Timestamped<WindowedSnapshot>>,
    // Raw (not windowed) per-interval requestsPerSec, for
    // RpsVolatilityLine - deliberately a separate history from
    // sparklineHistory above rather than derived from it, since
    // sparklineHistory's whole point is smoothing those same raw readings
    // into a windowed mean (see IperfViewModel.windowedStats' own doc
    // comment) - the thing RpsVolatilityLine exists to show *without* that
    // smoothing. Empty for every non-BOUNCEBACK run.
    val bbRequestsHistory: List<TimeSeriesPoint>,
    // Same exception again, for WorkingLoadUpMeter/WorkingLoadDownMeter's
    // own paired MiniSparklines - see IperfViewModel.
    // workingLoadUpHistoryFlow/workingLoadDownHistoryFlow's own doc
    // comment. BOUNCEBACK + workingLoadEnabled only, so empty otherwise.
    val workingLoadUpHistory: List<TimeSeriesPoint>,
    val workingLoadDownHistory: List<TimeSeriesPoint>,
    // Same "not just the final min/avg/max" exception as sparklineHistory
    // above, for RttFloorChart (TCP and UDP-L4S both, not BOUNCEBACK-only
    // like sparklineHistory) - see IperfViewModel.rttHistoryFlow's own doc
    // comment.
    val rttHistory: List<Timestamped<RttHistoryPoint>>,
    // Same exception again, for the MiniSparkline paired beside the
    // (compact) Throughput/CE Duration dials - see IperfViewModel.
    // throughputHistoryFlow/ceDurationHistoryFlow's own doc comments.
    // ceDurationHistory is empty for TCP runs (never populated there);
    // writeTimeHistory/retryHistory are TCP-only, so empty for the other
    // modes instead.
    val throughputHistory: List<TimeSeriesPoint>,
    val ceDurationHistory: List<TimeSeriesPoint>,
    val writeTimeHistory: List<TimeSeriesPoint>,
    val retryHistory: List<TimeSeriesPoint>,
    // Same exception again, for BytesInFlightMeter's own combined CWND/
    // inFlight/NotSent mini chart - see IperfViewModel.
    // cwndInflightHistoryFlow's own doc comment. TCP-only, so empty for
    // the other modes.
    val cwndInflightHistory: List<Timestamped<CwndInflightPoint>>,
    // UDP-L4S counterparts to the TCP-only history fields above - see
    // IperfViewModel.windowInflightHistoryFlow/ppsHistoryFlow/
    // ceMarksPerSecHistoryFlow/markProbHistoryFlow/lossPercentHistoryFlow's
    // own doc comments. Empty for TCP/BOUNCEBACK runs.
    val windowInflightHistory: List<Timestamped<WindowInflightPoint>>,
    val ppsHistory: List<TimeSeriesPoint>,
    val ceMarksPerSecHistory: List<TimeSeriesPoint>,
    val markProbHistory: List<TimeSeriesPoint>,
    val lossPercentHistory: List<TimeSeriesPoint>,
)
