package com.rjmcmahon.iperf2client.runner

import android.content.Context
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/**
 * Probes which TCP congestion control algorithms this device's kernel
 * actually supports, by invoking the bundled iperf2 binary itself against an
 * unreachable loopback port. setCongestionControl() (Settings.cpp:1461)
 * applies the sockopt right after the socket is created, before connect() is
 * even attempted, so the probe never needs a reachable target and each one
 * finishes in well under a second (confirmed: ~0.1-0.2s for a valid
 * algorithm, ~1.2s for an invalid one that has to fail the sockopt first).
 *
 * This exists because Android's SELinux policy blocks apps (and even the
 * shell domain) from reading /proc/sys/net/ipv4/tcp_available_congestion_control
 * directly, even though the DAC permissions on that file are world-readable -
 * confirmed via `run-as` returning "Permission denied" on it. The sockopt
 * itself is not similarly restricted, so probing by attempting it is the
 * only reliable way to find out what's actually usable.
 */
object CcaProbe {
    private const val PROBE_PORT = 1 // nothing listens here; connect() fails fast either way

    // Probed concurrently - a failing candidate takes ~1.2s (has to fail the
    // sockopt before erroring) vs ~0.1-0.2s for a valid one, so running the
    // full candidate list serially would make app startup noticeably slower.
    suspend fun availableAlgorithms(context: Context, candidates: List<String>): List<String> = coroutineScope {
        val binary = IperfCommandBuilder.binaryPath(context)
        val results = candidates.map { name -> async(Dispatchers.IO) { name to isAvailable(binary, name) } }.awaitAll()
        results.filter { (_, available) -> available }.map { (name, _) -> name }
    }

    private fun isAvailable(binaryPath: String, name: String): Boolean = try {
        val proc = ProcessBuilder(
            binaryPath, "--client", "127.0.0.1", "--port", PROBE_PORT.toString(), "--time", "1", "--cca", name,
        ).redirectErrorStream(true).start()
        val output = proc.inputStream.bufferedReader().readText()
        proc.waitFor(3, TimeUnit.SECONDS)
        !output.contains("congestion control failed")
    } catch (e: Exception) {
        false
    }
}
