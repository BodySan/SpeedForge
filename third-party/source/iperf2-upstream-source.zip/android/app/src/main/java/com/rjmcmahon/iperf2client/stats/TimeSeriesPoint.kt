package com.rjmcmahon.iperf2client.stats

// One interval's raw reading plus its own real elapsed time (the CSV row's
// own intervalEndSecs, ground truth from iperf2 itself) - for every
// MiniSparkline-backed history (throughput, CE duration, write-block time,
// retries, packets/sec, CE marks/sec, marking probability, loss
// probability).
//
// value is nullable - a timestamped null, appended once per real sample
// (every real CSV row, unconditionally) whenever that particular field
// wasn't actually available this interval (e.g. UDP-L4S's CE duration
// before the first CE-marked packet). iperf2's own CSV output already
// gives every interval a fixed-position field and a real timestamp
// regardless of whether that field has a value yet (see
// CsvLineParser's field-count check, which discards a malformed row
// wholesale, not a single missing field) - a null here preserves that,
// rather than silently omitting the interval from this history entirely
// the way an earlier version of this ingest code did. Charts break the
// line across a null instead of interpolating a straight line through a
// genuinely missing stretch, which would otherwise misrepresent a
// two widely-separated readings as continuous data.
data class TimeSeriesPoint(val value: Double?, val elapsedSecs: Double)
