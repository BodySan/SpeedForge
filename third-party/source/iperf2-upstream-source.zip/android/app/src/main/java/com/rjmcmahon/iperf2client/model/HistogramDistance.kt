package com.rjmcmahon.iperf2client.model

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Distribution-shape comparison stats for [BounceBackHistogram].
 *
 * [emdAgainstReference] is the one actually shown in the app's own UI
 * (BounceBackHistogramChart's "EMD vs golden" line) - Earth Mover's
 * Distance (1D Wasserstein-1) against a user-saved "golden" baseline (see
 * GoldenHistogramStore). The native side already computes this once, live,
 * at the end of a run whose --histogram-baseline was configured up front
 * (IperfCommandBuilder), and that frozen value is what
 * [BounceBackHistogram.emdVsBaseline] holds - but a saved A/B/C/D preset's
 * own frozen value goes stale the moment a *newer* golden is saved after
 * that preset was captured (comparing A/B/C/D against golden, not just
 * A against B, means each one needs to be re-measured against whatever's
 * *currently* golden, not whatever was golden when it was recorded).
 * [emdAgainstReference] recomputes that same distance in Kotlin, on
 * demand, for any histogram - live or a saved preset - against the
 * current golden reference, using the exact same CDF-integral identity as
 * histogram_emd() (src/histogram.c): W1(P,Q) = integral over the real
 * line of |F_P(x) - F_Q(x)| dx, computed exactly (no numerical-integration
 * error) as a sum of rectangle areas between consecutive points on the
 * union of both distributions' own bin edges.
 *
 * [ksAgainstLogNormal]/[ksAgainstReference] are a second, currently-unused-
 * in-the-UI pair of Kolmogorov-Smirnov comparisons, kept for the same
 * "does this run's shape look normal" question EMD-against-golden doesn't
 * answer on its own (a run can be a large EMD from golden while still
 * being an unremarkable, healthy-looking distribution in its own right,
 * or vice versa) - [ksAgainstLogNormal] against a log-normal fit to this
 * histogram's own data (not a plain Gaussian - RTT is inherently
 * right-skewed, bounded below by the physical minimum propagation delay,
 * unbounded above by queueing/retransmission, so a Gaussian reference
 * would read as "abnormal" on essentially every healthy run) rather than
 * a saved reference, so it's always available with no golden needed.
 *
 * All three operate on the histogram's own binned counts, not raw samples
 * (all iperf2 ever sends off-device is the histogram) - the empirical CDF
 * is a step function evaluated at each bin's own upper edge. This is the
 * standard grouped-data approximation of these statistics, accurate to
 * within one bin width of the true continuous-sample value.
 */

// Abramowitz & Stegun 7.1.26 - maximum error 1.5e-7, well within what a
// shape-comparison stat that's already only accurate to one bin width
// (see this file's own doc comment) needs.
private fun erf(x: Double): Double {
    val sign = if (x < 0) -1.0 else 1.0
    val ax = abs(x)
    val t = 1.0 / (1.0 + 0.3275911 * ax)
    val y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * exp(-ax * ax)
    return sign * y
}

private fun normalCdf(x: Double, mean: Double, stdev: Double): Double {
    if (stdev <= 0.0) return if (x < mean) 0.0 else 1.0
    return 0.5 * (1.0 + erf((x - mean) / (stdev * sqrt(2.0))))
}

/** Fraction of this histogram's samples at or below [xMs]. */
private fun BounceBackHistogram.empiricalCdf(xMs: Double): Double {
    if (totalCount <= 0) return 0.0
    var cumulative = 0
    for (bin in bins) {
        val upperEdgeMs = bin.binNumber * binWidthUs / 1000.0
        if (upperEdgeMs > xMs) break
        cumulative += bin.count
    }
    return cumulative.toDouble() / totalCount
}

/** Every populated bin's own upper-edge latency (ms) - the x-grid a comparison evaluates on. */
private fun BounceBackHistogram.binEdgesMs(): List<Double> = bins.map { it.binNumber * binWidthUs / 1000.0 }

/**
 * Two-sample Earth Mover's Distance between this histogram and
 * [reference] - see this file's own doc comment for why this (not the
 * KS pair below) is the metric the app's own UI shows, and why it's
 * recomputed here in Kotlin rather than only ever trusting the native
 * side's own frozen [BounceBackHistogram.emdVsBaseline]. Evaluated on the
 * union of both histograms' own bin edges (their binWidthUs can differ
 * between runs, so the two step functions don't already share a grid) -
 * unlike [ksAgainstReference] below, order matters here (this is an
 * integral over consecutive segments, not a plain max), so the merged
 * grid is explicitly sorted first. Null if either histogram has no
 * samples.
 *
 * [fromMs] restricts the integral to [fromMs, +inf) instead of the whole
 * range - since EMD is a plain definite integral, splitting the domain
 * at any point x0 gives an *exact* decomposition:
 * emdAgainstReference(ref) == emdAgainstReference(ref, x0) + (the same
 * call restricted to [0, x0], i.e. the two pieces sum back to the whole).
 * Used to isolate a "tail EMD" (BounceBackHistogramChart's own tail
 * stat/zoom) - how much of the total distance is coming from the slow
 * tail specifically, in the same ms units as the whole-range number, not
 * a separately-scaled or otherwise incomparable metric.
 */
fun BounceBackHistogram.emdAgainstReference(reference: BounceBackHistogram, fromMs: Double = 0.0): Double? {
    if (totalCount <= 0 || reference.totalCount <= 0) return null
    val grid = (binEdgesMs() + reference.binEdgesMs()).filter { it > fromMs }.distinct().sorted()
    if (grid.isEmpty()) return 0.0
    var emd = 0.0
    var prevX = fromMs
    grid.forEach { x ->
        val diff = abs(empiricalCdf(prevX) - reference.empiricalCdf(prevX))
        emd += diff * (x - prevX)
        prevX = x
    }
    return emd
}

/**
 * This histogram's own weighted mean latency (ms) - used only to give
 * [emdAgainstReference] a shift *direction* in the app's own UI
 * ("EMD vs golden: +0.245 ms" vs "-0.245 ms"). EMD itself is a magnitude
 * with no natural sign (it's an integral of an absolute difference, always
 * >= 0) - but for 1D distributions, the *signed* counterpart of that same
 * CDF-integral identity (dropping the absolute value) always equals
 * exactly meanA - meanB, a standard identity of the equivalent quantile/
 * inverse-CDF formulation of Wasserstein-1. Its magnitude is always <= the
 * true unsigned EMD (equal only when the two CDFs never cross, i.e. one
 * run is uniformly faster/slower than the other across the whole
 * distribution) - so meanA - meanB is a real, principled proxy for "which
 * way did this shift", not an arbitrary heuristic. Null if there are no
 * samples.
 */
fun BounceBackHistogram.meanMs(): Double? {
    if (totalCount <= 0) return null
    var sum = 0.0
    bins.forEach { bin -> sum += binMidpointMs(bin.binNumber) * bin.count }
    return sum / totalCount
}

/**
 * KS distance against a log-normal fit to this histogram's own weighted
 * mean/variance of log(latency) - see this file's own doc comment for why
 * log-normal rather than Gaussian. Null if there's not enough data to fit
 * a distribution from (fewer than 2 samples, or every sample landed in one
 * bin - a fitted sigma of 0 makes "distance from a point mass" meaningless
 * rather than 0).
 */
fun BounceBackHistogram.ksAgainstLogNormal(): Double? {
    if (totalCount < 2 || bins.isEmpty()) return null
    var sumLog = 0.0
    var sumLogSq = 0.0
    bins.forEach { bin ->
        val logMs = ln(binMidpointMs(bin.binNumber).coerceAtLeast(1e-6))
        sumLog += logMs * bin.count
        sumLogSq += logMs * logMs * bin.count
    }
    val n = totalCount.toDouble()
    val meanLog = sumLog / n
    val varianceLog = (sumLogSq / n) - (meanLog * meanLog)
    if (varianceLog <= 0.0) return null
    val sigma = sqrt(varianceLog * n / (n - 1))
    var maxDiff = 0.0
    binEdgesMs().forEach { xMs ->
        val empirical = empiricalCdf(xMs)
        val fitted = normalCdf(ln(xMs.coerceAtLeast(1e-6)), meanLog, sigma)
        maxDiff = max(maxDiff, abs(empirical - fitted))
    }
    return maxDiff
}

/**
 * Two-sample KS distance between this histogram and [reference] - the
 * largest absolute gap between the two empirical CDFs, evaluated at the
 * union of both histograms' own bin edges. Order doesn't matter here
 * (unlike [emdAgainstReference] above) since this is a plain max over all
 * grid points, not an integral. Null if either histogram has no samples.
 */
fun BounceBackHistogram.ksAgainstReference(reference: BounceBackHistogram): Double? {
    if (totalCount <= 0 || reference.totalCount <= 0) return null
    val grid = (binEdgesMs() + reference.binEdgesMs()).distinct()
    var maxDiff = 0.0
    grid.forEach { xMs ->
        maxDiff = max(maxDiff, abs(empiricalCdf(xMs) - reference.empiricalCdf(xMs)))
    }
    return maxDiff
}
