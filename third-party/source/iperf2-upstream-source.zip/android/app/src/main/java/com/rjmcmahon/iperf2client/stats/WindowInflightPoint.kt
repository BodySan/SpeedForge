package com.rjmcmahon.iperf2client.stats

// One UDP-L4S interval's Window/inFlight/Queued snapshot (pkts), for
// BytesInFlightMeter's own combined mini time-series chart paired beside
// that bar - the UDP-L4S counterpart to CwndInflightPoint (see that data
// class's own doc comment for why an atomic triple, appended only when all
// three are available, beats three independently-guarded history buffers).
// Always packets, regardless of TestConfig.queueUnitsPackets - see
// queuePacketsForStackValue's own doc comment (BytesInFlightMeter) for why
// the bar's own fill (and so this chart) needs a dimensionally consistent
// unit regardless of what the bar's text displays.
// No elapsedSecs field here - windowInflightHistoryFlow wraps this in
// Timestamped<WindowInflightPoint> instead - see that data class's and
// RttHistoryPoint's own doc comments for why the timestamp lives at the
// wrapper level, not on the point itself.
data class WindowInflightPoint(val windowPkts: Double, val inflightPkts: Double, val queuedPkts: Double)
