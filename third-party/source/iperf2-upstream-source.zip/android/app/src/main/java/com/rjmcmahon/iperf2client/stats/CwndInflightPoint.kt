package com.rjmcmahon.iperf2client.stats

// One TCP interval's CWND/inFlight/NotSent snapshot (KB), for
// BytesInFlightMeter's own combined mini time-series chart paired beside
// that bar - same "raw per-interval point, not windowed" convention as
// RttHistoryPoint. All three fields come from the same interval's sample
// (gettcpinfo(), see Client::WriteTcpTxHdr/Server::RunTCP) and are only
// appended together when all three are actually available, rather than each
// getting its own independently-guarded history buffer - keeps the three
// lines meaningfully aligned in time instead of silently drifting apart
// whenever one field's own -1 "not available" sentinel fires on a
// different interval than the others.
// No elapsedSecs field here - cwndInflightHistoryFlow wraps this in
// Timestamped<CwndInflightPoint> instead - see that data class's and
// RttHistoryPoint's own doc comments for why the timestamp lives at the
// wrapper level, not on the point itself.
data class CwndInflightPoint(val cwndKB: Double, val inFlightKB: Double, val notSentKB: Double)
