package com.rjmcmahon.iperf2client.runner

import android.content.Context
import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import com.rjmcmahon.iperf2client.model.HistogramBin
import com.rjmcmahon.iperf2client.model.MeterStats
import com.rjmcmahon.iperf2client.model.RunSnapshot
import com.rjmcmahon.iperf2client.model.TestConfig
import com.rjmcmahon.iperf2client.stats.CwndInflightPoint
import com.rjmcmahon.iperf2client.stats.RttHistoryPoint
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.WindowInflightPoint
import com.rjmcmahon.iperf2client.stats.WindowedSnapshot
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists the *results* half of an A/B/C/D preset slot - every *Stats/
 * history/histogram field [RunSnapshot] carries - as a sibling to
 * [TestConfigStore]'s own config-only persistence. TestConfigStore
 * deliberately stops at config (see its own doc comment: "re-running is
 * what repopulates its charts"), which meant a technician who saved a slot,
 * then closed the app for any reason (backgrounded and reclaimed under
 * memory pressure, a phone reboot, a crash) came back to every chart reset
 * to "Waiting for data…" with nothing left to compare until they re-ran the
 * whole test. This closes that gap: one JSON file per slot (org.json - part
 * of the Android platform, no new dependency), written every time
 * IperfViewModel.saveCurrentAs() writes the config half via TestConfigStore,
 * read back at the same point IperfViewModel.loadPresetSnapshot() reads
 * TestConfigStore's own config half.
 *
 * [config]/[savedAtMillis] are passed in rather than re-persisted here -
 * they're already TestConfigStore's job, and a slot with a config but no (or
 * an unparseable) results file should still show *something* useful, so
 * [load] returns null on any failure and the caller falls back to the
 * existing stats-null placeholder rather than losing the slot entirely. A
 * results file going stale/incompatible across an app upgrade (a future
 * version adding a field this one doesn't know about, or vice versa) is
 * harmless to just drop; losing the config would lose the point of the slot.
 */
object RunSnapshotStore {
    private fun file(context: Context, slot: Char): File = File(context.filesDir, "preset_${slot}_results.json")

    fun clear(context: Context, slot: Char) {
        file(context, slot).delete()
    }

    fun save(context: Context, slot: Char, snapshot: RunSnapshot) {
        val json = JSONObject()
        json.putStats("throughputStats", snapshot.throughputStats)
        json.putStats("rttStats", snapshot.rttStats)
        json.putStats("inFlightStats", snapshot.inFlightStats)
        json.putStats("packetsInFlightStats", snapshot.packetsInFlightStats)
        json.putStats("cwndStats", snapshot.cwndStats)
        json.putStats("retryStats", snapshot.retryStats)
        json.putStats("notSentStats", snapshot.notSentStats)
        json.putStats("tcpExcessRttStats", snapshot.tcpExcessRttStats)
        json.putStats("sndBufStats", snapshot.sndBufStats)
        json.putStats("writeTimeStats", snapshot.writeTimeStats)
        json.putStats("sndBufLimitedStats", snapshot.sndBufLimitedStats)
        json.putStats("rwndLimitedStats", snapshot.rwndLimitedStats)
        json.putStats("busyTimeStats", snapshot.busyTimeStats)
        json.putStats("flowingStats", snapshot.flowingStats)
        json.putStats("ceMarksStats", snapshot.ceMarksStats)
        json.putStats("ceMarksWhenMarkingStats", snapshot.ceMarksWhenMarkingStats)
        json.putStats("queueDelayStats", snapshot.queueDelayStats)
        json.putStats("queueBytesStats", snapshot.queueBytesStats)
        json.putStats("queuePacketsStats", snapshot.queuePacketsStats)
        json.putStats("l4sRttStats", snapshot.l4sRttStats)
        json.putStats("l4sPacketWindowStats", snapshot.l4sPacketWindowStats)
        json.putStats("l4sInflightStats", snapshot.l4sInflightStats)
        json.putStats("l4sMarkingProbStats", snapshot.l4sMarkingProbStats)
        json.putStats("errPercentStats", snapshot.errPercentStats)
        json.putStats("bbRequestsStats", snapshot.bbRequestsStats)
        json.putStats("workingLoadUpStats", snapshot.workingLoadUpStats)
        json.putStats("workingLoadDownStats", snapshot.workingLoadDownStats)

        snapshot.bbHistogram?.let { json.put("bbHistogram", it.toJson()) }
        snapshot.bbRttMinUs?.let { json.put("bbRttMinUs", it) }
        snapshot.bbHistogramRawLine?.let { json.put("bbHistogramRawLine", it) }

        json.putTimestamped("sparklineHistory", snapshot.sparklineHistory, ::windowedSnapshotToJson)
        json.putSeries("bbRequestsHistory", snapshot.bbRequestsHistory)
        json.putSeries("workingLoadUpHistory", snapshot.workingLoadUpHistory)
        json.putSeries("workingLoadDownHistory", snapshot.workingLoadDownHistory)
        json.putTimestamped("rttHistory", snapshot.rttHistory, ::rttPointToJson)
        json.putSeries("throughputHistory", snapshot.throughputHistory)
        json.putSeries("ceDurationHistory", snapshot.ceDurationHistory)
        json.putSeries("writeTimeHistory", snapshot.writeTimeHistory)
        json.putSeries("retryHistory", snapshot.retryHistory)
        json.putTimestamped("cwndInflightHistory", snapshot.cwndInflightHistory, ::cwndPointToJson)
        json.putTimestamped("windowInflightHistory", snapshot.windowInflightHistory, ::windowInflightPointToJson)
        json.putSeries("ppsHistory", snapshot.ppsHistory)
        json.putSeries("ceMarksPerSecHistory", snapshot.ceMarksPerSecHistory)
        json.putSeries("markProbHistory", snapshot.markProbHistory)
        json.putSeries("lossPercentHistory", snapshot.lossPercentHistory)

        file(context, slot).writeText(json.toString())
    }

    /** Null on any missing/unparseable file - see this object's own doc comment for why that's the right fallback. */
    fun load(context: Context, slot: Char, config: TestConfig, savedAtMillis: Long): RunSnapshot? {
        val f = file(context, slot)
        if (!f.exists()) return null
        return runCatching {
            val json = JSONObject(f.readText())
            RunSnapshot(
                config = config,
                savedAtMillis = savedAtMillis,
                throughputStats = json.optStats("throughputStats"),
                rttStats = json.optStats("rttStats"),
                inFlightStats = json.optStats("inFlightStats"),
                packetsInFlightStats = json.optStats("packetsInFlightStats"),
                cwndStats = json.optStats("cwndStats"),
                retryStats = json.optStats("retryStats"),
                notSentStats = json.optStats("notSentStats"),
                tcpExcessRttStats = json.optStats("tcpExcessRttStats"),
                sndBufStats = json.optStats("sndBufStats"),
                writeTimeStats = json.optStats("writeTimeStats"),
                sndBufLimitedStats = json.optStats("sndBufLimitedStats"),
                rwndLimitedStats = json.optStats("rwndLimitedStats"),
                busyTimeStats = json.optStats("busyTimeStats"),
                flowingStats = json.optStats("flowingStats"),
                ceMarksStats = json.optStats("ceMarksStats"),
                ceMarksWhenMarkingStats = json.optStats("ceMarksWhenMarkingStats"),
                queueDelayStats = json.optStats("queueDelayStats"),
                queueBytesStats = json.optStats("queueBytesStats"),
                queuePacketsStats = json.optStats("queuePacketsStats"),
                l4sRttStats = json.optStats("l4sRttStats"),
                l4sPacketWindowStats = json.optStats("l4sPacketWindowStats"),
                l4sInflightStats = json.optStats("l4sInflightStats"),
                l4sMarkingProbStats = json.optStats("l4sMarkingProbStats"),
                errPercentStats = json.optStats("errPercentStats"),
                bbRequestsStats = json.optStats("bbRequestsStats"),
                bbHistogram = json.optJSONObject("bbHistogram")?.let(::jsonToHistogram),
                bbRttMinUs = if (json.has("bbRttMinUs")) json.getLong("bbRttMinUs") else null,
                bbHistogramRawLine = if (json.has("bbHistogramRawLine")) json.getString("bbHistogramRawLine") else null,
                workingLoadUpStats = json.optStats("workingLoadUpStats"),
                workingLoadDownStats = json.optStats("workingLoadDownStats"),
                sparklineHistory = json.getTimestamped("sparklineHistory", ::jsonToWindowedSnapshot),
                bbRequestsHistory = json.getSeries("bbRequestsHistory"),
                workingLoadUpHistory = json.getSeries("workingLoadUpHistory"),
                workingLoadDownHistory = json.getSeries("workingLoadDownHistory"),
                rttHistory = json.getTimestamped("rttHistory", ::jsonToRttPoint),
                throughputHistory = json.getSeries("throughputHistory"),
                ceDurationHistory = json.getSeries("ceDurationHistory"),
                writeTimeHistory = json.getSeries("writeTimeHistory"),
                retryHistory = json.getSeries("retryHistory"),
                cwndInflightHistory = json.getTimestamped("cwndInflightHistory", ::jsonToCwndPoint),
                windowInflightHistory = json.getTimestamped("windowInflightHistory", ::jsonToWindowInflightPoint),
                ppsHistory = json.getSeries("ppsHistory"),
                ceMarksPerSecHistory = json.getSeries("ceMarksPerSecHistory"),
                markProbHistory = json.getSeries("markProbHistory"),
                lossPercentHistory = json.getSeries("lossPercentHistory"),
            )
        }.getOrNull()
    }
}

private fun JSONObject.putStats(key: String, stats: MeterStats?) {
    if (stats == null) return
    put(key, JSONObject().apply { put("min", stats.min); put("avg", stats.avg); put("max", stats.max) })
}

private fun JSONObject.optStats(key: String): MeterStats? {
    val o = optJSONObject(key) ?: return null
    return MeterStats(min = o.getDouble("min"), avg = o.getDouble("avg"), max = o.getDouble("max"))
}

/** [TimeSeriesPoint.value] omitted entirely (rather than written as JSON null) when null - org.json's null handling is easy to get wrong across put/opt, so absence-of-key is the one signal used throughout this file for "no value at this point." */
private fun JSONObject.putSeries(key: String, points: List<TimeSeriesPoint>) {
    val arr = JSONArray()
    points.forEach { p ->
        arr.put(JSONObject().apply { p.value?.let { put("v", it) }; put("t", p.elapsedSecs) })
    }
    put(key, arr)
}

private fun JSONObject.getSeries(key: String): List<TimeSeriesPoint> {
    val arr = optJSONArray(key) ?: return emptyList()
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        TimeSeriesPoint(value = if (o.has("v")) o.getDouble("v") else null, elapsedSecs = o.getDouble("t"))
    }
}

/** Generic [Timestamped] list codec - [valueToJson]/[jsonToValue] supply the one per-type mapping, same "absent key means null value" convention as [putSeries]/[getSeries] above. */
private fun <T> JSONObject.putTimestamped(key: String, points: List<Timestamped<T>>, valueToJson: (T) -> JSONObject) {
    val arr = JSONArray()
    points.forEach { t ->
        val o = t.value?.let(valueToJson) ?: JSONObject()
        o.put("t", t.elapsedSecs)
        arr.put(o)
    }
    put(key, arr)
}

private fun <T> JSONObject.getTimestamped(key: String, jsonToValue: (JSONObject) -> T?): List<Timestamped<T>> {
    val arr = optJSONArray(key) ?: return emptyList()
    return (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        Timestamped(value = jsonToValue(o), elapsedSecs = o.getDouble("t"))
    }
}

private fun windowedSnapshotToJson(s: WindowedSnapshot) = JSONObject().apply {
    put("mean", s.mean); put("stdev", s.stdev); put("min", s.min); put("max", s.max)
    put("count", s.count); put("maxZ", s.maxZScore)
}

private fun jsonToWindowedSnapshot(o: JSONObject): WindowedSnapshot? {
    if (!o.has("mean")) return null
    return WindowedSnapshot(
        mean = o.getDouble("mean"), stdev = o.getDouble("stdev"), min = o.getDouble("min"),
        max = o.getDouble("max"), count = o.getInt("count"), maxZScore = o.getDouble("maxZ"),
    )
}

private fun rttPointToJson(p: RttHistoryPoint) = JSONObject().apply {
    put("rtt", p.currentRttMs); put("rttMin", p.rttMinMs)
}

private fun jsonToRttPoint(o: JSONObject): RttHistoryPoint? {
    if (!o.has("rtt")) return null
    return RttHistoryPoint(currentRttMs = o.getDouble("rtt"), rttMinMs = o.getDouble("rttMin"))
}

private fun cwndPointToJson(p: CwndInflightPoint) = JSONObject().apply {
    put("cwnd", p.cwndKB); put("inflight", p.inFlightKB); put("notSent", p.notSentKB)
}

private fun jsonToCwndPoint(o: JSONObject): CwndInflightPoint? {
    if (!o.has("cwnd")) return null
    return CwndInflightPoint(cwndKB = o.getDouble("cwnd"), inFlightKB = o.getDouble("inflight"), notSentKB = o.getDouble("notSent"))
}

private fun windowInflightPointToJson(p: WindowInflightPoint) = JSONObject().apply {
    put("window", p.windowPkts); put("inflight", p.inflightPkts); put("queued", p.queuedPkts)
}

private fun jsonToWindowInflightPoint(o: JSONObject): WindowInflightPoint? {
    if (!o.has("window")) return null
    return WindowInflightPoint(windowPkts = o.getDouble("window"), inflightPkts = o.getDouble("inflight"), queuedPkts = o.getDouble("queued"))
}

private fun BounceBackHistogram.toJson(): JSONObject = JSONObject().apply {
    put("binWidthUs", binWidthUs)
    put("totalCount", totalCount)
    put("bins", JSONArray().apply { bins.forEach { b -> put(JSONObject().apply { put("n", b.binNumber); put("c", b.count) }) } })
    put("ciLowerPercent", ciLowerPercent)
    put("ciUpperPercent", ciUpperPercent)
    put("ciLowerBin", ciLowerBin)
    put("ciUpperBin", ciUpperBin)
    put("p999Bin", p999Bin)
    put("outlierCount", outlierCount)
    put("oobLower", oobLower)
    put("oobUpper", oobUpper)
    put("name", name)
    emdVsBaseline?.let { put("emdVsBaseline", it) }
}

private fun jsonToHistogram(o: JSONObject): BounceBackHistogram {
    val binsArr = o.getJSONArray("bins")
    val bins = (0 until binsArr.length()).map { i ->
        val b = binsArr.getJSONObject(i)
        HistogramBin(binNumber = b.getInt("n"), count = b.getInt("c"))
    }
    return BounceBackHistogram(
        binWidthUs = o.getDouble("binWidthUs"),
        totalCount = o.getInt("totalCount"),
        bins = bins,
        ciLowerPercent = o.getDouble("ciLowerPercent"),
        ciUpperPercent = o.getDouble("ciUpperPercent"),
        ciLowerBin = o.getInt("ciLowerBin"),
        ciUpperBin = o.getInt("ciUpperBin"),
        p999Bin = o.getInt("p999Bin"),
        outlierCount = o.getInt("outlierCount"),
        oobLower = o.getInt("oobLower"),
        oobUpper = o.getInt("oobUpper"),
        name = o.getString("name"),
        emdVsBaseline = if (o.has("emdVsBaseline")) o.getDouble("emdVsBaseline") else null,
    )
}
