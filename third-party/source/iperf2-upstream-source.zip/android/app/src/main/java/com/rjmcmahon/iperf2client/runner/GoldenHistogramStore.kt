package com.rjmcmahon.iperf2client.runner

import android.content.Context
import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import java.io.File

/**
 * Persists a single "golden" BOUNCEBACK histogram CSV row across app
 * restarts - the file --histogram-baseline points the native client at on
 * every subsequent BOUNCEBACK run (see IperfCommandBuilder), so it can
 * compute this run's own Earth Mover's Distance against it natively (see
 * histogram_emd_against_baseline(), src/histogram.c). Deliberately a
 * single file, not a history - "the" golden run, overwritten each time a
 * new one is saved (see IperfViewModel.saveGoldenHistogram()'s own doc
 * comment for why this is a dedicated user-driven action, not something
 * the app decides on its own).
 *
 * The saved content is the exact raw CSV line the native binary itself
 * printed (see IperfViewModel._bbHistogramRawLine's own doc comment) -
 * this app never reformats it, since histogram_emd_against_baseline()'s
 * own file parser expects exactly the shape histogram_print_csv() itself
 * produces.
 */
object GoldenHistogramStore {
    private const val FILE_NAME = "golden_bb_histogram.csv"

    fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    fun exists(context: Context): Boolean = file(context).exists()

    fun save(context: Context, rawCsvLine: String) {
        file(context).writeText(rawCsvLine.trim() + "\n")
    }

    fun clear(context: Context) {
        file(context).delete()
    }

    /**
     * Parses the saved file back into a [BounceBackHistogram] - reusing
     * [CsvLineParser.parseBounceBackHistogram] on the exact same raw text
     * [save] wrote, since it's already the identical row shape that
     * function expects. Null if nothing's been saved yet, or the file
     * doesn't parse (e.g. hand-edited/corrupted). Used app-side by
     * HistogramDistance.emdAgainstReference to recompute EMD on demand for
     * whatever histogram is currently being viewed - see that function's
     * own doc comment for why the native side's own frozen
     * [BounceBackHistogram.emdVsBaseline] alone isn't enough once a saved
     * A/B/C/D preset can be viewed well after it was captured.
     */
    fun load(context: Context): BounceBackHistogram? {
        val f = file(context)
        if (!f.exists()) return null
        return CsvLineParser.parseBounceBackHistogram(f.readText())
    }

    /**
     * The saved file's own raw text, trimmed the same way [save] trims its
     * own input before writing - used app-side (IperfScreen's isGoldenSaved)
     * to tell whether whatever's currently being viewed (live or an A/B/C/D
     * preset) *is* the golden reference, by comparing this against that
     * view's own IperfViewModel.bbHistogramRawLine/RunSnapshot.
     * bbHistogramRawLine. A parsed-vs-parsed [BounceBackHistogram] equality
     * check would work too, but comparing the exact original bytes is
     * simpler and can't be fooled by two different runs that happen to
     * parse to the same bin counts.
     */
    fun loadRaw(context: Context): String? {
        val f = file(context)
        if (!f.exists()) return null
        return f.readText().trim()
    }

    private const val SOURCE_SLOT_FILE_NAME = "golden_bb_histogram_slot.txt"
    private fun sourceSlotFile(context: Context): File = File(context.filesDir, SOURCE_SLOT_FILE_NAME)

    /**
     * Which A/B/C/D preset (IperfViewModel.promoteSlotToGolden) was
     * explicitly promoted to be the golden reference - the single source
     * of truth RunCompareTabs' own star uses, rather than comparing raw
     * bytes against every slot ([loadRaw] above). A byte comparison sounds
     * equivalent but isn't: if two different slots ever end up holding
     * byte-identical data (e.g. two "hold to save" gestures both
     * capturing the same still-live run before a fresh test actually ran),
     * a byte comparison would star *both* of them at once, breaking the
     * "only ever one reference" invariant this app promises. Explicit
     * designation can't do that - exactly one slot (or none) is ever
     * recorded here, independent of what any slot's own bytes happen to
     * contain. Null clears it (no argument overload - see
     * IperfViewModel.promoteSlotToGolden/clearGoldenSlot for the two call
     * sites, save vs clear, rather than one ambiguous nullable setter).
     */
    fun saveSourceSlot(context: Context, slot: Char) {
        sourceSlotFile(context).writeText(slot.toString())
    }

    fun clearSourceSlot(context: Context) {
        sourceSlotFile(context).delete()
    }

    fun loadSourceSlot(context: Context): Char? {
        val f = sourceSlotFile(context)
        if (!f.exists()) return null
        return f.readText().trim().firstOrNull()
    }
}
