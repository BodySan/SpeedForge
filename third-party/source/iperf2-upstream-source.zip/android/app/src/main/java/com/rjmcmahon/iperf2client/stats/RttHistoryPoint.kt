package com.rjmcmahon.iperf2client.stats

// One interval's {current, floor} RTT pair, in ms - the raw ingredients
// behind IperfViewModel's rttHistoryFlow (see that property's own doc
// comment for the TCP/UDP-L4S source formulas). Unlike WindowedSnapshot
// above, this isn't a windowed/smoothed aggregate - each point is one
// already-kernel/PragueCC-smoothed interval reading, plotted as-is.
//
// No elapsedSecs field here - rttHistoryFlow wraps this in
// Timestamped<RttHistoryPoint> instead (see that data class's own doc
// comment for why the timestamp lives at the wrapper level: RTT is only
// appended with a real value when both currentRttMs/rttMinMs are actually
// available this interval, but every real interval still gets an entry -
// a Timestamped with a null value - so a chart can tell "no RTT this
// interval" from "list ended here," same as TimeSeriesPoint's own nullable
// value does for single-field histories).
data class RttHistoryPoint(val currentRttMs: Double, val rttMinMs: Double)
