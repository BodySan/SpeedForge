package com.rjmcmahon.iperf2client

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Keeps this app's process - and the native iperf2 child process
 * IperfProcessRunner spawns inside it - exempt from Android's background
 * execution limits (the cached-app freezer/Doze CPU throttling) for the
 * duration of a run. Without this, backgrounding the app mid-test (screen
 * lock, switching to another app) eventually freezes the whole process:
 * IperfViewModel's own elapsed-time display (a lightweight wall-clock
 * coroutine) keeps ticking past the configured duration, but no further
 * interval samples arrive since the underlying subprocess itself is
 * frozen, and the run never reaches its own natural completion - no final
 * histogram, nothing. A foreground service (with this always-on
 * notification while it's active) is the standard, and effectively only
 * reliable, way to hold that exemption on modern Android.
 *
 * Does no work of its own - the actual test still runs entirely through
 * IperfViewModel/IperfProcessRunner. Started/stopped in lockstep with
 * IperfViewModel's own isRunning via its setRunning() helper, one call per
 * transition (never both foreground and stopped at once).
 */
class IperfForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Running test", NotificationManager.IMPORTANCE_LOW),
            )
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("iperf2 test running")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setSilent(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        return START_NOT_STICKY
    }

    private companion object {
        const val CHANNEL_ID = "iperf_running"
        const val NOTIFICATION_ID = 1
    }
}
