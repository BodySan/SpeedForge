package com.rjmcmahon.iperf2client.ui.theme

/**
 * SYSTEM (the default) follows the device's own dark-mode setting -
 * DARK/LIGHT are an explicit override via the sun/moon toggle
 * (IperfScreen's top bar), persisted by [ThemePreferenceStore] so it
 * survives process death the same way TestConfigStore's settings do.
 */
enum class ThemeMode { SYSTEM, LIGHT, DARK }
