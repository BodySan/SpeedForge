package com.rjmcmahon.iperf2client.ui.meters

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import kotlin.math.ceil
import kotlin.math.floor

private val AXIS_LABEL = Color(0xFFBDBDBD)

// How many multiples of the smallest observed inter-sample delta counts as
// a real dropout rather than ordinary reporting jitter - see the line-
// drawing loop's own doc comment below for the full reasoning. 1.75x
// tolerates a single interval occasionally running long (report timing
// isn't perfectly regular) while still catching a single fully-dropped
// sample (whose delta is ~2x nominal).
private const val GAP_MULTIPLIER = 1.75

/**
 * A small, undecorated per-interval line trace paired beside a compact
 * dial (see SpeedometerGauge's own `compact` param and IperfScreen's dial
 * rows) - lets a reader correlate this metric's own recent trend against
 * whatever's happening in the row above/below it, which a single dial
 * reading alone can't show. Deliberately minimal compared to LiveSparkline/
 * RttFloorChart: no windowed mean/stdev band (those chart a windowed
 * statistic's own spread; this charts raw per-interval values as-is, same
 * "no CLT-style justification needed" reasoning as rttHistory's own doc
 * comment, IperfViewModel) - but it still needs its own axis top/bottom
 * values and a current-reading callout (same as LiveSparkline's own ticks/
 * value text), otherwise the line's shape has no numbers to anchor it to
 * and reads as trend-only, not actually correlatable against another
 * metric's own differently-scaled chart. sized to the ~80% of a row width
 * (and its own taller 140dp height) that a 20%-wide dial gives up - this is
 * the thing people actually want to read the shape of, so it gets the bulk
 * of the row, not the dial.
 */
@Composable
fun MiniSparkline(
    values: List<TimeSeriesPoint>,
    color: Color,
    // Appended after every numeric label (axis top/bottom, current value) -
    // caller passes whatever unit the paired dial itself shows (e.g. "Mbps",
    // "ms"), so the two stay consistent at a glance.
    unit: String = "",
    // Small extra line pinned to the bottom-left corner, same convention as
    // RttFloorChart's own "RTT min" corner label - for a value related to
    // this chart's own plotted series but not itself part of it (e.g. Load
    // Delay's own MiniSparkline plots currentRttMs - rttMinMs; rttMinMs
    // itself isn't otherwise shown anywhere near this chart, so the caller
    // passes it here). Null (the default) omits the corner entirely.
    footnote: String? = null,
    // TestConfig.durationSecs - the run's configured total length, so the
    // time axis can span the *whole* test (fixed, known in advance) rather
    // than whatever's currently in `values`. -1 (or null) means "run until
    // Stop" - no known end, so the axis instead grows with elapsed time.
    // See this file's own xOf/axisSpanSecs doc comment below for why this
    // matters beyond just the axis label text.
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 11.sp.toPx() }
    val valueTextSizePx = with(density) { 13.sp.toPx() }
    val footnoteTextSizePx = with(density) { 10.sp.toPx() }
    val timeAxisTextSizePx = with(density) { 10.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            this.color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
        }
    }
    val footnotePaint = remember(footnoteTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            this.color = AXIS_LABEL.toArgb()
            textSize = footnoteTextSizePx
        }
    }
    val timeAxisLeftPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            this.color = AXIS_LABEL.toArgb()
            textSize = timeAxisTextSizePx
        }
    }
    val timeAxisRightPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            this.color = AXIS_LABEL.toArgb()
            textSize = timeAxisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }
    val valuePaint = remember(valueTextSizePx, color) {
        Paint().apply {
            isAntiAlias = true
            this.color = color.toArgb()
            textSize = valueTextSizePx
            textAlign = Paint.Align.RIGHT
            isFakeBoldText = true
        }
    }

    // A point's own value can be a timestamped null (see TimeSeriesPoint's
    // own doc comment - iperf2 gives every interval a real CSV row/timestamp
    // regardless of whether this particular field had a reading that
    // interval), so "enough to draw a chart" means enough *valid* readings,
    // not just enough timestamped slots.
    val validCount = values.count { it.value != null }

    Box(
        modifier = modifier.fillMaxWidth().height(140.dp).padding(top = 8.dp, start = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (validCount < 2) {
            Text(text = "Waiting for data…", style = MaterialTheme.typography.bodySmall)
        } else {
            val validValues = values.mapNotNull { it.value }
            val dataMin = validValues.min()
            val dataMax = validValues.max().coerceAtLeast(dataMin + 0.001)
            val pad = (dataMax - dataMin) * 0.1
            val rawMin = dataMin - pad
            val rawMax = dataMax + pad
            // Snapped to a "nice" 1/2/5/10x10^n step (niceAxisStep,
            // LiveSparkline.kt) rather than the raw padded min/max - a
            // reader doesn't need to see this chart's exact observed extreme
            // (e.g. "43.7") to read its trend, and a round axis (e.g.
            // "40"/"45") is what every other chart in this app already does
            // (RttFloorChart, CwndInflightChart/WindowInflightChart) - this
            // was the one holdout still showing raw values, per direct UI
            // feedback that they read as "weird" numbers.
            val axisStep = niceAxisStep(rawMax - rawMin)
            val axisMin = floor(rawMin / axisStep) * axisStep
            val axisMax = ceil(rawMax / axisStep) * axisStep

            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(color = Color.Black)

                // Reserve a bottom strip for the time-axis labels below,
                // so they never collide with the value-axis ticks/footnote
                // (both of which are free to land anywhere down to the
                // very bottom edge otherwise, since data commonly trends
                // toward one extreme).
                val bottomMarginPx = 14.dp.toPx()
                val plotHeight = size.height - bottomMarginPx

                fun yOf(v: Double): Float =
                    plotHeight - (((v - axisMin) / (axisMax - axisMin)).toFloat() * plotHeight)

                // axisSpanSecs is the *fixed* denominator every point's x
                // position is computed against - NOT values.size (a point
                // count), which grows every sample and used to force every
                // existing point to silently shift left each time a new one
                // arrived (worst right after a test starts, tapering off as
                // the buffer grew - "the left side shrinks slower"). For a
                // known-duration run it's the configured length (so the
                // axis - and every point's x - is stable and correct from
                // the very first sample, with the line simply growing
                // rightward to fill it by the run's end); maxOf'd with
                // actual elapsed time only to cover a rare overrun tail,
                // not as the normal driver. For "run until Stop"
                // (durationSecs null/-1, no known end), there's no fixed
                // span available, so it falls back to elapsed time - still
                // real seconds, just one that (necessarily, for an
                // open-ended run) keeps growing.
                //
                // Each point's x comes from its OWN elapsedSecs
                // (TimeSeriesPoint, sourced from the CSV row's own
                // intervalEndSecs - ground truth from iperf2 itself, always
                // present even when this point's own value is a timestamped
                // null), not from its position in `values`.
                val elapsedSecs = values.last().elapsedSecs
                val axisSpanSecs = if (durationSecs != null && durationSecs > 0) {
                    maxOf(durationSecs.toDouble(), elapsedSecs)
                } else {
                    elapsedSecs.coerceAtLeast(0.001)
                }
                fun xOf(pointElapsedSecs: Double): Float = (pointElapsedSecs / axisSpanSecs).toFloat() * size.width

                // Null-valued points break the line rather than being
                // silently interpolated across (a straight line through a
                // genuinely missing stretch would misrepresent two
                // widely-separated readings as continuous data) - moveTo
                // starts a new disconnected segment after every gap instead
                // of always lineTo'ing from whatever the previous point was.
                //
                // A large real time gap between two consecutive *non-null*
                // points breaks the line too - `values` only ever gets an
                // entry appended for a row IperfViewModel actually parsed
                // successfully (or an explicit paused-null), so a run of
                // CSV rows this metric failed to parse (e.g. a working-load
                // download row a format/port mismatch silently dropped -
                // see CsvLineParser.parseWorkingLoadDownloadThroughput)
                // leaves no entry at all for that stretch, not a null one.
                // Without this, two readings genuinely tens of seconds
                // apart still get lineTo'd directly together, drawing a
                // smooth straight interpolation across a gap that was
                // actually missing data - indistinguishable from a real,
                // continuously-declining trend. gapThresholdSecs tracks the
                // smallest delta seen so far as a self-calibrating proxy
                // for "one normal reporting interval" (immune to whatever
                // --interval this run used, and never pulled upward by a
                // dropout's own inflated delta, since it's a running min) -
                // GAP_MULTIPLIER's worth of that counts as a real dropout,
                // not just ordinary reporting jitter.
                val line = Path()
                var penDown = false
                var prevElapsedSecs: Double? = null
                var typicalDeltaSecs = Double.POSITIVE_INFINITY
                values.forEach { p ->
                    val v = p.value
                    if (v == null) {
                        penDown = false
                    } else {
                        val x = xOf(p.elapsedSecs)
                        val y = yOf(v)
                        val delta = prevElapsedSecs?.let { p.elapsedSecs - it }
                        if (!penDown || (delta != null && delta > typicalDeltaSecs * GAP_MULTIPLIER)) {
                            line.moveTo(x, y)
                            penDown = true
                        } else {
                            line.lineTo(x, y)
                        }
                        if (delta != null) typicalDeltaSecs = minOf(typicalDeltaSecs, delta)
                        prevElapsedSecs = p.elapsedSecs
                    }
                }
                drawPath(line, color = color, style = Stroke(width = 1.5.dp.toPx()))

                // Last *valid* point, not necessarily values.last() (the
                // most recent interval could itself be a timestamped null,
                // e.g. a metric that stopped reporting near the end of a
                // run) - this is what the highlighted dot and current-
                // reading text both anchor to, since there's no reading to
                // show for a null.
                val lastValid = values.last { it.value != null }
                val lastPoint = Offset(xOf(lastValid.elapsedSecs), yOf(lastValid.value!!))

                // Last point highlighted - the one reading that also lines
                // up with the paired dial's own current readout, so a
                // reader can visually anchor "that dial number is this
                // dot" before reading the trend leading up to it.
                drawCircle(color = color, radius = 3.dp.toPx(), center = lastPoint)

                // Y-axis top/bottom values - the nice-rounded axis bounds
                // (not this chart's raw observed min/max), so the line's
                // shape has real, human-friendly numbers to anchor it to.
                val ticks = listOf(
                    axisMax to "%.1f%s".format(axisMax, unit),
                    axisMin to "%.1f%s".format(axisMin, unit),
                )
                ticks.forEach { (value, label) ->
                    val y = yOf(value)
                    drawLine(
                        color = AXIS_LABEL,
                        start = Offset(0f, y),
                        end = Offset(6.dp.toPx(), y),
                        strokeWidth = 1.dp.toPx(),
                    )
                    drawContext.canvas.nativeCanvas.drawText(
                        label,
                        8.dp.toPx(),
                        (y + axisTextSizePx * 0.35f).coerceIn(axisTextSizePx, plotHeight - 2.dp.toPx()),
                        axisPaint,
                    )
                }

                // Current reading, printed right on the chart next to
                // where the line ends - same "one number most worth
                // reading at a glance" placement as LiveSparkline's own
                // current-value callout.
                drawContext.canvas.nativeCanvas.drawText(
                    "%.1f%s".format(lastValid.value, unit),
                    (lastPoint.x - 6.dp.toPx()).coerceAtLeast(size.width * 0.35f),
                    (lastPoint.y - 8.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    valuePaint,
                )

                // Offset up from the axisMin axis tick label just below it
                // (both sit at the same x) so the two don't overlap - same
                // "corner label above the bottom axis tick" convention as
                // RttFloorChart's own RTT min label.
                footnote?.let {
                    drawContext.canvas.nativeCanvas.drawText(
                        it,
                        8.dp.toPx(),
                        plotHeight - 20.dp.toPx(),
                        footnotePaint,
                    )
                }

                // Time axis - "-Ns" at the fixed left edge, "now" at the
                // chart's own true latest timestamp (values.last(), which
                // may itself be a null - the time axis reflects real
                // elapsed time regardless of whether this particular
                // metric has a reading right now) - not the canvas's own
                // right edge, which - unlike before - no longer means "the
                // newest sample" once axisSpanSecs is the whole run's
                // length rather than whatever's currently plotted: mid-run,
                // real data only occupies the left portion, with unplotted
                // future to the right, so pinning "now" to the static edge
                // would point at blank space. coerceAtLeast keeps the
                // right-aligned label from clipping off the left edge in
                // the first second or two of a run, when the true "now" x
                // is still near zero.
                //
                // The left label itself is elapsedSecs, NOT axisSpanSecs -
                // x=0 is always t=0 (the run's start), so "how long ago
                // was that" is genuinely elapsedSecs and grows every tick.
                // axisSpanSecs is a fixed span for *positioning* math only
                // (see its own doc comment above) - printing it here
                // instead would show "-60s" from the very first sample of
                // a 60s run, while only a sliver of the chart actually has
                // data yet, reading as a lie about how much history is
                // really on screen.
                drawContext.canvas.nativeCanvas.drawText(
                    "-%.0fs".format(elapsedSecs),
                    2.dp.toPx(),
                    size.height - 2.dp.toPx(),
                    timeAxisLeftPaint,
                )
                val nowX = xOf(elapsedSecs).coerceAtLeast(24.dp.toPx())
                drawContext.canvas.nativeCanvas.drawText(
                    "now",
                    nowX,
                    size.height - 2.dp.toPx(),
                    timeAxisRightPaint,
                )
            }
        }
    }
}
