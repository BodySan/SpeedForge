package com.rjmcmahon.iperf2client.ui.meters

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rjmcmahon.iperf2client.stats.RttHistoryPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import kotlin.math.ceil
import kotlin.math.floor

private val CURRENT_LINE = Color(0xFFFFD600)
private val FLOOR_LINE = Color(0xFF66BB6A)
private val AXIS_LABEL = Color(0xFFBDBDBD)

// Left-edge y-axis tick + label, same convention as LiveSparkline's own
// ticks - a chart with lines but no numbers on it doesn't actually tell
// you the scale of what you're looking at (a "flat" floor line looks
// identical whether it's flat at 9ms or flat at 90ms without this).
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAxisTick(
    value: Double,
    y: Float,
    axisPaint: Paint,
    // Lower clamp bound for the label's own baseline - the plotted area's
    // own height when a time axis reserves a bottom strip below it (see
    // RttFloorChart's bottomMarginPx), full canvas height otherwise.
    maxY: Float = size.height,
) {
    drawLine(
        color = AXIS_LABEL,
        start = Offset(0f, y),
        end = Offset(6.dp.toPx(), y),
        strokeWidth = 1.dp.toPx(),
    )
    drawContext.canvas.nativeCanvas.drawText(
        "%.1f".format(value),
        8.dp.toPx(),
        (y + axisPaint.textSize * 0.35f).coerceIn(axisPaint.textSize, maxY - 2.dp.toPx()),
        axisPaint,
    )
}

/**
 * Two lines sharing one real y-axis (both already in ms, no per-series
 * normalization needed - unlike a hypothetical combined Throughput/RTT/CE
 * Duration chart, which was scoped and deliberately not built for exactly
 * this reason, see this session's own UDP-L4S redesign notes): current RTT
 * riding above rttMin, the connection's own tracked floor. TCP and
 * UDP-L4S both feed this from IperfViewModel.rttHistoryFlow - same chart,
 * same axis, same two colors for both modes, for direct A/B comparison
 * (Fi-Wi vs. traditional AP) the same way every other meter in this app
 * was brought to parity this session.
 *
 * What this chart is actually for: on UDP-L4S, rttMin is a genuinely
 * permanent floor - PragueCC::m_rtt_min only ever ratchets down for the
 * connection's whole lifetime (src/prague_cc.cpp: `m_rtt_min = (m_rtt_min
 * > m_rtt) ? m_rtt : m_rtt_min`, no reset, no window, no decay), so a
 * *widening* gap between the two lines reads unambiguously as increasing
 * load/congestion-adjacent delay. TCP's floor (tcpi_min_rtt) is weaker: the
 * kernel tracks it with a *windowed* min-RTT filter (the same `minmax`
 * mechanism built for BBR, generically exposed via TCP_INFO since kernel
 * 4.11), which periodically re-probes and can legitimately creep back up
 * on a long enough run if the true achievable floor gets and stays worse -
 * so on TCP specifically, an occasional small *rise* in the floor line is
 * a real, expected reading, not a bug in this chart. A floor that stays
 * flat still says the achievable best case is stable either way; a
 * current-RTT line that stays close to it says the path is running near
 * that floor most of the time.
 */
@Composable
fun RttFloorChart(
    history: List<Timestamped<RttHistoryPoint>>,
    // See MiniSparkline's own durationSecs doc comment - same "fixed,
    // known-in-advance axis span instead of one derived from history.size"
    // reasoning. Each point's own elapsedSecs (Timestamped, sourced from
    // the CSV's own intervalEndSecs) drives x position - see MiniSparkline's
    // own axisSpanSecs doc comment for why that's real elapsed time, not
    // list position.
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 12.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
        }
    }
    // Smaller and tinted to match the floor line itself (FLOOR_LINE) -
    // distinct from axisPaint's neutral gray scale-bound ticks, so this
    // reads as "the green line's own current value," not another axis
    // tick. Just the RTT min reading - the paired dial beside this chart
    // already shows RTT smoothed, so this chart's own job is to add the
    // one number that dial doesn't cover.
    val minRttTextSizePx = with(density) { 10.sp.toPx() }
    val minRttPaint = remember(minRttTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = FLOOR_LINE.toArgb()
            textSize = minRttTextSizePx
        }
    }
    val timeAxisTextSizePx = with(density) { 10.sp.toPx() }
    val timeAxisLeftPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = timeAxisTextSizePx
        }
    }
    val timeAxisRightPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = timeAxisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }

    // A point's own value can be a timestamped null (see Timestamped's own
    // doc comment - iperf2 gives every interval a real CSV row/timestamp
    // regardless of whether RTT had a reading that interval), so "enough to
    // draw a chart" means enough *valid* readings, not just enough
    // timestamped slots.
    val validCount = history.count { it.value != null }

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        if (validCount < 2) {
            // Same fixed-height, centered "Waiting for data…" box as
            // MiniSparkline's own empty state (just this chart's own
            // 180dp, not MiniSparkline's 140dp) - without it, this text
            // collapses to its own natural (much shorter, top-aligned)
            // height instead of lining up with the row's own dial and
            // every other row's paired chart.
            Box(
                modifier = Modifier.fillMaxWidth().height(180.dp).padding(top = 4.dp, start = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = "Waiting for data…", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val validPoints = history.mapNotNull { it.value }
            val dataMin = validPoints.minOf { it.rttMinMs }
            val dataMax = validPoints.maxOf { it.currentRttMs }.coerceAtLeast(dataMin + 0.001)
            val pad = ((dataMax - dataMin) * 0.08).coerceAtLeast(0.1)
            val rawMin = (dataMin - pad).coerceAtLeast(0.0)
            val rawMax = dataMax + pad
            val axisStep = niceAxisStep(rawMax - rawMin)
            val axisMin = floor(rawMin / axisStep) * axisStep
            val axisMax = ceil(rawMax / axisStep) * axisStep

            Canvas(modifier = Modifier.fillMaxWidth().height(180.dp).padding(top = 4.dp)) {
                drawRect(color = Color.Black)

                // Same reserved-bottom-strip convention as MiniSparkline's
                // own bottomMarginPx - keeps the time labels below clear of
                // the value-axis ticks/RTT-min corner label, both of which
                // are free to land anywhere down to the very bottom edge.
                val bottomMarginPx = 14.dp.toPx()
                val plotHeight = size.height - bottomMarginPx

                fun yOf(value: Double): Float =
                    plotHeight - (((value - axisMin) / (axisMax - axisMin)).toFloat() * plotHeight)

                // See MiniSparkline's own axisSpanSecs doc comment - same
                // fixed-denominator reasoning (avoids both the frozen-axis-
                // label bug and the rescale-during-fill artifact), each
                // point positioned by its own elapsedSecs rather than list
                // index (Timestamped's own doc comment).
                val elapsedSecs = history.last().elapsedSecs
                val axisSpanSecs = if (durationSecs != null && durationSecs > 0) {
                    maxOf(durationSecs.toDouble(), elapsedSecs)
                } else {
                    elapsedSecs.coerceAtLeast(0.001)
                }
                fun xOf(pointElapsedSecs: Double): Float = (pointElapsedSecs / axisSpanSecs).toFloat() * size.width

                // Null-valued points break both lines rather than being
                // silently interpolated across - same reasoning as
                // MiniSparkline's own line-drawing (current/floor share
                // one gate - RttHistoryPoint is only ever appended as a
                // whole, see that data class's own doc comment - so one
                // "penDown" state covers both lines).
                fun linePath(values: (RttHistoryPoint) -> Double): Path {
                    val path = Path()
                    var penDown = false
                    history.forEach { p ->
                        val v = p.value
                        if (v == null) {
                            penDown = false
                        } else {
                            val x = xOf(p.elapsedSecs)
                            val y = yOf(values(v))
                            if (!penDown) {
                                path.moveTo(x, y)
                                penDown = true
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                    }
                    return path
                }

                drawPath(linePath { it.rttMinMs }, color = FLOOR_LINE, style = Stroke(width = 2.dp.toPx()))
                drawPath(linePath { it.currentRttMs }, color = CURRENT_LINE, style = Stroke(width = 2.dp.toPx()))

                // Axis scale bounds - without these the chart shows lines
                // moving but no indication of what ms range they span.
                drawAxisTick(axisMax, yOf(axisMax), axisPaint, maxY = plotHeight)
                drawAxisTick(axisMin, yOf(axisMin), axisPaint, maxY = plotHeight)

                // RTT min's own current value, small and pinned toward the
                // bottom-left (not tracking the floor line's own last
                // point, which drifts along the x-axis) - the floor line
                // normally sits low in this chart, so a corner label reads
                // as "belongs to that line" without needing to visually
                // chase a moving endpoint. Offset up from the axisMin tick
                // label just below it (both sit at the same x) so the two
                // don't overlap.
                drawContext.canvas.nativeCanvas.drawText(
                    "RTT min %.1f ms".format(validPoints.last().rttMinMs),
                    8.dp.toPx(),
                    plotHeight - 20.dp.toPx(),
                    minRttPaint,
                )

                // Time axis - see MiniSparkline's own doc comment for why
                // "now" tracks the actual last-point x rather than the
                // canvas's static right edge, and why the left label is
                // elapsedSecs (grows every tick) rather than the fixed
                // axisSpanSecs used for point positioning.
                drawContext.canvas.nativeCanvas.drawText(
                    "-%.0fs".format(elapsedSecs),
                    2.dp.toPx(),
                    size.height - 2.dp.toPx(),
                    timeAxisLeftPaint,
                )
                val nowX = xOf(elapsedSecs).coerceAtLeast(24.dp.toPx())
                drawContext.canvas.nativeCanvas.drawText(
                    "now",
                    nowX,
                    size.height - 2.dp.toPx(),
                    timeAxisRightPaint,
                )
            }
        }
    }
}

