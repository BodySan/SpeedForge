package com.rjmcmahon.iperf2client.ui.meters

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Digital-dash-style black gauge: a black face with a ring of white tick
 * marks (lit up to fraction, dim beyond) over a 270-degree sweep (gap at
 * the bottom), plus a big digital numeric readout in the middle - modeled
 * on a car digital speedometer look rather than an analog needle dial.
 * fraction is value/scaleMax (caller-supplied, see ThroughputMeter/RttMeter).
 */
@Composable
fun SpeedometerGauge(
    label: String,
    // Small parenthesized qualifier appended after `label` (e.g. RTT's
    // "smoothed", distinguishing PragueCC's EWMA-smoothed srtt from a raw
    // per-packet RTT reading) - smaller text on the same baseline as the
    // label (not a dropped/raised subscript, which read as visually
    // unbalanced), so it doesn't cost this already-tight gauge column any
    // extra vertical space.
    labelSubscript: String? = null,
    mainText: String,
    unitText: String,
    fraction: Float,
    modifier: Modifier = Modifier,
    accentColor: Color = Color.White,
    tickCount: Int = 30,
    // Per-tick color override, keyed by the tick's own position (0f..1f
    // along the same fraction space as `fraction`) - lets a gauge show
    // multiple color zones at once (e.g. green up to a threshold, yellow
    // beyond) instead of the whole lit arc snapping to one color. Falls
    // back to accentColor for every tick when null (ThroughputMeter's case).
    colorAt: ((Float) -> Color)? = null,
    // Per-tick length scale (0f..1f, keyed by tick position same as
    // colorAt) - lets a log-scale gauge visually show that equal angular
    // steps represent unequal underlying value jumps (e.g. Throughput:
    // each tick near the low end represents a small Mbps interval, each
    // tick near the high end a huge one) by drawing shorter ticks where
    // the interval is small and longer ticks where it's large. Falls back
    // to full-length (1f) for every tick when null.
    lengthAt: ((Float) -> Float)? = null,
    // Running min/avg/max (see IperfViewModel's StatAccumulator), shown
    // once at least one non-first sample has arrived, as two explicitly
    // centered lines - avg on its own (it's the headline number), min/max
    // together underneath - rather than one "min X - avg Y - max Z" string
    // left to wrap wherever it happens to run out of width: an unplanned
    // wrap stays left-aligned within each wrapped line even though the
    // whole block is centered, which reads as ragged/unbalanced,
    // especially in this dial row's narrower per-item columns now that
    // UDP-L4S shows three dials across instead of two. Null hides the
    // whole block rather than reserving blank space for it.
    avgText: String? = null,
    minMaxText: String? = null,
    // One more line, ABOVE avgText (between the dial and the avg/min/max
    // block) - for a derived number prominent enough to want above the
    // historical summary rather than folded into it (unlike extraText
    // below, this renders in compact mode too - see MarkingProbabilityMeter's
    // own call site for why that distinction mattered for its first use).
    // Null hides it, same "don't reserve blank space" convention as every
    // other optional text slot here.
    derivedText: String? = null,
    // One more line below avgText/minMaxText, for a derived number that's
    // related to but distinct from this dial's own primary reading (e.g.
    // RttMeter's TCP "excess above min" - rtt minus the kernel's own
    // tracked rtt_min). Null hides it, same "don't reserve blank space"
    // convention as avgText/minMaxText.
    extraText: String? = null,
    // Where the running max sits, in the same 0f..1f fraction space as
    // `fraction` itself (caller maps stats.max through its own scale
    // function, e.g. ThroughputMeter/RttMeter's log curve) - drawn as a
    // small pennant just outside the tick rim, like a peak-hold needle on
    // a real analog gauge. Null (no stats yet, or mid-first-interval)
    // hides it rather than drawing a marker at a meaningless position.
    peakFraction: Float? = null,
    peakColor: Color = Color(0xFF00E5FF),
    // Dial face color - default matches every dial's usual black face.
    // Overridden light-gray by RttMeter's CeDurationPlaceholder to read as
    // genuinely disabled/unavailable at a glance, distinct from a normal
    // black-faced dial just waiting on its first sample (both show "N/A"
    // text, so the face color is the only thing that tells them apart).
    faceColor: Color = Color.Black,
    // True when this dial is paired with a MiniSparkline beside it (see
    // IperfScreen's dial+sparkline rows) rather than standing alone at full
    // row width. Shrinks the numeric readout and drops avgText/minMaxText/
    // extraText entirely - the sparkline is what now carries the trend/
    // spread story, so repeating min/avg/max as text underneath a dial
    // that's already lost half its width would just wrap awkwardly.
    compact: Boolean = false,
) {
    val animatedFraction by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), label = "$label-fraction")
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = buildAnnotatedString {
                append(label)
                labelSubscript?.let { sub ->
                    withStyle(SpanStyle(fontSize = 11.sp)) {
                        append(" ($sub)")
                    }
                }
            },
            style = if (compact) MaterialTheme.typography.labelMedium else MaterialTheme.typography.labelLarge,
        )
        Box(
            modifier = Modifier.fillMaxWidth(if (compact) 0.95f else 0.8f).aspectRatio(1f).padding(top = 4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                val startAngleDeg = 135f
                val totalSweepDeg = 270f
                val radius = size.minDimension / 2f
                val center = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
                val bezelWidth = radius * 0.06f

                // Black face (or faceColor override) + a subtle lighter
                // bezel ring for depth.
                drawCircle(color = faceColor, radius = radius - bezelWidth / 2f, center = center)
                drawCircle(
                    color = Color(0xFF4A4A4A),
                    radius = radius - bezelWidth / 2f,
                    center = center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = bezelWidth),
                )

                val outerR = radius - bezelWidth * 1.8f
                val innerR = outerR - radius * 0.16f
                val litCount = (tickCount * animatedFraction).roundToInt().coerceIn(0, tickCount)
                val tickStroke = radius * 0.045f
                for (i in 0 until tickCount) {
                    val tickPosition = i.toFloat() / (tickCount - 1)
                    val angleDeg = startAngleDeg + totalSweepDeg * tickPosition
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val cosA = cos(angleRad).toFloat()
                    val sinA = sin(angleRad).toFloat()
                    // Ticks grow inward from the same outer rim as they
                    // shrink, rather than shrinking from both ends - matches
                    // how a physical dial's minor ticks are drawn.
                    val lengthScale = lengthAt?.invoke(tickPosition)?.coerceIn(0f, 1f) ?: 1f
                    val tickInnerR = outerR - (outerR - innerR) * lengthScale
                    val p1 = androidx.compose.ui.geometry.Offset(center.x + tickInnerR * cosA, center.y + tickInnerR * sinA)
                    val p2 = androidx.compose.ui.geometry.Offset(center.x + outerR * cosA, center.y + outerR * sinA)
                    val lit = i < litCount
                    drawLine(
                        color = if (lit) (colorAt?.invoke(tickPosition) ?: accentColor) else Color.White.copy(alpha = 0.18f),
                        start = p1,
                        end = p2,
                        strokeWidth = tickStroke,
                        cap = StrokeCap.Round,
                    )
                }

                peakFraction?.let { pf ->
                    val angleDeg = startAngleDeg + totalSweepDeg * pf.coerceIn(0f, 1f)
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    val cosA = cos(angleRad).toFloat()
                    val sinA = sin(angleRad).toFloat()
                    // Small pennant sitting just outside the tick rim,
                    // tip pointing in at the ticks - reads as a flag
                    // planted at the high-water mark rather than another
                    // tick fighting for attention among the rest.
                    val tipR = outerR + radius * 0.01f
                    val baseR = outerR + radius * 0.11f
                    val halfWidthRad = Math.toRadians(2.2)
                    val tip = androidx.compose.ui.geometry.Offset(center.x + tipR * cosA, center.y + tipR * sinA)
                    val baseAngle1 = angleRad + halfWidthRad
                    val baseAngle2 = angleRad - halfWidthRad
                    val base1 = androidx.compose.ui.geometry.Offset(
                        center.x + baseR * cos(baseAngle1).toFloat(),
                        center.y + baseR * sin(baseAngle1).toFloat(),
                    )
                    val base2 = androidx.compose.ui.geometry.Offset(
                        center.x + baseR * cos(baseAngle2).toFloat(),
                        center.y + baseR * sin(baseAngle2).toFloat(),
                    )
                    val pennant = Path().apply {
                        moveTo(tip.x, tip.y)
                        lineTo(base1.x, base1.y)
                        lineTo(base2.x, base2.y)
                        close()
                    }
                    drawPath(pennant, color = peakColor)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = mainText,
                    color = accentColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (compact) 20.sp else 34.sp,
                )
                Text(
                    text = unitText,
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = if (compact) 10.sp else 14.sp,
                )
            }
        }
        // avg on its own line, min/max together underneath - shown in
        // compact dials too (just at a smaller font, to fit the narrower
        // column a paired MiniSparkline leaves), not just full-size ones -
        // the sparkline covers the *trend*, but the numeric avg/min/max
        // summary is still the fastest way to read a run's overall spread
        // at a glance, same reason full-size dials already show it.
        val statsStyle = if (compact) {
            MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp)
        } else {
            MaterialTheme.typography.bodySmall
        }
        derivedText?.let {
            Text(
                text = it,
                style = statsStyle,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        avgText?.let {
            Text(
                text = it,
                style = statsStyle,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        minMaxText?.let {
            Text(
                text = it,
                style = statsStyle,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
        if (!compact) {
            extraText?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
}
