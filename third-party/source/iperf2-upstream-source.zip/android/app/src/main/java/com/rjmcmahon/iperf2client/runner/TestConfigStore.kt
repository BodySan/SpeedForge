package com.rjmcmahon.iperf2client.runner

import android.content.Context
import android.content.SharedPreferences
import com.rjmcmahon.iperf2client.model.BouncebackTransport
import com.rjmcmahon.iperf2client.model.L4SCongestionControl
import com.rjmcmahon.iperf2client.model.NetworkPreference
import com.rjmcmahon.iperf2client.model.TestConfig
import com.rjmcmahon.iperf2client.model.TestKind
import com.rjmcmahon.iperf2client.model.Transport
import com.rjmcmahon.iperf2client.model.WorkingLoadDirection

/**
 * Persists [TestConfig] across app restarts via SharedPreferences, so users
 * don't have to re-enter host/port/toggle state every time the
 * Activity/ViewModel is recreated (e.g. process death under memory
 * pressure, or the single-Activity task being finished and relaunched).
 *
 * Also persists the config half of each A/B/C/D preset compare slot (see
 * IperfViewModel.saveCurrentAs/savedRuns) - same field set, same read/write
 * helpers, just under a per-slot key prefix rather than the bare keys the
 * live/current config uses. Deliberately config-only, not the full
 * RunSnapshot - the *results* half (every meter's stats/history, the
 * histogram) is a separate concern with a different shape (nested
 * lists/objects rather than flat scalars) and a different failure mode
 * (fine to drop and fall back to a placeholder if it doesn't parse, unlike
 * config which should always round-trip cleanly) - see RunSnapshotStore,
 * which persists that half and is loaded alongside this one.
 */
object TestConfigStore {
    private const val PREFS_NAME = "test_config"

    private const val KEY_TEST_KIND = "test_kind"
    private const val KEY_CAPACITY_TRANSPORT = "capacity_transport"
    private const val KEY_HOST = "host"
    private const val KEY_PORT = "port"
    private const val KEY_DURATION = "duration_secs"
    private const val KEY_INTERVAL = "interval_secs"
    private const val KEY_PARALLEL = "parallel_streams"
    private const val KEY_WRITE_PREFETCH_ENABLED = "write_prefetch_enabled"
    private const val KEY_WRITE_PREFETCH_BYTES = "write_prefetch_bytes"
    private const val KEY_TCP_CCA_ENABLED = "tcp_cca_enabled"
    private const val KEY_TCP_CCA = "tcp_cca"
    private const val KEY_BOUNCEBACK_CCA_ENABLED = "bounceback_cca_enabled"
    private const val KEY_REVERSE_ENABLED = "reverse_enabled"
    private const val KEY_WORKING_LOAD_ENABLED = "working_load_enabled"
    private const val KEY_WORKING_LOAD_DIRECTION = "working_load_direction"
    private const val KEY_WORKING_LOAD_TRANSPORT = "working_load_transport"
    private const val KEY_WORKING_LOAD_CCA = "working_load_cca"
    private const val KEY_WORKING_LOAD_L4S_CCA = "working_load_l4s_cca"
    private const val KEY_BOUNCEBACK_SIZE_ENABLED = "bounceback_size_enabled"
    private const val KEY_BOUNCEBACK_REQUEST_BYTES = "bounceback_request_bytes"
    private const val KEY_BOUNCEBACK_REPLY_BYTES = "bounceback_reply_bytes"
    private const val KEY_BOUNCEBACK_TRANSPORT = "bounceback_transport"
    private const val KEY_L4S_CCA = "l4s_cca"
    private const val KEY_FORCE_IPV6 = "force_ipv6"
    private const val KEY_NETWORK_PREFERENCE = "network_preference"
    private const val KEY_RECENT_HOSTS = "recent_hosts"
    private const val KEY_RECENT_PORTS = "recent_ports"
    // Deliberately its own top-level key, not one of the CONFIG_KEYS above -
    // see TestConfig.manualPermitKey's own doc comment for why this is
    // host-scoped rather than round-tripping with the rest of a config/preset.
    private const val KEY_HOST_PERMIT_KEYS = "host_permit_keys"
    // Preset-slot-only key, alongside the KEY_* config fields above under
    // the same per-slot prefix - doubles as the "does this slot actually
    // have anything saved" marker (see loadPreset): a slot that was never
    // saved has no value under this key at all, whereas every real save
    // always writes a real System.currentTimeMillis() (> 0).
    private const val KEY_SAVED_AT_MILLIS = "saved_at_millis"

    // Every key written by writeConfig() below, plus KEY_SAVED_AT_MILLIS -
    // the exact set clearPreset() needs to wipe for one slot without
    // touching the live (unprefixed) config or other slots.
    private val CONFIG_KEYS = listOf(
        KEY_TEST_KIND, KEY_CAPACITY_TRANSPORT, KEY_HOST, KEY_PORT, KEY_DURATION, KEY_INTERVAL, KEY_PARALLEL,
        KEY_WRITE_PREFETCH_ENABLED, KEY_WRITE_PREFETCH_BYTES, KEY_TCP_CCA_ENABLED, KEY_TCP_CCA,
        KEY_BOUNCEBACK_CCA_ENABLED,
        KEY_REVERSE_ENABLED, KEY_WORKING_LOAD_ENABLED, KEY_WORKING_LOAD_DIRECTION,
        KEY_WORKING_LOAD_TRANSPORT, KEY_WORKING_LOAD_CCA, KEY_WORKING_LOAD_L4S_CCA,
        KEY_BOUNCEBACK_SIZE_ENABLED, KEY_BOUNCEBACK_REQUEST_BYTES, KEY_BOUNCEBACK_REPLY_BYTES,
        KEY_BOUNCEBACK_TRANSPORT, KEY_L4S_CCA, KEY_FORCE_IPV6, KEY_NETWORK_PREFERENCE,
    )

    private const val MAX_RECENT_ENTRIES = 8
    // "|" rather than "," since it can't appear in a hostname/IP/port either
    // way, but avoids any ambiguity with the handful of legacy tools that
    // stuff commas into copy-pasted host,port strings.
    private const val RECENT_ENTRIES_DELIMITER = "|"
    // Separates a host from its permit key within one entry of the
    // pipe-delimited KEY_HOST_PERMIT_KEYS blob (e.g. "host1=key1|host2=key2") -
    // "=" can't appear in a hostname/IP either, and a hex-encoded SHA-256
    // permit key can't contain it either.
    private const val HOST_PERMIT_KEY_DELIMITER = "="

    fun load(context: Context): TestConfig =
        readConfig(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE), prefix = "")

    fun save(context: Context, config: TestConfig) {
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        writeConfig(editor, prefix = "", config)
        editor.apply()
    }

    /**
     * Saves preset [slot]'s config half (see this object's own doc comment)
     * - [savedAtMillis] is the caller's own System.currentTimeMillis() at
     * save time (IperfViewModel.saveCurrentAs already computes one for the
     * in-memory RunSnapshot; passed in rather than read fresh here so both
     * copies agree), reused by [loadPreset] to rebuild a RunSnapshot whose
     * "saved Xm ago" caption (IperfScreen's formatSavedAt) reflects the
     * original save, not whenever the app happened to restart.
     */
    fun savePreset(context: Context, slot: Char, config: TestConfig, savedAtMillis: Long) {
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        val prefix = presetPrefix(slot)
        writeConfig(editor, prefix, config)
        editor.putLong(prefix + KEY_SAVED_AT_MILLIS, savedAtMillis)
        editor.apply()
    }

    /** Null if [slot] was never saved (or was cleared) - see [KEY_SAVED_AT_MILLIS]'s own doc comment. */
    fun loadPreset(context: Context, slot: Char): Pair<TestConfig, Long>? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val prefix = presetPrefix(slot)
        val savedAtMillis = prefs.getLong(prefix + KEY_SAVED_AT_MILLIS, -1L)
        if (savedAtMillis < 0) return null
        return readConfig(prefs, prefix) to savedAtMillis
    }

    fun clearPreset(context: Context, slot: Char) {
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        val prefix = presetPrefix(slot)
        (CONFIG_KEYS + KEY_SAVED_AT_MILLIS).forEach { editor.remove(prefix + it) }
        editor.apply()
    }

    private fun presetPrefix(slot: Char) = "preset_${slot}_"

    private fun readConfig(prefs: SharedPreferences, prefix: String): TestConfig {
        val default = TestConfig()
        val host = prefs.getString(prefix + KEY_HOST, default.host) ?: default.host
        return TestConfig(
            testKind = prefs.getString(prefix + KEY_TEST_KIND, null)
                ?.let { runCatching { TestKind.valueOf(it) }.getOrNull() } ?: default.testKind,
            capacityTransport = prefs.getString(prefix + KEY_CAPACITY_TRANSPORT, null)
                ?.let { runCatching { Transport.valueOf(it) }.getOrNull() } ?: default.capacityTransport,
            host = host,
            port = prefs.getInt(prefix + KEY_PORT, default.port),
            durationSecs = prefs.getInt(prefix + KEY_DURATION, default.durationSecs),
            intervalSecs = prefs.getFloat(prefix + KEY_INTERVAL, default.intervalSecs.toFloat()).toDouble(),
            parallelStreams = prefs.getInt(prefix + KEY_PARALLEL, default.parallelStreams),
            writePrefetchEnabled = prefs.getBoolean(prefix + KEY_WRITE_PREFETCH_ENABLED, default.writePrefetchEnabled),
            writePrefetchBytes = prefs.getString(prefix + KEY_WRITE_PREFETCH_BYTES, default.writePrefetchBytes)
                ?: default.writePrefetchBytes,
            tcpCcaEnabled = prefs.getBoolean(prefix + KEY_TCP_CCA_ENABLED, default.tcpCcaEnabled),
            tcpCca = prefs.getString(prefix + KEY_TCP_CCA, default.tcpCca) ?: default.tcpCca,
            bouncebackCcaEnabled = prefs.getBoolean(prefix + KEY_BOUNCEBACK_CCA_ENABLED, default.bouncebackCcaEnabled),
            reverseEnabled = prefs.getBoolean(prefix + KEY_REVERSE_ENABLED, default.reverseEnabled),
            workingLoadEnabled = prefs.getBoolean(prefix + KEY_WORKING_LOAD_ENABLED, default.workingLoadEnabled),
            workingLoadDirection = prefs.getString(prefix + KEY_WORKING_LOAD_DIRECTION, null)
                ?.let { runCatching { WorkingLoadDirection.valueOf(it) }.getOrNull() } ?: default.workingLoadDirection,
            workingLoadTransport = prefs.getString(prefix + KEY_WORKING_LOAD_TRANSPORT, null)
                ?.let { runCatching { Transport.valueOf(it) }.getOrNull() } ?: default.workingLoadTransport,
            workingLoadCca = prefs.getString(prefix + KEY_WORKING_LOAD_CCA, default.workingLoadCca) ?: default.workingLoadCca,
            workingLoadL4sCca = prefs.getString(prefix + KEY_WORKING_LOAD_L4S_CCA, null)
                ?.let { runCatching { L4SCongestionControl.valueOf(it) }.getOrNull() } ?: default.workingLoadL4sCca,
            bouncebackSizeEnabled = prefs.getBoolean(prefix + KEY_BOUNCEBACK_SIZE_ENABLED, default.bouncebackSizeEnabled),
            bouncebackRequestBytes = prefs.getString(prefix + KEY_BOUNCEBACK_REQUEST_BYTES, default.bouncebackRequestBytes)
                ?: default.bouncebackRequestBytes,
            bouncebackReplyBytes = prefs.getString(prefix + KEY_BOUNCEBACK_REPLY_BYTES, default.bouncebackReplyBytes)
                ?: default.bouncebackReplyBytes,
            // Missing-key-safe: a config saved before this field existed has
            // no KEY_BOUNCEBACK_TRANSPORT entry, so getString returns null
            // and this falls through to default.bouncebackTransport (TCP).
            bouncebackTransport = prefs.getString(prefix + KEY_BOUNCEBACK_TRANSPORT, null)
                ?.let { runCatching { BouncebackTransport.valueOf(it) }.getOrNull() } ?: default.bouncebackTransport,
            l4sCca = prefs.getString(prefix + KEY_L4S_CCA, null)
                ?.let { runCatching { L4SCongestionControl.valueOf(it) }.getOrNull() } ?: default.l4sCca,
            forceIpv6 = prefs.getBoolean(prefix + KEY_FORCE_IPV6, default.forceIpv6),
            networkPreference = prefs.getString(prefix + KEY_NETWORK_PREFERENCE, null)
                ?.let { runCatching { NetworkPreference.valueOf(it) }.getOrNull() } ?: default.networkPreference,
            // Not one of this function's own prefixed keys - see
            // TestConfig.manualPermitKey's doc comment. Read from the same
            // global (unprefixed) host->key map every prefix/slot shares, so
            // a preset referencing a given host picks up whatever key that
            // host currently has, same as the live config would.
            manualPermitKey = loadHostPermitKeys(prefs)[host] ?: "",
        )
    }

    private fun writeConfig(editor: SharedPreferences.Editor, prefix: String, config: TestConfig) {
        editor.putString(prefix + KEY_TEST_KIND, config.testKind.name)
            .putString(prefix + KEY_CAPACITY_TRANSPORT, config.capacityTransport.name)
            .putString(prefix + KEY_HOST, config.host)
            .putInt(prefix + KEY_PORT, config.port)
            .putInt(prefix + KEY_DURATION, config.durationSecs)
            .putFloat(prefix + KEY_INTERVAL, config.intervalSecs.toFloat())
            .putInt(prefix + KEY_PARALLEL, config.parallelStreams)
            .putBoolean(prefix + KEY_WRITE_PREFETCH_ENABLED, config.writePrefetchEnabled)
            .putString(prefix + KEY_WRITE_PREFETCH_BYTES, config.writePrefetchBytes)
            .putBoolean(prefix + KEY_TCP_CCA_ENABLED, config.tcpCcaEnabled)
            .putString(prefix + KEY_TCP_CCA, config.tcpCca)
            .putBoolean(prefix + KEY_BOUNCEBACK_CCA_ENABLED, config.bouncebackCcaEnabled)
            .putBoolean(prefix + KEY_REVERSE_ENABLED, config.reverseEnabled)
            .putBoolean(prefix + KEY_WORKING_LOAD_ENABLED, config.workingLoadEnabled)
            .putString(prefix + KEY_WORKING_LOAD_DIRECTION, config.workingLoadDirection.name)
            .putString(prefix + KEY_WORKING_LOAD_TRANSPORT, config.workingLoadTransport.name)
            .putString(prefix + KEY_WORKING_LOAD_CCA, config.workingLoadCca)
            .putString(prefix + KEY_WORKING_LOAD_L4S_CCA, config.workingLoadL4sCca.name)
            .putBoolean(prefix + KEY_BOUNCEBACK_SIZE_ENABLED, config.bouncebackSizeEnabled)
            .putString(prefix + KEY_BOUNCEBACK_REQUEST_BYTES, config.bouncebackRequestBytes)
            .putString(prefix + KEY_BOUNCEBACK_REPLY_BYTES, config.bouncebackReplyBytes)
            .putString(prefix + KEY_BOUNCEBACK_TRANSPORT, config.bouncebackTransport.name)
            .putString(prefix + KEY_L4S_CCA, config.l4sCca.name)
            .putBoolean(prefix + KEY_FORCE_IPV6, config.forceIpv6)
            .putString(prefix + KEY_NETWORK_PREFERENCE, config.networkPreference.name)
    }

    /** Most-recently-used first, capped at [MAX_RECENT_ENTRIES]. */
    fun loadRecentHosts(context: Context): List<String> = loadRecentEntries(context, KEY_RECENT_HOSTS)

    /**
     * Moves [host] to the front of the recent-hosts list (deduping any
     * existing entry) and persists it. Called when a test actually starts
     * (see IperfViewModel.onStart) rather than on every keystroke, so the
     * list reflects hosts actually tested against rather than every
     * intermediate value typed.
     *
     * No-op for a DEFAULT_HOSTS entry (see PublicServers.kt) - those are
     * already always shown in the Host dropdown regardless of history, so
     * recording them here would just let testing through the whole public
     * roster crowd out actually-custom/private hosts in this capped-size
     * list.
     */
    fun recordHostUse(context: Context, host: String): List<String> {
        if (host in DEFAULT_HOSTS) return loadRecentHosts(context)
        return recordEntryUse(context, KEY_RECENT_HOSTS, host)
    }

    fun clearRecentHosts(context: Context) = clearRecentEntries(context, KEY_RECENT_HOSTS)

    /** Most-recently-used first, capped at [MAX_RECENT_ENTRIES]. */
    fun loadRecentPorts(context: Context): List<Int> =
        loadRecentEntries(context, KEY_RECENT_PORTS).mapNotNull { it.toIntOrNull() }

    /** Same MRU behavior as [recordHostUse], for the Port field. */
    fun recordPortUse(context: Context, port: Int): List<Int> =
        recordEntryUse(context, KEY_RECENT_PORTS, port.toString()).mapNotNull { it.toIntOrNull() }

    fun clearRecentPorts(context: Context) = clearRecentEntries(context, KEY_RECENT_PORTS)

    private fun loadRecentEntries(context: Context, key: String): List<String> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(key, null) ?: return emptyList()
        return raw.split(RECENT_ENTRIES_DELIMITER).filter { it.isNotBlank() }
    }

    private fun recordEntryUse(context: Context, key: String, value: String): List<String> {
        if (value.isBlank()) return loadRecentEntries(context, key)
        val updated = (listOf(value) + loadRecentEntries(context, key).filterNot { it == value })
            .take(MAX_RECENT_ENTRIES)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(key, updated.joinToString(RECENT_ENTRIES_DELIMITER))
            .apply()
        return updated
    }

    private fun clearRecentEntries(context: Context, key: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .remove(key)
            .apply()
    }

    /** Manually-saved permit key for [host], or "" if none is saved - see TestConfig.manualPermitKey. */
    fun loadPermitKeyForHost(context: Context, host: String): String =
        loadHostPermitKeys(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE))[host] ?: ""

    /**
     * Saves [permitKey] against [host], or removes any existing entry for
     * it when [permitKey] is blank. Called from IperfViewModel.updateConfig
     * whenever the field is edited (not gated to test-start, unlike
     * recordHostUse/recordPortUse - a partially-typed key transiently
     * overwriting a prior one is harmless, and gating this the same way
     * would mean a key typed but never actually run against wouldn't stick).
     */
    fun savePermitKeyForHost(context: Context, host: String, permitKey: String) {
        if (host.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val updated = loadHostPermitKeys(prefs).toMutableMap()
        if (permitKey.isBlank()) updated.remove(host) else updated[host] = permitKey
        prefs.edit()
            .putString(
                KEY_HOST_PERMIT_KEYS,
                updated.entries.joinToString(RECENT_ENTRIES_DELIMITER) { (h, k) -> "$h$HOST_PERMIT_KEY_DELIMITER$k" },
            )
            .apply()
    }

    private fun loadHostPermitKeys(prefs: SharedPreferences): Map<String, String> {
        val raw = prefs.getString(KEY_HOST_PERMIT_KEYS, null) ?: return emptyMap()
        return raw.split(RECENT_ENTRIES_DELIMITER).mapNotNull { entry ->
            val splitAt = entry.indexOf(HOST_PERMIT_KEY_DELIMITER)
            if (splitAt <= 0) null else entry.substring(0, splitAt) to entry.substring(splitAt + 1)
        }.toMap()
    }
}
