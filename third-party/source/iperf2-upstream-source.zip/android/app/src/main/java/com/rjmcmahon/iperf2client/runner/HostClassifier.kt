package com.rjmcmahon.iperf2client.runner

/**
 * Distinguishes local/private-network destinations (LAN testing) from public
 * ones. Two things depend on this: whether to silently attach the public
 * server's permit-key (only for non-local hosts - see IperfCommandBuilder),
 * and how many parallel streams the UI offers (the 8-thread cap is the
 * public server's per-client limit; LAN testing has no such constraint -
 * see IperfScreen's Parallel-streams dropdown). A hostname (anything that
 * isn't a literal IPv4 address, e.g. responde.fi-wi.com) is always treated
 * as non-local - deliberately no DNS resolution here, this only needs to be
 * a fast, offline, best-effort classification.
 */
object HostClassifier {
    private val IPV4_REGEX = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$""")

    fun isLocalOrPrivate(host: String): Boolean {
        val trimmed = host.trim()
        if (trimmed.equals("localhost", ignoreCase = true) || trimmed == "::1") return true
        val match = IPV4_REGEX.find(trimmed) ?: return false
        val octets = match.groupValues.drop(1).map { it.toIntOrNull() ?: return false }
        val (a, b) = octets[0] to octets[1]
        return when {
            a == 127 -> true // loopback (127.0.0.0/8)
            a == 10 -> true // RFC1918 10.0.0.0/8
            a == 172 && b in 16..31 -> true // RFC1918 172.16.0.0/12
            a == 192 && b == 168 -> true // RFC1918 192.168.0.0/16
            a == 169 && b == 254 -> true // link-local 169.254.0.0/16
            else -> false
        }
    }
}
