package com.rjmcmahon.iperf2client.ui.meters

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.MeterStats
import kotlin.math.exp
import kotlin.math.ln

private const val MAX_MBPS = 2_500.0 // 2.5 Gbps full-scale, per fixed dial ceiling
// Pivot divisor for the log curve below - a plain ln(x+1)/ln(max+1) grows
// too fast relative to a 2500 Mbps ceiling (e.g. 50 Mbps alone already lit
// ~15 of 30 ticks, half the dial, since ln(51)/ln(2501) ~= 0.50). Dividing
// by a reference value before taking the log slows the initial rise -
// 100 Mbps (a "typical decent WiFi" reference point) now lands at ~4
// ticks instead of ~15, while 2500 Mbps still reaches full scale.
private const val PIVOT_MBPS = 100.0
// ln((MAX_MBPS/PIVOT_MBPS) + 1) - the log curve's total "steepness span",
// reused by both the fraction calc and the tick-length derivative below.
private val LOG_SPAN = ln(MAX_MBPS / PIVOT_MBPS + 1.0)
// Tick length floor so low-end ticks (smallest represented Mbps interval)
// stay clearly visible instead of nearly vanishing - see lengthAt below.
private const val MIN_TICK_SCALE = 0.35f

@Composable
fun ThroughputMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    // Once the test's stopped, show the run's own average instead of
    // whatever the last live interval happened to read - a single
    // interval (especially the last, often partial one) is a noisy,
    // arbitrary "final" number; the average is what the run actually
    // achieved. Same running stats already shown in the text below,
    // just also driving the big readout once there's nothing live left
    // to show.
    val mbps = if (!isRunning && stats != null) stats.avg else (sample?.speedBitsPerSec ?: 0L) / 1_000_000.0

    // Log scale (ln(x/k+1), so 0 Mbps still maps to 0), same technique as
    // RttMeter - a linear scale left the dial showing zero lit ticks for
    // any throughput well under MAX_MBPS/tickCount (~83 Mbps per tick),
    // which reads as "no signal" for perfectly real, modest results (e.g.
    // 38 Mbps home-network runs never lit a single tick).
    val logFraction = (ln(mbps / PIVOT_MBPS + 1.0) / LOG_SPAN).toFloat()

    SpeedometerGauge(
        label = "Throughput",
        mainText = "%.0f".format(mbps),
        unitText = "Mbps",
        fraction = logFraction,
        // Equal angular steps on a log scale represent unequal Mbps
        // intervals - d(mbps)/d(fraction) = k*L*exp(fraction*L), which
        // normalizes (dividing by its value at fraction=1) to exp((f-1)*L)
        // - i.e. ticks near the low end (small represented interval) draw
        // short, ticks near the high end (huge represented interval) draw
        // long, making the non-linear scale visible at a glance.
        lengthAt = { position ->
            val ratio = exp((position - 1.0) * LOG_SPAN).toFloat()
            MIN_TICK_SCALE + (1f - MIN_TICK_SCALE) * ratio
        },
        avgText = stats?.let { "avg %.0f".format(it.avg) },
        minMaxText = stats?.let { "min %.0f · max %.0f".format(it.min, it.max) },
        peakFraction = stats?.let { (ln(it.max / PIVOT_MBPS + 1.0) / LOG_SPAN).toFloat() },
        compact = compact,
        modifier = modifier,
    )
}
