package com.rjmcmahon.iperf2client.runner

import android.content.Context
import java.io.File

/**
 * Every raw line the iperf2 subprocess printed to stdout/stderr during the
 * most recent run - including lines this app's own CSV parsing otherwise
 * discards or overwrites in-memory (IperfViewModel._statusMessage keeps
 * only the *last* non-CSV line seen, not a log - see that field's own doc
 * comment), most notably the connect banner (e.g. "local <ip> port <n>
 * connected with <ip> port <n>"), which is the only place the actual local
 * IP a run bound to is ever printed. Added because the live-meters UI has
 * nowhere it surfaces that line, and a technician debugging which network
 * interface (e.g. WiFi vs. a USB Ethernet adapter) a test actually used
 * needs to see it after the fact.
 *
 * getExternalFilesDir, not the app-private filesDir GoldenHistogramStore/
 * RunSnapshotStore use - no permission needed on any supported API level,
 * but unlike filesDir it's reachable with a plain `adb pull` (or many file
 * managers) without needing `run-as` against a debuggable build. A
 * single file, overwritten fresh at the start of every run (same "latest
 * wins, not a history" convention as GoldenHistogramStore) - this is a
 * point-in-time diagnostic aid, not a durable log.
 */
object RawRunLogStore {
    // .txt, not .log: FileProvider derives the shared content:// URI's
    // MIME type strictly from the file extension via MimeTypeMap,
    // independent of the ACTION_SEND intent's own explicit
    // type = "text/plain" (IperfScreen.kt) - "log" isn't a MIME-registered
    // extension, so contentResolver.getType() on that URI returned null.
    // Several mail apps (Gmail included) query that directly when handling
    // EXTRA_STREAM and silently drop the attachment on a null type rather
    // than falling back to the intent's declared type - "Dump diags"
    // opened a compose screen with nothing attached. .txt resolves
    // unambiguously to text/plain, matching the intent's own type exactly.
    private const val FILE_NAME = "last_run_raw.txt"

    fun file(context: Context): File? {
        val dir = context.getExternalFilesDir(null) ?: return null
        return File(dir, FILE_NAME)
    }
}
