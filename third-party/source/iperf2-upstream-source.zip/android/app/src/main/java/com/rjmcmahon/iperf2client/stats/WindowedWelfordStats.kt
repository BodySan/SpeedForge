package com.rjmcmahon.iperf2client.stats

import java.util.ArrayDeque
import kotlin.math.sqrt

/** One windowed statistics snapshot - see [WindowedWelfordStats.snapshot]. */
data class WindowedSnapshot(
    val mean: Double,
    val stdev: Double,
    val min: Double,
    val max: Double,
    val count: Int,
    val maxZScore: Double,
)

/** One (timestamp, value) sample held in the sliding window. */
private data class TimedValue(val elapsedSecs: Double, val value: Double)

/**
 * Sliding-window online statistics for a stream of doubles, windowed by
 * elapsed time rather than by raw sample count. Used here for
 * --bounceback's own per-interval requests-per-second (RPS) reading -
 * averaging many iid-ish per-interval RPS samples together in the window
 * is what makes the windowed *mean* asymptotically Gaussian per the
 * central limit theorem, regardless of the underlying per-interval RPS
 * distribution, so stdev-based bands are statistically justified for the
 * windowed series even though a single interval's raw RPS need not be
 * Gaussian on its own.
 *
 * Time-based (not a fixed sample count): a fixed sample count silently
 * turns into a lifetime/cumulative average whenever a run's total sample
 * count stays at or under the window size for a while - which is common,
 * since LiveSparkline's own chart axis spans the whole run rather than
 * scrolling to a fixed recent window. That made the "windowed" mean track
 * an early transition fine (little history yet to lag behind) but barely
 * respond to a later one (e.g. a working-load pause/resume click) - it
 * was still effectively averaging in every sample since the run began.
 * Windowing by elapsed seconds instead keeps the window's *duration*
 * meaningful regardless of the configured --interval or how long the run
 * has been going.
 *
 * Windowed mean/variance via Welford's online algorithm, both add and
 * remove - never E[x^2] - E[x]^2 (catastrophic cancellation for values
 * with a large mean relative to their variance, which bounce latency
 * routinely is). Windowed min/max via two monotonic deques (one
 * non-increasing for max, one non-decreasing for min) - O(1) amortized
 * per sample rather than an O(window) rescan on every eviction. Eviction
 * removes by value equality against the deque's front rather than
 * tracking (value, index) pairs - sound here because every add() pushes
 * exactly one entry per window element (never deduplicated), so the
 * deque never holds more occurrences of a value than the window actually
 * contains, and removing one matching occurrence on eviction always
 * leaves the deque correctly representing the remaining window.
 *
 * Not thread-safe - callers ingesting from one coroutine/thread and
 * reading [snapshot] from another must synchronize externally (see
 * IperfViewModel, which only ever touches this from its own collect
 * coroutine).
 */
class WindowedWelfordStats(private val windowSecs: Double) {
    private val window = ArrayDeque<TimedValue>()
    private val maxDeque = ArrayDeque<Double>() // front = current window max
    private val minDeque = ArrayDeque<Double>() // front = current window min

    private var mean = 0.0
    private var m2 = 0.0 // sum of squared deviations from the running mean
    private var count = 0

    fun add(elapsedSecs: Double, value: Double) {
        window.addLast(TimedValue(elapsedSecs, value))

        count++
        val delta = value - mean
        mean += delta / count
        val delta2 = value - mean
        m2 += delta * delta2

        while (maxDeque.isNotEmpty() && (maxDeque.peekLast() ?: value) < value) maxDeque.removeLast()
        maxDeque.addLast(value)
        while (minDeque.isNotEmpty() && (minDeque.peekLast() ?: value) > value) minDeque.removeLast()
        minDeque.addLast(value)

        while (window.isNotEmpty() && elapsedSecs - window.peekFirst().elapsedSecs > windowSecs) evictOldest()
    }

    private fun evictOldest() {
        val removed = window.removeFirst().value
        // Welford remove: exact inverse of the add() update above.
        if (count > 1) {
            val newCount = count - 1
            val newMean = (mean * count - removed) / newCount
            val delta = removed - mean
            val delta2 = removed - newMean
            m2 -= delta * delta2
            mean = newMean
            count = newCount
        } else {
            mean = 0.0
            m2 = 0.0
            count = 0
        }
        if (maxDeque.isNotEmpty() && maxDeque.peekFirst() == removed) maxDeque.removeFirst()
        if (minDeque.isNotEmpty() && minDeque.peekFirst() == removed) minDeque.removeFirst()
    }

    /** Null if nothing's been added yet (or everything's been reset). */
    fun snapshot(): WindowedSnapshot? {
        if (count == 0) return null
        val variance = if (count > 1) m2 / (count - 1) else 0.0
        val stdev = sqrt(variance)
        val min = minDeque.peekFirst() ?: 0.0
        val max = maxDeque.peekFirst() ?: 0.0
        val maxZ = if (stdev > 0.0) (max - mean) / stdev else 0.0
        return WindowedSnapshot(mean = mean, stdev = stdev, min = min, max = max, count = count, maxZScore = maxZ)
    }

    fun reset() {
        window.clear()
        maxDeque.clear()
        minDeque.clear()
        mean = 0.0
        m2 = 0.0
        count = 0
    }
}
