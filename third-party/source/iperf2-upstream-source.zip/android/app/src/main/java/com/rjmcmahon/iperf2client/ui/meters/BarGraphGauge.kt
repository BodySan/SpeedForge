package com.rjmcmahon.iperf2client.ui.meters

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.ceil

private val LIT_COLOR = Color(0xFF2E7D32)

/**
 * Segmented LED/equalizer-style bar graph: a row of discrete green blocks,
 * lit up to fraction (running-max-scaled, same convention as
 * SpeedometerGauge) and dimmed beyond it. Visually distinct from the dial
 * gauges - matches "bar graph gauge" as asked for bytes in flight
 * specifically.
 */
@Composable
fun BarGraphGauge(
    label: String,
    valueText: String,
    fraction: Float,
    modifier: Modifier = Modifier,
    litColor: Color = LIT_COLOR,
    segments: Int = 24,
    // Per-segment color override, keyed by the segment's own position
    // (0f..1f along the same fraction space as `fraction`) - lets the bar
    // show multiple zones at once (e.g. green then yellow then red segments)
    // instead of every lit segment snapping to one color. Falls back to
    // litColor for every segment when null.
    colorAt: ((Float) -> Color)? = null,
    // Running min/avg/max text (see IperfViewModel's StatAccumulator),
    // shown once at least one non-first sample has arrived. Null hides the
    // row entirely rather than reserving blank space for it.
    statsText: String? = null,
    // Two-column variant of the line above - e.g. CWND alongside
    // bytes-in-flight (BytesInFlightMeter), both equally "the current
    // reading" rather than one primary number with a secondary caption.
    // Which is which is established by the bar's own label/title (e.g.
    // "CWND/Inflight"), not repeated here. Centered per column (previously
    // left/right-justified toward the screen edge - changed because that
    // only visually lined up under statsAvgTextStart/End's own centered
    // text when the min/max string happened to be long enough to nearly
    // fill the column; a short string, e.g. a lone "0", left a visible gap
    // between it and the centered avg above). Takes priority over
    // statsText when either is non-null; statsText still covers every
    // other (single-series) bar's plain centered line.
    // Single-series counterpart to statsAvgTextStart/Mid/End below -
    // avg, centered above statsText's own (now also centered) min/max
    // line, same "avg is the headline, min/max is centered supporting
    // detail beneath it" hierarchy as the column variant and
    // SpeedometerGauge's avgText/minMaxText. Null (the default) omits
    // it, leaving statsText to render alone as before.
    statsAvgText: String? = null,
    statsTextStart: String? = null,
    statsTextEnd: String? = null,
    // Three-column variant, for a bar with three series (e.g. TCP's
    // "CWND/inFlight/NotSent") instead of two - start/mid/end each get
    // equal weight, all centered (see statsTextStart/End's own doc comment
    // above for why), same "which is which is established by the label"
    // reasoning as the two-column variant above. Takes priority over both
    // statsTextStart/End and statsText when non-null.
    statsTextMid: String? = null,
    // Optional row of three per-column averages, rendered *above*
    // statsTextStart/Mid/End (which then holds just min/max) - each column
    // is centered regardless of that column's own Start/Center/End
    // alignment below it, matching how SpeedometerGauge always centers its
    // own avgText/minMaxText under the dial. Centering just the avg line
    // (not the min/max line under it) makes avg read as the headline
    // number for that column, with min/max as centered supporting detail
    // beneath it - same visual hierarchy as the Throughput/RTT dials, just
    // repeated per column instead of once. Null (the default, and any
    // individual null column) omits that column's avg line, no reserved
    // blank space.
    statsAvgTextStart: String? = null,
    statsAvgTextMid: String? = null,
    statsAvgTextEnd: String? = null,
    // Smaller text/bar for a secondary reading shown alongside a more
    // important one (e.g. BOUNCEBACK's working-load bars underneath RPS) -
    // roughly 60% the visual weight of the default size, so the primary
    // metric stays the obviously prominent one on screen.
    compact: Boolean = false,
    // A boundary/ceiling marker: always a thin tick at backgroundFraction
    // (never treated as its own data series, unlike `fraction`/
    // tertiaryFraction) - e.g. TCP's congestion window (BytesInFlightMeter):
    // CWND isn't a quantity of data sitting between in-flight and not-sent
    // bytes, it's a *limit* on how much can be in flight at once, so it
    // never gets its own fill "between" the two real data series (as if it
    // were its own chunk of bytes). When the ceiling sits past every real
    // fill - i.e. the segments between them would otherwise be plain unlit
    // black - those segments are painted backgroundColor too (see
    // fillEndCount/backgroundLitCount below), so unused headroom under the
    // cap reads as "capped here" rather than "no data here". When the
    // ceiling instead sits at or behind a real fill (e.g. notSent already
    // past CWND), only the tick itself marks it - that segment keeps its
    // own fill's color, unchanged. Null (the default) omits the marker
    // entirely.
    backgroundFraction: Float? = null,
    backgroundColor: Color = Color(0xFFE53935),
    // Third series, filling contiguously right after `fraction` (not past
    // backgroundFraction - see that param's own doc comment for why CWND
    // isn't part of this bar's fill order at all) - e.g. TCP's notSent
    // bytes (BytesInFlightMeter): data written but not yet sent, queued
    // immediately behind the in-flight bytes `fraction` already covers.
    // Null (the default) omits this tier entirely.
    tertiaryFraction: Float? = null,
    tertiaryColor: Color = Color(0xFFFFD600),
    // Fourth series, filling contiguously right after tertiaryFraction -
    // e.g. TCP's SndBufLimited/RwndLimited/BusyTime bar (BytesInFlightMeter):
    // time spent limited by the peer's receive window, stacked after time
    // spent limited by the local send buffer. Null (the default) omits
    // this tier entirely.
    quaternaryFraction: Float? = null,
    quaternaryColor: Color = Color(0xFFE53935),
    // A trailing zone (reserved from this bar's own segment count - see
    // headroomZoneFraction) showing "how much more room exists beyond
    // what's plotted", log-scaled by the caller into 0f..1f rather than
    // linear like fraction/tertiaryFraction/backgroundFraction above - e.g.
    // TCP's live send socket buffer ceiling (BytesInFlightMeter): the
    // ceiling can be orders of magnitude past the live data (kernel
    // autotuning routinely reaches multi-MB while actual in-flight data
    // sits in the tens-of-KB range), so sharing one linear scale with the
    // live series would either crush them to invisible slivers or (if the
    // live series drives the scale instead) hide the ceiling entirely -
    // this renders it as its own distinctly-scaled, visually separated
    // zone instead of forcing one scale to serve both. Null (the default)
    // omits the zone entirely - the bar then uses its full segment count
    // for live data, unchanged from before this concept existed.
    headroomFraction: Float? = null,
    headroomColor: Color = Color(0xFF757575),
    // What share of this bar's total segment count the headroom zone
    // reserves (taken from the tail end) - fixed regardless of
    // headroomFraction's own value, so the live-data zone's own scale
    // doesn't shift size run to run as the ceiling/live ratio changes.
    headroomZoneFraction: Float = 0.25f,
    // Right-justified caption above the segmented bar itself (below label/
    // valueText) - for a derived/contextual number that isn't one of this
    // bar's own plotted series, e.g. TCP's live send socket buffer ceiling
    // (BytesInFlightMeter), shown here as an exact figure since the
    // headroom zone below only conveys it log-scaled/approximate. Sits
    // right-aligned so it reads as a caption on the bar it's about to
    // introduce, not competing with the left-aligned label/valueText above
    // it. Null (the default) omits it, no reserved blank space.
    topRightText: String? = null,
) {
    val animatedFraction by animateFloatAsState(targetValue = fraction.coerceIn(0f, 1f), label = "$label-bars")
    val animatedBackgroundFraction by animateFloatAsState(
        targetValue = (backgroundFraction ?: 0f).coerceIn(0f, 1f),
        label = "$label-bg-bars",
    )
    val animatedTertiaryFraction by animateFloatAsState(
        targetValue = (tertiaryFraction ?: 0f).coerceIn(0f, 1f),
        label = "$label-tertiary-bars",
    )
    val animatedQuaternaryFraction by animateFloatAsState(
        targetValue = (quaternaryFraction ?: 0f).coerceIn(0f, 1f),
        label = "$label-quaternary-bars",
    )
    val animatedHeadroomFraction by animateFloatAsState(
        targetValue = (headroomFraction ?: 0f).coerceIn(0f, 1f),
        label = "$label-headroom-bars",
    )
    val barHeight = if (compact) 20.dp else 32.dp
    Column(modifier = modifier.fillMaxWidth().padding(vertical = if (compact) 4.dp else 8.dp)) {
        Text(text = label, style = if (compact) MaterialTheme.typography.labelMedium else MaterialTheme.typography.labelLarge)
        Text(text = valueText, style = if (compact) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium)
        topRightText?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Canvas(modifier = Modifier.fillMaxWidth().height(barHeight).padding(top = 4.dp)) {
            // Black housing behind the segments, matching the black gauge faces.
            drawRoundRect(color = Color.Black, cornerRadius = CornerRadius(6.dp.toPx()))

            val inset = size.height * 0.15f
            val gap = size.width * 0.006f
            val segWidth = (size.width - inset * 2 - gap * (segments - 1)) / segments
            val cornerRadius = CornerRadius(2.dp.toPx())
            // Reserve a trailing zone for the log-scaled headroom indicator
            // (see headroomFraction's own doc comment) - the live series
            // below only ever scale against liveSegments, not the full
            // segments count, so their own scale/proportions stay exactly
            // as they'd be with no headroom zone at all; the zone is purely
            // additive. A visible gap (extraGap below) separates the two
            // zones so they don't read as one continuous linear scale.
            val hasHeadroomZone = headroomFraction != null
            val liveSegments = if (hasHeadroomZone) {
                (segments * (1f - headroomZoneFraction)).toInt().coerceIn(1, segments - 1)
            } else {
                segments
            }
            val headroomZoneSegments = segments - liveSegments
            val extraGap = if (hasHeadroomZone) segWidth * 0.6f else 0f

            val litCount = (liveSegments * animatedFraction).toInt().coerceIn(0, liveSegments)
            // Fills contiguously right after the primary (green) series -
            // see tertiaryFraction's own doc comment for why this doesn't
            // account for backgroundFraction (CWND) at all, unlike before.
            val tertiaryLitCount = if (tertiaryFraction != null) {
                (liveSegments * animatedTertiaryFraction).toInt().coerceIn(litCount, liveSegments)
            } else {
                0
            }
            // Fills contiguously right after the tertiary (yellow) series.
            val quaternaryLitCount = if (quaternaryFraction != null) {
                (liveSegments * animatedQuaternaryFraction).toInt().coerceIn(tertiaryLitCount, liveSegments)
            } else {
                0
            }
            // A shared scale between two bars (see BytesInFlightMeter's
            // working-load pair) can leave the smaller one's own fraction
            // well under 1/liveSegments, truncating to zero lit segments
            // and reading as "no data" for a real, nonzero value. Rather
            // than lighting a full first segment (which would misrepresent
            // a tiny fraction as "a full increment"), draw it at half
            // height instead - visibly a tick, not a bar - so the
            // distinction between "genuinely zero" and "nonzero but small"
            // survives the rounding.
            val showMinTick = animatedFraction > 0f && litCount == 0
            // Where the real fill(s) end - the tertiary (yellow) series if
            // present, otherwise the primary (green) one - used below to
            // tell "the ceiling tick sits past all real data, in what would
            // otherwise be dead/unlit segments" apart from "the ceiling
            // sits at or behind data that's already filled in".
            val fillEndCount = when {
                quaternaryFraction != null -> quaternaryLitCount
                tertiaryFraction != null -> tertiaryLitCount
                else -> litCount
            }
            // Ceiling, not floor (unlike litCount/tertiaryLitCount above) -
            // the tick itself (drawn later at animatedBackgroundFraction's
            // exact, non-truncated pixel position) always lands inside or
            // past the last segment this rounds up to, so the red fill
            // never stops one segment short of where the tick actually
            // sits. Flooring here (matching litCount's own convention)
            // left a visible black segment between the red fill and the
            // red tick whenever the fraction landed mid-segment.
            val backgroundLitCount = if (backgroundFraction != null) {
                ceil(liveSegments * animatedBackgroundFraction).toInt().coerceIn(0, liveSegments)
            } else {
                0
            }
            val headroomLitCount = (headroomZoneSegments * animatedHeadroomFraction).toInt().coerceIn(0, headroomZoneSegments)
            for (i in 0 until segments) {
                val inHeadroomZone = i >= liveSegments
                val x = inset + i * (segWidth + gap) + (if (inHeadroomZone) extraGap else 0f)
                if (inHeadroomZone) {
                    val headroomIndex = i - liveSegments
                    val color = if (headroomIndex < headroomLitCount) headroomColor else Color(0xFF3A3A3A)
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(x, inset),
                        size = Size(segWidth, size.height - inset * 2),
                        cornerRadius = cornerRadius,
                    )
                    continue
                }
                val segPosition = i.toFloat() / (liveSegments - 1).coerceAtLeast(1)
                val lit = i < litCount
                val tertiaryLit = i < tertiaryLitCount
                // Otherwise-dead segments between the real fill and the
                // ceiling tick - i.e. headroom the ceiling still allows but
                // nothing has used yet - read as more meaningful painted
                // red (the same color as the tick itself) than as plain
                // unlit black, which looked like "no data" rather than
                // "capped here". Segments already covered by a real fill
                // (tertiaryLit, e.g. notSent already past the ceiling)
                // stay that fill's own color - the tick alone marks the
                // boundary there, same as before.
                val inCeilingHeadroom = backgroundFraction != null && i >= fillEndCount && i < backgroundLitCount
                val quaternaryLit = i < quaternaryLitCount
                val color = when {
                    lit -> colorAt?.invoke(segPosition) ?: litColor
                    tertiaryLit -> tertiaryColor
                    quaternaryLit -> quaternaryColor
                    inCeilingHeadroom -> backgroundColor
                    else -> Color(0xFF3A3A3A)
                }
                if (showMinTick && i == 0) {
                    val tickHeight = (size.height - inset * 2) * 0.5f
                    val tickTop = inset + ((size.height - inset * 2) - tickHeight) / 2f
                    drawRoundRect(
                        color = colorAt?.invoke(segPosition) ?: litColor,
                        topLeft = Offset(x, tickTop),
                        size = Size(segWidth, tickHeight),
                        cornerRadius = cornerRadius,
                    )
                } else {
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(x, inset),
                        size = Size(segWidth, size.height - inset * 2),
                        cornerRadius = cornerRadius,
                    )
                }
            }

            // CWND ceiling marker - see backgroundFraction's own doc
            // comment for why this is always a tick, never a fill. Spans
            // the full canvas height (not just the inset segment area) so
            // it visibly pokes past the segments and reads as a distinct
            // marker, not just another segment.
            if (backgroundFraction != null) {
                // Scaled against the live zone's own width, not the full
                // canvas - CWND is a live-data-scale concept (see
                // backgroundFraction's doc comment), unrelated to the
                // headroom zone's separate log scale, so it must map onto
                // just the live segments' own pixel span.
                val liveZoneWidth = liveSegments * segWidth + (liveSegments - 1).coerceAtLeast(0) * gap
                val tickX = inset + animatedBackgroundFraction * liveZoneWidth
                val tickWidth = (size.width * 0.01f).coerceAtLeast(2.dp.toPx())
                drawRoundRect(
                    color = backgroundColor,
                    topLeft = Offset(tickX - tickWidth / 2f, 0f),
                    size = Size(tickWidth, size.height),
                    cornerRadius = CornerRadius(1.dp.toPx()),
                )
            }
        }
        if (statsAvgTextStart != null || statsAvgTextMid != null || statsAvgTextEnd != null) {
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Text(
                    text = statsAvgTextStart ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = statsAvgTextMid ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = statsAvgTextEnd ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (statsTextMid != null) {
            Row(modifier = Modifier.fillMaxWidth().padding(top = if (statsAvgTextStart != null || statsAvgTextMid != null || statsAvgTextEnd != null) 0.dp else 4.dp)) {
                Text(
                    text = statsTextStart ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = statsTextMid,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = statsTextEnd ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        } else if (statsTextStart != null || statsTextEnd != null) {
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Text(
                    text = statsTextStart ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = statsTextEnd ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        } else {
            statsAvgText?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                )
            }
            statsText?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = if (statsAvgText != null) 0.dp else 4.dp),
                )
            }
        }
    }
}
