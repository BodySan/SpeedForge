package com.rjmcmahon.iperf2client.model

/**
 * One parsed row from iperf2's client enhanced CSV output. The TCP and
 * UDP-L4S write-enhanced CSV formats (reportCSV_bw_tcp_write_enhanced_format
 * / reportCSV_bw_udp_write_enhanced_format in src/Locale.c) happen to both
 * have 19 comma-separated fields, but with completely different meanings
 * past the shared time/address/bytes/speed prefix - so which format a line
 * came from must be tracked by which mode the running test used (see
 * CsvLineParser), not inferred from field count. Fields not applicable to
 * the mode that produced this sample are left at -1, matching this app's
 * existing "-1 means not available" convention (see BytesInFlightMeter).
 *
 * speedBitsPerSec is bits/sec (cntBytes*8/interval) for both modes. TCP-only:
 * rttMicros/rttVarMicros (struct iperf_tcpstats.rtt/rttvar,
 * include/gettcpinfo.h), cwndBytes, bytesInFlight/packetsInFlight (only
 * non-zero when HAVE_TCP_INFLIGHT compiled in). UDP-L4S-only: jitterMs
 * (stats->jitter * 1e3 in src/ReportOutputs.c - internal units are seconds),
 * packetsPerSec, ceCount/cePercent (PragueCC congestion-experienced marks,
 * echoed back from the server over the L4S ACK channel - also populated,
 * as of this session, for BOUNCEBACK regardless of transport: UDP-L4S
 * bounceback reuses these same PragueCC fields, and plain TCP bounceback
 * now feeds them from the kernel's own tcpi_delivered_ce/tcpi_delivered
 * TCP_INFO counters instead - see CsvLineParser's BOUNCEBACK doc comment
 * for the -1-vs-0 sentinel distinction that matters for both), ceDuration*
 * (mean/min/max ms and episode count of each CE-marked run within the
 * interval, stats->CE_Duration), queueDelayUs/queueBytes (PragueCC::
 * GetQueueInfo(), src/prague_cc.cpp - sender-side queueing-delay estimate
 * and its Little's Law (L = lambda*W) translation into bytes; a live
 * snapshot like rttMicros/bytesInFlight above, not a per-interval min/mean/
 * max like ceDuration* - the app folds these into running min/avg/max the
 * same way it already does for TCP's rtt/bytesInFlight, for an apples-to-
 * apples comparison between the two test modes' meters. Always -1 in
 * --reverse: queueing delay is a sender-side computation and there's no
 * relay of the writer's state back to the reader yet), l4sRttUs
 * (PragueCC::GetSmoothedRtt() - the raw RTT queueDelayUs is itself derived
 * from, srtt - rtt_min; same live-snapshot/-1-in-reverse contract as
 * queueDelayUs, shown as its own dial so a reader can sanity-check the
 * derived load-delay number against the real measured RTT - see Koen De
 * Schepper's review, doc/email_koen_littles_law_review.txt) - see
 * reportCSV_bw_udp_write_enhanced_l4s_format in src/Locale.c. BOUNCEBACK-only: bbCount/bbAvgMs/bbMinMs/bbMaxMs/
 * bbStdevMs (round-trip bounce latency stats, stats->bbrtt) and
 * requestsPerSec - reuses tcpRetry/cwndBytes/cwndPackets/rttMicros/
 * rttVarMicros above for --bounceback's own tcpretry/tcpcwnd/tcppcwnd/
 * tcprtt/tcprttvar columns (same underlying TCP_INFO fields TCP mode
 * already surfaces, just alongside the bounce stats instead of alone) -
 * see reportCSV_client_bb_bw_tcp_format in src/Locale.c.
 *
 * notSentBytes (TCP-only, forward and --reverse both) is
 * iperf_tcpstats.notsent_bytes (Linux tcpi_notsent_bytes, kernel 4.6+) -
 * bytes already written to the socket's send buffer but not yet put on the
 * wire, what --tcp-write-prefetch/TCP_NOTSENT_LOWAT actually bounds -
 * distinct from bytesInFlight (unacked bytes genuinely in flight on the
 * network). -1 when the kernel doesn't expose this field.
 *
 * l4sPacketWindow/l4sInflight/l4sMarkingProb (UDP-L4S write/upload
 * direction only, always -1 in --reverse - no relay yet, same limitation
 * as queueDelayUs/queueBytes/l4sRttUs) are PragueCC's own congestion
 * window and actual in-flight packet count (tracked directly by the CC
 * algorithm's send/ACK accounting, completely independent of the
 * srtt-rtt_min-derived queueDelayUs above) and its EWMA-smoothed
 * CE-marking probability (PragueCC::GetMarkingProbability(), raw 0..1<<20
 * scale - distinct from cePercent's own raw unsmoothed per-interval
 * ratio). Per Koen De Schepper's review: comparing window/inflight against
 * queueDelayUs/l4sRttUs is a direct, RTT-independent way to tell whether
 * elevated delay is actually queueing in our own window versus something
 * else (MAC contention, aggregation, etc.) - see
 * doc/email_koen_littles_law_review.txt. errPercent (UDP-L4S, both
 * directions - a reader's own locally-tracked datagram loss, no relay
 * needed) is the standard iperf2 UDP loss percentage (errors/datagrams),
 * already on the wire in the plain 19-field UDP prefix but never parsed
 * for this mode until now - the "loss probability" half of the same ask.
 *
 * rttMinMicros (TCP, --reverse, and BOUNCEBACK) is iperf_tcpstats.rtt_min
 * (Linux tcpi_min_rtt, kernel 4.11+) - the kernel's own continuously-
 * updated minimum RTT for this connection, tracked at full per-ACK
 * granularity. For TCP/reverse, lets the app compute "excess RTT above
 * best observed" (rttMicros - rttMinMicros) directly analogous to
 * UDP-L4S's Load Delay (srtt - rtt_min), without an app-side
 * approximation. -1 when the kernel doesn't expose this field.
 * Deliberately NOT used for any further "queueing vs network" split -
 * notSentBytes was considered for that and rejected (see
 * IperfViewModel.tcpExcessRttAcc's own doc comment for why). For
 * BOUNCEBACK, distinct from bbMinMs (the app-measured min request/reply
 * latency for one report interval, userspace-timed): since bounceback is
 * strictly serialized (the client blocks on each reply before sending the
 * next request), 1000 / (rttMinMicros / 1000.0) is a real, principled
 * ceiling on achievable RPS - useful alongside requestsPerSec to tell
 * pacing-limited from path-limited runs apart.
 *
 * sndBufKB (TCP-only, forward and --reverse both) is
 * iperf_tcpstats.sndbuf_bytes (getsockopt SOL_SOCKET/SO_SNDBUF, KB) - the
 * live, currently-autotuned send socket buffer size, sampled once per
 * interval alongside the rest of the writer's own gettcpinfo() call - the
 * kernel's actual buffer allocation, not the sysctl tcp_wmem min/default/
 * max range that bounds its own autotuning. Drives BytesInFlightMeter's
 * CWND/inFlight/NotSent bar's own log-scaled headroom zone (see that
 * composable and BarGraphGauge's headroomFraction) rather than the bar's
 * main linear scale - the ceiling routinely sits orders of magnitude past
 * the live data, so sharing one scale between them would crush the live
 * series to an unreadable sliver. -1 when unavailable.
 *
 * writeTimeUs (TCP-only, forward and --reverse both) is
 * write_mmm.current.mean (ReportStruct.write_time, --tcp-write-times only)
 * - mean microseconds spent blocked inside the write()/writev() syscall
 * itself this interval: real wall-clock time (the app's data socket is
 * always blocking, never O_NONBLOCK - see src/Client.cpp), so this is
 * genuine send-side backpressure/buffer-sojourn delay, not a Little's Law
 * estimate the way notSentBytes-derived numbers would be. An earlier and
 * separate stage from rttMicros: TCP's own RTT clock only starts once a
 * byte is actually transmitted, so time spent here was never part of RTT
 * to begin with - nothing to decompose out of RTT, this is additional.
 * -1 when --tcp-write-times isn't active (this app doesn't enable it by
 * default - see IperfCommandBuilder) or no write was sampled yet.
 *
 * sndBufLimitedUs/rwndLimitedUs/busyTimeUs (TCP-only, forward and
 * --reverse both) are this-interval deltas of the kernel's own
 * tcpi_sndbuf_limited/tcpi_rwnd_limited/tcpi_busy_time (kernel 4.9+,
 * microseconds) - iperf_tcpstats.sndbuf_limited/rwnd_limited/busy_time on
 * the C side. Direct kernel measurements of time spent capped by the
 * local send buffer, the peer's advertised receive window, and total time
 * spent with data queued to send at all, respectively - complementing
 * writeTimeUs's per-write blocking measurement with a cumulative,
 * kernel-tracked figure. 0 when unavailable (same "0 could also be a
 * genuine reading" ambiguity as a real zero, not a distinguishable -1
 * sentinel - see compat/gettcpinfo.c's own doc comment).
 */
data class IntervalSample(
    val intervalStartSecs: Double,
    val intervalEndSecs: Double,
    val bytes: Long,
    val speedBitsPerSec: Long,
    val tcpRetry: Long = -1,
    val cwndBytes: Long = -1,
    val cwndPackets: Long = -1,
    val rttMicros: Long = -1,
    val rttVarMicros: Long = -1,
    val packetsInFlight: Long = -1,
    val bytesInFlight: Long = -1,
    val notSentBytes: Long = -1,
    val rttMinMicros: Long = -1,
    val sndBufKB: Long = -1,
    val writeTimeUs: Long = -1,
    val sndBufLimitedUs: Long = 0,
    val rwndLimitedUs: Long = 0,
    val busyTimeUs: Long = 0,
    val jitterMs: Double = -1.0,
    val packetsPerSec: Double = -1.0,
    val ceCount: Long = -1,
    val cePercent: Double = -1.0,
    val ceDurationAvgMs: Double = -1.0,
    val ceDurationMinMs: Double = -1.0,
    val ceDurationMaxMs: Double = -1.0,
    val ceDurationCount: Long = -1,
    val queueDelayUs: Long = -1,
    val queueBytes: Long = -1,
    val l4sRttUs: Long = -1,
    val l4sPacketWindow: Long = -1,
    val l4sInflight: Long = -1,
    val l4sMarkingProb: Long = -1,
    val errPercent: Double = -1.0,
    // --cca <prague|reno>, under --udp-l4s (native commit 2ecc85d4) - which
    // congestion-response variant this run actually used, "prague" or
    // "reno" verbatim off the wire (CsvLineParser's IDX_L4S_CCA_MODE).
    // Defaults to "prague" (the native default when the flag is omitted),
    // not a sentinel like the numeric fields above - there's no
    // "unavailable" state for this one, every UDP L4S sample always
    // carries it.
    val l4sCcaMode: String = "prague",
    val bbCount: Long = -1,
    val bbAvgMs: Double = -1.0,
    val bbMinMs: Double = -1.0,
    val bbMaxMs: Double = -1.0,
    val bbStdevMs: Double = -1.0,
    val requestsPerSec: Double = -1.0,
    // Local IP the native binary's socket actually used for this interval
    // (the shared CSV prefix's srcaddress column, every format, always
    // index 1) - ground truth for whether a forced NetworkPreference
    // (WIFI/ETHERNET/CELLULAR) really took effect, since Android's own
    // ConnectivityManager can report a live Network object for the
    // requested transport even when the native `-c host%device`
    // SO_BINDTODEVICE bind silently didn't stick on a given device/OEM
    // build - see IperfViewModel's own transport-mismatch detection. Null
    // only if the field was somehow missing/unparseable, not a normal
    // "not applicable" case like the -1 fields above.
    val srcAddress: String? = null,
)
