package com.rjmcmahon.iperf2client.ui.theme

import android.content.Context

/**
 * Persists the sun/moon toggle's chosen [ThemeMode] across app restarts.
 * Deliberately its own SharedPreferences file, not folded into
 * TestConfigStore - this is an app-chrome preference, not a test
 * parameter, so it shouldn't be touched by resetToDefaults() wiping the
 * live test config back to defaults.
 */
object ThemePreferenceStore {
    private const val PREFS_NAME = "theme_preference"
    private const val KEY_MODE = "mode"

    fun load(context: Context): ThemeMode {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_MODE, null)
        return raw?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM
    }

    fun save(context: Context, mode: ThemeMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MODE, mode.name)
            .apply()
    }
}
