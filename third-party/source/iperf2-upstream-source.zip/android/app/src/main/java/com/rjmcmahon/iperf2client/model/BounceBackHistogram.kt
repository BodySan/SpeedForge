package com.rjmcmahon.iperf2client.model

/**
 * One printed bin from BOUNCEBACK's RTT histogram - "bin(w=%d%s):cnt(%d)=
 * %d:%d,%d:%d,..." (histogram_print(), src/histogram.c) only ever lists
 * bins with a nonzero count for the run (a zero-delta bin is skipped
 * entirely, not printed as "n:0"), so [BounceBackHistogram.bins] is sparse -
 * missing bin numbers between the ones present are real zero-count bins,
 * not gaps in parsing. [binNumber] is 1-based, exactly as printed (bin 1
 * covers [0, binWidthUs), see [BounceBackHistogram.binMidpointMs]'s own doc
 * comment for the full mapping).
 */
data class HistogramBin(val binNumber: Int, val count: Int)

/**
 * BOUNCEBACK's one-per-run round-trip-time distribution summary - parsed
 * from the single histogram line iperf2's client prints right after the
 * last interval's own report, at the very end of a completed run
 * (histogram_print(), src/histogram.c ~line 199-284; see
 * CsvLineParser.parseBounceBackHistogram's own doc comment for the exact
 * wire format and both branches it handles). Always the " BB8"-named
 * histogram (round-trip bounce latency) - BOUNCEBACK never sets up the
 * separate OWD-TX/OWD-RX histograms --trip-times would add, so this app
 * doesn't need to distinguish by name past the "BB8" match already done at
 * parse time.
 *
 * [binWidthUs]/[totalCount]/[bins] describe the distribution itself:
 * [binWidthUs] is always converted to microseconds here regardless of
 * whether the run actually used --histogram to switch iperf2's own
 * bin(w=...) units to milliseconds, so every consumer of this class can
 * assume one consistent unit. [totalCount] is the histogram's own
 * intervalpopulation - the number of RTT samples this distribution
 * summarizes (should equal the run's total bbcnt across all intervals for
 * a normal completed run). [bins] is the sparse (binNumber, count) list
 * actually printed - see [HistogramBin]'s own doc comment.
 *
 * [ciLowerPercent]/[ciUpperPercent] are the confidence-interval bounds as
 * percentages (BOUNCEBACK's own defaults are 5.00/95.00, ci_lower/ci_upper
 * in histogram_init() - Reports.c's isBounceBack branch); [ciLowerBin]/
 * [ciUpperBin]/[p999Bin] are the 1-based bin numbers where the running
 * cumulative count first crossed the lower-CI, upper-CI, and 99.7th-
 * percentile thresholds respectively - real latency percentile markers,
 * convertible to a latency value via [binMidpointMs]. [outlierCount] is a
 * Tukey's-method (3x the 10-90% inner-fence spread past the 90% point)
 * outlier count - genuinely unusual-slow-bounce samples, not just "past the
 * 99.7th percentile." [oobLower]/[oobUpper] are samples that landed below
 * bin 1 or past the histogram's last configured bin entirely (didn't fit
 * any bin) - normally 0/0; a nonzero [oobUpper] on a real run usually means
 * the configured bin count/width was too small for an outlier RTT spike
 * that occurred.
 */
data class BounceBackHistogram(
    val binWidthUs: Double,
    val totalCount: Int,
    val bins: List<HistogramBin>,
    val ciLowerPercent: Double,
    val ciUpperPercent: Double,
    val ciLowerBin: Int,
    val ciUpperBin: Int,
    val p999Bin: Int,
    val outlierCount: Int,
    val oobLower: Int,
    val oobUpper: Int,
    // This histogram's own name field (e.g. " BB8") - what a saved
    // --histogram-baseline reference file self-identifies with when the
    // native client loads it back for a later run's own EMD comparison
    // (see histogram_emd_against_baseline(), src/histogram.c). Not
    // otherwise used by the app itself.
    val name: String,
    // Earth Mover's Distance (Wasserstein-1) between this run and whatever
    // --histogram-baseline reference was configured for this histogram,
    // in ms - null when no baseline was configured for this run (the
    // native side's own -1.0 sentinel, see this field's own native doc
    // comment). Frozen at whatever golden reference was active when this
    // run finished - see HistogramDistance.emdAgainstReference's own doc
    // comment for why the app's own UI recomputes this fresh against the
    // *current* golden instead of only ever trusting this frozen value,
    // once a preset (A/B/C/D) can be viewed well after it was captured.
    val emdVsBaseline: Double?,
) {
    /**
     * Converts a 1-based printed bin number to the latency (ms) it
     * represents, for the chart's x-axis. histogram_insert() (src/
     * histogram.c ~line 129-133) computes bin = (units * value) / binwidth
     * (0-based internally) and histogram_print() prints it as bin+1, so
     * printed bin n covers the microsecond half-open range
     * [(n-1)*binWidthUs, n*binWidthUs) - this returns that range's midpoint
     * (a single representative value per bin, rather than the range's own
     * two edges) converted to ms.
     */
    fun binMidpointMs(binNumber: Int): Double = ((binNumber - 0.5) * binWidthUs) / 1000.0
}
