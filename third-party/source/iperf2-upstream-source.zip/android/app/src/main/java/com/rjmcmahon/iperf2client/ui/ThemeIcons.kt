package com.rjmcmahon.iperf2client.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Local copies of Icons.Filled.LightMode/DarkMode's own path data - same
 * "extract via javap rather than pull in the whole extended-icons library"
 * reasoning as NetworkIcons.kt (~4MB of unused classes.dex for a couple of
 * icons). Path data extracted directly from the compiled LightModeKt/
 * DarkModeKt bytecode (javap -c), not retyped from memory, so this renders
 * pixel-identical to the original Material icons.
 */
private var _lightModeIcon: ImageVector? = null
val LightModeIcon: ImageVector
    get() {
        _lightModeIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "Filled.LightMode",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            // Sun disc
            moveTo(12f, 7f)
            curveToRelative(-2.76f, 0f, -5f, 2.24f, -5f, 5f)
            reflectiveCurveToRelative(2.24f, 5f, 5f, 5f)
            reflectiveCurveToRelative(5f, -2.24f, 5f, -5f)
            reflectiveCurveTo(14.76f, 7f, 12f, 7f)
            lineTo(12f, 7f)
            close()
            // Left ray
            moveTo(2f, 13f)
            lineToRelative(2f, 0f)
            curveToRelative(0.55f, 0f, 1f, -0.45f, 1f, -1f)
            reflectiveCurveToRelative(-0.45f, -1f, -1f, -1f)
            lineToRelative(-2f, 0f)
            curveToRelative(-0.55f, 0f, -1f, 0.45f, -1f, 1f)
            reflectiveCurveTo(1.45f, 13f, 2f, 13f)
            close()
            // Right ray
            moveTo(20f, 13f)
            lineToRelative(2f, 0f)
            curveToRelative(0.55f, 0f, 1f, -0.45f, 1f, -1f)
            reflectiveCurveToRelative(-0.45f, -1f, -1f, -1f)
            lineToRelative(-2f, 0f)
            curveToRelative(-0.55f, 0f, -1f, 0.45f, -1f, 1f)
            reflectiveCurveTo(19.45f, 13f, 20f, 13f)
            close()
            // Top ray
            moveTo(11f, 2f)
            verticalLineToRelative(2f)
            curveToRelative(0f, 0.55f, 0.45f, 1f, 1f, 1f)
            reflectiveCurveToRelative(1f, -0.45f, 1f, -1f)
            verticalLineTo(2f)
            curveToRelative(0f, -0.55f, -0.45f, -1f, -1f, -1f)
            reflectiveCurveTo(11f, 1.45f, 11f, 2f)
            close()
            // Bottom ray
            moveTo(11f, 20f)
            verticalLineToRelative(2f)
            curveToRelative(0f, 0.55f, 0.45f, 1f, 1f, 1f)
            reflectiveCurveToRelative(1f, -0.45f, 1f, -1f)
            verticalLineToRelative(-2f)
            curveToRelative(0f, -0.55f, -0.45f, -1f, -1f, -1f)
            curveTo(11.45f, 19f, 11f, 19.45f, 11f, 20f)
            close()
            // Top-left diagonal ray
            moveTo(5.99f, 4.58f)
            curveToRelative(-0.39f, -0.39f, -1.03f, -0.39f, -1.41f, 0f)
            curveToRelative(-0.39f, 0.39f, -0.39f, 1.03f, 0f, 1.41f)
            lineToRelative(1.06f, 1.06f)
            curveToRelative(0.39f, 0.39f, 1.03f, 0.39f, 1.41f, 0f)
            reflectiveCurveToRelative(0.39f, -1.03f, 0f, -1.41f)
            lineTo(5.99f, 4.58f)
            close()
            // Bottom-right diagonal ray
            moveTo(18.36f, 16.95f)
            curveToRelative(-0.39f, -0.39f, -1.03f, -0.39f, -1.41f, 0f)
            curveToRelative(-0.39f, 0.39f, -0.39f, 1.03f, 0f, 1.41f)
            lineToRelative(1.06f, 1.06f)
            curveToRelative(0.39f, 0.39f, 1.03f, 0.39f, 1.41f, 0f)
            curveToRelative(0.39f, -0.39f, 0.39f, -1.03f, 0f, -1.41f)
            lineTo(18.36f, 16.95f)
            close()
            // Top-right diagonal ray
            moveTo(19.42f, 5.99f)
            curveToRelative(0.39f, -0.39f, 0.39f, -1.03f, 0f, -1.41f)
            curveToRelative(-0.39f, -0.39f, -1.03f, -0.39f, -1.41f, 0f)
            lineToRelative(-1.06f, 1.06f)
            curveToRelative(-0.39f, 0.39f, -0.39f, 1.03f, 0f, 1.41f)
            reflectiveCurveToRelative(1.03f, 0.39f, 1.41f, 0f)
            lineTo(19.42f, 5.99f)
            close()
            // Bottom-left diagonal ray
            moveTo(7.05f, 18.36f)
            curveToRelative(0.39f, -0.39f, 0.39f, -1.03f, 0f, -1.41f)
            curveToRelative(-0.39f, -0.39f, -1.03f, -0.39f, -1.41f, 0f)
            lineToRelative(-1.06f, 1.06f)
            curveToRelative(-0.39f, 0.39f, -0.39f, 1.03f, 0f, 1.41f)
            reflectiveCurveToRelative(1.03f, 0.39f, 1.41f, 0f)
            lineTo(7.05f, 18.36f)
            close()
        }.build()
        _lightModeIcon = built
        return built
    }

private var _darkModeIcon: ImageVector? = null
val DarkModeIcon: ImageVector
    get() {
        _darkModeIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "Filled.DarkMode",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(12f, 3f)
            curveToRelative(-4.97f, 0f, -9f, 4.03f, -9f, 9f)
            reflectiveCurveToRelative(4.03f, 9f, 9f, 9f)
            reflectiveCurveToRelative(9f, -4.03f, 9f, -9f)
            curveToRelative(0f, -0.46f, -0.04f, -0.92f, -0.1f, -1.36f)
            curveToRelative(-0.98f, 1.37f, -2.58f, 2.26f, -4.4f, 2.26f)
            curveToRelative(-2.98f, 0f, -5.4f, -2.42f, -5.4f, -5.4f)
            curveToRelative(0f, -1.81f, 0.89f, -3.42f, 2.26f, -4.4f)
            curveTo(12.92f, 3.04f, 12.46f, 3f, 12f, 3f)
            lineTo(12f, 3f)
            close()
        }.build()
        _darkModeIcon = built
        return built
    }
