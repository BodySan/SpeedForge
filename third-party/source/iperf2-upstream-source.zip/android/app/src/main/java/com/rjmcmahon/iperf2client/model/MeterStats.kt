package com.rjmcmahon.iperf2client.model

/**
 * Running min/avg/max for one metric over a test run, computed entirely in
 * this app - iperf2's own final CSV row only gives a true whole-test average
 * for bytes/speed (stats->cntBytes = stats->total.Bytes.current, see
 * Reporter.c); rtt/cwnd/bytes-in-flight/packets-in-flight in that same final
 * row are just the single most recent TCP_INFO snapshot, not an average or a
 * max. So there's no way to get min/avg/max for those from iperf2's output
 * at all - this app has to fold every interval sample in itself (see
 * IperfViewModel's StatAccumulator).
 */
data class MeterStats(val min: Double, val avg: Double, val max: Double)
