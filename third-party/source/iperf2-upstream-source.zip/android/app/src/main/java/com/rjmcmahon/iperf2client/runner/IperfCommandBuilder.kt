package com.rjmcmahon.iperf2client.runner

import android.content.Context
import com.rjmcmahon.iperf2client.model.BouncebackTransport
import com.rjmcmahon.iperf2client.model.L4SCongestionControl
import com.rjmcmahon.iperf2client.model.TestConfig
import com.rjmcmahon.iperf2client.model.TestMode
import com.rjmcmahon.iperf2client.model.Transport
import com.rjmcmahon.iperf2client.model.WorkingLoadDirection
import java.io.File

/**
 * Builds the argv for the bundled iperf2 CLI. Always a client, always
 * enhanced CSV output (--enhanced --reportstyle C) - the meters this app
 * shows all come from parsing that one line format (see CsvLineParser,
 * which is mode-aware since the TCP and UDP-L4S enhanced CSV formats
 * differ past the shared prefix). write-prefetch is TCP-bulk-transfer-only,
 * so it's only added in TCP mode; cca applies to any TCP-based test (TCP,
 * and Bounceback when its own transport toggle is still TCP - see
 * BouncebackTransport) - not UDP L4S, nor Bounceback-over-UDP-L4S -
 * Settings.cpp would just print a WARN and unset it under --udp, but
 * cleaner to not send it at all when it doesn't apply. ("--cca" is the
 * current documented flag name; "--tcp-cca" is kept native-side only as a
 * deprecated alias, see Settings.cpp.) Long options throughout, not their
 * short-flag equivalents (-c/-p/-t/etc.) - explicit user preference, makes
 * a captured/logged argv self-documenting without cross-referencing the
 * man page.
 */
object IperfCommandBuilder {
    /** Path Android will actually let us execute - see android/README.md for why. */
    fun binaryPath(context: Context): String =
        File(context.applicationInfo.nativeLibraryDir, "libiperf.so").absolutePath

    /**
     * versionInfo is the bundled binary's own "--version" output (already fetched
     * once at app startup - see IperfViewModel) - passed in rather than
     * re-run here so this stays a plain synchronous argv builder. Used to
     * silently derive --permit-key for non-local hosts only (see
     * HostClassifier/PermitKeyProvider) when the user hasn't typed their own
     * (config.manualPermitKey) - LAN/private testing never needs the public
     * server's gate, but a manually-entered key (for a technician's own
     * permit-key-gated server) always overrides that, local host or not.
     */
    fun buildArgs(context: Context, config: TestConfig, versionInfo: String?): List<String> = buildList {
        add(binaryPath(context))
        // %device (SO_BINDTODEVICE) forces this test's traffic over a
        // specific NIC - see NetworkPreference/findNetworkInterfaceName's
        // own doc comments for why this, not
        // ConnectivityManager.bindProcessToNetwork(), is what actually
        // works for a spawned native-binary test. Null (AUTO, or the
        // requested transport isn't currently up) leaves the host
        // argument plain, same as before this feature existed.
        add("--client")
        add(findNetworkInterfaceName(context, config.networkPreference)?.let { "${config.host}%$it" } ?: config.host)
        // config.port already reflects the right server for the current mode
        // - the kind/transport selectors' onKindChange/onClick (IperfScreen.kt)
        // shift it by one when switching TCP<->UDP L4S, since the UDP L4S server is
        // deployed one port up from the TCP one on the same host (e.g. TCP
        // 5201 / UDP L4S 5202). PermitKeyProvider's key doesn't depend on
        // port, so the same --permit-key value works against both.
        add("--port"); add(config.port.toString())
        // --ipv6_domain (-V's long name in Settings.cpp): forces
        // resolution/connection over IPv6 (see TestConfig.forceIpv6's own
        // doc comment for why this exists as an explicit override rather
        // than relying on SockAddr_setHostname's default try-v4-then-v6
        // fallback). Mode-independent, unlike the flags inside the
        // `when (config.mode)` block below.
        if (config.forceIpv6) {
            add("--ipv6_domain")
        }
        add("--enhanced")
        add("--reportstyle"); add("C")
        add("--interval"); add(config.intervalSecs.toString())
        // No padding here: a --time N run's tracked-sample count (e.g. the
        // live sparkline's n=) legitimately lands at N-1, not N -
        // IperfViewModel deliberately drops the very first interval report
        // (its data was still sitting in the client's local socket send
        // buffer, not yet actually measured on the wire). Tried padding +1
        // second to make the visible count hit N; empirically iperf itself
        // doesn't add a full extra interval for a single extra requested
        // second (--time 60 and --time 61 both measured out to the same 60
        // raw intervals against a live server), so the padding didn't even
        // work, and the exact
        // offset needed isn't a reliably fixed constant - it depends on
        // connection-setup timing relative to the interval boundary.
        // Simpler and honest: duration means duration, sample count is
        // whatever it legitimately is.
        add("--time"); add(config.durationSecs.toString())
        // config.parallelStreams pinned to 1 for now, ignoring whatever's
        // stored - RTT/bytes-in-flight only reflect one stream's TCP_INFO,
        // so >1 produces meters that don't match reality. UI control for
        // this is removed too (IperfScreen.kt); revisit both together.
        add("--parallel"); add("1")
        when (config.mode) {
            TestMode.TCP -> {
                if (config.writePrefetchEnabled) {
                    add("--tcp-write-prefetch"); add(config.writePrefetchBytes)
                }
                if (config.tcpCcaEnabled) {
                    add("--cca"); add(config.tcpCca)
                }
                // Unconditional, not gated on writePrefetchEnabled - plain
                // wall-clock timing around the write()/writev() syscall
                // (src/Client.cpp), measuring real send-side blocking
                // regardless of whether an explicit TCP_NOTSENT_LOWAT cap
                // is set. Backs IntervalSample.writeTimeUs/BytesInFlight-
                // Meter's own write-block-time bar.
                add("--tcp-write-times")
            }
            // --udp-l4s implies --udp, PragueCC congestion control, and
            // enhanced reporting on its own (Settings.cpp OPT_UDP_L4S case).
            TestMode.UDP_L4S -> {
                add("--udp-l4s")
                // --cca reno, under --udp-l4s: opt-in only, omitted for
                // PRAGUE since that's already the native default (see
                // L4SCongestionControl's own doc comment) - keeps argv
                // identical to before this feature existed for the common
                // case.
                if (config.l4sCca == L4SCongestionControl.RENO) {
                    add("--cca"); add("reno")
                }
            }
            TestMode.BOUNCEBACK -> {
                // --cca applies at the socket level (Settings.cpp's
                // OPT_TCP_CCA case isn't gated to any one test type) and
                // bounceback runs over TCP, so the same congestion-control
                // picker the TCP test uses applies here too - distinct from
                // --working-load-cca, which only affects the separate
                // working-load streams, not the bounce connection itself.
                // Only when the probe transport is still TCP, though - CCA
                // is a TCP-only concept, and Settings.cpp would just WARN
                // and unset it under -u anyway, but cleaner not to send it
                // at all when it doesn't apply (see IperfCommandBuilder's
                // own class doc comment). Gated on bouncebackCcaEnabled, not
                // tcpCcaEnabled - Bounceback's own switch, see TestConfig's
                // own doc comment for why they're kept independent.
                when (config.bouncebackTransport) {
                    BouncebackTransport.TCP -> {
                        if (config.bouncebackCcaEnabled) {
                            add("--cca"); add(config.tcpCca)
                        }
                    }
                    // --udp-l4s: switches the bounce round trip itself to
                    // UDP, ECT(1)-marked (discrete stop-and-wait - see
                    // BouncebackTransport's own doc comment). Working load
                    // and the request/reply size knobs below are unaffected
                    // either way.
                    BouncebackTransport.UDP_L4S -> add("--udp-l4s")
                    // --udp: same discrete UDP round trip, deliberately
                    // unmarked - HEADER_BBL4S (payloads.h) is only set on
                    // the wire when the client itself ran --udp-l4s, so
                    // plain --udp here also gets an unmarked reply, not
                    // just an unmarked request.
                    BouncebackTransport.UDP -> add("--udp")
                }
                add("--bounceback")
                // --bounceback-period is required_argument (a plain two-token
                // "flag value" pair works, unlike --working-load/--permit-key
                // below) - defaults to 0 (send the next request immediately
                // on reply, no artificial client-side pacing) so this
                // measures actual round-trip latency back-to-back rather
                // than latency-plus-however-long-the-client-chose-to-wait.
                // Not exposed as a UI option - same "keep it simple" call as
                // every other bounceback/working-load knob this app doesn't
                // surface.
                add("--bounceback-period"); add("0")
                // --bounceback-request/--bounceback-reply are both
                // required_argument, same plain "flag value" pair as
                // --bounceback-period above.
                if (config.bouncebackSizeEnabled) {
                    add("--bounceback-request"); add(config.bouncebackRequestBytes)
                    add("--bounceback-reply"); add(config.bouncebackReplyBytes)
                }
                // --histogram-baseline name=path: compares this run's own
                // RTT histogram against a previously-saved "golden"
                // reference natively (Earth Mover's Distance, see
                // histogram_emd_against_baseline(), src/histogram.c),
                // rather than the app trying to reproduce that math in
                // Kotlin. " BB8" must match struct histogram.myname
                // exactly (Reports.c) - it's what lets a single flag stay
                // unambiguous on a run with more than one active
                // histogram. Only added once a golden reference actually
                // exists (GoldenHistogramStore.save(), triggered by the
                // user's own "Save as golden" action - see
                // IperfViewModel.saveGoldenHistogram()'s own doc comment
                // for why this is never automatic).
                if (GoldenHistogramStore.exists(context)) {
                    add("--histogram-baseline"); add(" BB8=${GoldenHistogramStore.file(context).absolutePath}")
                }
                // --working-load is optional_argument, same single-token
                // rule as --permit-key below - "up"/"down"/"bidir" plus an
                // optional ",<threads>" (Settings.cpp OPT_WORKING_LOAD).
                if (config.workingLoadEnabled) {
                    val dir = when (config.workingLoadDirection) {
                        WorkingLoadDirection.UP -> "up"
                        WorkingLoadDirection.DOWN -> "down"
                        WorkingLoadDirection.BIDIR -> "bidir"
                    }
                    // Thread count pinned to 1, ignoring whatever's stored
                    // in config.workingLoadThreads - a live test found
                    // --working-load with >1 threads fails almost
                    // immediately server-side (connection reset right
                    // after the first write), a C-side issue independent
                    // of this app. UI control for this is removed too
                    // (IperfScreen.kt); revisit both together once that's
                    // fixed.
                    add("--working-load=$dir,1")
                    // --working-load-transport udp-l4s: runs this stream
                    // over UDP L4S instead of TCP, with its own independent
                    // Prague/Reno choice (isWorkingLoadL4SCcaReno,
                    // Launch.cpp) - not tied to the main flow's own
                    // bouncebackCcaEnabled/tcpCca choice above. --cca reno,
                    // under --working-load-transport udp-l4s: opt-in only,
                    // omitted for PRAGUE since that's already the native
                    // default - same "keep argv identical to before this
                    // feature existed" reasoning as the main flow's own
                    // l4sCca handling above. When TCP, --working-load-cca is
                    // still the TCP_CONGESTION sockopt for this stream.
                    if (config.workingLoadTransport == Transport.UDP_L4S) {
                        add("--working-load-transport"); add("udp-l4s")
                        if (config.workingLoadL4sCca == L4SCongestionControl.RENO) {
                            add("--working-load-cca"); add("reno")
                        }
                    } else {
                        // --working-load-cca is required_argument (plain
                        // "flag value" pair, unlike --working-load above).
                        add("--working-load-cca"); add(config.workingLoadCca)
                    }
                }
            }
        }
        // --reverse: server becomes the writer, this device becomes the
        // reader - supported for both TCP and UDP L4S (Settings.cpp doesn't
        // gate isReverse by protocol). --tcp-write-prefetch/--tcp-cca above
        // still get relayed to and applied by the server in this mode
        // (negotiated over the header exchange regardless of direction), so
        // they're added unconditionally in the TCP branch above, not
        // skipped here. Bounceback is its own round-trip protocol, not a
        // direction, so --reverse never applies there regardless of
        // config.reverseEnabled's (possibly stale, left over from a prior
        // TCP/UDP L4S selection) value.
        if (config.reverseEnabled && config.mode != TestMode.BOUNCEBACK) {
            add("--reverse")
        }
        // --permit-key is declared as optional_argument in getopt_long
        // (Settings.cpp) - a separate "--permit-key" "value" argv pair does
        // NOT associate the value with the option (getopt_long only
        // recognizes --permit-key=value for optional-argument long
        // options), so this must always be a single token or the client
        // hits "ERROR: option of --permit-key requires a value" and exits
        // immediately without ever connecting.
        val manualKey = config.manualPermitKey.trim()
        if (manualKey.isNotEmpty()) {
            // Explicit override - sent regardless of HostClassifier, unlike
            // the auto-computed key below. That heuristic only exists to
            // avoid needlessly sending the *auto-computed* key (which only
            // matches this app's own built-in responde.* fleet) to
            // unrelated hosts; a manually-typed key means the user is
            // deliberately testing their own permit-key-gated server.
            add("--permit-key=$manualKey")
            // --permit-key-hmac: the value above is used as an HMAC-SHA256
            // key by the native binary (build_permit_key_wire_value(),
            // Settings.cpp) rather than sent as a raw bearer secret - the
            // native client is the sole implementation of that wire format,
            // this app never constructs it itself. See PERMIT_KEY_NOTES.
            add("--permit-key-hmac")
        } else if (!HostClassifier.isLocalOrPrivate(config.host)) {
            PermitKeyProvider.compute(versionInfo)?.let { key ->
                add("--permit-key=$key")
                add("--permit-key-hmac")
            }
        }
    }
}
