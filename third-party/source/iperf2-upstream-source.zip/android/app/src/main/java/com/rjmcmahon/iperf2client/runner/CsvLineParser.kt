package com.rjmcmahon.iperf2client.runner

import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import com.rjmcmahon.iperf2client.model.BouncebackTransport
import com.rjmcmahon.iperf2client.model.HistogramBin
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.TestMode

/**
 * Parses one line of `iperf -c ... -e -y C` output into an [IntervalSample].
 *
 * TCP fields (reportCSV_bw_tcp_write_enhanced_format, src/Locale.c):
 * time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,
 * speed,writecnt,writeerr,tcpretry,tcpcwnd,tcppcwnd,tcprtt,tcprttvar,
 * tcppktsinflight,tcpbytesinflight,tcpnotsent,tcpminrtt,tcpsndbuf,
 * tcpwritetimeus (23 fields - tcpnotsent is iperf_tcpstats.notsent_bytes,
 * Linux tcpi_notsent_bytes: bytes already written to the socket but not
 * yet put on the wire, distinct from tcpbytesinflight's unacked-on-the-wire
 * bytes. tcpminrtt is iperf_tcpstats.rtt_min, Linux tcpi_min_rtt: the
 * kernel's own continuously-updated minimum RTT for this connection.
 * tcpsndbuf is iperf_tcpstats.sndbuf_bytes (getsockopt SO_SNDBUF, KB) - the
 * live, currently-autotuned send socket buffer size, sampled every
 * interval alongside the rest of this writer's own gettcpinfo() call.
 * tcpwritetimeus is write_mmm.current.mean (ReportStruct.write_time,
 * --tcp-write-times only) - mean microseconds spent blocked inside the
 * write()/writev() syscall itself this interval: send-side backpressure/
 * buffer-sojourn delay, an earlier and separate stage from tcprtt (TCP's
 * RTT clock only starts once a byte is actually transmitted) - -1 when
 * --tcp-write-times isn't active).
 *
 * UDP-L4S fields (reportCSV_bw_udp_write_enhanced_l4s_format, src/Locale.c):
 * time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,
 * speed,jitter,errors,datagrams,errpercent,outoforder,writecnt,writeerr,
 * writetimeo,pps,ce,ceperc,cedurationavg,cedurationmin,cedurationmax,
 * cedurationcnt,qdelayus,qbytes,rttus,pktwindow,inflight,markprob (31
 * fields - the l4s variant adds ce/ceperc, PragueCC's congestion-experienced
 * mark stats, cedurationavg/min/max/cnt (mean/min/max duration in ms of
 * each CE-marked episode within the interval), qdelayus/qbytes (PragueCC::
 * GetQueueInfo() - sender-side queueing-delay estimate and its Little's Law
 * queue-occupancy estimate in bytes, a live snapshot like TCP's tcprtt/
 * tcpbytesinflight rather than a per-interval min/mean/max), rttus
 * (PragueCC::GetSmoothedRtt() - the raw RTT qdelayus is itself derived
 * from, same live-snapshot contract), and pktwindow/inflight/markprob
 * (PragueCC's own congestion window/actual in-flight packets - direct,
 * RTT-independent measurements, distinct from qdelayus's RTT-derived
 * estimate - and its EWMA-smoothed marking probability, distinct from
 * ceperc's own raw per-interval ratio) on top of the plain UDP
 * write-enhanced format's 19. errpercent (already part of the shared
 * 19-field prefix, at a fixed position regardless of mode) is the standard
 * UDP loss percentage - the "loss probability" counterpart to markprob's
 * "marking probability", parsed here too even though it predates this
 * L4S-specific extension.
 *
 * Unlike TCP, UDP-L4S doesn't need a separate isReverse branch:
 * reportCSV_bw_udp_read_enhanced_l4s_format (the -R/reader-role CSV) has
 * the exact same 31 fields in the exact same positions as the write-side
 * format above - only writecnt/writeerr/writetimeo become
 * readcnt/readtimeo/readerrlen, columns this parser never reads anyway -
 * so the same field-index constants below work for both directions. Note
 * qdelayus/qbytes/rttus/pktwindow/inflight/markprob are always -1 on the
 * read/reverse side (all sender-side-only PragueCC state, not yet relayed
 * back to the reader) - errpercent is unaffected, it's the reader's own
 * locally-tracked loss.
 *
 * TCP reverse-mode fields (reportCSV_bw_tcp_read_enhanced_reverse_format,
 * src/Locale.c): time,srcaddress,srcport,dstaddr,dstport,transferid,
 * istart,iend,bytes,speed,readcnt,bin0..bin7,tcprtt,tcpbytesinflight,
 * tcppktsinflight,tcpcwnd,tcpretry,tcpnotsent,tcpminrtt,tcpsndbuf,
 * tcpwritetimeus (28 fields - this device is the reader in -R mode, so
 * rtt/bytes-in-flight/packets-in-flight/cwnd/retry/notsent/min-rtt/sndbuf/
 * writetimeus are all relayed from the server's own gettcpinfo()/write_mmm
 * sample rather than measured locally, see Client::WriteTcpTxHdr/
 * Server::RunTCP). tcprtt here is raw microseconds (not pre-divided like
 * the human-readable report), matching the plain TCP format's tcprtt
 * column.
 *
 * BOUNCEBACK fields (reportCSV_client_bb_bw_tcp_format, src/Locale.c):
 * time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,
 * speed,bbcnt,bbavg,bbmin,bbmax,bbstdev,tcpretry,tcpcwnd,tcppcwnd,tcprtt,
 * tcprttvar,tcprttmin,txbytes,rxbytes,rps,ce,ceperc (26 fields - a unique
 * count, no collision with the others below). bbavg/min/max/stdev are the
 * actual measured round-trip bounce latency (ms) - the number this mode
 * exists to show. tcpretry/tcpcwnd/tcppcwnd/tcprtt/tcprttvar/tcprttmin reuse
 * this app's existing tcpRetry/cwndBytes/cwndPackets/rttMicros/rttVarMicros/
 * rttMinMicros fields, same as plain TCP. tcprttmin (iperf_tcpstats.
 * rtt_min, Linux tcpi_min_rtt) is the kernel-tracked connection-lifetime
 * floor, distinct from bbmin (the app-measured min request/reply latency
 * for this interval) - since bounceback is strictly serialized (the
 * client blocks on each reply before sending the next request), 1000 /
 * (rttMinMicros / 1000.0) is a real ceiling on achievable RPS, useful
 * alongside observed RPS to tell pacing-limited from path-limited runs
 * apart. Known gap carried over from the C side: bbmin/bbmax print 0
 * (not -1) when an interval had fewer than 2 bounces to measure - same
 * "0 used as a no-data sentinel" issue CE_Duration had before it was
 * fixed; not yet fixed here since bbcnt<2 in one report interval is rare
 * for a real bounceback test (frequent round trips), but worth revisiting
 * if a run's bbmin ever looks suspiciously exactly 0. The trailing
 * ce/ceperc pair (added after this session's earlier UDP-L4S bounceback
 * work) is the kernel's own TCP_INFO congestion-experienced-mark counters
 * (tcpi_delivered_ce/tcpi_delivered, gettcpinfo.c) - reuses
 * IntervalSample.ceCount/cePercent, the exact same fields UDP-L4S/UDP-L4S
 * bounceback already populate, so CeMarksPerSecMeter needs no mode check to
 * work for TCP bounceback too. Sentinel semantics here are important and
 * different from a lot of this file's other -1 conventions: -1 in *both*
 * fields together means "can't tell you" - either this kernel/build predates
 * tcpi_delivered_ce/tcpi_delivered entirely, or genuinely no data was
 * delivered this interval so a percentage is undefined - while a real
 * ce=0 (NOT -1) means the counters ARE valid and this interval simply saw
 * zero marks (e.g. plain --cca cubic, which is ECN-capable but doesn't
 * itself mark) - a live, meaningful zero, not "unsupported". Parsing needs
 * no special-casing either way: fields[IDX_BB_TCP_CE].toLong() already
 * parses the literal text "-1" as -1L on its own. Distinguishing the two
 * cases visually (grayed-out "N/A" dial vs. a live "0") is entirely the
 * UI layer's job - see CeMarksPerSecMeter's own doc comment.
 *
 * UDP BOUNCEBACK fields (`--udp --bounceback`'s own CSV format, distinct
 * from reportCSV_client_bb_bw_tcp_format above - shared identically by
 * both BouncebackTransport.UDP_L4S and .UDP, see that enum's own doc
 * comment for why the ECT(1)-marking choice doesn't change the CSV shape,
 * only what's on the wire): time,srcaddress,srcport,
 * dstaddr,dstport,transferid,istart,iend,bytes,speed,bbcnt,bbavg,bbmin,
 * bbmax,bbstdev,txbytes,rxbytes,rps,ce,ceperc (20 fields). The shared
 * 10-field prefix (time..speed) and the bbcnt..bbstdev/rps block occupy the
 * exact same positions as the TCP bounceback format above (IDX_BBCNT..
 * IDX_BBSTDEV are reused as-is), since this is the same discrete
 * stop-and-wait request/reply measurement, just carried over a UDP socket
 * instead of TCP - no TCP_INFO columns at all (tcpretry/tcpcwnd/tcprtt/
 * etc.), since there's no TCP connection to sample. txbytes/rxbytes
 * (indices 15-16) are left unparsed, same as the TCP format's own
 * txbytes/rxbytes columns never being read either. ce/ceperc are
 * PragueCC's usual congestion-experienced mark count/percent (see
 * IntervalSample.ceCount/cePercent, already used by TestMode.UDP_L4S and,
 * as of the trailing ce/ceperc columns documented in the TCP BOUNCEBACK
 * section above, plain TCP bounceback too) - reused here rather than
 * duplicated, even though this data arrives via TestMode.BOUNCEBACK, not
 * TestMode.UDP_L4S. Legitimately always 0 for BouncebackTransport.UDP -
 * an unmarked packet is never CE-mark-eligible, so there's nothing for a
 * queue to mark. Because TestMode.BOUNCEBACK
 * now covers two different CSV shapes (this one, shared by both UDP
 * variants, and the TCP one above), [parse] takes an explicit
 * bouncebackTransport parameter to pick between them - mode alone is no
 * longer enough.
 *
 * The TCP, plain-UDP, and TCP-reverse formats can all coincidentally
 * share a field count (19 or 21) but have completely different meanings
 * past the shared 10-field prefix (time..speed), so which one a line
 * matches MUST be driven by which mode/direction the running test used -
 * not inferred from field count alone, or a line could silently get
 * misparsed as the wrong kind of data instead of being rejected. If any
 * of these format strings change, this is the one file that needs
 * updating.
 */
object CsvLineParser {
    // 27, not 26 - trailing tcppaused column (reportCSV_bw_tcp_write_
    // enhanced_format), a count of SIGUSR1-paused null events this
    // interval (0 for any non-working-load TCP writer, always) - lets a
    // deliberately paused --working-load=up|bidir interval (0 bytes,
    // tcppaused > 0) be told apart from a genuine backpressure stall or
    // intermittent network outage (0 bytes, tcppaused == 0), which would
    // otherwise be an identical zero-byte row. See IDX_TCP_PAUSED's own
    // doc comment.
    private const val TCP_FIELD_COUNT = 27
    // 32, not 31 - trailing ccamode column (--cca, under --udp-l4s; native
    // commit 2ecc85d4), see IDX_L4S_CCA_MODE's own doc comment.
    private const val UDP_L4S_FIELD_COUNT = 32
    private const val TCP_REVERSE_FIELD_COUNT = 31
    // 28, not 26 - trailing tcpbusyus/tcpsndbuflimitedus columns (native
    // commit adding reportCSV_client_bb_bw_tcp_format's own tcpbusyus/
    // tcpsndbuflimitedus fields) added specifically to break a real
    // ambiguity with TCP_FIELD_COUNT above: both were 26, field-for-field
    // indistinguishable by shape alone from a plain TCP
    // working-load=up|bidir forward-write row even though the column
    // *meanings* are completely different. Two trailing fields, not one -
    // TCP_FIELD_COUNT's own new value (27, tcppaused above) needed a
    // number too, and it would have collided with a single-field bump
    // here (both landing on 27) just as surely as the original 26/26
    // collision this whole fix exists for - see IDX_BB_TCPBUSYUS's own
    // doc comment.
    private const val BOUNCEBACK_FIELD_COUNT = 28
    private const val BOUNCEBACK_UDP_FIELD_COUNT = 20

    // Shared by every format's prefix (see the class doc comment). -1 here
    // marks iperf2's own "Sum" aggregate row, emitted once per interval
    // whenever a report group has more than one stream to combine - e.g.
    // --working-load's background stream(s) sharing a group with the
    // bounceback connection itself. That row happens to carry exactly
    // BOUNCEBACK_FIELD_COUNT fields too (all-(-1) sentinels past the
    // shared prefix), so without this check it parses as a normal
    // BOUNCEBACK sample and overwrites latestSample with an
    // all-unavailable reading every other interval - the bar graph would
    // flicker to N/A and back on each report tick.
    // Shared by every format at this same fixed position - the socket's
    // actual local IP for this interval, see IntervalSample.srcAddress's
    // own doc comment for why this is read into every branch below.
    private const val IDX_SRCADDRESS = 1
    private const val IDX_DSTADDR = 3
    // Confirmed via a real device+native repro (2026-07-31) that dstaddr is
    // NOT a reliable upload/download signal for UDP L4S working-load rows -
    // a blank dstaddr on the download/read row was never a deliberate
    // protocol invariant, just an accident of one specific (buggy,
    // since-fixed) native code path that reused a shared socket without
    // ever populating its own peer sockaddr; a plain standalone `-R
    // --udp-l4s` reverse test prints a fully populated dstaddr today, same
    // as upload rows do. IDX_SRCPORT/IDX_DSTPORT below are the actual
    // robust signal instead - see parseWorkingLoadUploadThroughput's own
    // doc comment.
    private const val IDX_SRCPORT = 2
    private const val IDX_DSTPORT = 4
    private const val IDX_TRANSFERID = 5
    private const val IDX_ISTART = 6
    private const val IDX_IEND = 7
    private const val IDX_BYTES = 8
    private const val IDX_SPEED = 9

    private const val IDX_TCPRETRY = 12
    private const val IDX_TCPCWND = 13
    private const val IDX_TCPPCWND = 14
    private const val IDX_TCPRTT = 15
    private const val IDX_TCPRTTVAR = 16
    private const val IDX_PKTSINFLIGHT = 17
    private const val IDX_BYTESINFLIGHT = 18
    private const val IDX_TCPNOTSENT = 19
    private const val IDX_TCPMINRTT = 20
    private const val IDX_TCPSNDBUF = 21
    private const val IDX_TCPWRITETIME = 22
    private const val IDX_TCPSNDBUFLIMITED = 23
    private const val IDX_TCPRWNDLIMITED = 24
    private const val IDX_TCPBUSYTIME = 25
    // Trailing field added when reportCSV_bw_tcp_write_enhanced_format
    // grew from 26 to 27 fields - see TCP_FIELD_COUNT's own doc comment
    // for why (breaking a real shape collision with BOUNCEBACK_FIELD_
    // COUNT) and what the value means (a count of SIGUSR1-paused null
    // events this interval, always a real 0 for anything but a paused
    // working-load thread).
    private const val IDX_TCP_PAUSED = 26

    private const val IDX_JITTER = 10
    private const val IDX_ERRPERCENT = 13
    private const val IDX_PPS = 18
    private const val IDX_CE = 19
    private const val IDX_CEPERC = 20
    private const val IDX_CE_DURATION_AVG = 21
    private const val IDX_CE_DURATION_MIN = 22
    private const val IDX_CE_DURATION_MAX = 23
    private const val IDX_CE_DURATION_CNT = 24
    private const val IDX_QUEUE_DELAY_US = 25
    private const val IDX_QUEUE_BYTES = 26
    private const val IDX_L4S_RTT_US = 27
    private const val IDX_L4S_PACKET_WINDOW = 28
    private const val IDX_L4S_INFLIGHT = 29
    private const val IDX_L4S_MARKING_PROB = 30
    // --cca <prague|reno>, under --udp-l4s (native commit 2ecc85d4) - trailing
    // "prague"/"reno" string column, printed by ReportOutputs.c's
    // udp_output_read/write_enhanced_csv_l4s. Bumps UDP_L4S_FIELD_COUNT
    // below from 31 to 32 - the exact-count check at this class's own
    // parse() call site means this MUST stay in sync with the native
    // CSV column count, or every UDP L4S line silently fails to parse.
    private const val IDX_L4S_CCA_MODE = 31

    private const val IDX_REV_TCPRTT = 19
    private const val IDX_REV_TCPBYTESINFLIGHT = 20
    private const val IDX_REV_TCPPKTSINFLIGHT = 21
    private const val IDX_REV_TCPCWND = 22
    private const val IDX_REV_TCPRETRY = 23
    private const val IDX_REV_TCPNOTSENT = 24
    private const val IDX_REV_TCPMINRTT = 25
    private const val IDX_REV_TCPSNDBUF = 26
    private const val IDX_REV_TCPWRITETIME = 27
    private const val IDX_REV_TCPSNDBUFLIMITED = 28
    private const val IDX_REV_TCPRWNDLIMITED = 29
    private const val IDX_REV_TCPBUSYTIME = 30

    private const val IDX_BBCNT = 10
    private const val IDX_BBAVG = 11
    private const val IDX_BBMIN = 12
    private const val IDX_BBMAX = 13
    private const val IDX_BBSTDEV = 14
    private const val IDX_BB_TCPRETRY = 15
    private const val IDX_BB_TCPCWND = 16
    private const val IDX_BB_TCPPCWND = 17
    private const val IDX_BB_TCPRTT = 18
    private const val IDX_BB_TCPRTTVAR = 19
    private const val IDX_BB_TCPRTTMIN = 20
    private const val IDX_RPS = 23
    // Trailing pair added when reportCSV_client_bb_bw_tcp_format grew from
    // 24 to 26 fields - kernel TCP_INFO CE-mark counters, see the class doc
    // comment's BOUNCEBACK section for the -1-vs-0 sentinel distinction.
    private const val IDX_BB_TCP_CE = 24
    private const val IDX_BB_TCP_CEPERC = 25
    // Trailing field added when reportCSV_client_bb_bw_tcp_format grew from
    // 26 to 27 fields - kernel-tracked cumulative busy time for this
    // connection's socket (Linux tcpi_busy_time, same field plain TCP's own
    // tcpbusyus column already surfaces), microseconds. Bumped
    // BOUNCEBACK_FIELD_COUNT specifically to stop colliding with
    // TCP_FIELD_COUNT (both were 26) - a --working-load=up|bidir TCP
    // stream's own forward-write row was, before this, field-for-field
    // indistinguishable in *shape* from a real bounceback row despite
    // completely different column meanings, and got silently misparsed as
    // a garbage bounceback sample every interval. Not yet read into
    // IntervalSample below - this constant exists so the field is at least
    // documented and reachable if a future change wants to surface it.
    private const val IDX_BB_TCPBUSYUS = 26

    // UDP-L4S bounceback (BOUNCEBACK_UDP_FIELD_COUNT) only. bbcnt..bbstdev
    // sit at the same IDX_BBCNT..IDX_BBSTDEV positions as TCP bounceback
    // above - reused as-is, not redeclared - since both formats share the
    // same 10-field prefix and immediately follow it with the same
    // bbcnt/bbavg/bbmin/bbmax/bbstdev block.
    private const val IDX_BB_UDP_TXBYTES = 15
    private const val IDX_BB_UDP_RXBYTES = 16
    private const val IDX_BB_UDP_RPS = 17
    private const val IDX_BB_UDP_CE = 18
    private const val IDX_BB_UDP_CEPERC = 19

    // Reverse-mode rtt and packets-in-flight are both printed unsigned
    // (%PRIuLEAST32, see reportCSV_bw_tcp_read_enhanced_reverse_format/
    // ReportOutputs.c), so the "not valid" sentinel comes across as the
    // literal text "4294967295" ((uint32_t)-1), not "-1" - unlike
    // bytesInFlight there (intmax_t, printed as a real signed -1).
    // Translate it to this app's usual -1L "not available" convention so
    // the >= 0 checks in RttMeter/BytesInFlightMeter etc. don't mistake
    // it for a real (and wildly wrong) value.
    private const val UNSIGNED_SENTINEL = 0xFFFFFFFFL

    /** True for the one CSV header line iperf2 prints once per run - useful
     * so callers can distinguish "not a data line, but not worth showing as
     * a status message either" from a genuine error/info line. */
    fun isHeaderLine(line: String): Boolean = line.trim().startsWith("time,")

    /**
     * True for iperf2's own "Sum" aggregate row (see [IDX_TRANSFERID]'s doc
     * comment) - [parse] already rejects these for BOUNCEBACK so they never
     * become a sample, but callers still need to recognize and discard them
     * explicitly, or the raw CSV text would otherwise fall through and get
     * shown as if it were a status message once per interval.
     */
    fun isSumRow(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("time,")) return false
        val fields = trimmed.split(",")
        return fields.size > IDX_TRANSFERID && fields[IDX_TRANSFERID] == "-1"
    }

    /**
     * True for the one benign warning bounceback always logs at the very end
     * of a normal, successful run: the per-thread duration timer
     * (timer_create()/SIGEV_THREAD_ID, see Client.cpp's RunBounceBackTCP)
     * interrupts the client's blocked read with EINTR to end the test on
     * schedule, and that read failure is reported the same way a real one
     * would be ("timeout: bounceback read failed: Interrupted system call").
     * It's expected on essentially every completed run, not a sign anything
     * went wrong - display-layer noise only. This is intentionally an
     * Android-app-only filter: the underlying C code and CLI output are
     * unchanged, since command-line users still want to see everything.
     */
    fun isBenignBounceBackEndOfTestInterrupt(line: String): Boolean =
        line.trim() == "timeout: bounceback read failed: Interrupted system call"

    fun parse(
        line: String,
        mode: TestMode,
        isReverse: Boolean = false,
        // Only meaningful when mode == BOUNCEBACK - TestMode alone can no
        // longer determine the CSV shape for that mode (see the class doc
        // comment's UDP-L4S BOUNCEBACK paragraph), so the caller (which
        // knows the running test's own TestConfig) must say which one to
        // expect. Ignored for every other mode.
        bouncebackTransport: BouncebackTransport = BouncebackTransport.TCP,
    ): IntervalSample? {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("time,")) return null // header line
        val fields = trimmed.split(",")
        return try {
            when (mode) {
                TestMode.TCP -> {
                    if (isReverse) {
                        if (fields.size != TCP_REVERSE_FIELD_COUNT) return null
                        val rawRtt = fields[IDX_REV_TCPRTT].toLong()
                        val rawPktsInFlight = fields[IDX_REV_TCPPKTSINFLIGHT].toLong()
                        val rawRetry = fields[IDX_REV_TCPRETRY].toLong()
                        val rawRttMin = fields[IDX_REV_TCPMINRTT].toLong()
                        IntervalSample(
                            intervalStartSecs = fields[IDX_ISTART].toDouble(),
                            intervalEndSecs = fields[IDX_IEND].toDouble(),
                            bytes = fields[IDX_BYTES].toLong(),
                            speedBitsPerSec = fields[IDX_SPEED].toLong(),
                            tcpRetry = if (rawRetry == UNSIGNED_SENTINEL) -1L else rawRetry,
                            cwndBytes = fields[IDX_REV_TCPCWND].toLong(),
                            rttMicros = if (rawRtt == UNSIGNED_SENTINEL) -1L else rawRtt,
                            bytesInFlight = fields[IDX_REV_TCPBYTESINFLIGHT].toLong(),
                            packetsInFlight = if (rawPktsInFlight == UNSIGNED_SENTINEL) -1L else rawPktsInFlight,
                            notSentBytes = fields[IDX_REV_TCPNOTSENT].toLong(),
                            rttMinMicros = if (rawRttMin == UNSIGNED_SENTINEL) -1L else rawRttMin,
                            sndBufKB = fields[IDX_REV_TCPSNDBUF].toLong(),
                            writeTimeUs = fields[IDX_REV_TCPWRITETIME].toLong(),
                            sndBufLimitedUs = fields[IDX_REV_TCPSNDBUFLIMITED].toLong(),
                            rwndLimitedUs = fields[IDX_REV_TCPRWNDLIMITED].toLong(),
                            busyTimeUs = fields[IDX_REV_TCPBUSYTIME].toLong(),
                            srcAddress = fields.getOrNull(IDX_SRCADDRESS),
                        )
                    } else {
                        if (fields.size != TCP_FIELD_COUNT) return null
                        val rawRttMin = fields[IDX_TCPMINRTT].toLong()
                        IntervalSample(
                            intervalStartSecs = fields[IDX_ISTART].toDouble(),
                            intervalEndSecs = fields[IDX_IEND].toDouble(),
                            bytes = fields[IDX_BYTES].toLong(),
                            speedBitsPerSec = fields[IDX_SPEED].toLong(),
                            tcpRetry = fields[IDX_TCPRETRY].toLong(),
                            cwndBytes = fields[IDX_TCPCWND].toLong(),
                            cwndPackets = fields[IDX_TCPPCWND].toLong(),
                            rttMicros = fields[IDX_TCPRTT].toLong(),
                            rttVarMicros = fields[IDX_TCPRTTVAR].toLong(),
                            packetsInFlight = fields[IDX_PKTSINFLIGHT].toLong(),
                            bytesInFlight = fields[IDX_BYTESINFLIGHT].toLong(),
                            notSentBytes = fields[IDX_TCPNOTSENT].toLong(),
                            rttMinMicros = if (rawRttMin == UNSIGNED_SENTINEL) -1L else rawRttMin,
                            sndBufKB = fields[IDX_TCPSNDBUF].toLong(),
                            writeTimeUs = fields[IDX_TCPWRITETIME].toLong(),
                            sndBufLimitedUs = fields[IDX_TCPSNDBUFLIMITED].toLong(),
                            rwndLimitedUs = fields[IDX_TCPRWNDLIMITED].toLong(),
                            busyTimeUs = fields[IDX_TCPBUSYTIME].toLong(),
                            srcAddress = fields.getOrNull(IDX_SRCADDRESS),
                        )
                    }
                }
                TestMode.UDP_L4S -> {
                    if (fields.size != UDP_L4S_FIELD_COUNT) return null
                    IntervalSample(
                        intervalStartSecs = fields[IDX_ISTART].toDouble(),
                        intervalEndSecs = fields[IDX_IEND].toDouble(),
                        bytes = fields[IDX_BYTES].toLong(),
                        speedBitsPerSec = fields[IDX_SPEED].toLong(),
                        jitterMs = fields[IDX_JITTER].toDouble(),
                        packetsPerSec = fields[IDX_PPS].toDouble(),
                        ceCount = fields[IDX_CE].toLong(),
                        cePercent = fields[IDX_CEPERC].toDouble(),
                        ceDurationAvgMs = fields[IDX_CE_DURATION_AVG].toDouble(),
                        ceDurationMinMs = fields[IDX_CE_DURATION_MIN].toDouble(),
                        ceDurationMaxMs = fields[IDX_CE_DURATION_MAX].toDouble(),
                        ceDurationCount = fields[IDX_CE_DURATION_CNT].toLong(),
                        queueDelayUs = fields[IDX_QUEUE_DELAY_US].toLong(),
                        queueBytes = fields[IDX_QUEUE_BYTES].toLong(),
                        l4sRttUs = fields[IDX_L4S_RTT_US].toLong(),
                        l4sPacketWindow = fields[IDX_L4S_PACKET_WINDOW].toLong(),
                        l4sInflight = fields[IDX_L4S_INFLIGHT].toLong(),
                        l4sMarkingProb = fields[IDX_L4S_MARKING_PROB].toLong(),
                        errPercent = fields[IDX_ERRPERCENT].toDouble(),
                        l4sCcaMode = fields[IDX_L4S_CCA_MODE],
                        srcAddress = fields.getOrNull(IDX_SRCADDRESS),
                    )
                }
                TestMode.BOUNCEBACK -> {
                    // Both UDP variants (marked or not) share the identical
                    // CSV schema - the wire-level marking choice
                    // (HEADER_BBL4S) doesn't change what columns iperf2
                    // prints, only what's in the TOS byte. Only TCP gets
                    // the other shape below.
                    if (bouncebackTransport != BouncebackTransport.TCP) {
                        if (fields.size != BOUNCEBACK_UDP_FIELD_COUNT) return null
                        if (fields[IDX_TRANSFERID] == "-1") return null // Sum row - see IDX_TRANSFERID
                        IntervalSample(
                            intervalStartSecs = fields[IDX_ISTART].toDouble(),
                            intervalEndSecs = fields[IDX_IEND].toDouble(),
                            bytes = fields[IDX_BYTES].toLong(),
                            speedBitsPerSec = fields[IDX_SPEED].toLong(),
                            bbCount = fields[IDX_BBCNT].toLong(),
                            bbAvgMs = fields[IDX_BBAVG].toDouble(),
                            bbMinMs = fields[IDX_BBMIN].toDouble(),
                            bbMaxMs = fields[IDX_BBMAX].toDouble(),
                            bbStdevMs = fields[IDX_BBSTDEV].toDouble(),
                            requestsPerSec = fields[IDX_BB_UDP_RPS].toDouble(),
                            ceCount = fields[IDX_BB_UDP_CE].toLong(),
                            cePercent = fields[IDX_BB_UDP_CEPERC].toDouble(),
                            srcAddress = fields.getOrNull(IDX_SRCADDRESS),
                        )
                    } else {
                        if (fields.size != BOUNCEBACK_FIELD_COUNT) return null
                        if (fields[IDX_TRANSFERID] == "-1") return null // Sum row - see IDX_TRANSFERID
                        IntervalSample(
                            intervalStartSecs = fields[IDX_ISTART].toDouble(),
                            intervalEndSecs = fields[IDX_IEND].toDouble(),
                            bytes = fields[IDX_BYTES].toLong(),
                            speedBitsPerSec = fields[IDX_SPEED].toLong(),
                            tcpRetry = fields[IDX_BB_TCPRETRY].toLong(),
                            cwndBytes = fields[IDX_BB_TCPCWND].toLong(),
                            cwndPackets = fields[IDX_BB_TCPPCWND].toLong(),
                            rttMicros = fields[IDX_BB_TCPRTT].toLong(),
                            rttVarMicros = fields[IDX_BB_TCPRTTVAR].toLong(),
                            rttMinMicros = fields[IDX_BB_TCPRTTMIN].toLong(),
                            bbCount = fields[IDX_BBCNT].toLong(),
                            bbAvgMs = fields[IDX_BBAVG].toDouble(),
                            bbMinMs = fields[IDX_BBMIN].toDouble(),
                            bbMaxMs = fields[IDX_BBMAX].toDouble(),
                            bbStdevMs = fields[IDX_BBSTDEV].toDouble(),
                            requestsPerSec = fields[IDX_RPS].toDouble(),
                            ceCount = fields[IDX_BB_TCP_CE].toLong(),
                            cePercent = fields[IDX_BB_TCP_CEPERC].toDouble(),
                            srcAddress = fields.getOrNull(IDX_SRCADDRESS),
                        )
                    }
                }
            }
        } catch (e: NumberFormatException) {
            null // malformed line (e.g. an interleaved error/warning message) - ignore, don't crash
        }
    }

    /**
     * One working-load stream's own reading: which connection ([transferId],
     * iperf2's own per-connection id) and its current speed - needed rather
     * than just the speed alone because --working-load-threads > 1 spawns
     * several same-direction connections at once, each printing its own
     * independent row, and IperfViewModel sums the latest reading per
     * [transferId] to get that direction's combined throughput (iperf2
     * itself doesn't emit an already-combined number for these - the only
     * "Sum" row observed in practice reuses the *bounceback* group's
     * all-(-1) shape, not a real per-direction total - see [IDX_TRANSFERID]).
     * [intervalEndSecs] (this row's own [IDX_IEND], same field every other
     * format already parses) gives IperfViewModel a real elapsed-time value
     * to timestamp this direction's own TimeSeriesPoint history with,
     * rather than guessing from wall-clock arrival time. [paused] (this
     * row's own [IDX_TCP_PAUSED] - TCP shape only, always false for a UDP
     * L4S working-load row, that format has no equivalent column) is true
     * when this interval was a deliberate SIGUSR1 pause rather than a
     * genuine stall - IperfViewModel uses it to leave a gap in the chart
     * instead of plotting a real zero, so a technician can tell "I paused
     * this" apart from "the network hiccuped" at a glance.
     */
    data class WorkingLoadReading(
        val transferId: Int,
        val speedBitsPerSec: Long,
        val intervalEndSecs: Double,
        val paused: Boolean = false,
    )

    /**
     * --working-load's background stream(s) print their own ordinary CSV
     * rows, interleaved with the bounceback test's own
     * [BOUNCEBACK_FIELD_COUNT]-field rows in the same stdout stream.
     * "up"/"bidir" spawns plain forward-writing connection(s)
     * ([TCP_FIELD_COUNT] fields, same shape as TCP mode, or
     * [UDP_L4S_FIELD_COUNT] fields under `--working-load-transport
     * udp-l4s`); "down"/"bidir" spawns *reverse-role* connection(s)
     * instead - this device reads, the server writes - so those print
     * [TCP_REVERSE_FIELD_COUNT]-field rows for TCP, not the forward shape.
     * UDP L4S is different: write and read roles share the exact same
     * [UDP_L4S_FIELD_COUNT]-field layout (see [parse]'s own UDP-L4S
     * paragraph), so field count alone can't tell them apart the way it
     * does for TCP. [serverPort] does instead: a row whose own [IDX_DSTPORT]
     * is the server's port is addressed *to* the server (upload); a row
     * whose own [IDX_SRCPORT] is the server's port originated *from* the
     * server (download) - true by construction for any UDP L4S connection,
     * unlike the [IDX_DSTADDR] blank/populated check this replaced (see
     * that constant's own doc comment for why it was never actually
     * reliable). [serverPort] is the port the *working-load* stream itself
     * connects to - equal to the main flow's own [TestConfig.port] except
     * when working-load's own transport differs from the main flow's
     * (Launch.cpp's own client-side port +/-1 shift for that mismatch,
     * not currently mirrored here - only the common same-transport case,
     * matching the reported bug, is covered). Both share the same
     * [IDX_SPEED] position past the common prefix either way. Guards
     * against a same-shaped "Sum" row the working load's own multiple
     * streams might produce, the same way [parse] does for bounceback's -
     * see [IDX_TRANSFERID]. Only ever called for lines [parse] already
     * rejected for the current mode.
     */
    fun parseWorkingLoadUploadThroughput(line: String, serverPort: Int): WorkingLoadReading? {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("time,")) return null
        val fields = trimmed.split(",")
        when (fields.size) {
            TCP_FIELD_COUNT -> {}
            UDP_L4S_FIELD_COUNT -> if (fields.getOrNull(IDX_DSTPORT)?.toIntOrNull() != serverPort) return null
            else -> return null
        }
        val transferId = fields[IDX_TRANSFERID].toIntOrNull() ?: return null
        if (transferId < 0) return null // Sum row
        val speed = fields[IDX_SPEED].toLongOrNull() ?: return null
        val intervalEndSecs = fields[IDX_IEND].toDoubleOrNull() ?: return null
        // Only the TCP shape has a tcppaused column at all - see
        // WorkingLoadReading.paused's own doc comment for why UDP L4S
        // working-load stays false always.
        val paused = fields.size == TCP_FIELD_COUNT && (fields.getOrNull(IDX_TCP_PAUSED)?.toLongOrNull() ?: 0L) > 0L
        return WorkingLoadReading(transferId, speed, intervalEndSecs, paused)
    }

    /** See [parseWorkingLoadUploadThroughput]'s doc comment. */
    fun parseWorkingLoadDownloadThroughput(line: String, serverPort: Int): WorkingLoadReading? {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("time,")) return null
        val fields = trimmed.split(",")
        when (fields.size) {
            TCP_REVERSE_FIELD_COUNT -> {}
            UDP_L4S_FIELD_COUNT -> if (fields.getOrNull(IDX_SRCPORT)?.toIntOrNull() != serverPort) return null
            else -> return null
        }
        val transferId = fields[IDX_TRANSFERID].toIntOrNull() ?: return null
        if (transferId < 0) return null // Sum row
        val speed = fields[IDX_SPEED].toLongOrNull() ?: return null
        val intervalEndSecs = fields[IDX_IEND].toDoubleOrNull() ?: return null
        return WorkingLoadReading(transferId, speed, intervalEndSecs)
    }

    // Matches everything from the line's own "[ id]" prefix through the
    // first closing paren after "cnt(N)=<bins>" - i.e. the fixed header +
    // sparse bin list, stopping right before the trailer (percentile
    // markers/outliers/out-of-bounds). Group 5 (the trailer content, not
    // including its own parens) is matched reluctantly (.+?) rather than
    // greedily: histogram_print() (src/histogram.c) sometimes appends a
    private const val BOUNCEBACK_HISTOGRAM_FIELD_COUNT = 21
    private const val IDX_BB_HIST_BINWIDTH = 8
    private const val IDX_BB_HIST_TOTALCOUNT = 9
    private const val IDX_BB_HIST_CILOWERPCT = 10
    private const val IDX_BB_HIST_CIUPPERPCT = 11
    private const val IDX_BB_HIST_CILOWERBIN = 12
    private const val IDX_BB_HIST_CIUPPERBIN = 13
    private const val IDX_BB_HIST_P999BIN = 14
    private const val IDX_BB_HIST_OUTLIERS = 15
    private const val IDX_BB_HIST_OOBLOWER = 16
    private const val IDX_BB_HIST_OOBUPPER = 17
    private const val IDX_BB_HIST_BINS = 18
    // Trailing fields, general-purpose (any struct histogram, not
    // bounceback-only despite this function's own name) - see
    // reportCSV_client_histogram_format's own doc comment (Locale.c).
    private const val IDX_BB_HIST_NAME = 19
    private const val IDX_BB_HIST_EMD = 20
    // The native side's own "no --histogram-baseline configured for this
    // histogram" sentinel (histogram_emd_against_baseline(), src/
    // histogram.c) - maps to a null [BounceBackHistogram.emdVsBaseline].
    private const val EMD_NOT_CONFIGURED_SENTINEL = -1.0

    /**
     * Parses BOUNCEBACK's one-per-run request/reply time distribution
     * summary row (reportCSV_client_histogram_format,
     * histogram_print_csv() in src/histogram.c) - a real, final-only CSV
     * row emitted right after the last interval's own summary row, e.g.:
     * `<time>,127.0.0.1,38802,127.0.0.1,5931,1,0.0,2.0,100,20,5.00,95.00,
     * 1,2,2,0,0,0,1:19;2:1, BB8,-1.000000`. This used to be a hand-rolled regex over
     * histogram_print()'s human-readable text line (the format `-y C`
     * itself never actually emitted - tcp_output_write_bb_csv() simply
     * never called histogram_print() at all, so this app's own -y C runs
     * were silently missing the histogram entirely regardless of how this
     * function parsed it). Fixed on the native side instead of papering
     * over it with a better regex: histogram_print_csv() is a new,
     * CSV-native sibling of histogram_print(), so this is now a plain
     * field-count-dispatched row like every other shape in this file, not
     * a special case.
     *
     * Shares the same time/srcaddress/srcport/dstaddr/dstport/transferid/
     * istart/iend prefix as every other row here (IDX_ISTART/IDX_IEND
     * reused as-is), then: binwidthus/totalcount (bin width, this
     * histogram's own sample count), cilowerpct/ciupperpct (configured
     * percentile bounds, e.g. 5.00/95.00), cilowerbin/ciupperbin/p999bin
     * (1-based bin numbers where the running population first crossed each
     * threshold - see [BounceBackHistogram.binMidpointMs] for converting a
     * bin number to a latency value), outliers/ooblower/oobupper, and a
     * a bins field: every populated bin as semicolon-joined
     * "binnumber:count" pairs (semicolons, not commas, since commas are
     * already this row's own top-level field separator - see
     * histogram_print_csv()'s own doc comment, src/histogram.c), then two
     * trailing fields: name (this histogram's own myname, e.g. " BB8" -
     * see [BounceBackHistogram.name]'s own doc comment) and emd (Earth
     * Mover's Distance against a --histogram-baseline reference, or the
     * native side's own -1.0 "no baseline configured" sentinel - mapped
     * to null, see [BounceBackHistogram.emdVsBaseline]). Only ever the
     * final row - BOUNCEBACK's per-interval histogram is opt-in via
     * --histogram and this app doesn't request it, so there's no
     * "is this the final one" ambiguity to resolve the way [parse]'s
     * isFinalSummaryLine has to for regular interval rows.
     *
     * Returns null for anything that doesn't match this shape (wrong field
     * count, an unrelated line, a malformed number) rather than throwing -
     * same defensive convention as [parse]'s own NumberFormatException
     * catch.
     */
    fun parseBounceBackHistogram(line: String): BounceBackHistogram? {
        val trimmed = line.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("time,")) return null
        val fields = trimmed.split(",")
        if (fields.size != BOUNCEBACK_HISTOGRAM_FIELD_COUNT) return null
        return try {
            val binsRaw = fields[IDX_BB_HIST_BINS]
            val bins = if (binsRaw.isBlank()) {
                emptyList()
            } else {
                binsRaw.split(";").map { entry ->
                    val parts = entry.split(":")
                    HistogramBin(parts[0].toInt(), parts[1].toInt())
                }
            }
            BounceBackHistogram(
                binWidthUs = fields[IDX_BB_HIST_BINWIDTH].toDouble(),
                totalCount = fields[IDX_BB_HIST_TOTALCOUNT].toInt(),
                bins = bins,
                ciLowerPercent = fields[IDX_BB_HIST_CILOWERPCT].toDouble(),
                ciUpperPercent = fields[IDX_BB_HIST_CIUPPERPCT].toDouble(),
                ciLowerBin = fields[IDX_BB_HIST_CILOWERBIN].toInt(),
                ciUpperBin = fields[IDX_BB_HIST_CIUPPERBIN].toInt(),
                p999Bin = fields[IDX_BB_HIST_P999BIN].toInt(),
                outlierCount = fields[IDX_BB_HIST_OUTLIERS].toInt(),
                oobLower = fields[IDX_BB_HIST_OOBLOWER].toInt(),
                oobUpper = fields[IDX_BB_HIST_OOBUPPER].toInt(),
                name = fields[IDX_BB_HIST_NAME],
                emdVsBaseline = fields[IDX_BB_HIST_EMD].toDouble()
                    .takeIf { it != EMD_NOT_CONFIGURED_SENTINEL },
            )
        } catch (e: NumberFormatException) {
            null // malformed row - ignore, don't crash (same convention as parse())
        } catch (e: IndexOutOfBoundsException) {
            null // e.g. a "n:" bin pair missing its count half
        }
    }
}
