package com.rjmcmahon.iperf2client.ui.meters

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.MeterStats
import com.rjmcmahon.iperf2client.model.TestMode
import kotlin.math.ln

private const val MAX_RTT_MS = 1_000.0 // 1 second full-scale, per fixed dial ceiling
private const val RTT_YELLOW_MS = 10.0 // 0-10ms green, 10-100ms yellow, above 100ms red
private const val RTT_RED_MS = 100.0
// RTT's pivot of 1.0 makes the general ln(x/pivot+1)/ln(max/pivot+1) curve
// below reduce to the plain ln(x+1)/ln(max+1) it always used - no behavior
// change here.
private const val RTT_PIVOT_MS = 1.0
// CE episodes run sub-ms to a few ms in practice (observed ~0.2-1.5ms even
// under real congestion), nowhere near RTT's hundreds-of-ms range - reusing
// RTT's plain log curve against a 200ms ceiling left the needle pinned
// under ~5% for any real reading. Same pivot technique ThroughputMeter uses
// against its own MAX/PIVOT_MBPS: dividing by a small pivot before the log
// slows the initial rise so a typical ~1ms reading lands partway up the
// dial instead of hugging zero.
private const val MAX_CE_DURATION_MS = 20.0
private const val CE_DURATION_PIVOT_MS = 0.2
private const val CE_DURATION_YELLOW_MS = 5.0
private const val CE_DURATION_RED_MS = 10.0 // a CE episode running this long signals sustained queue buildup

private val GREEN = Color(0xFF2E7D32)
private val YELLOW = Color(0xFFFFD600) // true yellow, not amber/orange
private val RED = Color(0xFFE53935)

/**
 * Shows RTT for TCP tests, CE (congestion-experienced) mark episode
 * duration for UDP-L4S tests - same dial widget, different metric. Jitter
 * used to occupy this slot for UDP-L4S, but it's a receive-side measurement
 * (see reportCSV_bw_udp_write_enhanced_format, src/Locale.c) - a
 * client/write-only role like this app's never actually gets a real value
 * for it, always -1/"N/A". CE duration is genuinely available client-side
 * (echoed back over the L4S ACK feedback channel, see
 * reportCSV_bw_udp_write_enhanced_l4s_format) and is the mean duration, in
 * ms, of each CE-marked episode within the interval - the min/avg/max text
 * below is this app's own running stat across intervals (same as it always
 * was for RTT/jitter), not the per-interval min/max iperf2 itself reports.
 * BOUNCEBACK reuses TCP's own RTT thresholds/pivot - bounce latency is the
 * same order of magnitude as TCP RTT (an application-level round trip
 * instead of the kernel's TCP_INFO estimate), not CE duration's sub-ms
 * scale, so it doesn't need its own tuned constants. See BounceBoxPlot for
 * the min/max/stdev this dial's own running min/avg/max doesn't capture.
 */
@Composable
fun RttMeter(
    sample: IntervalSample?,
    mode: TestMode,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val label: String
    // TCP's rttMicros is struct iperf_tcpstats.rtt (TCP_INFO's tcpi_rtt) -
    // the kernel's own EWMA-smoothed RTT estimate (SRTT), same "smoothed"
    // category as L4sRttMeter's PragueCC::GetSmoothedRtt() - see that
    // composable's own doc comment. BOUNCEBACK's "Bounce RTT" is a raw,
    // single application-level round trip instead (no kernel smoothing
    // involved), so it doesn't get the qualifier.
    val labelSubscript: String?
    val rawValueMs: Double
    val maxMs: Double
    val pivotMs: Double
    val yellowMs: Double
    val redMs: Double
    when (mode) {
        TestMode.TCP -> {
            // "RTT smoothed" (not "RTT" + a parenthesized subscript) -
            // matches RttFloorChart's own line label now that this dial
            // sits paired beside that chart (IperfScreen), so the same
            // quantity reads with the same name in both places.
            label = "RTT smoothed"
            labelSubscript = null
            rawValueMs = (sample?.rttMicros ?: -1L) / 1000.0
            maxMs = MAX_RTT_MS
            pivotMs = RTT_PIVOT_MS
            yellowMs = RTT_YELLOW_MS
            redMs = RTT_RED_MS
        }
        TestMode.UDP_L4S -> {
            label = "CE Duration"
            labelSubscript = null
            rawValueMs = sample?.ceDurationAvgMs ?: -1.0
            maxMs = MAX_CE_DURATION_MS
            pivotMs = CE_DURATION_PIVOT_MS
            yellowMs = CE_DURATION_YELLOW_MS
            redMs = CE_DURATION_RED_MS
        }
        TestMode.BOUNCEBACK -> {
            label = "Bounce RTT"
            labelSubscript = null
            rawValueMs = sample?.bbAvgMs ?: -1.0
            maxMs = MAX_RTT_MS
            pivotMs = RTT_PIVOT_MS
            yellowMs = RTT_YELLOW_MS
            redMs = RTT_RED_MS
        }
    }
    // Once stopped, show the run's own worst case instead of whichever
    // instant the last live interval happened to catch - the peak is the
    // operationally meaningful "final" number for latency (a single bad
    // spike matters for real-time traffic), and it makes the readout
    // agree with the peak marker already drawn on the dial instead of
    // looking inconsistent with it.
    val finalMs = stats?.max
    val available = if (!isRunning && finalMs != null) true else rawValueMs >= 0.0
    val valueMs = if (!isRunning && finalMs != null) finalMs else if (available) rawValueMs else 0.0

    // Pivoted log scale (ln(x/pivot+1)/ln(max/pivot+1), same technique
    // ThroughputMeter uses) - dividing by pivotMs before the log slows the
    // curve's initial rise so a typical reading lands partway up the dial
    // instead of a plain ln(x+1)/ln(max+1) pinning the needle near zero
    // whenever pivot-scale values sit far below maxMs (RTT's pivot of 1.0
    // makes this identical to the old plain-log formula).
    val logSpan = ln(maxMs / pivotMs + 1.0)
    fun logFractionOf(ms: Double) = (ln(ms / pivotMs + 1.0) / logSpan).toFloat()
    val logFraction = if (available) logFractionOf(valueMs) else 0f

    val color = when {
        !available -> Color.White
        valueMs >= redMs -> RED
        valueMs >= yellowMs -> YELLOW
        else -> GREEN
    }

    // Threshold positions in the same log-fraction space as the ticks
    // themselves, so the dial shows green/yellow/red *zones* (e.g. green up
    // to 10ms, yellow from there) rather than every lit tick snapping to
    // whichever single color the current value happens to be in.
    val yellowFraction = logFractionOf(yellowMs)
    val redFraction = logFractionOf(redMs)

    SpeedometerGauge(
        label = label,
        labelSubscript = labelSubscript,
        mainText = if (available) "%.1f".format(valueMs) else "N/A",
        unitText = if (available) "ms" else "",
        fraction = logFraction,
        accentColor = color,
        colorAt = { position ->
            when {
                position >= redFraction -> RED
                position >= yellowFraction -> YELLOW
                else -> GREEN
            }
        },
        avgText = stats?.let { "avg %.1f".format(it.avg) },
        minMaxText = stats?.let { "min %.1f · max %.1f".format(it.min, it.max) },
        peakFraction = stats?.let { logFractionOf(it.max) },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * UDP-L4S only (write/upload direction - always -1/"N/A" in --reverse,
 * same as QueueDelayMeter's queueDelayUs). Shows the raw RTT
 * (PragueCC::GetSmoothedRtt()) that QueueDelayMeter's "Load Delay"
 * (srtt - rtt_min) is itself derived from - a second, separate dial rather
 * than folded into that one, so a reader can see both the derived estimate
 * and the real measured number it came from side by side. Added per Koen
 * De Schepper's review (doc/email_koen_littles_law_review.txt): reuses
 * TCP's own RTT thresholds/pivot (this file's MAX_RTT_MS etc.) since it's
 * the same kind of round-trip measurement, just for a different transport.
 */
@Composable
fun L4sRttMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val rawValueMs = (sample?.l4sRttUs ?: -1L).takeIf { it >= 0 }?.let { it / 1000.0 } ?: -1.0

    val finalMs = stats?.max
    val available = if (!isRunning && finalMs != null) true else rawValueMs >= 0.0
    val valueMs = if (!isRunning && finalMs != null) finalMs else if (available) rawValueMs else 0.0

    val logSpan = ln(MAX_RTT_MS / RTT_PIVOT_MS + 1.0)
    fun logFractionOf(ms: Double) = (ln(ms / RTT_PIVOT_MS + 1.0) / logSpan).toFloat()
    val logFraction = if (available) logFractionOf(valueMs) else 0f

    val color = when {
        !available -> Color.White
        valueMs >= RTT_RED_MS -> RED
        valueMs >= RTT_YELLOW_MS -> YELLOW
        else -> GREEN
    }
    val yellowFraction = logFractionOf(RTT_YELLOW_MS)
    val redFraction = logFractionOf(RTT_RED_MS)

    SpeedometerGauge(
        // "RTT smoothed" - matches RttFloorChart's own line label now that
        // this dial sits paired beside that chart (IperfScreen).
        label = "RTT smoothed",
        mainText = if (available) "%.1f".format(valueMs) else "N/A",
        unitText = if (available) "ms" else "",
        fraction = logFraction,
        accentColor = color,
        colorAt = { position ->
            when {
                position >= redFraction -> RED
                position >= yellowFraction -> YELLOW
                else -> GREEN
            }
        },
        avgText = stats?.let { "avg %.1f".format(it.avg) },
        minMaxText = stats?.let { "min %.1f · max %.1f".format(it.min, it.max) },
        peakFraction = stats?.let { logFractionOf(it.max) },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * TCP's own row 2 has no real CE Duration to show - the kernel's
 * struct tcp_info only exposes a cumulative CE mark count
 * (tcpi_delivered_ce/tcpi_delivered), not per-episode timing the way this
 * app's own userspace PragueCC library tracks for UDP-L4S (see this
 * session's own investigation). Shown anyway, always N/A/grayed rather
 * than omitted, so the dial grid stays 4-and-4 for a direct A/B look
 * between modes, and so the gap itself is visible - a blank slot next to
 * TCP's other three real dials is a more honest signal to whoever's next
 * looking at kernel-side TCP ECN instrumentation than silently leaving it
 * out would be.
 */
@Composable
fun CeDurationPlaceholder(compact: Boolean = false, modifier: Modifier = Modifier) {
    SpeedometerGauge(
        label = "CE Duration",
        mainText = "N/A",
        unitText = "",
        fraction = 0f,
        compact = compact,
        // Light gray face + dark text (the inverse of every other dial's
        // black face/white text) so this one reads as genuinely disabled
        // at a glance, not just another dial waiting on its first sample -
        // white-on-white "N/A" would otherwise look identical to a normal
        // dial's own pre-test state (see this composable's own doc
        // comment). accentColor doubles as mainText's own color
        // (SpeedometerGauge's convention), so it has to be dark here too
        // for contrast against the light face.
        accentColor = Color(0xFF757575),
        faceColor = Color(0xFFD9D9D9),
        modifier = modifier,
    )
}
