package com.rjmcmahon.iperf2client.runner

import android.util.Log
import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

// SIGUSR1/SIGUSR2 - must match main.cpp's Sig_PauseWorkingLoad/
// Sig_ResumeWorkingLoad handlers (same numbering on every Linux arch
// Android runs on: arm, arm64, x86, x86_64).
private const val SIGUSR1 = 10
private const val SIGUSR2 = 12
private const val TAG = "IperfProcessRunner"

/**
 * Owns the lifecycle of the iperf2 subprocess. One instance = one in-flight
 * test at a time (guarded via [isRunning]).
 */
class IperfProcessRunner {
    @Volatile
    private var process: Process? = null

    // destroy()-ing a running Process interrupts its blocking stdout read
    // with an IOException ("read interrupted by close() on another
    // thread") - that's the expected, intentional shutdown path from
    // stop(), not a launch failure, so it must not surface as one.
    @Volatile
    private var stopRequested = false

    val isRunning: Boolean
        get() = process?.isAlive == true

    /**
     * Starts the process and emits its stdout (stderr merged in - iperf2
     * CLI errors like "connection refused" go to stderr and the UI needs to
     * see them) line by line. Completes the flow when the process exits.
     *
     * [rawLogFile], when non-null (see RawRunLogStore), gets every emitted
     * line mirrored to it as a plain-text log - written here, at the single
     * point every line already passes through regardless of how the
     * ViewModel-side CSV/status parsing further downstream classifies it,
     * rather than duplicating that classification. Opened fresh (truncated)
     * per run, closed in the same finally that already guards the read
     * loop, so a run that errors out or gets stop()'d still leaves a
     * complete, readable file rather than a truncated one.
     *
     * [rawLogHeader], when non-empty, is written (one line each, "# "
     * prefixed) before any process output - the app's own substitute for
     * the native CLI's connect banner, which `-e -y C` (this app's own CSV
     * output mode) always suppresses (see describeNetworkForLog's own doc
     * comment). Written here rather than by the caller pre-opening the file
     * itself, so there's exactly one place that opens/truncates rawLogFile.
     */
    fun start(args: List<String>, rawLogFile: File? = null, rawLogHeader: List<String> = emptyList()): Flow<String> = flow {
        if (isRunning) return@flow // guard against double-start
        stopRequested = false

        val proc = ProcessBuilder(args)
            .redirectErrorStream(true)
            .start()
        process = proc

        val logWriter = try {
            rawLogFile?.bufferedWriter()
        } catch (e: IOException) {
            Log.w(TAG, "could not open raw log file $rawLogFile", e)
            null
        }
        logWriter?.let { writer ->
            try {
                rawLogHeader.forEach { line ->
                    writer.write("# $line")
                    writer.newLine()
                }
                writer.flush()
            } catch (e: IOException) {
                Log.w(TAG, "raw log header write failed", e)
            }
        }
        try {
            proc.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    logWriter?.let {
                        try {
                            it.write(line)
                            it.newLine()
                            it.flush()
                        } catch (e: IOException) {
                            Log.w(TAG, "raw log write failed", e)
                        }
                    }
                    emit(line)
                }
            }
        } catch (e: IOException) {
            if (!stopRequested) throw e // a genuine, unexpected read failure
        } finally {
            logWriter?.close()
        }
        proc.waitFor()
        process = null
    }.flowOn(Dispatchers.IO)

    /**
     * iperf2 already exits cleanly on SIGTERM (its existing signal handler),
     * so destroy() alone is normally enough; destroyForcibly() is only a
     * fallback if it doesn't exit within the grace period.
     */
    suspend fun stop() {
        val proc = process ?: return
        stopRequested = true
        withContext(Dispatchers.IO) {
            proc.destroy()
            val exited = proc.waitFor(1, java.util.concurrent.TimeUnit.SECONDS)
            if (!exited) proc.destroyForcibly()
        }
        process = null
    }

    /**
     * Pauses the running test's own working-load stream by sending
     * SIGUSR1 to the iperf child process (main.cpp's Sig_PauseWorkingLoad
     * handler; see Client.cpp's sWorkingLoadPaused checks in
     * RunTCP/RunWriteEventsTCP/RunUDPL4S). Only the working-load thread's
     * own writes stop - the main traffic thread (bounceback's RPS probe)
     * is untouched. No-op if nothing is running or the pid can't be
     * resolved (older/OEM Process implementations - see [pidOf]).
     */
    fun pauseWorkingLoad() = sendSignal(SIGUSR1)

    /** Resumes writes paused by [pauseWorkingLoad] - sends SIGUSR2. */
    fun resumeWorkingLoad() = sendSignal(SIGUSR2)

    private fun sendSignal(signal: Int) {
        val proc = process
        if (proc == null) {
            Log.w(TAG, "sendSignal($signal): no process running, ignoring")
            return
        }
        val pid = pidOf(proc)
        if (pid <= 0) {
            Log.w(TAG, "sendSignal($signal): could not resolve child pid, ignoring")
            return
        }
        Log.i(TAG, "sendSignal($signal) -> pid $pid")
        android.os.Process.sendSignal(pid, signal)
    }

    /**
     * java.lang.Process.pid() is declared in this app's compileSdk stub
     * (android.jar) but NOT actually implemented by this device's real ART
     * runtime - confirmed on-device: proc.javaClass.getMethod("pid") throws
     * NoSuchMethodException against the concrete class ART actually uses
     * here, java.lang.UNIXProcess (a stub/runtime mismatch, not a toolchain
     * or minSdk issue - this device is API 36, well above where pid() was
     * supposedly added at API 26). UNIXProcess is literally OpenJDK's own
     * pre-JDK9 Process implementation class name, which is exactly the
     * class the long-standing "private pid field" reflection trick
     * targets, so read that field directly instead of going through the
     * (here, absent) public method. Returns -1 (a harmless no-op signal
     * target) if reflection fails for any reason, e.g. an OEM Process
     * implementation without that field.
     */
    private fun pidOf(proc: Process): Int = try {
        val field = proc.javaClass.getDeclaredField("pid")
        field.isAccessible = true
        field.getInt(proc)
    } catch (e: Exception) {
        Log.w(TAG, "pid field reflection failed on ${proc.javaClass.name}", e)
        -1
    }

    /**
     * Non-suspending, best-effort teardown for ViewModel.onCleared(), which
     * has no coroutine scope left to call the suspending [stop] from (its
     * own viewModelScope is already cancelled by the time onCleared() runs).
     * Skips the graceful wait/destroyForcibly escalation stop() does - a
     * plain destroy() (SIGTERM) is enough to keep the subprocess from
     * outliving the ViewModel, and onCleared() isn't the place to block on
     * a wait().
     */
    fun destroyNow() {
        stopRequested = true
        process?.destroy()
        process = null
    }
}
