package com.rjmcmahon.iperf2client.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

/**
 * Resolves [themeMode] against the system setting (SYSTEM only) and picks
 * a light/dark ColorScheme, then wraps [content] in MaterialTheme. Dynamic
 * (Material You) color on API 31+ - the OS-provided per-wallpaper palette
 * - falling back to the stock light/darkColorScheme() below that, which is
 * exactly what plain `MaterialTheme { ... }` (this app's previous, only
 * theme setup) already rendered - so a SYSTEM/LIGHT app on a pre-S device
 * looks pixel-identical to before this existed, nothing to re-verify there.
 */
@Composable
fun IperfTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && darkTheme -> dynamicDarkColorScheme(context)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !darkTheme -> dynamicLightColorScheme(context)
        darkTheme -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}
