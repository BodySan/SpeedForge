package com.rjmcmahon.iperf2client.runner

import android.content.Context
import android.net.ConnectivityManager
import android.net.InetAddresses
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import com.rjmcmahon.iperf2client.model.NetworkPreference
import java.net.InetAddress
import java.net.UnknownHostException

/** Which physical transport a test's traffic is actually going out over. */
enum class NetworkTransport { WIFI, ETHERNET, CELLULAR, OTHER }

/**
 * Reads Android's own idea of which network is the current *default*
 * route - i.e. what a socket this app opens actually uses, absent an
 * explicit NetworkPreference override (see findNetwork() below - when a
 * WIFI/ETHERNET preference is bound via bindProcessToNetwork(), THAT
 * becomes the default route for this process, so this function keeps
 * reading correctly either way). Added directly in response to a
 * technician needing to confirm whether a run went out over WiFi or a
 * newly-attached USB Ethernet adapter without adb/`ip addr` access.
 *
 * A snapshot, not a live subscription (ConnectivityManager.NetworkCallback
 * would catch a route changing mid-run, but this app only needs "what was
 * active when this test started" - see IperfViewModel.onStart()'s own call
 * site). Returns null if ConnectivityManager itself, the active network,
 * or its capabilities aren't available (e.g. airplane mode, no network at
 * all) - the UI treats that as "don't show the indicator" rather than a
 * fourth transport value.
 */
fun currentNetworkTransport(context: Context): NetworkTransport? {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
    val network = cm.activeNetwork ?: return null
    val caps = cm.getNetworkCapabilities(network) ?: return null
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkTransport.ETHERNET
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkTransport.WIFI
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkTransport.CELLULAR
        else -> NetworkTransport.OTHER
    }
}

/**
 * Resolves a forced NetworkPreference (WIFI/ETHERNET/CELLULAR) to an actual
 * Network object for the native CLI's own `-c host%device` SO_BINDTODEVICE
 * option (see NetworkPreference's own doc comment). Returns null for AUTO
 * (meaning: don't override, use the system default route) and null if no
 * currently-up network actually has the requested transport with a usable
 * INTERNET capability (e.g. ETHERNET requested but nothing's plugged in) -
 * callers should treat that as "fall back to AUTO" rather than a hard
 * error, since the alternative is a test that can't start at all over a
 * transport that just isn't there.
 *
 * Requiring NET_CAPABILITY_INTERNET (not just the transport bit) matters
 * specifically for CELLULAR: a phone with an active call/VoLTE can expose
 * a SECOND cellular-transport Network purely for IMS signaling (e.g.
 * interface "ipsec265", capability IMS but no general INTERNET) alongside
 * the real mobile-data Network (e.g. "rmnet1") - confirmed on a real
 * device via logcat, where cm.allNetworks listed the IMS tunnel first.
 * Filtering on transport alone picked that dead-end signaling-only network
 * over the actual internet-capable one, which the CLI then couldn't route
 * real traffic through.
 */
fun findNetwork(context: Context, preference: NetworkPreference): Network? {
    if (preference == NetworkPreference.AUTO) return null
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
    val wantTransport = when (preference) {
        NetworkPreference.WIFI -> NetworkCapabilities.TRANSPORT_WIFI
        NetworkPreference.ETHERNET -> NetworkCapabilities.TRANSPORT_ETHERNET
        NetworkPreference.CELLULAR -> NetworkCapabilities.TRANSPORT_CELLULAR
        NetworkPreference.AUTO -> return null
    }
    return cm.allNetworks.firstOrNull { network ->
        val caps = cm.getNetworkCapabilities(network) ?: return@firstOrNull false
        caps.hasTransport(wantTransport) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

/**
 * Which of WIFI/ETHERNET/CELLULAR are actually up right now - used to gate
 * the Network row (IperfScreen) so it only shows options there's something
 * real to pick between (AUTO is always implicitly available and isn't
 * included here), and to only render chips for transports that exist
 * rather than a fixed always-three-options list. A device with only WiFi
 * up (the common case) returns a single-element set, hiding the row
 * entirely - the same "don't waste UI space with nothing to choose
 * between" reasoning the Ethernet-only version of this had.
 */
fun availableForcableTransports(context: Context): Set<NetworkPreference> {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return emptySet()
    val result = mutableSetOf<NetworkPreference>()
    for (network in cm.allNetworks) {
        val caps = cm.getNetworkCapabilities(network) ?: continue
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) result += NetworkPreference.WIFI
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) result += NetworkPreference.ETHERNET
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) result += NetworkPreference.CELLULAR
    }
    return result
}

/**
 * Resolves a forced NetworkPreference to the actual kernel interface name
 * (e.g. "wlan0", "eth0") for the native CLI's own `-c host%device`
 * SO_BINDTODEVICE option - see IperfCommandBuilder.buildArgs's call site.
 *
 * This exists because ConnectivityManager.bindProcessToNetwork() (tried
 * first) turned out NOT to work for this app: bindProcessToNetwork() only
 * affects sockets the calling process opens directly, and this app has no
 * networking of its own - every test packet comes from the bundled native
 * `iperf` binary, launched via ProcessBuilder. ProcessBuilder forks then
 * exec()s a completely separate ELF binary, and exec() replaces the whole
 * process image - the netId binding bindProcessToNetwork() set lives in
 * the calling (Kotlin) process's own memory and libnetd_client.so state,
 * none of which survives exec() into a different binary. So a forced WIFI
 * preference silently had no effect whenever Ethernet was also up (Ethernet
 * just kept winning as the system default route for the child process) -
 * confirmed on-device, not just a theoretical concern.
 *
 * `-c host%device` instead works because it's applied via setsockopt()
 * inside the actual test process after exec() - see src/PerfSocket.cpp's
 * sol_bindtodevice(). Returns null (meaning: no override, plain `-c host`)
 * for AUTO or if the requested transport's interface name can't be read.
 */
fun findNetworkInterfaceName(context: Context, preference: NetworkPreference): String? {
    if (preference == NetworkPreference.AUTO) return null
    val network = findNetwork(context, preference) ?: return null
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
    return cm.getLinkProperties(network)?.interfaceName
}

/**
 * Every local IP address a forced NetworkPreference's resolved Network
 * actually owns - so IperfViewModel's transport-mismatch check (compare
 * the CSV's own real srcaddress column, IntervalSample.srcAddress's own
 * doc comment, against this set) can ask "is the real address one of
 * THIS interface's own," not "does it equal one arbitrarily-picked
 * address." Returning a single address (an earlier version of this
 * function did, via linkAddresses.firstOrNull{}) is genuinely wrong on
 * any dual-stack interface: a network commonly owns both an IPv4 and an
 * IPv6 address, linkAddresses' own ordering between them isn't something
 * to rely on, and the real connection might resolve/use whichever family
 * DNS happened to return - "first" and "actually used" are unrelated.
 * Picking only one produced real false-positive mismatch warnings on a
 * WiFi network that was genuinely used correctly (confirmed on-device:
 * Sebastian Moeller, 2026-08-11 - RTT confirmed WiFi was really in use,
 * warning fired anyway). Empty for AUTO or if no matching network is
 * currently available - callers should treat that as "nothing to compare
 * against," not a mismatch.
 */
fun expectedLocalAddresses(context: Context, preference: NetworkPreference): Set<InetAddress> {
    if (preference == NetworkPreference.AUTO) return emptySet()
    val network = findNetwork(context, preference) ?: return emptySet()
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return emptySet()
    // InetAddress, NOT String. An earlier version returned
    // it.address.hostAddress and the caller compared those strings against
    // the CSV's srcaddress column - which silently never matched for IPv6,
    // because the two sides render the same address differently:
    //
    //   native inet_ntop():      2600:3c01::f03c:93ff:fec2:16e6
    //   Java getHostAddress():   2600:3c01:0:0:f03c:93ff:fec2:16e6
    //
    // Java's Inet6Address never emits the "::" run-compression that
    // inet_ntop() always does, so the strings differ for any address with a
    // zero run while denoting the same 16 bytes. Every dual-stack run that
    // resolved over IPv6 therefore reported a transport mismatch it hadn't
    // had. InetAddress.equals() compares the raw bytes, so membership here
    // is independent of either side's text formatting.
    return cm.getLinkProperties(network)?.linkAddresses
        ?.filter { !it.address.isLinkLocalAddress }
        ?.map { it.address }
        ?.toSet() ?: emptySet()
}

/**
 * Parse a numeric IP literal (as the native CSV's srcaddress column always
 * is) into an InetAddress, or null if it isn't one.
 *
 * Deliberately never performs a DNS lookup. InetAddress.getByName() will
 * happily resolve anything that isn't a valid literal, which on the sample
 * path would mean a blocking network call per interval row; the literal
 * check below runs first so only something already known to be numeric is
 * ever handed to it. API 29+ has InetAddresses.parseNumericAddress(), which
 * is explicitly lookup-free - minSdk is 24, hence the fallback rather than
 * just calling it.
 */
fun parseNumericAddressOrNull(value: String?): InetAddress? {
    val raw = value?.trim().orEmpty()
    if (raw.isEmpty()) return null
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            InetAddresses.parseNumericAddress(raw)
        } else {
            if (!looksLikeNumericAddress(raw)) return null
            InetAddress.getByName(raw)
        }
    } catch (e: IllegalArgumentException) {
        null
    } catch (e: UnknownHostException) {
        null
    }
}

// Anything containing ':' is an IPv6 literal attempt and can never be read
// as a hostname, so getByName() cannot be tricked into a lookup by it.
// IPv4 needs the full dotted-quad range check: "1.2.3.4.5" is all digits
// and dots yet is not a literal, and would otherwise go to the resolver.
private val DOTTED_QUAD = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$""")

private fun looksLikeNumericAddress(value: String): Boolean {
    if (value.contains(':')) return true
    val m = DOTTED_QUAD.matchEntire(value) ?: return false
    return m.groupValues.drop(1).all { (it.toIntOrNull() ?: 256) <= 255 }
}

/**
 * Human-readable "device (local IP)" description of which interface a run
 * is about to use - written as a header line into the raw run log (see
 * RawRunLogStore/IperfProcessRunner) so a shared log actually shows which
 * NIC was used. `-e -y C` (this app's own IperfCommandBuilder always uses
 * it, for the CSV rows the live meters parse) makes the native CLI suppress
 * its own connect banner entirely - Settings.cpp's `-y C`/`-y c` case calls
 * setNoConnReport(), so Client::Connect() never queues a CONNECTION_REPORT
 * and reporter_print_connection_report() (which DOES have a %device-aware
 * format string, ReportOutputs.c's report_peer_dev) never runs. There's no
 * flag combination that gets both CSV rows and that banner, so this app
 * reconstructs the same "which device" answer itself from what it already
 * knows (NetworkPreference + LinkProperties) rather than trying to coax it
 * out of the CLI.
 */
fun describeNetworkForLog(context: Context, preference: NetworkPreference): String {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        ?: return "unknown (no ConnectivityManager)"
    val network = if (preference == NetworkPreference.AUTO) cm.activeNetwork else findNetwork(context, preference)
    if (network == null) {
        return if (preference == NetworkPreference.AUTO) {
            "unknown (no active network)"
        } else {
            "unavailable, falling back to auto (no active network)"
        }
    }
    val props = cm.getLinkProperties(network)
    val iface = props?.interfaceName ?: "?"
    val addr = props?.linkAddresses?.firstOrNull { !it.address.isLinkLocalAddress }?.address?.hostAddress ?: "?"
    val suffix = if (preference == NetworkPreference.AUTO) " (auto, system default route)" else " (forced)"
    return "$iface ($addr)$suffix"
}
