package com.rjmcmahon.iperf2client.model

/**
 * The two top-level tests this app's UI actually offers (IperfScreen's own
 * TestKindSelector) - all client-only. CAPACITY is a continuous throughput
 * stream (TCP or UDP L4S, see TestConfig.capacityTransport); BOUNCEBACK is
 * the discrete request/reply RTT/RPS probe (also TCP or UDP L4S, see
 * bouncebackTransport). Deliberately NOT the same type as [TestMode] below -
 * a Capacity test over UDP L4S and a Bounceback test over UDP L4S are
 * different protocols/report shapes even though they share a transport
 * choice, so the app's internals still need to tell all three apart (see
 * TestConfig.mode).
 */
enum class TestKind { CAPACITY, BOUNCEBACK }

/**
 * The actual protocol driving the currently selected [TestKind] - what
 * IperfCommandBuilder/CsvLineParser/the meters all switch on, since a
 * Capacity-over-UDP-L4S run and a Bounceback run report completely
 * different CSV shapes even when Bounceback's own transport happens to be
 * UDP_L4S too (BOUNCEBACK-over-UDP_L4S is discrete stop-and-wait, not the
 * continuous PragueCC stream UDP_L4S itself is). Not stored directly -
 * TestConfig.mode is a computed property derived from
 * testKind/capacityTransport, so every existing `config.mode ==
 * TestMode.X` check throughout the app keeps working unchanged regardless
 * of which of the two top-level tests is selected.
 */
enum class TestMode { TCP, UDP_L4S, BOUNCEBACK }

/**
 * --working-load direction (Settings.cpp OPT_WORKING_LOAD) - background
 * traffic run alongside a --bounceback test so its RTT numbers reflect a
 * loaded path, not an idle one. UP/DOWN drop the opposite direction's
 * setWorkingLoad*() call; BIDIR (the CLI's own no-argument default) keeps
 * both.
 */
enum class WorkingLoadDirection { UP, DOWN, BIDIR }

/**
 * --bounceback's probe transport (native's `-u --bounceback`, added
 * alongside the existing plain-TCP `--bounceback`). Working load and the
 * request/reply payload-size knobs above stay on their existing meaning
 * either way - only the bounce round trip itself moves off TCP. Both UDP
 * variants are discrete stop-and-wait (same shape as TCP bounceback, not
 * the continuous PragueCC stream UDP_L4S's own TestMode uses), so both
 * reuse this app's existing ceCount/cePercent fields (see IntervalSample)
 * even though they're reached through TestMode.BOUNCEBACK, not
 * TestMode.UDP_L4S.
 *
 * UDP_L4S sends `--udp-l4s` - ECT(1)-marked via writemsg_delay_tos()
 * (Client::RunBounceBackUDP), so a congestion-capable queue along the
 * path can absorb congestion as CE marks instead of only dropping.
 * UDP sends plain `--udp` - same discrete round trip, deliberately
 * unmarked, so the two can be A/B compared against the same path (see
 * ccaTag/configSummary's own "udp"/"udp-l4s" tags): loss/tail latency
 * with marking off vs. ce/ceperc absorbing congestion with it on. Neither
 * has a congestion-control loop to select (that's UDP_L4S's own
 * continuous-stream TestMode, not Bounceback's discrete one - see
 * L4SCongestionControl's own doc comment) - the congestion-control row is
 * TCP-only (IperfScreen), not shown for either UDP variant.
 */
enum class BouncebackTransport { TCP, UDP_L4S, UDP }

/**
 * TCP vs UDP L4S - a shared enum for two independent knobs:
 * --working-load-transport udp-l4s (runs the working-load stream over UDP
 * L4S instead of TCP, independent of the main test's own protocol, so e.g.
 * a TCP Bounceback probe can be background-loaded with a UDP L4S stream or
 * vice versa) and TestConfig.capacityTransport (which wire protocol a
 * CAPACITY test itself uses - see TestKind's own doc comment). A separate
 * type from BouncebackTransport even though the values are identical -
 * they're independent knobs on independent streams, not the same choice
 * reused, so switching one never clobbers another.
 */
enum class Transport { TCP, UDP_L4S }

/**
 * --cca <prague|reno>, under --udp-l4s (native, --udp-l4s only - no
 * congestion-control loop exists for BOUNCEBACK-over-UDP-L4S to select,
 * since that transport is discrete stop-and-wait, not a continuous PragueCC
 * stream - see BouncebackTransport's own doc comment). PRAGUE (the native
 * default) reduces window/rate proportionally to the smoothed CE-marking
 * probability; RENO ignores CE marks for congestion response and reacts
 * only to loss with a flat halving, emulating a legacy/Classic flow sharing
 * an L4S-capable queue - still marks packets ECT(1)/L4S-capable on the wire
 * either way, only the sender's own reaction to CE differs. See
 * src/prague_cc.cpp's ACKReceived() for the full picture.
 */
enum class L4SCongestionControl { PRAGUE, RENO }

/**
 * Which physical network interface a test's traffic should actually go
 * out over - AUTO (the default) leaves it to Android's own default-route
 * selection (see NetworkTransportProbe.currentNetworkTransport, which
 * reads that same decision back for the live indicator). WIFI/ETHERNET/
 * CELLULAR force it via the native CLI's own `-c host%device`
 * (SO_BINDTODEVICE) option - see IperfCommandBuilder.buildArgs and
 * NetworkTransportProbe.findNetworkInterfaceName's own doc comment for why
 * that, and NOT ConnectivityManager.bindProcessToNetwork(), is what's
 * actually used: bindProcessToNetwork() only binds sockets the calling
 * (Kotlin) process opens directly, and every test packet here comes from
 * the bundled native binary spawned via ProcessBuilder, whose exec()'d
 * process image doesn't inherit that binding.
 *
 * No OTHER choice (unlike NetworkTransport) - only transports Android
 * itself has a stable, selectable Network object for are forceable; OTHER
 * on the read-back side just means "some other transport was the system
 * default," not something a user could deliberately pick.
 */
enum class NetworkPreference { AUTO, WIFI, ETHERNET, CELLULAR }

/** Client-only test parameters. */
data class TestConfig(
    // BOUNCEBACK, not CAPACITY - it's the kind this app is actually built
    // around (RPS/histogram/golden-reference comparison), so a fresh
    // install and an explicit Reset should both land there rather than on
    // plain throughput. TestConfigStore.load falls back to this same
    // default() whenever a stored "test_kind" key is missing/unreadable, so
    // this one line covers both a first-run app start and resetToDefaults().
    val testKind: TestKind = TestKind.BOUNCEBACK,
    // Which wire protocol a CAPACITY test uses - only meaningful when
    // testKind is CAPACITY, but kept as its own persisted field (rather
    // than one shared "transport" for both kinds) so switching testKind
    // doesn't clobber whatever Bounceback's own transport (below) was set
    // to, and vice versa.
    val capacityTransport: Transport = Transport.TCP,
    val host: String = "192.168.1.1",
    val port: Int = 5001,
    val durationSecs: Int = 10,
    // Fractional seconds - iperf2's -i accepts down to 100us/5ms depending
    // on platform (SMALLEST_INTERVAL_SEC, include/Settings.hpp), so 0.1s is
    // well within range; a plain Int couldn't represent that.
    val intervalSecs: Double = 1.0,
    val parallelStreams: Int = 1,
    // --tcp-write-prefetch: sets TCP_NOTSENT_LOWAT and switches to
    // event-based writes. Client-only, TCP-only (Settings.cpp rejects it
    // on the server or under -u) - exactly this app's scope, so on by
    // default. byte_atoi() (src/stdio.c) accepts the K/M/G suffix form.
    val writePrefetchEnabled: Boolean = true,
    val writePrefetchBytes: String = "128K",
    // --cca: sets the TCP congestion control algorithm by name (passed
    // straight to setsockopt(TCP_CONGESTION), see Settings.cpp:1461). On by
    // default, pinned to cubic (first in CcaProbe's probe list and this
    // device's kernel default anyway) so the algorithm actually in use is
    // explicit rather than left to the kernel's own default silently.
    // Available algorithms are kernel-specific - reno/bbr/cubic are present
    // on stock Android; "prague" needs a patched kernel and fails with a
    // clear "No such file or directory" error otherwise. ("--cca" is the
    // current documented flag name; "--tcp-cca" is kept native-side only as
    // a deprecated alias, see Settings.cpp.)
    val tcpCcaEnabled: Boolean = true,
    val tcpCca: String = "cubic",
    // Bounceback-over-TCP's own on/off switch for the same tcpCca field
    // (IperfScreen's "Congestion control" Switch row under Bounceback) -
    // separate from tcpCcaEnabled above so TCP mode's own switch/default
    // keeps its own unrelated state undisturbed. Off by default and after a
    // Reset: Bounceback's own probe traffic getting a congestion-controlled
    // TCP connection at all is already the common case (any TCP socket has
    // *some* CCA, kernel default if unset), so this only needs to be
    // reached for when a technician deliberately wants to pin one -
    // defaulting it on read as "yes, deliberately pinned to cubic" every
    // fresh install/reset, which isn't true.
    val bouncebackCcaEnabled: Boolean = false,
    // -R/--reverse: server becomes the writer, this device just receives.
    // --tcp-write-prefetch/--cca above still apply - the client relays
    // them to the server over the existing header exchange regardless of
    // direction (Settings.cpp), since whichever side is actually writing
    // is what they configure. TCP-only, same as the two options above.
    val reverseEnabled: Boolean = false,
    // --working-load: BOUNCEBACK-only background traffic.
    val workingLoadEnabled: Boolean = false,
    val workingLoadDirection: WorkingLoadDirection = WorkingLoadDirection.BIDIR,
    // --working-load-transport udp-l4s: see Transport's own doc comment.
    val workingLoadTransport: Transport = Transport.TCP,
    // --working-load-cca <name>: TCP_CONGESTION sockopt for the
    // working-load stream - only sent while workingLoadTransport is TCP.
    // Independent of tcpCca (the main test's own TCP CCA choice) since the
    // two streams often want deliberately different algorithms - e.g. a
    // steady cubic background load against a probe running bbr. Defaults to
    // "cubic", matching this option's behavior before it became
    // user-configurable.
    val workingLoadCca: String = "cubic",
    // --working-load-cca prague|reno, under --working-load-transport
    // udp-l4s: the working-load stream's own independent Prague/Reno
    // choice (isWorkingLoadL4SCcaReno, Launch.cpp) - NOT tied to the main
    // flow's own l4sCca, same "deliberately independent" reasoning as
    // workingLoadCca vs tcpCca above (e.g. run the main flow Prague while
    // the working load runs Reno, or vice versa). Only sent while
    // workingLoadTransport is UDP_L4S.
    val workingLoadL4sCca: L4SCongestionControl = L4SCongestionControl.PRAGUE,
    // No longer surfaced in the UI or read by IperfCommandBuilder (pinned
    // to 1 thread there instead) - a live test found --working-load with
    // >1 threads fails almost immediately server-side, independent of this
    // app. Field kept rather than deleted so a saved TestConfig with an
    // old value doesn't fail to deserialize; revisit both together once
    // the underlying issue is fixed.
    val workingLoadThreads: Int = 1,
    // --bounceback-request/--bounceback-reply: payload size of each bounce
    // round trip, request and reply independently (Settings.cpp defaults
    // both to kDefault_BBTCPReqLen = 100 bytes if left unset). Off by
    // default for the same "simple by default" reason as working load -
    // most runs don't need anything but the built-in 100-byte default.
    val bouncebackSizeEnabled: Boolean = false,
    val bouncebackRequestBytes: String = "100",
    val bouncebackReplyBytes: String = "100",
    // -u (combined with --bounceback): switches the bounce round trip
    // itself from plain TCP to UDP L4S (ECT(1)/CE-marked, discrete
    // stop-and-wait - see BouncebackTransport's own doc comment). Default
    // TCP so this app's existing bounceback behavior is unchanged unless a
    // technician explicitly opts in, same "simple by default" reasoning as
    // every other bounceback knob above. --cca doesn't apply once this is
    // UDP_L4S (IperfCommandBuilder skips --cca and adds -u instead).
    val bouncebackTransport: BouncebackTransport = BouncebackTransport.TCP,
    // --cca <prague|reno>, under --udp-l4s: CAPACITY-over-UDP_L4S only (not
    // BOUNCEBACK, even when its own transport is UDP_L4S - see
    // L4SCongestionControl's own doc comment for why that transport has no
    // congestion-control loop to select on). PRAGUE matches the native
    // default, so this flag is omitted from argv entirely unless RENO is
    // explicitly chosen (see IperfCommandBuilder).
    val l4sCca: L4SCongestionControl = L4SCongestionControl.PRAGUE,
    // -V/--ipv6_domain: forces resolution/connection over IPv6. Applies to
    // all three modes identically (unlike reverseEnabled/tcpCcaEnabled,
    // which are gated per-mode in IperfCommandBuilder), since address
    // family is orthogonal to which test is running. Off by default:
    // SockAddr_setHostname (src/SocketAddr.c) already tries IPv4 first and
    // only falls back to IPv6 if that fails, so this exists as an explicit
    // diagnostic override (e.g. a dual-stack host whose IPv4 path is
    // reachable but broken/filtered in a way DNS resolution alone can't
    // detect - see the IETF-126 bug report this was added for) rather than
    // something most runs need to touch.
    val forceIpv6: Boolean = false,
    // Manually-entered permit key for the currently-configured host, sent
    // instead of PermitKeyProvider's silently auto-computed key
    // (IperfCommandBuilder) whenever non-blank - lets a technician point
    // this app at their own permit-key-gated server (a different
    // salt/key than the built-in responde.* fleet uses), not just the
    // servers this app already knows how to authenticate to. Host-scoped,
    // not part of this class's own flat SharedPreferences round-trip
    // (TestConfigStore's CONFIG_KEYS/readConfig/writeConfig deliberately
    // skip it): persisted separately, keyed by `host` alone, via
    // TestConfigStore.savePermitKeyForHost/loadPermitKeyForHost, and
    // re-derived automatically by IperfViewModel.updateConfig() whenever
    // `host` changes - so switching between saved hosts (dropdown or
    // typing) restores each one's own key without every other config
    // field/preset slot needing to carry it too.
    val manualPermitKey: String = "",
    // AUTO (default) or a forced WIFI/ETHERNET choice - see
    // NetworkPreference's own doc comment. Applies to every mode/kind
    // identically, same "orthogonal to what's being tested" reasoning as
    // forceIpv6 above.
    val networkPreference: NetworkPreference = NetworkPreference.AUTO,
) {
    // Derived, not stored - see TestMode's own doc comment for why this
    // exists as a computed property rather than a constructor field: every
    // existing `config.mode == TestMode.X` check across
    // IperfCommandBuilder/CsvLineParser/IperfViewModel/the meters/
    // IperfScreen's own gating keeps working unchanged, reading whichever
    // of the two top-level tests (and, for CAPACITY, which transport) is
    // actually selected.
    val mode: TestMode get() = when (testKind) {
        TestKind.CAPACITY -> if (capacityTransport == Transport.TCP) TestMode.TCP else TestMode.UDP_L4S
        TestKind.BOUNCEBACK -> TestMode.BOUNCEBACK
    }
}
