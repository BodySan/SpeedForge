package com.rjmcmahon.iperf2client.ui.meters

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.MeterStats
import com.rjmcmahon.iperf2client.model.TestMode
import com.rjmcmahon.iperf2client.stats.CwndInflightPoint
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.WindowInflightPoint
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln

private val GREEN = Color(0xFF2E7D32)
private val YELLOW = Color(0xFFFFD600) // true yellow, not amber/orange
private val RED = Color(0xFFE53935)
// Formats with up to 2 decimals, then trims trailing zeros (and a
// trailing "." if nothing's left after them) - "28.00" -> "28",
// "0.30" -> "0.3", "0.00" -> "0", but "28.34"/"0.03" keep their real
// precision rather than being forced to round to a fixed decimal
// count. No magnitude thresholds to maintain - the actual value
// itself decides how many decimals are meaningful.
private fun formatMs(ms: Double): String = "%.2f".format(ms).trimEnd('0').trimEnd('.').ifEmpty { "0" }
// CE marks are ECN/L4S doing exactly what it's designed to do (an early,
// non-drop congestion signal), not a fault - green/yellow/red zone coloring
// elsewhere in this app means "fine/caution/bad", which would misread a
// working L4S path as a problem. Neutral white instead, same as this app's
// existing "informational, not a verdict" convention (RttMeter's
// not-available needle).
private val NEUTRAL = Color.White

// CE percent's operating range in practice is roughly 1-10%; treat 100%
// (every packet marked) as the extreme end of the scale rather than trying
// to guess a running max. Log-scale (ln(x+1), so 0% still maps to 0) the
// same way RttMeter log-scales ms - a linear 0-100% bar would leave a
// typical 1-10% reading pinned at 0-2 lit segments out of 24.
private const val MAX_CE_PERCENT = 100.0

// See BarGraphGauge's headroomFraction doc comment and this file's own
// headroomRatio computation (BytesInFlightMeter's TCP branch) - beyond
// 100x the live data's own scale, the headroom zone is already fully lit;
// growing the cap further would only ever change how close to "full" a
// reading that's already effectively "there's plenty of room" looks.
private const val HEADROOM_CAP_RATIO = 100.0

/**
 * TCP: single bar, bytes (pkts) in flight. UDP-L4S bars are ordered for A/B
 * parity with TCP's own bar stack (this session's UDP L4S redesign plan) -
 * the first bar lines up positionally with TCP's own first (CWND/inFlight/
 * NotSent) bar, with L4S-only bars (no TCP equivalent) filling the rest, the
 * same way TCP's own Flowing/SndBufLimited/RwndLimited bar occupies TCP's
 * own second position (Write Block Time and Retries, TCP's former third and
 * fourth bars, moved out to their own dial+MiniSparkline rows - see
 * WriteBlockTimeMeter/RetriesMeter below):
 *   1. Window/Inflight/Queued - GREEN/YELLOW/RED-tick overlay, same
 *      structure and color language as CWND/inFlight/NotSent (window plays
 *      CWND's ceiling role, Queued plays NotSent's "in the path, not yet
 *      delivered" role).
 *   2. Packets/sec (own running-max scale) - L4S-only, no TCP equivalent.
 *   3. CE marks/sec (log-scaled against CE *percent*, not pps - see
 *      MAX_CE_PERCENT - so a typical low single-digit percent reading
 *      still lights a legible chunk of the bar instead of rounding down to
 *      0 segments) - L4S-only.
 *   4. Marking Probability - L4S-only.
 *   5. Loss Probability, NEUTRAL - packet loss is UDP's semantic equivalent
 *      of TCP retries, same as RetriesMeter's own "informational, no
 *      established good/bad threshold" NEUTRAL convention.
 */
@Composable
fun BytesInFlightMeter(
    sample: IntervalSample?,
    mode: TestMode,
    stats: MeterStats? = null,
    // TCP-only running max of packetsInFlight (see IperfViewModel's
    // packetsInFlightAcc) - a separate accumulator from `stats` since
    // packetsInFlight is a distinct CSV field from bytesInFlight, not
    // derived from it. Lets the final reading pair "peak bytes" with
    // "peak packets" together instead of dropping the packet count.
    packetsStats: MeterStats? = null,
    // TCP-only running stats for congestion window (KB) and per-interval
    // retry count (see IperfViewModel's cwndAcc/retryAcc) - populated in
    // both forward and --reverse TCP (relayed from the server's own
    // gettcpinfo() sample in reverse mode, same as rtt/bytesInFlight/
    // packetsInFlight - see Client::WriteTcpTxHdr/Server::RunTCP).
    // cwndStats backs the "CWND/Inflight" bar's own red CWND overlay;
    // retryStats backs a second, separate "Retries" bar below it.
    cwndStats: MeterStats? = null,
    // TCP-only - raw per-interval {CWND, inFlight, NotSent} history (KB),
    // for the combined mini chart paired beside the CWND/inFlight/NotSent
    // bar (see CwndInflightPoint's own doc comment and CwndInflightChart
    // below). Distinct from cwndStats/stats/notSentStats above, which are
    // each a single collapsed MeterStats (min/avg/max), not a plottable
    // per-interval trend.
    cwndInflightHistory: List<Timestamped<CwndInflightPoint>> = emptyList(),
    // TCP-only (forward and --reverse) - bytes written to the socket but
    // not yet sent (iperf_tcpstats.notsent_bytes), a third tier on the
    // same bar: NOT bounded by CWND (unlike bytesInFlight), so it can
    // extend past the red CWND-headroom boundary rather than sitting
    // inside it - see BytesInFlightMeter's TCP branch for the segment
    // ordering this implies.
    notSentStats: MeterStats? = null,
    // TCP-only (forward and --reverse) - live, currently-autotuned send
    // socket buffer size (iperf_tcpstats.sndbuf_bytes, KB - see
    // IntervalSample.sndBufKB's own doc comment). Drives this bar's own
    // log-scaled headroom zone (BarGraphGauge's headroomFraction) - the
    // bar's main linear scale stays driven by the three plotted series'
    // own running max; the ceiling is routinely orders of magnitude past
    // that, so it gets a separately-scaled zone rather than stretching (or
    // crushing) the main scale to fit it. Also shown as an exact figure in
    // the bar's own topRightText caption.
    sndBufStats: MeterStats? = null,
    // TCP-only (forward and --reverse) - this-interval delta of the
    // kernel's own tcpi_sndbuf_limited (kernel 4.9+, microseconds - see
    // IntervalSample.sndBufLimitedUs's own doc comment): time spent capped
    // by the local send buffer. Kernel-measured complement to
    // writeTimeStats' own per-write blocking measurement.
    sndBufLimitedStats: MeterStats? = null,
    // Same convention, for time limited by the peer's advertised receive
    // window (tcpi_rwnd_limited) - a receiver-side cap, distinct from
    // sndBufLimitedStats' local one.
    rwndLimitedStats: MeterStats? = null,
    // Same convention, for total time this connection had data queued to
    // send at all (tcpi_busy_time) - the denominator sndBufLimitedStats/
    // rwndLimitedStats are naturally compared against, and this bar's own
    // scale (see BarGraphGauge call below) - not displayed as its own
    // column (flowingStats below covers the "how much of it was healthy"
    // reading that matters on screen).
    busyTimeStats: MeterStats? = null,
    // busyTimeUs minus sndBufLimitedUs/rwndLimitedUs (IperfViewModel's
    // flowingAcc) - see BytesInFlightMeter's own "Flowing" doc comment
    // below for the precise, deliberately unclaimed definition.
    flowingStats: MeterStats? = null,
    // UDP-L4S only (write/upload direction only, same -1/N/A convention as
    // queueDelayUs in --reverse) - PragueCC's own congestion window/actual
    // in-flight packet count (see IperfViewModel's l4sPacketWindowAcc/
    // l4sInflightAcc doc comment).
    l4sPacketWindowStats: MeterStats? = null,
    l4sInflightStats: MeterStats? = null,
    // UDP-L4S only - raw per-interval {Window, inFlight, Queued} history
    // (pkts), for the combined mini chart paired beside the Window/
    // Inflight/Queued bar - see WindowInflightChart below and
    // CwndInflightPoint/cwndInflightHistory's own doc comments (TCP's
    // equivalent).
    windowInflightHistory: List<Timestamped<WindowInflightPoint>> = emptyList(),
    // UDP-L4S only running stats for the Little's Law queue-occupancy
    // estimate, in KB (see IperfViewModel's queueBytesAcc) or packets
    // (queuePacketsAcc) - both always computed, queueUnitsPackets just
    // picks which one this bar displays (see TestConfig's own doc comment
    // on why packets is the default). Write/upload direction only, same
    // -1/"N/A" convention as queueDelayUs in --reverse.
    queueBytesStats: MeterStats? = null,
    queuePacketsStats: MeterStats? = null,
    queueUnitsPackets: Boolean = true,
    // Flips config.queueUnitsPackets - null hides the toggle entirely
    // (callers that don't want it interactive, e.g. read-only contexts).
    onToggleQueueUnits: (() -> Unit)? = null,
    // BOUNCEBACK only running stats for requests/sec (see IperfViewModel's
    // bbRequestsAcc) - same "final reading is the average" role as
    // ceMarksStats above.
    bbRequestsStats: MeterStats? = null,
    // BOUNCEBACK only - the kernel's own live connection-lifetime min RTT
    // (IperfViewModel.bbRttMinUs), microseconds. Drives the RPS bar's own
    // scale below via the same "theoretical RPS ceiling = 1000 / rttMinMs"
    // reasoning LiveSparkline's own caption uses - BOUNCEBACK's
    // stop-and-wait request/reply protocol means achievable RPS is
    // fundamentally capped by round-trip latency, so this is a real,
    // principled ceiling rather than an arbitrary one. Null when not yet
    // available (no sample yet, or the kernel doesn't report TCP_INFO
    // min_rtt) - the bar falls back to its own previous "observed max"
    // scale in that case.
    bbRttMinUs: Long? = null,
    isRunning: Boolean = true,
    // Threaded through to CwndInflightChart/WindowInflightChart's own time
    // axis - see MiniSparkline's own durationSecs doc comment. Each
    // point's own elapsedSecs (CwndInflightPoint/WindowInflightPoint)
    // drives x position, not an interval param.
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) {
    // iperf2 reports -1 for bytesInFlight/packetsInFlight when the data isn't
    // available (e.g. HAVE_TCP_INFLIGHT not compiled in, or a -P > 1 "Sums"
    // aggregate row, which never carries per-connection inflight data) -
    // see the -1 sentinel fix in src/ReportOutputs.c. Treat that as
    // "not available", not a real negative measurement. Same -1 convention
    // applies to packetsPerSec when a TCP sample flows through here (or vice
    // versa) - see IntervalSample/CsvLineParser.
    //
    // Once stopped, replace whichever instant the last live interval
    // happened to catch with a run-level number: TCP's bytes-in-flight
    // exists to diagnose worst-case buffering/bufferbloat, so its final
    // reading is the peak. UDP-L4S's pps/CE-marks final reading is the
    // run's average instead (see the UDP-L4S branch below) - a single
    // instant pps/CE spike isn't the interesting number the way a
    // bufferbloat peak is.
    val showFinal = !isRunning && stats != null

    when (mode) {
        TestMode.TCP -> {
            val available = showFinal || (sample?.bytesInFlight ?: -1L) >= 0L
            val value = if (showFinal) stats!!.max.toFloat() else if (available) sample!!.bytesInFlight.toFloat() else 0f
            // packetsInFlight is unavailable in --reverse mode (the relayed
            // reverse-mode CSV format only carries bytes-in-flight, not a
            // packet count - see CsvLineParser) - drop the "(pkts)" part
            // rather than print a misleading "-1 pkts".
            val pktsAvailable = (sample?.packetsInFlight ?: -1L) >= 0L
            // NOTE: despite the historic "bytes"/tcpbytesinflight naming (CSV
            // column, struct field bytes_in_flight), this value is actually in
            // KB - compat/gettcpinfo.c divides by 1024 (same longstanding
            // convention as cwnd, just never relabeled).

            // Congestion window (KB, same unit as bytes-in-flight) -
            // forward and --reverse both populate this now (see cwndStats'
            // own doc comment above). Drawn as a red *tick* marking where
            // the ceiling currently sits (BarGraphGauge's
            // backgroundFraction) - CWND isn't a quantity of data, it's a
            // limit on how much bytesInFlight+notSent are allowed to reach,
            // so it doesn't get its own fill the way those two do.
            val cwndAvailable = showFinal || (sample?.cwndBytes ?: -1L) >= 0L
            val cwndValue = if (showFinal) cwndStats?.max?.toFloat() else if (cwndAvailable) sample?.cwndBytes?.toFloat() else null

            // Bytes written to the socket but not yet sent - fills
            // contiguously right after the green in-flight bytes (real
            // data, queued immediately behind what's already on the wire),
            // not bounded by CWND the way bytesInFlight is - see
            // BarGraphGauge's tertiaryFraction doc comment.
            val notSentAvailable = showFinal || (sample?.notSentBytes ?: -1L) >= 0L
            val notSentValue = if (showFinal) notSentStats?.max?.toFloat() else if (notSentAvailable) sample?.notSentBytes?.toFloat() else null
            val yellowEdgeValue = if (available && notSentAvailable && notSentValue != null) value + notSentValue else null

            // Live send socket buffer ceiling (KB) - see sndBufStats' own
            // doc comment. "Final = max" matches CWND's own convention:
            // autotuning only ever grows the buffer within a run, so the
            // peak is the actual ceiling this run reached.
            val sndBufAvailable = showFinal || (sample?.sndBufKB ?: -1L) >= 0L
            val sndBufValue = if (showFinal) sndBufStats?.max?.toFloat() else if (sndBufAvailable) sample?.sndBufKB?.toFloat() else null
            val sndBufText = if (sndBufAvailable && sndBufValue != null) "%.0fK".format(sndBufValue) else "N/A"

            // Three numbers on screen at once, not just inferable from the
            // bar fill - final reading is each one's own peak (CWND's own
            // bufferbloat-relevant worst case, same "final = max" reasoning
            // as bytes-in-flight already used). CWND/inFlight/notSent order,
            // matching the "CWND/inFlight/NotSent" label - no need to
            // spell out any of the three words again here, the label
            // already establishes which number is which.
            val valueText = if (showFinal) {
                val cwndText = cwndStats?.let { "%.0fK".format(it.max) } ?: "N/A"
                val bifText = "%.0fK".format(stats!!.max)
                val notSentText = notSentStats?.let { "%.0fK".format(it.max) } ?: "N/A"
                "$cwndText / $bifText / $notSentText"
            } else if (!available) "N/A"
            else {
                val cwndText = if (cwndAvailable) "${sample?.cwndBytes}K" else "N/A"
                val bifText = if (pktsAvailable) "${sample?.bytesInFlight}K (${sample?.packetsInFlight} pkts)" else "${sample?.bytesInFlight}K"
                val notSentText = if (notSentAvailable) "${sample?.notSentBytes}K" else "N/A"
                "$cwndText / $bifText / $notSentText"
            }
            // Same CWND/inFlight/notSent order as valueText above, via
            // BarGraphGauge's three-column statsTextStart/Mid/End (min/max,
            // each column keeping its own Start/Center/End alignment - left/
            // right columns justified toward the screen edge, same as
            // before) plus statsAvgTextStart/Mid/End (avg, always centered
            // per column regardless of that column's own alignment below
            // it) - matching SpeedometerGauge's own avgText/minMaxText
            // split for Throughput/RTT, just repeated per column.
            val cwndAvgText = cwndStats?.let { "avg %.0f".format(it.avg) }
            val cwndMinMaxText = cwndStats?.let { "min %.0f · max %.0f K".format(it.min, it.max) }
            val inFlightAvgText = stats?.let { "avg %.0f".format(it.avg) }
            val inFlightMinMaxText = stats?.let { "min %.0f · max %.0f K".format(it.min, it.max) }
            val notSentAvgText = notSentStats?.let { "avg %.0f".format(it.avg) }
            val notSentMinMaxText = notSentStats?.let { "min %.0f · max %.0f K".format(it.min, it.max) }

            // Bar's own (live-zone) scale - the three plotted series' own
            // running max, same as before the headroom-zone concept
            // existed. Deliberately NOT driven by the sndbuf ceiling
            // itself (tried that - see git history/session notes: the
            // ceiling routinely sits orders of magnitude above live data,
            // which crushed CWND/inFlight/notSent to an unreadable sliver).
            // The ceiling now gets its own separately-scaled headroom zone
            // instead - see headroomFraction below.
            val maxSeen = maxOf(
                stats?.max?.toFloat() ?: value,
                cwndStats?.max?.toFloat() ?: 0f,
                cwndValue ?: 0f,
                yellowEdgeValue ?: 0f,
                (stats?.max?.toFloat() ?: 0f) + (notSentStats?.max?.toFloat() ?: 0f),
            ).coerceAtLeast(1f)

            val cwndFraction = if (cwndAvailable && cwndValue != null && maxSeen > 0f) (cwndValue / maxSeen) else null
            val notSentFraction = if (yellowEdgeValue != null && maxSeen > 0f) (yellowEdgeValue / maxSeen) else null

            // Headroom zone (see BarGraphGauge's own doc comment): how much
            // further the live socket buffer ceiling sits beyond the live
            // data's own scale (maxSeen above), log-scaled since that ratio
            // can span orders of magnitude (e.g. a few hundred KB of real
            // traffic against a multi-MB autotuned ceiling). HEADROOM_CAP_
            // RATIO=100 means "100x or more past the live scale" already
            // maxes out the zone - beyond that point the exact ratio isn't
            // interesting, just "there's plenty more room".
            val headroomRatio = if (sndBufAvailable && sndBufValue != null && maxSeen > 0f) (sndBufValue / maxSeen) else 1f
            val headroomFraction = if (headroomRatio > 1f) {
                (ln(headroomRatio.toDouble()) / ln(HEADROOM_CAP_RATIO)).toFloat().coerceIn(0f, 1f)
            } else {
                0f
            }

            // Kernel-measured time-limited counters (see sndBufLimitedStats/
            // rwndLimitedStats/busyTimeStats' own doc comments), overlaid on
            // one bar the same way CWND/inFlight/NotSent are - not a
            // coincidence: per the kernel's own tcp_chrono accounting,
            // busy_time is the *whole* (total time spent with data queued
            // to send), and sndbuf_limited/rwnd_limited are two
            // mutually-exclusive named slices *within* it - the remainder
            // (busy_time minus both) is time spent sending freely,
            // unconstrained by either buffer, i.e. reads as the healthy
            // portion the same way unlit capacity does on the CWND bar.
            // Unlike that bar, busy_time isn't a running-max scale or a
            // ceiling tick past the live data - sndbuf_limited/rwnd_limited
            // are always <= busy_time by kernel construction, so busy_time
            // itself is exactly this bar's 100% mark, live or final alike.
            val sndBufLimitedValue = if (showFinal) sndBufLimitedStats?.max?.toFloat() else sample?.sndBufLimitedUs?.toFloat()
            val sndBufLimitedText = if (showFinal) {
                sndBufLimitedStats?.let { "${formatMs(it.max / 1000.0)} ms" } ?: "N/A"
            } else if (sample != null) "${formatMs(sample.sndBufLimitedUs / 1000.0)} ms" else "N/A"
            val sndBufLimitedAvgText = sndBufLimitedStats?.let { "avg ${formatMs(it.avg / 1000.0)}" }
            val sndBufLimitedMinMaxText = sndBufLimitedStats?.let { "min ${formatMs(it.min / 1000.0)} · max ${formatMs(it.max / 1000.0)}" }

            val rwndLimitedValue = if (showFinal) rwndLimitedStats?.max?.toFloat() else sample?.rwndLimitedUs?.toFloat()
            val rwndLimitedText = if (showFinal) {
                rwndLimitedStats?.let { "${formatMs(it.max / 1000.0)} ms" } ?: "N/A"
            } else if (sample != null) "${formatMs(sample.rwndLimitedUs / 1000.0)} ms" else "N/A"
            val rwndLimitedAvgText = rwndLimitedStats?.let { "avg ${formatMs(it.avg / 1000.0)}" }
            val rwndLimitedMinMaxText = rwndLimitedStats?.let { "min ${formatMs(it.min / 1000.0)} · max ${formatMs(it.max / 1000.0)}" }

            // 24000f floor for the same reason as writeTimeMaxSeen (a
            // healthy interval's busy_time can be legitimately tiny) - past
            // that floor this is always the real busy_time, never a running
            // max, since sndbuf_limited/rwnd_limited can't exceed it.
            val busyTimeValue = if (showFinal) busyTimeStats?.max?.toFloat() else sample?.busyTimeUs?.toFloat()
            val busyTimeMaxSeen = (busyTimeValue ?: 0f).coerceAtLeast(24000f)
            val busyTimeText = if (showFinal) {
                busyTimeStats?.let { "${formatMs(it.max / 1000.0)} ms" } ?: "N/A"
            } else if (sample != null) "${formatMs(sample.busyTimeUs / 1000.0)} ms" else "N/A"
            val busyTimeAvgText = busyTimeStats?.let { "avg ${formatMs(it.avg / 1000.0)}" }
            val busyTimeMinMaxText = busyTimeStats?.let { "min ${formatMs(it.min / 1000.0)} · max ${formatMs(it.max / 1000.0)}" }

            // Three tiers stacking to fill the *entire* bar, not just the
            // limited portion - an all-black remainder read as "no data"
            // rather than "busy but not buffer-limited" (the common case).
            // GREEN ("Flowing" - short and positive without implying
            // infinite/uncapped capacity; considered and rejected
            // "Unlimited"/"Healthy"/"Uncapped"/"Not Buffer-Limited"/
            // "Free-Flowing"/"Cwnd-Limited": this slice is exactly Linux's
            // own TCP_CHRONO_BUSY ("actively sending data, non-empty write
            // queue" - see net/ipv4/tcp_output.c), the default active-send
            // state whenever neither TCP_CHRONO_SNDBUF_LIMITED nor
            // TCP_CHRONO_RWND_LIMITED applies - NOT a measurement of
            // tcp_is_cwnd_limited(), which the kernel computes separately
            // in tcp_write_xmit() but doesn't fold into a chrono counter.
            // So this slice can include genuine cwnd exhaustion, pacing,
            // TCP Small Queues/qdisc/NIC queueing, Nagle, or loss recovery
            // - "active send time not attributed to send-buffer or
            // receive-window limitation", nothing more specific than that)
            // is the base; sndBufLimitedFraction/
            // rwndLimitedFraction are cumulative
            // *end* positions stacked after it (tertiaryFraction/
            // quaternaryFraction's own contract - see BarGraphGauge), so
            // the last of the three always lands at ~1.0 (healthy +
            // sndbuf_limited + rwnd_limited == busy_time by construction).
            val healthyValue = if (sndBufLimitedValue != null && rwndLimitedValue != null && busyTimeValue != null) {
                (busyTimeValue - sndBufLimitedValue - rwndLimitedValue).coerceAtLeast(0f)
            } else {
                null
            }
            val healthyFraction = if (healthyValue != null && busyTimeMaxSeen > 0f) (healthyValue / busyTimeMaxSeen) else 0f
            val sndBufLimitedEndFraction = if (healthyValue != null && sndBufLimitedValue != null && busyTimeMaxSeen > 0f) {
                (healthyValue + sndBufLimitedValue) / busyTimeMaxSeen
            } else {
                null
            }
            val rwndLimitedEndFraction = if (sndBufLimitedEndFraction != null && rwndLimitedValue != null && busyTimeMaxSeen > 0f) {
                sndBufLimitedEndFraction + (rwndLimitedValue / busyTimeMaxSeen)
            } else {
                null
            }
            // Final headline uses flowingStats' own tracked peak (a real
            // running max, like sndBufLimited/rwndLimited/busyTime's own
            // headline text above) rather than re-deriving from the other
            // three's independent maxes, which aren't guaranteed to be
            // from the same interval; live headline still derives from
            // healthyValue (this sample's own consistent decomposition -
            // no separate accumulated "current" reading needed live).
            val flowingText = if (showFinal) {
                flowingStats?.let { "${formatMs(it.max / 1000.0)} ms" } ?: "N/A"
            } else if (healthyValue != null) "${formatMs(healthyValue / 1000.0)} ms" else "N/A"
            val flowingAvgText = flowingStats?.let { "avg ${formatMs(it.avg / 1000.0)}" }
            val flowingMinMaxText = flowingStats?.let { "min ${formatMs(it.min / 1000.0)} · max ${formatMs(it.max / 1000.0)}" }
            // Collapses to a single "N/A" rather than "N/A / N/A / N/A"
            // when there's no sample at all yet - same convention as
            // valueText's own `else if (!available) "N/A"` branch above.
            // Flowing/SndBufLimited/RwndLimited order, matching the bar's
            // own "Flowing/SndBufLimited/RwndLimited" label.
            val limitedValueText = if (!showFinal && sample == null) {
                "N/A"
            } else {
                "$flowingText / $sndBufLimitedText / $rwndLimitedText"
            }

            Column(modifier = modifier.fillMaxWidth()) {
                BarGraphGauge(
                    label = "CWND/inFlight/NotSent",
                    valueText = valueText,
                    fraction = if (available && maxSeen > 0f) (value / maxSeen) else 0f,
                    statsAvgTextStart = cwndAvgText,
                    statsAvgTextMid = inFlightAvgText,
                    statsAvgTextEnd = notSentAvgText,
                    statsTextStart = cwndMinMaxText,
                    statsTextMid = inFlightMinMaxText,
                    statsTextEnd = notSentMinMaxText,
                    backgroundFraction = cwndFraction,
                    backgroundColor = RED,
                    tertiaryFraction = notSentFraction,
                    headroomFraction = if (sndBufAvailable) headroomFraction else null,
                    topRightText = "SndBuf ceiling: $sndBufText",
                    compact = true,
                )
                ColorLegend(
                    LegendEntry("inFlight", GREEN),
                    LegendEntry("CWND", RED, isTick = true),
                    LegendEntry("NotSent", YELLOW),
                    centered = true,
                )
                // Combined trend for the bar just above - a single
                // collapsed reading (or even three separate MiniSparklines)
                // can't show whether e.g. inFlight is riding right up
                // against CWND throughout the run or only spiked there
                // once; three lines sharing one axis, same colors as the
                // legend just printed, answers that. See CwndInflightChart's
                // own doc comment.
                CwndInflightChart(cwndInflightHistory, durationSecs)
                BarGraphGauge(
                    label = "Flowing/SndBufLimited/RwndLimited",
                    valueText = limitedValueText,
                    fraction = healthyFraction,
                    litColor = GREEN,
                    statsAvgTextStart = flowingAvgText,
                    statsAvgTextMid = sndBufLimitedAvgText,
                    statsAvgTextEnd = rwndLimitedAvgText,
                    statsTextStart = flowingMinMaxText,
                    statsTextMid = sndBufLimitedMinMaxText,
                    statsTextEnd = rwndLimitedMinMaxText,
                    tertiaryFraction = sndBufLimitedEndFraction,
                    tertiaryColor = YELLOW,
                    quaternaryFraction = rwndLimitedEndFraction,
                    quaternaryColor = RED,
                    compact = true,
                )
                ColorLegend(
                    LegendEntry("Flowing", GREEN),
                    LegendEntry("Send-Buffer Limited", YELLOW),
                    LegendEntry("Receive-Window Limited", RED),
                    centered = true,
                )
                // Write Block Time and Retries used to be two more bars
                // here - moved out to their own [dial | MiniSparkline] rows
                // (WriteBlockTimeMeter/RetriesMeter below, IperfScreen),
                // same treatment as Throughput/RTT/Load Delay/CE Duration,
                // so their own trends are visible and correlatable too.
            }
        }
        TestMode.UDP_L4S -> {
            // Little's Law (L = lambda*W) load estimate (write/upload
            // direction only - always -1/"N/A" in --reverse, see
            // IntervalSample's doc comment) - both units always computed,
            // queueUnitsPackets picks which one this bar shows (see
            // TestConfig's own doc comment on why packets is the default:
            // L4S's own marking mechanism reasons in packets/delay, not
            // byte occupancy). Same "final reading is the average"
            // convention as pps/CE marks above (a load spike is expected/
            // transient behavior for L4S, not a bufferbloat fault the way
            // TCP's peak bytes-in-flight is).
            //
            // Labeled "Estimated Load in Path", not "Queue" - per Koen De
            // Schepper's review (doc/email_koen_littles_law_review.txt),
            // the underlying delay term (srtt - rtt_min, QueueDelayMeter)
            // isn't pure single-queue delay on Wi-Fi (MAC contention,
            // scheduler delay, A-MPDU formation, rate adaptation all fold
            // in too), so calling this a literal queue-depth measurement
            // would overclaim precision - it's a real load signal, framed
            // as such.
            val queueStats = if (queueUnitsPackets) queuePacketsStats else queueBytesStats
            val showFinalQueue = showFinal && queueStats != null
            val liveQueueRaw = if (queueUnitsPackets) {
                // Raw CSV/model field is bytes; /1024.0 matches queueBytesAcc's
                // own KB conversion in IperfViewModel and TCP's "Bytes (pkts)
                // in flight" bar's own K-unit convention, for the bytes path.
                // The packets path (packetsPerSec * queueing delay) is a pure
                // Kotlin derivation - see IperfViewModel's queuePacketsAcc.
                if ((sample?.packetsPerSec ?: -1.0) >= 0.0 && (sample?.queueDelayUs ?: -1) >= 0) {
                    sample!!.packetsPerSec * (sample.queueDelayUs / 1_000_000.0)
                } else null
            } else {
                (sample?.queueBytes ?: -1L).takeIf { it >= 0L }?.let { it / 1024.0 }
            }
            val queueAvailable = showFinalQueue || liveQueueRaw != null
            val queueUnitLabel = if (queueUnitsPackets) "pkts" else "KB"
            val queueText = if (showFinalQueue) "%.1f %s".format(queueStats!!.avg, queueUnitLabel)
            else if (queueAvailable) "%.1f %s".format(liveQueueRaw, queueUnitLabel) else "N/A"
            val queueAvgText = queueStats?.let { "avg %.1f".format(it.avg) }
            val queueMinMaxText = queueStats?.let { "min %.1f · max %.1f %s".format(it.min, it.max, queueUnitLabel) }
            // Packets specifically (independent of the pkts/KB toggle above,
            // which only controls queueText/queueMinMaxText's displayed
            // unit) - the combined Window/Inflight/Queued bar below stacks
            // Queued after Inflight on the same linear scale as Window,
            // which is always packets (PragueCC has no byte-denominated
            // congestion window), so the *fill* needs a dimensionally
            // consistent packets value regardless of what the text shows.
            val liveQueuePacketsForStack = if ((sample?.packetsPerSec ?: -1.0) >= 0.0 && (sample?.queueDelayUs ?: -1) >= 0) {
                sample!!.packetsPerSec * (sample.queueDelayUs / 1_000_000.0)
            } else null
            val queuePacketsForStackValue = if (showFinal) queuePacketsStats?.max?.toFloat() else liveQueuePacketsForStack?.toFloat()

            // PragueCC's own congestion window (packets) and actual
            // in-flight packet count - direct, RTT-independent measurements
            // (unlike Queue above, which is derived from srtt-rtt_min).
            // Same overlay pattern as TCP's CWND/inFlight/NotSent bar: green
            // fill up to inflight, yellow stacked after it up to inflight+
            // queued (Queued plays NotSent's role here - data "in the path"
            // but not yet delivered), red tick at the window ceiling.
            val windowAvailable = showFinal || (sample?.l4sPacketWindow ?: -1L) >= 0L
            val windowValue = if (showFinal) l4sPacketWindowStats?.max?.toFloat() else if (windowAvailable) sample?.l4sPacketWindow?.toFloat() else null
            val inflightAvailable = showFinal || (sample?.l4sInflight ?: -1L) >= 0L
            val inflightValue = if (showFinal) l4sInflightStats?.max?.toFloat() else if (inflightAvailable) sample?.l4sInflight?.toFloat() else 0f
            val windowMaxSeen = maxOf(
                l4sInflightStats?.max?.toFloat() ?: inflightValue ?: 0f,
                l4sPacketWindowStats?.max?.toFloat() ?: 0f,
                windowValue ?: 0f,
                (inflightValue ?: 0f) + (queuePacketsForStackValue ?: 0f),
                (l4sInflightStats?.max?.toFloat() ?: 0f) + (queuePacketsStats?.max?.toFloat() ?: 0f),
            ).coerceAtLeast(1f)
            val windowFraction = if (windowAvailable && windowValue != null && windowMaxSeen > 0f) (windowValue / windowMaxSeen) else null
            val queuedEndFraction = if (inflightValue != null && queuePacketsForStackValue != null && windowMaxSeen > 0f) {
                (inflightValue + queuePacketsForStackValue) / windowMaxSeen
            } else {
                null
            }
            val windowText = if (showFinal) {
                val windowText0 = l4sPacketWindowStats?.let { "%.0f".format(it.max) } ?: "N/A"
                val inflightText0 = l4sInflightStats?.let { "%.0f".format(it.max) } ?: "N/A"
                "$windowText0 / $inflightText0 / $queueText"
            } else if (!inflightAvailable) "N/A"
            else {
                val windowText0 = if (windowAvailable) "${sample?.l4sPacketWindow}" else "N/A"
                "$windowText0 / ${sample?.l4sInflight} / $queueText"
            }
            val windowAvgText = l4sPacketWindowStats?.let { "avg %.0f".format(it.avg) }
            val windowMinMaxText = l4sPacketWindowStats?.let { "min %.0f · max %.0f pkts".format(it.min, it.max) }
            val inflightAvgText = l4sInflightStats?.let { "avg %.0f".format(it.avg) }
            val inflightMinMaxText = l4sInflightStats?.let { "min %.0f · max %.0f pkts".format(it.min, it.max) }

            Column(modifier = modifier.fillMaxWidth()) {
                // First bar, matching TCP's own CWND/inFlight/NotSent
                // position 1:1 for A/B comparison - see this session's UDP
                // L4S redesign plan. GREEN=inFlight (primary), YELLOW=Queued
                // stacked after it (NotSent's role: in the path, not yet
                // delivered), RED tick=Window (the ceiling, CWND's role).
                // Absorbs the former standalone "Estimated Load in Path"
                // bar as this bar's third tier rather than a separate bar -
                // see queuePacketsForStackValue's own doc comment above for
                // why the fill always uses packets regardless of the pkts/
                // KB toggle below (which only affects the displayed text).
                BarGraphGauge(
                    label = "Window/Inflight/Queued",
                    valueText = windowText,
                    fraction = if (inflightAvailable && inflightValue != null && windowMaxSeen > 0f) (inflightValue / windowMaxSeen) else 0f,
                    litColor = GREEN,
                    statsAvgTextStart = windowAvgText,
                    statsAvgTextMid = inflightAvgText,
                    statsAvgTextEnd = queueAvgText,
                    statsTextStart = windowMinMaxText,
                    statsTextMid = inflightMinMaxText,
                    statsTextEnd = queueMinMaxText,
                    tertiaryFraction = queuedEndFraction,
                    tertiaryColor = YELLOW,
                    backgroundFraction = windowFraction,
                    backgroundColor = RED,
                    compact = true,
                )
                ColorLegend(
                    LegendEntry("inFlight", GREEN),
                    LegendEntry("window", RED, isTick = true),
                    LegendEntry("Queued", YELLOW),
                    centered = true,
                )
                // Combined trend for the bar just above - same "one chart,
                // three lines, same colors as the legend" treatment as
                // TCP's own CwndInflightChart (see that composable's own
                // doc comment) - Window plays CWND's role here.
                WindowInflightChart(windowInflightHistory, durationSecs)
                // Compact unit toggle for Queued's displayed text (End
                // column above) - see TestConfig.queueUnitsPackets's own
                // doc comment.
                if (onToggleQueueUnits != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 4.dp),
                    ) {
                        Text("Queued units:", style = MaterialTheme.typography.labelSmall)
                        UnitToggleLabel("pkts", selected = queueUnitsPackets, onClick = { if (!queueUnitsPackets) onToggleQueueUnits() })
                        UnitToggleLabel("KB", selected = !queueUnitsPackets, onClick = { if (queueUnitsPackets) onToggleQueueUnits() })
                    }
                }
                // Packets/sec, CE marks/sec, Marking Probability, and Loss
                // Probability used to be four more bars here - moved out to
                // their own [dial | MiniSparkline] rows (PacketsPerSecMeter/
                // CeMarksPerSecMeter/MarkingProbabilityMeter/
                // LossProbabilityMeter below, IperfScreen), same treatment
                // as TCP's Write Block Time/Retries.
            }
        }
        TestMode.BOUNCEBACK -> {
            // Same "final reading is the average" convention as UDP-L4S's
            // pps bar above - a single instant request-rate spike isn't the
            // number worth keeping once the run stops. Uses bbRequestsStats,
            // not the outer `showFinal`/`stats` (those are fed from
            // inFlightAcc, which BOUNCEBACK never populates - see
            // IperfViewModel's `inFlight` when-block).
            val bbShowFinal = !isRunning && bbRequestsStats != null
            val rpsAvailable = bbShowFinal || (sample?.requestsPerSec ?: -1.0) >= 0.0
            val rpsValue = if (bbShowFinal) bbRequestsStats!!.avg.toFloat() else if (rpsAvailable) sample!!.requestsPerSec.toFloat() else 0f
            // Theoretical ceiling (1000 / rttMinMs, see bbRttMinUs' own doc
            // comment above) when available - a stable, principled scale
            // that doesn't creep upward over the course of a run the way
            // "observed max so far" does (which reads as a nearly-full bar
            // early on, then keeps rescaling itself smaller as new peaks
            // arrive). Still floored against the observed max/current
            // value so a real reading is never visually clipped past 100%
            // if it briefly exceeds the estimate (e.g. before bbRttMinUs
            // has settled to its own true minimum).
            val theoreticalCeiling = bbRttMinUs?.takeIf { it > 0 }?.let { (1_000_000.0 / it).toFloat() }
            val rpsMaxSeen = maxOf(theoreticalCeiling ?: 0f, bbRequestsStats?.max?.toFloat() ?: rpsValue, 1f)
            val rpsText = if (bbShowFinal) "%.0f RPS".format(bbRequestsStats!!.avg)
            else if (rpsAvailable) "%.0f RPS".format(sample?.requestsPerSec) else "N/A"
            val rpsStatsText = bbRequestsStats?.let { "min %.0f · avg %.0f · max %.0f RPS".format(it.min, it.avg, it.max) }
            val rpsLabel = "RPS (responses/sec)"
            // Live "how close to max" percentage - BarGraphGauge's own
            // topRightText slot (small, unobtrusive, doesn't compete with
            // the large valueText) is exactly built for this: a derived
            // number alongside the primary reading, not a second headline.
            // Moves up and down with rpsValue against the theoretical
            // ceiling specifically (not rpsMaxSeen, which can be padded/
            // floored above it - see that val's own doc comment). Null
            // (hidden) when there's no real ceiling to measure against
            // (bbRttMinUs unavailable).
            // "of ceiling", not "of max" - "max" already means something
            // else on this same chart (the observed-max half of the min/
            // avg/max caption below), and this percentage is against
            // theoreticalCeiling specifically, not the observed max.
            val rpsPercentText = theoreticalCeiling?.let { "%.0f%% of ceiling".format((rpsValue / it * 100f).coerceIn(0f, 999f)) }

            // Working load's own up/down throughput used to render as two
            // more bars stacked directly underneath this one - moved out to
            // their own [dial | MiniSparkline] rows (WorkingLoadUpMeter/
            // WorkingLoadDownMeter below, IperfScreen), same treatment as
            // every other secondary metric this session (see those
            // composables' own doc comment) - IperfScreen places them right
            // after this composable's own call, so they still render below
            // RPS, this mode's actual hero metric.
            BarGraphGauge(
                label = rpsLabel,
                valueText = rpsText,
                fraction = if (rpsAvailable && rpsMaxSeen > 0f) (rpsValue / rpsMaxSeen) else 0f,
                statsText = rpsStatsText,
                topRightText = rpsPercentText,
                modifier = modifier,
            )
        }
    }
}

// Left-edge y-axis tick + label - same convention as RttFloorChart's own
// drawAxisTick, just duplicated here rather than shared across files (that
// one is private to its own file) since it's a handful of lines.
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCwndAxisTick(
    value: Double,
    y: Float,
    axisPaint: Paint,
    // See RttFloorChart's own drawAxisTick maxY doc comment - the plotted
    // area's own (possibly time-axis-shrunk) height, not always the full
    // canvas height.
    maxY: Float = size.height,
) {
    drawLine(
        color = Color(0xFFBDBDBD),
        start = Offset(0f, y),
        end = Offset(6.dp.toPx(), y),
        strokeWidth = 1.dp.toPx(),
    )
    drawContext.canvas.nativeCanvas.drawText(
        "%.0fK".format(value),
        8.dp.toPx(),
        (y + axisPaint.textSize * 0.35f).coerceIn(axisPaint.textSize, maxY - 2.dp.toPx()),
        axisPaint,
    )
}

// Time-axis labels shared by CwndInflightChart/WindowInflightChart - same
// "-Ns at oldest, now at newest" convention as MiniSparkline/RttFloorChart's
// own time axis.
// elapsedSecs/nowX come from the caller's own xOf/elapsedSecs (see
// MiniSparkline's own doc comment for why point positions use a fixed,
// known-in-advance axisSpanSecs denominator, but this label uses
// elapsedSecs instead - x=0 is always t=0, so "how long ago was that" is
// genuinely elapsedSecs and grows every tick, not a constant; printing the
// fixed span instead would claim a run's full history is already on
// screen from the very first sample. Same reasoning for why "now" tracks
// the actual last-point x instead of the canvas's static right edge.
// coerceAtLeast keeps the right-aligned "now" label from clipping off the
// left edge in the first second or two of a run.
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTimeAxis(
    elapsedSecs: Double,
    nowX: Float,
    leftPaint: Paint,
    rightPaint: Paint,
) {
    drawContext.canvas.nativeCanvas.drawText(
        "-%.0fs".format(elapsedSecs),
        2.dp.toPx(),
        size.height - 2.dp.toPx(),
        leftPaint,
    )
    drawContext.canvas.nativeCanvas.drawText(
        "now",
        nowX.coerceAtLeast(24.dp.toPx()),
        size.height - 2.dp.toPx(),
        rightPaint,
    )
}

/**
 * Combined trend for the CWND/inFlight/NotSent bar just above it (see that
 * bar's own call site comment) - three lines sharing one KB y-axis, same
 * colors as that bar's own ColorLegend (CWND red, inFlight green, NotSent
 * yellow) so no second legend is needed here. Same "raw per-interval
 * points, own axis ticks" pattern as RttFloorChart, except the axis floor
 * is a fixed 0 rather than padded down from the observed minimum - these
 * are byte quantities that meaningfully start at zero, not a value with its
 * own nonzero floor the way RTT has.
 */
@Composable
private fun CwndInflightChart(
    history: List<Timestamped<CwndInflightPoint>>,
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 12.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = Color(0xFFBDBDBD).toArgb()
            textSize = axisTextSizePx
        }
    }
    // Current-value callouts, one per line, same "bold, right-aligned,
    // colored to match its own line" convention as MiniSparkline's own
    // current-reading label - three lines sharing one axis otherwise have
    // no numbers of their own, just relative shape.
    val valueTextSizePx = with(density) { 11.sp.toPx() }
    fun valuePaint(lineColor: Color) = Paint().apply {
        isAntiAlias = true
        color = lineColor.toArgb()
        textSize = valueTextSizePx
        textAlign = Paint.Align.RIGHT
        isFakeBoldText = true
    }
    val cwndValuePaint = remember(valueTextSizePx) { valuePaint(RED) }
    val inFlightValuePaint = remember(valueTextSizePx) { valuePaint(GREEN) }
    val notSentValuePaint = remember(valueTextSizePx) { valuePaint(YELLOW) }
    val timeAxisTextSizePx = with(density) { 10.sp.toPx() }
    val timeAxisLeftPaint = remember(timeAxisTextSizePx) {
        Paint().apply { isAntiAlias = true; color = Color(0xFFBDBDBD).toArgb(); textSize = timeAxisTextSizePx }
    }
    val timeAxisRightPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = Color(0xFFBDBDBD).toArgb()
            textSize = timeAxisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }

    // A point's own value can be a timestamped null (see Timestamped's own
    // doc comment), so "enough to draw a chart" means enough *valid*
    // readings, not just enough timestamped slots.
    val validCount = history.count { it.value != null }

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        if (validCount < 2) {
            // Same fixed-height, centered "Waiting for data…" box as
            // RttFloorChart's own empty state (just this chart's own
            // 140dp, matching the Canvas below rather than RttFloorChart's
            // 180dp) - without it, this text collapses to its own natural
            // (much shorter, top-aligned) height instead of lining up with
            // every other row's paired chart, which throws off vertical
            // alignment when comparing two saved presets whose history
            // lists differ in length (e.g. a config-only-restored preset,
            // TestConfigStore's own doc comment, has none at all).
            Box(
                modifier = Modifier.fillMaxWidth().height(140.dp).padding(top = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = "Waiting for data…", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val validPoints = history.mapNotNull { it.value }
            val dataMax = maxOf(
                validPoints.maxOf { it.cwndKB },
                validPoints.maxOf { it.inFlightKB },
                validPoints.maxOf { it.notSentKB },
            ).coerceAtLeast(0.001)
            val axisStep = niceAxisStep(dataMax * 1.08)
            val axisMax = ceil(dataMax * 1.08 / axisStep) * axisStep
            val axisMin = 0.0

            Canvas(modifier = Modifier.fillMaxWidth().height(140.dp).padding(top = 4.dp)) {
                drawRect(color = Color.Black)

                val bottomMarginPx = 14.dp.toPx()
                val plotHeight = size.height - bottomMarginPx

                fun yOf(value: Double): Float =
                    plotHeight - (((value - axisMin) / (axisMax - axisMin)).toFloat() * plotHeight)

                // See MiniSparkline's own axisSpanSecs/elapsedSecs doc
                // comments - axisSpanSecs (fixed) drives point positions,
                // elapsedSecs (grows every tick) drives the left label.
                // Each point's own elapsedSecs (Timestamped) drives x, not
                // list index.
                val elapsedSecs = history.last().elapsedSecs
                val axisSpanSecs = if (durationSecs != null && durationSecs > 0) {
                    maxOf(durationSecs.toDouble(), elapsedSecs)
                } else {
                    elapsedSecs.coerceAtLeast(0.001)
                }
                fun xOf(pointElapsedSecs: Double): Float = (pointElapsedSecs / axisSpanSecs).toFloat() * size.width

                // Null-valued points break all three lines rather than
                // being silently interpolated across - same reasoning as
                // MiniSparkline's own line-drawing (all three share one
                // gate - CwndInflightPoint is only ever appended as a
                // whole, see that data class's own doc comment - so one
                // "penDown" state covers all three lines).
                fun linePath(values: (CwndInflightPoint) -> Double): Path {
                    val path = Path()
                    var penDown = false
                    history.forEach { p ->
                        val v = p.value
                        if (v == null) {
                            penDown = false
                        } else {
                            val x = xOf(p.elapsedSecs)
                            val y = yOf(values(v))
                            if (!penDown) {
                                path.moveTo(x, y)
                                penDown = true
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                    }
                    return path
                }

                drawPath(linePath { it.notSentKB }, color = YELLOW, style = Stroke(width = 2.dp.toPx()))
                drawPath(linePath { it.cwndKB }, color = RED, style = Stroke(width = 2.dp.toPx()))
                drawPath(linePath { it.inFlightKB }, color = GREEN, style = Stroke(width = 2.dp.toPx()))

                drawCwndAxisTick(axisMax, yOf(axisMax), axisPaint, maxY = plotHeight)
                drawCwndAxisTick(axisMin, yOf(axisMin), axisPaint, maxY = plotHeight)
                drawTimeAxis(elapsedSecs, xOf(elapsedSecs), timeAxisLeftPaint, timeAxisRightPaint)

                // Staggered above/below each line's own last point (rather
                // than all three at the same offset) since CWND and inFlight
                // routinely converge near the end of a run (inFlight riding
                // right up against its own CWND ceiling) - same offset would
                // otherwise print two labels on top of each other right
                // where the reading matters most. Last *valid* point, not
                // necessarily the chart's true latest interval - see
                // MiniSparkline's own lastValid doc comment.
                val last = validPoints.last()
                val lastX = xOf(history.last { it.value != null }.elapsedSecs)
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0fK".format(last.cwndKB),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.cwndKB) - 16.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    cwndValuePaint,
                )
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0fK".format(last.inFlightKB),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.inFlightKB) + 16.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    inFlightValuePaint,
                )
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0fK".format(last.notSentKB),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.notSentKB) - 6.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    notSentValuePaint,
                )
            }
        }
    }
}

/**
 * UDP-L4S counterpart to CwndInflightChart above - same three-line-sharing-
 * one-axis treatment for the Window/Inflight/Queued bar (Window=red,
 * inFlight=green, Queued=yellow, same colors as that bar's own
 * ColorLegend), just in packets instead of KB (see WindowInflightPoint's
 * own doc comment for why always packets, not the pkts/KB toggle's
 * currently-selected unit).
 */
@Composable
private fun WindowInflightChart(
    history: List<Timestamped<WindowInflightPoint>>,
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 12.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = Color(0xFFBDBDBD).toArgb()
            textSize = axisTextSizePx
        }
    }
    val valueTextSizePx = with(density) { 11.sp.toPx() }
    fun valuePaint(lineColor: Color) = Paint().apply {
        isAntiAlias = true
        color = lineColor.toArgb()
        textSize = valueTextSizePx
        textAlign = Paint.Align.RIGHT
        isFakeBoldText = true
    }
    val windowValuePaint = remember(valueTextSizePx) { valuePaint(RED) }
    val inflightValuePaint = remember(valueTextSizePx) { valuePaint(GREEN) }
    val queuedValuePaint = remember(valueTextSizePx) { valuePaint(YELLOW) }
    val timeAxisTextSizePx = with(density) { 10.sp.toPx() }
    val timeAxisLeftPaint = remember(timeAxisTextSizePx) {
        Paint().apply { isAntiAlias = true; color = Color(0xFFBDBDBD).toArgb(); textSize = timeAxisTextSizePx }
    }
    val timeAxisRightPaint = remember(timeAxisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = Color(0xFFBDBDBD).toArgb()
            textSize = timeAxisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }

    // A point's own value can be a timestamped null (see Timestamped's own
    // doc comment), so "enough to draw a chart" means enough *valid*
    // readings, not just enough timestamped slots.
    val validCount = history.count { it.value != null }

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        if (validCount < 2) {
            // See CwndInflightChart's own doc comment on this same
            // fixed-height-placeholder pattern, just above.
            Box(
                modifier = Modifier.fillMaxWidth().height(140.dp).padding(top = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = "Waiting for data…", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val validPoints = history.mapNotNull { it.value }
            val dataMax = maxOf(
                validPoints.maxOf { it.windowPkts },
                validPoints.maxOf { it.inflightPkts },
                validPoints.maxOf { it.queuedPkts },
            ).coerceAtLeast(0.001)
            val axisStep = niceAxisStep(dataMax * 1.08)
            val axisMax = ceil(dataMax * 1.08 / axisStep) * axisStep
            val axisMin = 0.0

            Canvas(modifier = Modifier.fillMaxWidth().height(140.dp).padding(top = 4.dp)) {
                drawRect(color = Color.Black)

                val bottomMarginPx = 14.dp.toPx()
                val plotHeight = size.height - bottomMarginPx

                fun yOf(value: Double): Float =
                    plotHeight - (((value - axisMin) / (axisMax - axisMin)).toFloat() * plotHeight)

                // See MiniSparkline's own axisSpanSecs/elapsedSecs doc
                // comments - axisSpanSecs (fixed) drives point positions,
                // elapsedSecs (grows every tick) drives the left label.
                // Each point's own elapsedSecs (Timestamped) drives x, not
                // list index.
                val elapsedSecs = history.last().elapsedSecs
                val axisSpanSecs = if (durationSecs != null && durationSecs > 0) {
                    maxOf(durationSecs.toDouble(), elapsedSecs)
                } else {
                    elapsedSecs.coerceAtLeast(0.001)
                }
                fun xOf(pointElapsedSecs: Double): Float = (pointElapsedSecs / axisSpanSecs).toFloat() * size.width

                // Null-valued points break all three lines rather than
                // being silently interpolated across - see
                // CwndInflightChart's own linePath doc comment.
                fun linePath(values: (WindowInflightPoint) -> Double): Path {
                    val path = Path()
                    var penDown = false
                    history.forEach { p ->
                        val v = p.value
                        if (v == null) {
                            penDown = false
                        } else {
                            val x = xOf(p.elapsedSecs)
                            val y = yOf(values(v))
                            if (!penDown) {
                                path.moveTo(x, y)
                                penDown = true
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                    }
                    return path
                }

                drawPath(linePath { it.queuedPkts }, color = YELLOW, style = Stroke(width = 2.dp.toPx()))
                drawPath(linePath { it.windowPkts }, color = RED, style = Stroke(width = 2.dp.toPx()))
                drawPath(linePath { it.inflightPkts }, color = GREEN, style = Stroke(width = 2.dp.toPx()))

                drawCwndAxisTick(axisMax, yOf(axisMax), axisPaint, maxY = plotHeight)
                drawCwndAxisTick(axisMin, yOf(axisMin), axisPaint, maxY = plotHeight)
                drawTimeAxis(elapsedSecs, xOf(elapsedSecs), timeAxisLeftPaint, timeAxisRightPaint)

                // Same "staggered above/below" reasoning as
                // CwndInflightChart's own value labels - Window and
                // inFlight routinely converge near the end of a run. Last
                // *valid* point, not necessarily the chart's true latest
                // interval - see MiniSparkline's own lastValid doc comment.
                val last = validPoints.last()
                val lastX = xOf(history.last { it.value != null }.elapsedSecs)
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0f".format(last.windowPkts),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.windowPkts) - 16.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    windowValuePaint,
                )
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0f".format(last.inflightPkts),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.inflightPkts) + 16.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    inflightValuePaint,
                )
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0f".format(last.queuedPkts),
                    (lastX - 6.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (yOf(last.queuedPkts) - 6.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    queuedValuePaint,
                )
            }
        }
    }
}

/**
 * TCP-only (forward and --reverse) - mean per-write blocking time
 * (write_mmm.current.mean, --tcp-write-times - see IntervalSample.
 * writeTimeUs's own doc comment): a real measured send-side delay, an
 * earlier and separate stage from RTT (not a component of it). Moved out
 * of BytesInFlightMeter's own bar stack into the same [dial | MiniSparkline]
 * treatment as Throughput/RTT/Load Delay/CE Duration (IperfScreen), so its
 * own trend is visible and correlatable against the others, not just a
 * single collapsed bar reading. Linear (not log) scale against its own
 * running max, floored at 24ms - a healthy write blocks for a handful of
 * microseconds at most, so even a small real backpressure reading (tens to
 * hundreds of us) should still move the needle visibly rather than pinning
 * near zero against a floor set too low. NEUTRAL, not a verdict color - no
 * established "this many ms is bad" threshold exists for this metric.
 */
@Composable
fun WriteBlockTimeMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = showFinal || (sample?.writeTimeUs ?: -1L) >= 0L
    val valueUs = if (showFinal) stats!!.max else if (available) (sample?.writeTimeUs?.toDouble() ?: 0.0) else 0.0
    val maxSeenUs = (stats?.max ?: valueUs).coerceAtLeast(24_000.0)
    val fraction = if (available && maxSeenUs > 0.0) (valueUs / maxSeenUs).toFloat() else 0f

    SpeedometerGauge(
        label = "Write Block Time",
        mainText = if (available) formatMs(valueUs / 1000.0) else "N/A",
        unitText = if (available) "ms" else "",
        fraction = fraction,
        accentColor = NEUTRAL,
        avgText = stats?.let { "avg ${formatMs(it.avg / 1000.0)}" },
        minMaxText = stats?.let { "min ${formatMs(it.min / 1000.0)} · max ${formatMs(it.max / 1000.0)}" },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * TCP-only (forward and --reverse) - per-interval retransmit count
 * (iperf_tcpstats.retry_cnt). Moved out of BytesInFlightMeter's own bar
 * stack for the same reason as WriteBlockTimeMeter above - see that
 * composable's own doc comment. Linear scale against its own running max,
 * floored at 24 retries - a healthy run often sees just 1-2 retries total,
 * and a lower floor would otherwise pin the needle near full for what's
 * actually a negligible count. NEUTRAL, same "no established good/bad
 * threshold" reasoning as WriteBlockTimeMeter.
 */
@Composable
fun RetriesMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = showFinal || (sample?.tcpRetry ?: -1L) >= 0L
    val value = if (showFinal) stats!!.max else if (available) (sample?.tcpRetry?.toDouble() ?: 0.0) else 0.0
    val maxSeen = (stats?.max ?: value).coerceAtLeast(24.0)
    val fraction = if (available && maxSeen > 0.0) (value / maxSeen).toFloat() else 0f

    SpeedometerGauge(
        label = "Retries",
        mainText = if (available) "%.0f".format(value) else "N/A",
        unitText = "",
        fraction = fraction,
        accentColor = NEUTRAL,
        avgText = stats?.let { "avg %.0f".format(it.avg) },
        minMaxText = stats?.let { "min %.0f · max %.0f".format(it.min, it.max) },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * Small clickable unit chip for the Queue (Little's Law) bar's pkts/KB
 * toggle - bold+underlined when selected, dim otherwise, deliberately not a
 * full Switch/SegmentedButton so it reads as a minor in-context preference
 * next to the bar it affects, not a prominent standalone control.
 */
@Composable
private fun UnitToggleLabel(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = text,
        style = if (selected) {
            MaterialTheme.typography.labelMedium.copy(
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
            )
        } else {
            MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        modifier = Modifier.clickable(onClick = onClick),
    )
}

/**
 * BOUNCEBACK + workingLoadEnabled only - one direction's working-load
 * throughput dial. Moved out of BytesInFlightMeter's own bar stack (this
 * mode used to show up to two WorkingLoadBar bars stacked directly
 * underneath the RPS bar) into the same [dial | MiniSparkline] treatment
 * as WriteBlockTimeMeter/RetriesMeter/PacketsPerSecMeter above (see those
 * composables' own doc comments for the general reasoning) - IperfScreen
 * renders one of these per active direction, each paired with its own
 * MiniSparkline, both rows placed right after BytesInFlightMeter's own
 * call so they still render below the RPS bar, this mode's actual hero
 * metric. mbps/stats come from IperfViewModel's workingLoadUpAcc/DownAcc
 * directly (see that field's own doc comment), not IntervalSample -
 * working load's own CSV rows are parsed separately from the main
 * per-interval sample (CsvLineParser.parseWorkingLoadUploadThroughput/
 * parseWorkingLoadDownloadThroughput), merely interleaved in the same
 * stdout stream. "Final reading is the run's average" - same convention
 * as RPS/pps above. Linear scale against this dial's own running max (no
 * longer shared with the other direction's own scale - the old bar
 * stack's `wlSharedMaxSeen` doesn't carry over now that each direction is
 * its own full-width row rather than two bars stacked for direct visual
 * comparison). NEUTRAL, not a verdict color - secondary background
 * traffic, not a pass/fail reading, same reasoning as this mode's RPS bar
 * always keeping its own green instead.
 */
@Composable
fun WorkingLoadUpChart(
    mbps: Double?,
    stats: MeterStats?,
    history: List<TimeSeriesPoint>,
    // The stream's real congestion-control algorithm - a TCP CCA name
    // (workingLoadCca) or "prague"/"reno" (workingLoadL4sCca) depending on
    // workingLoadTransport, see IperfScreen's own call site - rather than
    // a hardcoded "cubic", now that both are user-configurable.
    ccaLabel: String,
    isRunning: Boolean = true,
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) = WorkingLoadChart("Working load up ($ccaLabel)", mbps, stats, history, isRunning, durationSecs, modifier)

/** See [WorkingLoadUpChart]'s doc comment - same, download direction. */
@Composable
fun WorkingLoadDownChart(
    mbps: Double?,
    stats: MeterStats?,
    history: List<TimeSeriesPoint>,
    ccaLabel: String,
    isRunning: Boolean = true,
    durationSecs: Int? = null,
    modifier: Modifier = Modifier,
) = WorkingLoadChart("Working load down ($ccaLabel)", mbps, stats, history, isRunning, durationSecs, modifier)

/**
 * Full-width, no dial - unlike every other secondary metric in this app
 * (WriteBlockTimeMeter/RetriesMeter/PacketsPerSecMeter/CeMarksPerSecMeter),
 * which pair a compact dial with an 80%-width MiniSparkline (see
 * MiniSparkline's own doc comment: it's sized to "the ~80% of a row width
 * ... that a 20%-wide dial gives up"). Working load sits directly under
 * BOUNCEBACK's own LiveSparkline (the RPS graph), which is itself
 * full-width with no dial - a dial+narrow-sparkline row here would give
 * this chart a different x-axis pixel scale than the RPS graph directly
 * above it, so a moment in time wouldn't line up vertically between the
 * two. Matching LiveSparkline's own shape (title text, full-width chart,
 * stats text below) keeps both graphs' time axes visually aligned instead.
 */
@Composable
private fun WorkingLoadChart(
    label: String,
    mbps: Double?,
    stats: MeterStats?,
    history: List<TimeSeriesPoint>,
    isRunning: Boolean,
    durationSecs: Int?,
    modifier: Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = showFinal || mbps != null
    val valueText = if (showFinal) "%.0f Mbps".format(stats!!.avg)
    else if (available) "%.0f Mbps".format(mbps) else "N/A"
    val statsText = stats?.let { "min %.0f · avg %.0f · max %.0f Mbps".format(it.min, it.avg, it.max) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(text = "$label: $valueText", style = MaterialTheme.typography.labelLarge)
        MiniSparkline(
            values = history,
            color = Color.White,
            unit = " Mbps",
            durationSecs = durationSecs,
            modifier = Modifier.fillMaxWidth(),
        )
        statsText?.let { Text(text = it, style = MaterialTheme.typography.bodySmall) }
    }
}

/**
 * "name (color)" caption row for a multi-series bar (e.g. TCP's
 * "CWND/inFlight/NotSent") - spells out which fill color means what,
 * since a stacked bar with three overlaid series isn't self-explanatory
 * the way a single-series bar's own label already is. Unlike the bars
 * themselves (drawn on their own black canvas, where NEUTRAL/white reads
 * fine), this row sits directly on the app's own light background - a
 * white dot there would be invisible, so NEUTRAL gets swapped for a
 * visible mid-gray outline dot instead of the bar's own literal color.
 * [isTick] entries (e.g. CWND) render a tick glyph ("▏") - alongside a
 * filled dot ("●") too, not instead of one, since CWND's own boundary can
 * now ALSO paint a red fill in the headroom between the real data and the
 * tick itself (BarGraphGauge's inCeilingHeadroom) - the legend shows both
 * marks CWND can actually put on the bar. Plain (non-tick) entries just
 * get the dot, matching BarGraphGauge's own fill-vs-tick distinction for
 * everything else - a bare tick would misleadingly suggest that series
 * never fills any part of the bar, which is only true for CWND today.
 */
// color is null for an entry that has no fill/tick of its own on the bar
// at all (e.g. SndBufLimited/RwndLimited/BusyTime's own BusyTime - it's
// the bar's implicit 100% span/scale, not a drawn segment) - the name
// still gets listed, just without a misleading colored dot next to it.
private data class LegendEntry(val name: String, val color: Color? = null, val isTick: Boolean = false)

@Composable
private fun ColorLegend(vararg entries: LegendEntry, centered: Boolean = false) {
    Text(
        text = buildAnnotatedString {
            entries.forEachIndexed { index, entry ->
                if (index > 0) append("  ·  ")
                append(entry.name)
                if (entry.color != null) {
                    append(" (")
                    val displayColor = if (entry.color == NEUTRAL) Color(0xFF9E9E9E) else entry.color
                    withStyle(SpanStyle(color = displayColor)) { append(if (entry.isTick) "●▏" else "●") }
                    append(")")
                }
            }
        },
        style = MaterialTheme.typography.labelSmall,
        textAlign = if (centered) TextAlign.Center else TextAlign.Start,
        modifier = if (centered) Modifier.fillMaxWidth().padding(top = 2.dp) else Modifier.padding(top = 2.dp),
    )
}

/**
 * UDP-L4S only - moved out of BytesInFlightMeter's own bar stack into the
 * same [dial | MiniSparkline] treatment as everything else (see
 * WriteBlockTimeMeter's own doc comment for the general reasoning). "Final
 * reading is the run's average" - a single instant pps spike isn't the
 * interesting "how did this test go" number. Linear scale against its own
 * running max (same as the bar it replaces), default GREEN accent (this
 * app's default "healthy" color, not itself a good/bad verdict - pps has no
 * established threshold, same as the app's other NEUTRAL-colored L4S dials,
 * it's just kept GREEN for continuity with the bar's own former default).
 */
@Composable
fun PacketsPerSecMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = showFinal || (sample?.packetsPerSec ?: -1.0) >= 0.0
    val value = if (showFinal) stats!!.avg else if (available) (sample?.packetsPerSec ?: 0.0) else 0.0
    val maxSeen = (stats?.max ?: value).coerceAtLeast(1.0)
    val fraction = if (available && maxSeen > 0.0) (value / maxSeen).toFloat() else 0f

    SpeedometerGauge(
        label = "Packets/sec",
        mainText = if (available) "%.0f".format(value) else "N/A",
        unitText = if (available) "pps" else "",
        fraction = fraction,
        accentColor = GREEN,
        avgText = stats?.let { "avg %.0f".format(it.avg) },
        minMaxText = stats?.let { "min %.0f · max %.0f".format(it.min, it.max) },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * UDP-L4S and BOUNCEBACK (both transports) - moved out of
 * BytesInFlightMeter's own bar stack, same reasoning as PacketsPerSecMeter
 * above. Headline reading is `stats` (IperfViewModel's ceMarksAcc, every
 * interval including zero-mark ones - "how much CE marking happened
 * overall this run"); avg/min/max caption is the separate `whenMarkingStats`
 * (ceMarksWhenMarkingAcc, only intervals where marking actually happened -
 * "how intense is it when it's happening") - same two-stat split the bar
 * this replaces used, see that param's own doc comment (BytesInFlightMeter).
 * Log-scaled fraction against its own running max, same as RetriesMeter's
 * own floor reasoning - a healthy run often sees long stretches of zero
 * marking, so a plain linear scale against a rare large burst would pin the
 * needle near zero most of the time.
 *
 * Grayed-out "unsupported" state, distinct from a live zero: `ceAvailable`
 * is only false when sample.ceCount is the -1 sentinel (no sample yet, or -
 * for TCP bounceback - this kernel/build lacks tcpi_delivered_ce/
 * tcpi_delivered, see CsvLineParser's BOUNCEBACK doc comment). A genuine
 * ceCount of 0 (counters valid, nothing marked this interval - e.g. plain
 * --tcp-cca cubic) is `ceAvailable = true` and renders as a completely
 * normal live "0", same dial face as any other reading. Only the
 * unsupported/no-data case gets the light-gray face + dark accent treatment
 * - same "read as genuinely disabled at a glance, not just waiting on a
 * sample" convention this codebase already established for
 * RttMeter.CeDurationPlaceholder (TCP mode's own always-N/A CE-duration
 * slot), reused here via the same SpeedometerGauge faceColor/accentColor
 * override rather than inventing a second visual language for the same
 * concept.
 *
 * [pragueRequired] is a second, independent reason to grey this dial out -
 * Capacity-over-UDP_L4S with Reno selected (see L4SCongestionControl):
 * ce/ceperc keep accumulating on the wire regardless of CCA mode (the
 * native side's CE bookkeeping is unconditional, see prague_cc.cpp's
 * ACKReceived()), so the data itself stays genuinely available - this is a
 * deliberate UI call that the reading isn't worth showing when Reno's own
 * congestion response ignores CE marks entirely, not a data-availability
 * gate like [sample]/[stats] above. Never set for BOUNCEBACK (no CCA
 * loop/l4sCca choice applies there at all - see IperfScreen's own call
 * site).
 */
@Composable
fun CeMarksPerSecMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    whenMarkingStats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    pragueRequired: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val intervalSecs = ((sample?.intervalEndSecs ?: 0.0) - (sample?.intervalStartSecs ?: 0.0)).takeIf { it > 0.0 }
    val ceAvailable = (sample?.ceCount ?: -1L) >= 0L
    val liveValue = if (ceAvailable && intervalSecs != null) (sample?.ceCount ?: 0L) / intervalSecs else 0.0
    val available = (showFinal || ceAvailable) && !pragueRequired
    // Grey face is reserved for a CONFIRMED-unsupported combo (a real
    // sample arrived and its ceCount is still the -1 sentinel - TCP
    // bounceback's kernel/build lacking tcpi_delivered_ce, see this
    // composable's own doc comment) OR pragueRequired (see that param's own
    // doc comment). Before the first sample of a UDP-L4S/UDP-L4S-bounceback
    // run, sample is null too, but that's just "no data yet" - same as
    // every sibling dial in this row, which renders a plain black-faced
    // "N/A" rather than greying out while waiting on their first interval.
    val unsupported = (sample != null && !ceAvailable && !showFinal) || pragueRequired
    val value = if (showFinal) stats!!.avg else liveValue
    val maxSeen = (stats?.max ?: value).coerceAtLeast(1.0)
    val logSpan = ln(maxSeen + 1.0)
    val fraction = if (available && logSpan > 0.0) (ln(value.coerceAtLeast(0.0) + 1.0) / logSpan).toFloat() else 0f

    SpeedometerGauge(
        label = "CE marks/sec",
        mainText = if (available) "%.0f".format(value) else "N/A",
        unitText = if (available) "/s" else "",
        fraction = fraction,
        // Unsupported (confirmed via a real sample, not just "waiting for
        // one") reads as genuinely disabled - light face + dark text -
        // rather than a normal black-faced dial that just happens to say
        // "N/A", same convention as CeDurationPlaceholder (see this
        // composable's own doc comment).
        accentColor = if (unsupported) Color(0xFF757575) else NEUTRAL,
        faceColor = if (unsupported) Color(0xFFD9D9D9) else Color.Black,
        avgText = whenMarkingStats?.let { "avg %.0f".format(it.avg) },
        minMaxText = whenMarkingStats?.let { "min %.0f · max %.0f".format(it.min, it.max) },
        compact = compact,
        modifier = modifier,
    )
}

/**
 * UDP-L4S only - moved out of BytesInFlightMeter's own bar stack, same
 * reasoning as PacketsPerSecMeter above. markProb is PragueCC's own raw
 * 0..1<<20 scale (see GetMarkingProbability()'s doc comment) - converted to
 * a percent here, same as the bar this replaces did. Log-scaled against
 * MAX_CE_PERCENT (see that constant's own doc comment for why a linear
 * percent scale left the bar this replaces looking empty in practice).
 */
@Composable
fun MarkingProbabilityMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    // Same convention/reasoning as CeMarksPerSecMeter's own pragueRequired
    // (see that composable's doc comment) - Capacity-over-UDP_L4S with Reno
    // selected greys this dial out too, even though PragueCC's alpha/
    // marking-probability EWMA keeps updating unconditionally regardless of
    // CCA mode (only the CE-triggered window decrease itself is gated, see
    // prague_cc.cpp's ACKReceived()) - it's still a CE-derived reading, and
    // Reno's own congestion response ignores it entirely, so showing it live
    // would be misleading about what's actually driving this run.
    pragueRequired: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = (showFinal || (sample?.l4sMarkingProb ?: -1L) >= 0L) && !pragueRequired
    val percent = if (showFinal) {
        100.0 * stats!!.avg / (1 shl 20)
    } else if (available) {
        100.0 * (sample?.l4sMarkingProb ?: 0L) / (1 shl 20)
    } else {
        0.0
    }
    val logSpan = ln(MAX_CE_PERCENT + 1.0)
    val fraction = if (available) (ln(percent.coerceAtLeast(0.0) + 1.0) / logSpan).toFloat() else 0f

    SpeedometerGauge(
        label = "Marking Probability",
        mainText = if (available) "%.1f".format(percent) else "N/A",
        unitText = if (available) "%" else "",
        fraction = fraction,
        // Grey face specifically for pragueRequired (see that param's own
        // doc comment) - same "genuinely disabled, not just no data yet"
        // treatment CeMarksPerSecMeter uses. Not applied to the plain
        // "waiting for first sample" case (pragueRequired == false,
        // available == false) - that stays the normal black face + N/A,
        // matching every sibling dial in this row.
        accentColor = if (pragueRequired) Color(0xFF757575) else NEUTRAL,
        faceColor = if (pragueRequired) Color(0xFFD9D9D9) else Color.Black,
        // Estimated per-flow rate the currently-shown marking level implies
        // - r = 1/p - 1 Mbps, per Koen De Schepper's own IETF-list guidance
        // on reading an L4S marking probability: the raw percent alone answers "how much is this path
        // marking", but not "what does that actually cap a well-behaved
        // flow to". Derived from `percent` (the same value the dial's own
        // mainText shows - live while running, stats.avg once stopped, see
        // `percent`'s own computation above), not SpeedometerGauge's
        // separate extraText slot - that slot is unconditionally suppressed
        // whenever compact=true (see its own render-site comment), and this
        // meter is *always* rendered compact in this app (paired with a
        // MiniSparkline, IperfScreen.kt), so extraText would silently never
        // appear here. derivedText, unlike extraText, does still render in
        // compact mode, and sits right below the dial (above avgText/
        // minMaxText) so it reads as a direct derivation of the number the
        // dial itself is currently showing. Only shown for p > 0 -
        // undefined/infinite at p = 0, and "0.0%" is what the dial's own
        // reading already says without a confusing second line.
        derivedText = if (available) estimatedRateText(percent) else null,
        avgText = stats?.let { "avg %.1f".format(100.0 * it.avg / (1 shl 20)) },
        minMaxText = stats?.let { "min %.1f · max %.1f".format(100.0 * it.min / (1 shl 20), 100.0 * it.max / (1 shl 20)) },
        compact = compact,
        modifier = modifier,
    )
}

// r = 1/p - 1 Mbps, where p is the marking probability as a fraction
// (percent/100) - see MarkingProbabilityMeter's own derivedText call site
// for the full citation/reasoning. Pulled out as its own function since
// nothing else here needs percent-to-fraction conversion inline.
private fun estimatedRateText(percent: Double): String? {
    if (!percent.isFinite() || percent <= 0.0) return null
    val p = percent / 100.0
    val estimatedMbps = 1.0 / p - 1.0
    return "est. max flow rate ~%.0f Mbps".format(estimatedMbps)
}

/**
 * UDP-L4S only (both directions - the reader's own locally-tracked loss,
 * not write/upload-only like the PragueCC-derived dials above) - moved out
 * of BytesInFlightMeter's own bar stack, same reasoning as
 * PacketsPerSecMeter above. Already a percent (errPercent), no conversion
 * needed - see MarkingProbabilityMeter's own doc comment for the log-scale
 * reasoning. NEUTRAL, matching this bar's own former "informational, no
 * established good/bad threshold" convention.
 */
@Composable
fun LossProbabilityMeter(
    sample: IntervalSample?,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showFinal = !isRunning && stats != null
    val available = showFinal || (sample?.errPercent ?: -1.0) >= 0.0
    val percent = if (showFinal) stats!!.avg else if (available) sample?.errPercent ?: 0.0 else 0.0
    val logSpan = ln(MAX_CE_PERCENT + 1.0)
    val fraction = if (available) (ln(percent.coerceAtLeast(0.0) + 1.0) / logSpan).toFloat() else 0f

    SpeedometerGauge(
        label = "Loss Probability",
        mainText = if (available) "%.1f".format(percent) else "N/A",
        unitText = if (available) "%" else "",
        fraction = fraction,
        accentColor = NEUTRAL,
        avgText = stats?.let { "avg %.1f".format(it.avg) },
        minMaxText = stats?.let { "min %.1f · max %.1f".format(it.min, it.max) },
        compact = compact,
        modifier = modifier,
    )
}
