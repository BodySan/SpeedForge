package com.rjmcmahon.iperf2client.ui.meters

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.WindowedSnapshot
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

// The stdev band alone, no separate min-max envelope - a min-max band
// covering the same window largely duplicated what rawHistory's own
// amber overlay line already shows more precisely (the actual raw values,
// not just their bounds), so it was dropped rather than kept alongside a
// second "how jittery is this" signal. Window min/max are still surfaced,
// just as plain axis ticks (see the current.max/current.min ticks below)
// and in the caption text, not as a second shaded region.
private val BAND_STDEV = Color(0xFF1B5E20).copy(alpha = 0.85f)
private val MEAN_LINE = Color.White
private val AXIS_LABEL = Color(0xFFBDBDBD)
private val RED = Color(0xFFE53935)
// Raw (unaveraged) per-interval RPS overlay - a warm, visually distinct
// hue against the cool white/green mean-line-and-bands palette above, so
// "this is the raw signal" reads at a glance without needing the legend
// text below to explain which dots are which. Plotted as discrete dots,
// not a connected line - each one is an independent, noisy measurement,
// not a continuous signal, and a connected line visually implies
// interpolation between samples that isn't there. The mean line already
// owns showing the trend; this overlay's only job is showing the scatter
// around it.
private val RAW_DOTS = Color(0xFFFFCA28)

// Must match IperfViewModel's LIVE_RENDER_TICK_MS - each point on the
// ribbon is one render tick apart, not one reporting interval apart (see
// this file's own class doc comment), so the time axis below has to use
// this fixed spacing rather than the run's configured intervalSecs.
private const val RENDER_TICK_SECS = 0.1

/**
 * BOUNCEBACK's live view - a scrolling ribbon of windowed RPS stats (see
 * IperfViewModel's windowedStats/sparklineHistoryFlow, fed from each
 * sample's requestsPerSec). Each point on the ribbon is one 10Hz render
 * tick's snapshot of the current 80-sample sliding window, not one raw
 * interval reading - the window is what smooths the line into something
 * CLT-justified (an average of many iid-ish per-interval samples), the
 * ribbon is just how that smoothed value moves over the course of the run.
 *
 * [rawHistory] overlays the un-windowed counterpart of that same signal on
 * the same axis (see its own doc comment below) - the smoothed ribbon
 * alone can read as far steadier than the connection actually is, since
 * an 80-sample window absorbs real interval-to-interval jitter the raw
 * line still shows.
 */
@Composable
fun LiveSparkline(
    // Timestamped, not a plain List<WindowedSnapshot> - see
    // IperfViewModel.sparklineHistory's own doc comment for why each
    // point needs its own real elapsedSecs rather than being positioned
    // by list index (a fixed RENDER_TICK_SECS-per-index assumption drifts
    // from reality here specifically, since this ribbon doesn't start
    // appending at t=0 the way its own render-tick loop starts ticking).
    history: List<Timestamped<WindowedSnapshot>>,
    // A/B compare (IperfScreen's effSparklineHistory): true when this is a
    // saved preset's frozen history rather than the in-progress run's own -
    // only changes the title text below, the chart itself already renders
    // a saved run's history identically to a live one.
    isSaved: Boolean = false,
    // Kernel-tracked connection-lifetime min RTT (IperfViewModel.bbRttMinUs,
    // iperf_tcpstats.rtt_min/tcpi_min_rtt), microseconds - null when not yet
    // available (e.g. HAVE_STRUCT_TCP_INFO_TCPI_MIN_RTT unsupported on the
    // server, or no sample has arrived yet). Since bounceback is strictly
    // serialized (the client blocks on each reply before sending the next
    // request - see RunBounceBackTCP, src/Client.cpp), 1000 / rttMinMs is a
    // real, principled ceiling on achievable RPS - shown alongside the
    // mean/stdev/min/max text below so a reader can tell whether a run is
    // pacing-limited (observed RPS well under the ceiling, by design) or
    // path-limited (observed RPS pressed right up against it).
    rttMinUs: Long? = null,
    // TestConfig.durationSecs - see MiniSparkline's own doc comment for why
    // the axis span needs to be this fixed, known-in-advance value instead
    // of one derived from history.size.
    durationSecs: Int? = null,
    // Raw (not windowed) per-interval RPS - IperfViewModel.bbRequestsHistoryFlow.
    // Overlaid on the same axis as the windowed mean/bands above, not a
    // separate chart, so the two are directly comparable at a glance
    // without needing to visually correlate two different plots: this is
    // literally the same underlying signal, one smoothed and one not.
    // Each point is positioned by its own real elapsedSecs (unlike
    // [history] above, which is one render tick apart - see this file's
    // own class doc comment), so the two lines line up correctly on the
    // shared time axis even though they're sampled at different rates.
    rawHistory: List<TimeSeriesPoint> = emptyList(),
    // The active TCP congestion-control algorithm (TestConfig.tcpCca), null
    // when --tcp-cca wasn't set - same "(cca=...)" title-suffix convention
    // as BytesInFlightMeter's own rpsCcaLabel, so RPS numbers stay
    // comparable across two runs that only differ by CCA without needing
    // to cross-reference the config summary elsewhere on screen.
    rpsCcaLabel: String? = null,
    // One of "off"/"up"/"down"/"bidir" (IperfScreen's own workingLoadTag) -
    // unlike rpsCcaLabel above, always shown rather than omitted for the
    // common/default case: BounceBackHistogramChart's own "wl=.../..." EMD
    // line and configSummary's "wl=..." both always show this too (a
    // technician needs to see "off" just as much as any other state to
    // judge whether two runs are comparable), so hiding it here only on
    // this one chart would be an inconsistent, easy-to-miss exception.
    workingLoadTag: String? = null,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 12.sp.toPx() }
    val valueTextSizePx = with(density) { 14.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
        }
    }
    val valuePaint = remember(valueTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = MEAN_LINE.toArgb()
            textSize = valueTextSizePx
            textAlign = Paint.Align.RIGHT
            isFakeBoldText = true
        }
    }
    // Same "-Ns at oldest, now at newest" convention as MiniSparkline/
    // RttFloorChart/CwndInflightChart's own time axes.
    val timeAxisLeftPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
        }
    }
    val timeAxisRightPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        val ccaSuffix = rpsCcaLabel?.let { " (cca=$it)" } ?: ""
        val wlSuffix = workingLoadTag?.let { " (wl=$it)" } ?: ""
        Text(
            text = (if (isSaved) "RPS (saved, windowed + raw)" else "RPS (live, windowed + raw)") + ccaSuffix + wlSuffix,
            style = MaterialTheme.typography.labelLarge,
        )

        // Real (elapsedSecs, snapshot) pairs - see history's own doc
        // comment for why elapsedSecs (not list index) drives x position.
        // value is only ever null for a "timestamped null" gap, which this
        // particular history never produces (see the append site,
        // IperfViewModel.onStart) - mapNotNull is just the idiomatic way
        // to satisfy Timestamped's own nullable-value type without an
        // unchecked !!.
        val points = history.mapNotNull { t -> t.value?.let { it to t.elapsedSecs } }
        if (points.isEmpty()) {
            Text(
                text = "Waiting for data…",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 4.dp),
            )
        } else {
            val rawValues = rawHistory.mapNotNull { it.value }
            // Bounds must cover the stdev band (mean +/- stdev), not just
            // each snapshot's own observed min/max - at small window sizes
            // mean+stdev can exceed the observed max (and mean-stdev can
            // go below the observed min), so scaling off min/max alone let
            // the darker stdev band render past the canvas edge. Also
            // widened to cover rawHistory's own range - the whole point of
            // overlaying the raw line is to show it swinging wider than
            // the smoothed band, so the axis has to fit it rather than
            // clipping it at the band's own (narrower) bounds.
            val dataMin = minOf(points.minOf { (s, _) -> minOf(s.min, s.mean - s.stdev) }, rawValues.minOrNull() ?: Double.POSITIVE_INFINITY)
            val dataMax = maxOf(points.maxOf { (s, _) -> maxOf(s.max, s.mean + s.stdev) }, rawValues.maxOrNull() ?: Double.NEGATIVE_INFINITY)
                .coerceAtLeast(dataMin + 0.001)
            // Pad before rounding, not after - "nice" rounding alone can
            // still land its boundary right on (or a hair past) the actual
            // data, e.g. a window min of 40.2 rounding to an axis min of
            // 40 leaves no visible black margin at all. Padding first
            // guarantees real headroom regardless of where the data
            // happens to sit relative to a round step.
            val pad = ((dataMax - dataMin) * 0.08).coerceAtLeast(0.5)
            val rawMin = dataMin - pad
            val rawMax = dataMax + pad
            // Round the padded range out to a "nice" step (1/2/5/10 x a
            // power of ten) rather than the raw observed min/max - e.g. an
            // 18-39 RPS range reads as a confusing "18 to 39" axis but a
            // clean "10 to 40" one once rounded.
            val axisStep = niceAxisStep(rawMax - rawMin)
            // RPS can never be negative - clamped after the step/rounding
            // math above (not by clamping dataMin/rawMin earlier), so a
            // low-mean, high-variance window's own mean-stdev dropping
            // below zero still gets a correctly-sized "nice" step; only
            // the floor itself is pulled back up to the real physical
            // bound. Without this, the padded/rounded floor could land
            // below zero, leaving the true "0" gridline floating above
            // the canvas's own bottom edge instead of sitting on it.
            val axisMin = (floor(rawMin / axisStep) * axisStep).coerceAtLeast(0.0)
            val axisMax = ceil(rawMax / axisStep) * axisStep

            Canvas(modifier = Modifier.fillMaxWidth().height(220.dp).padding(top = 4.dp)) {
                drawRect(color = Color.Black)

                // Reserve a bottom strip for the time-axis labels, same as
                // MiniSparkline's own bottomMarginPx - otherwise "-Ns"/"now"
                // would collide with the min/max ticks drawn near the plot's
                // bottom edge.
                val bottomMarginPx = 14.dp.toPx()
                val plotHeight = size.height - bottomMarginPx

                fun yOf(value: Double): Float =
                    plotHeight - (((value - axisMin) / (axisMax - axisMin)).toFloat() * plotHeight)

                // Same fixed-denominator reasoning as MiniSparkline's own
                // axisSpanSecs - elapsedSecs (grows every tick) drives the
                // left time-axis label below, axisSpanSecs (fixed) drives
                // every point's own x position, this ribbon's and
                // rawHistory's alike. Both now positioned by each point's
                // own real elapsedSecs (Timestamped/TimeSeriesPoint), not
                // by list index or RENDER_TICK_SECS spacing - see
                // history's own doc comment for why a per-index assumption
                // drifted from reality here specifically, which is exactly
                // what threw the two lines out of alignment with each
                // other before this fix.
                val elapsedSecs = points.last().second
                val axisSpanSecs: Double = if (durationSecs != null && durationSecs > 0) {
                    maxOf(durationSecs.toDouble(), elapsedSecs)
                } else {
                    elapsedSecs.coerceAtLeast(RENDER_TICK_SECS)
                }
                fun xOf(pointElapsedSecs: Double): Float = (pointElapsedSecs / axisSpanSecs).toFloat() * size.width

                // Drawn before the mean line/bands below so the smoothed
                // signal renders cleanly on top of the raw one, same
                // "instant reading dim underneath, moving average bold on
                // top" convention dashboards commonly use for this exact
                // pairing - the raw dots' whole purpose is to show *how
                // much* the smoothed line is hiding, not to compete with
                // it for attention.
                val rawPoints = rawHistory.mapNotNull { p -> p.value?.let { Offset(xOf(p.elapsedSecs), yOf(it)) } }
                for (p in rawPoints) {
                    drawCircle(color = RAW_DOTS, radius = 2.dp.toPx(), center = p)
                }

                val stdevTopPoints = points.map { (s, t) -> Offset(xOf(t), yOf(s.mean + s.stdev)) }
                val stdevBottomPoints = points.map { (s, t) -> Offset(xOf(t), yOf(s.mean - s.stdev)) }
                drawPath(bandPath(stdevTopPoints, stdevBottomPoints), color = BAND_STDEV)

                val meanPoints = points.map { (s, t) -> Offset(xOf(t), yOf(s.mean)) }
                val meanLine = Path().apply {
                    moveTo(meanPoints[0].x, meanPoints[0].y)
                    for (i in 1 until meanPoints.size) lineTo(meanPoints[i].x, meanPoints[i].y)
                }
                drawPath(meanLine, color = MEAN_LINE, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))

                // Axis ticks drawn right on the graph for the *current*
                // windowed snapshot's min-max band edges (WindowedWelfordStats'
                // own trailing sample window, not this chart's x-axis span -
                // see LiveSparkline's own class doc comment), so the chart
                // carries its own numbers instead of needing a separate
                // text summary alongside it. The fixed axisMax/axisMin
                // scale bounds deliberately aren't ticked here too - they
                // often land within a label's height of these, and a
                // "meter scale" number right next to an actual data number
                // just collided instead of adding information. Stdev isn't
                // a separate pair of ticks either - it's one number, folded
                // into the "mean +/- stdev" callout below instead of two
                // more lines to visually parse.
                val current = points.last().first
                val ticks = listOf(
                    current.max to "%.0f".format(current.max),
                    current.min to "%.0f".format(current.min),
                )
                ticks.forEach { (value, label) ->
                    val y = yOf(value)
                    drawLine(
                        color = AXIS_LABEL,
                        start = Offset(0f, y),
                        end = Offset(6.dp.toPx(), y),
                        strokeWidth = 1.dp.toPx(),
                    )
                    drawContext.canvas.nativeCanvas.drawText(
                        label,
                        8.dp.toPx(),
                        (y + axisTextSizePx * 0.35f).coerceIn(axisTextSizePx, plotHeight - 2.dp.toPx()),
                        axisPaint,
                    )
                }

                // Current reading, printed right on the graph next to
                // where the mean line ends - the one number most worth
                // reading at a glance while the test is running, paired
                // with its own spread rather than making the stdev band's
                // edges carry that information as separate ticks.
                val last = meanPoints.last()
                drawContext.canvas.nativeCanvas.drawText(
                    "%.0f ± %.1f".format(current.mean, current.stdev),
                    (last.x - 4.dp.toPx()).coerceAtLeast(size.width * 0.3f),
                    (last.y - 8.dp.toPx()).coerceIn(valueTextSizePx, plotHeight - 4.dp.toPx()),
                    valuePaint,
                )

                // See MiniSparkline's own doc comment for why "now" tracks
                // the actual last-point x rather than the canvas's static
                // right edge, and why the left label is elapsedSecs (grows
                // every tick) rather than the fixed axisSpanSecs used for
                // point positioning.
                drawContext.canvas.nativeCanvas.drawText(
                    "-%.0fs".format(elapsedSecs),
                    2.dp.toPx(),
                    size.height - 2.dp.toPx(),
                    timeAxisLeftPaint,
                )
                val nowX = xOf(elapsedSecs).coerceAtLeast(24.dp.toPx())
                drawContext.canvas.nativeCanvas.drawText(
                    "now",
                    nowX,
                    size.height - 2.dp.toPx(),
                    timeAxisRightPaint,
                )
            }
        }

        // One stats block (not the old two) - driven by the *current*
        // windowed snapshot (history.last()), same "live, responsive to
        // each incoming sample" data as the graph's own ticks, not a
        // whole-session average that goes stale as the run gets long.
        history.lastOrNull()?.value?.let {
            Text(
                text = "mean %.1f · stdev %.1f · min %.1f · max %.1f RPS (win=%d)".format(
                    it.mean, it.stdev, it.min, it.max, it.count,
                ),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp),
            )
            val maxZ = it.maxZScore
            val unusual = maxZ > 4.5
            Text(
                text = if (unusual) {
                    "Unusual spike: %.1f× the typical spread from average".format(maxZ)
                } else {
                    "Peak reading was %.1f× the typical spread from average".format(maxZ)
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (unusual) RED else Color.Unspecified,
            )
        }
        // Raw counterpart to the windowed block above - last/min/max of
        // rawHistory itself (not the windowed mean's own min/max, which
        // history.last() already carries), so the orange dots overlaid on
        // the graph have real numbers to go with them instead of shape alone.
        rawHistory.mapNotNull { it.value }.let { rawValues ->
            if (rawValues.isNotEmpty()) {
                // Default (theme-adaptive) text color, not RAW_DOTS - that
                // color is tuned for legibility against the chart's own
                // always-black Canvas background (every chart in this app
                // draws one explicitly), but this caption sits in the
                // surrounding Column, which follows the system theme -
                // RAW_DOTS' amber reads fine on black but is nearly
                // unreadable on a light theme's own white background.
                Text(
                    text = "raw last %.1f · min %.1f · max %.1f RPS".format(
                        rawValues.last(), rawValues.min(), rawValues.max(),
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
        rttMinUs?.let { us ->
            val rttMinMs = us / 1000.0
            // 0us is a real (if suspiciously exact) reading some kernels
            // report before their first genuine sample - guard the ceiling
            // math specifically (not the raw ms readout) so a momentary 0
            // doesn't render as an infinite/nonsensical RPS ceiling. Whole
            // line bolded, matching BounceBackHistogramChart's "EMD vs
            // golden" treatment.
            val ceilingText = if (us > 0) {
                " · theoretical RPS ceiling %.0f".format(1000.0 / rttMinMs)
            } else {
                ""
            }
            Text(
                text = "RTT min (kernel) %.1f ms%s".format(rttMinMs, ceilingText),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

/**
 * Picks a "nice" axis step (1/2/5/10 x a power of ten) that spans the given
 * range in roughly two divisions - e.g. a range of 21 (18 to 39) yields a
 * step of 10, rounding the visible axis out to a clean 10-40 rather than
 * the confusing raw 18-39. internal (not private) - RttFloorChart.kt reuses
 * this for its own axis rounding rather than duplicating the logic.
 */
internal fun niceAxisStep(range: Double): Double {
    if (range <= 0.0) return 1.0
    val rawStep = range / 2.0
    val magnitude = 10.0.pow(floor(log10(rawStep)))
    val residual = rawStep / magnitude
    val niceResidual = when {
        residual < 1.5 -> 1.0
        residual < 3.5 -> 2.0
        residual < 7.5 -> 5.0
        else -> 10.0
    }
    return niceResidual * magnitude
}

/**
 * A single closed contour for a filled band: top edge left-to-right, then
 * bottom edge right-to-left, then close. Building this as one path (rather
 * than two separately-built Paths merged with addPath) matters - addPath
 * starts a new contour, and Skia auto-closes each open contour independently
 * for fill purposes, so two addPath'd halves fill as two separate wedges
 * instead of one connected band.
 */
private fun bandPath(top: List<Offset>, bottom: List<Offset>): Path {
    val path = Path()
    if (top.isEmpty()) return path
    path.moveTo(top[0].x, top[0].y)
    for (i in 1 until top.size) path.lineTo(top[i].x, top[i].y)
    for (i in bottom.indices.reversed()) path.lineTo(bottom[i].x, bottom[i].y)
    path.close()
    return path
}
