package com.rjmcmahon.iperf2client.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Local copies of Icons.Filled.Wifi/Cable/SignalCellularAlt's own path data -
 * pulling in the whole androidx.compose.material:material-icons-extended
 * library (~11k classes across all 5 style variants x ~1100 icons) just for
 * these icons bloated the release APK by ~4MB of unused classes.dex
 * (confirmed: every other icon this app uses -
 * ArrowDropDown/Check/Clear/Refresh/Star - already ships in
 * material-icons-core, which material3 pulls in anyway, so removing the
 * extended dependency costs nothing elsewhere).
 *
 * Path data extracted directly from the compiled WifiKt/CableKt/
 * SignalCellularAltKt bytecode (javap -c) rather than retyped from memory,
 * so this renders pixel-identical to the original Material icons.
 */
private var _wifiIcon: ImageVector? = null
val WifiIcon: ImageVector
    get() {
        _wifiIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "Filled.Wifi",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(1f, 9f)
            lineToRelative(2f, 2f)
            curveToRelative(4.97f, -4.97f, 13.03f, -4.97f, 18f, 0f)
            lineToRelative(2f, -2f)
            curveTo(16.93f, 2.93f, 7.08f, 2.93f, 1f, 9f)
            close()
            moveTo(9f, 17f)
            lineToRelative(3f, 3f)
            lineToRelative(3f, -3f)
            curveToRelative(-1.65f, -1.66f, -4.34f, -1.66f, -6f, 0f)
            close()
            moveTo(5f, 13f)
            lineToRelative(2f, 2f)
            curveToRelative(2.76f, -2.76f, 7.24f, -2.76f, 10f, 0f)
            lineToRelative(2f, -2f)
            curveTo(15.14f, 9.14f, 8.87f, 9.14f, 5f, 13f)
            close()
        }.build()
        _wifiIcon = built
        return built
    }

private var _cableIcon: ImageVector? = null
val CableIcon: ImageVector
    get() {
        _cableIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "Filled.Cable",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(20f, 5f)
            verticalLineTo(4f)
            curveToRelative(0f, -0.55f, -0.45f, -1f, -1f, -1f)
            horizontalLineToRelative(-2f)
            curveToRelative(-0.55f, 0f, -1f, 0.45f, -1f, 1f)
            verticalLineToRelative(1f)
            horizontalLineToRelative(-1f)
            verticalLineToRelative(4f)
            curveToRelative(0f, 0.55f, 0.45f, 1f, 1f, 1f)
            horizontalLineToRelative(1f)
            verticalLineToRelative(7f)
            curveToRelative(0f, 1.1f, -0.9f, 2f, -2f, 2f)
            reflectiveCurveToRelative(-2f, -0.9f, -2f, -2f)
            verticalLineTo(7f)
            curveToRelative(0f, -2.21f, -1.79f, -4f, -4f, -4f)
            reflectiveCurveTo(5f, 4.79f, 5f, 7f)
            verticalLineToRelative(7f)
            horizontalLineTo(4f)
            curveToRelative(-0.55f, 0f, -1f, 0.45f, -1f, 1f)
            verticalLineToRelative(4f)
            horizontalLineToRelative(1f)
            verticalLineToRelative(1f)
            curveToRelative(0f, 0.55f, 0.45f, 1f, 1f, 1f)
            horizontalLineToRelative(2f)
            curveToRelative(0.55f, 0f, 1f, -0.45f, 1f, -1f)
            verticalLineToRelative(-1f)
            horizontalLineToRelative(1f)
            verticalLineToRelative(-4f)
            curveToRelative(0f, -0.55f, -0.45f, -1f, -1f, -1f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f)
            reflectiveCurveToRelative(2f, 0.9f, 2f, 2f)
            verticalLineToRelative(10f)
            curveToRelative(0f, 2.21f, 1.79f, 4f, 4f, 4f)
            reflectiveCurveToRelative(4f, -1.79f, 4f, -4f)
            verticalLineToRelative(-7f)
            horizontalLineToRelative(1f)
            curveToRelative(0.55f, 0f, 1f, -0.45f, 1f, -1f)
            verticalLineTo(5f)
            horizontalLineTo(20f)
            close()
        }.build()
        _cableIcon = built
        return built
    }

private var _cellularIcon: ImageVector? = null
val CellularIcon: ImageVector
    get() {
        _cellularIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "Filled.SignalCellularAlt",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(17f, 4f)
            horizontalLineToRelative(3f)
            verticalLineToRelative(16f)
            horizontalLineToRelative(-3f)
            close()
            moveTo(5f, 14f)
            horizontalLineToRelative(3f)
            verticalLineToRelative(6f)
            lineTo(5f, 20f)
            close()
            moveTo(11f, 9f)
            horizontalLineToRelative(3f)
            verticalLineToRelative(11f)
            horizontalLineToRelative(-3f)
            close()
        }.build()
        _cellularIcon = built
        return built
    }

/**
 * Simple bottle silhouette (cap, tapered neck, rounded body) - custom-
 * drawn, not extracted from Material. Material's closest match (Sanitizer)
 * bakes in a spray-droplet/cross mark that read as confusing at 16dp; the
 * next-closest (Liquor) is a multi-path icon with a liquid-level indicator
 * and cap highlight - accurately hand-transcribing 900+ bytecode lines of
 * curves for a decoration-level icon wasn't worth the transcription-error
 * risk. This shape is simple enough to author (and verify by eye) directly.
 * Used as the "bleach bottle" stand-in for the ECN-bleaching warning badges
 * (ConnectionStatusIndicator, IperfScreen).
 */
private var _bottleIcon: ImageVector? = null
val BottleIcon: ImageVector
    get() {
        _bottleIcon?.let { return it }
        val built = ImageVector.Builder(
            name = "BleachBottle",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).path(fill = SolidColor(Color.Black)) {
            moveTo(9f, 1f)
            horizontalLineTo(15f)
            verticalLineTo(4f)
            lineTo(17f, 7f)
            verticalLineTo(20f)
            curveTo(17f, 21.1f, 16.1f, 22f, 15f, 22f)
            horizontalLineTo(9f)
            curveTo(7.9f, 22f, 7f, 21.1f, 7f, 20f)
            verticalLineTo(7f)
            lineTo(9f, 4f)
            close()
        }.build()
        _bottleIcon = built
        return built
    }
