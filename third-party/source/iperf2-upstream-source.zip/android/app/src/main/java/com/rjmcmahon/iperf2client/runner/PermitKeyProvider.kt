package com.rjmcmahon.iperf2client.runner

import com.rjmcmahon.iperf2client.BuildConfig
import java.security.MessageDigest

/**
 * Computes the silent permit-key this app sends to non-local hosts (see
 * IperfCommandBuilder), gating access to a public server without exposing
 * anything to the user or requiring them to type a key (--permit-key
 * already exists in iperf2 - src/Listener.cpp's test_permit_key() - this
 * just derives what value to pass automatically).
 *
 * Deliberately a salted hash, not a bare hash of the version string: the
 * version string alone (e.g. "iperf 2.2.2 (3 July 2026) pthreads
 * (professional) (compiled by rjmcmahon)") is entirely self-reported and
 * derivable from the public iperf2 source - anyone could patch their own
 * build to print the identical string and recompute the same hash. The
 * salt (BuildConfig.PERMIT_KEY_SALT, sourced from the gitignored
 * local.properties, never committed to the public repo) is the one
 * ingredient an attacker with only the public source can't reproduce.
 *
 * This is still a cleartext shared secret sent over the wire (permit-key's
 * own limitation, see src/Listener.cpp's test_permit_key - plain strncmp,
 * no TLS) - sniff-and-replay within a given release's lifetime is possible.
 * Rotating PERMIT_KEY_SALT (and the server's --permit-key value to match)
 * on release is the accepted mitigation, not an attempt at perfect security.
 *
 * PERMIT_KEY_BUILD_FOR (local.properties `permitKeyBuildFor=`, set by the
 * build engineer after checkout - never committed, empty by default) names
 * who the build is for. When set it is mixed into the hash as its own
 * ingredient, deliberately separate from versionInfo, so the key is tied to
 * that build without baking "for <name>" into the native binary's compiled
 * version string (which would show up in the app's live -v output and every
 * diag dump). When empty it is left out of the hash entirely, preserving the
 * plain versionInfo|salt|host formula. Changing it changes the computed key
 * exactly like changing PERMIT_KEY_SALT does - the new value must be added
 * to all 11 responde.* servers' permit-keys.env (deploy_permit_key.sh)
 * before/alongside shipping a build that changes it. android/
 * compute_permit_key.py computes the same value.
 */
object PermitKeyProvider {
    /** Null if versionInfo is null/blank (e.g. -v failed) or the salt isn't configured. */
    fun compute(versionInfo: String?): String? {
        if (versionInfo.isNullOrBlank()) return null
        if (BuildConfig.PERMIT_KEY_SALT.isBlank()) return null
        val buildFor = BuildConfig.PERMIT_KEY_BUILD_FOR
        val input = if (buildFor.isEmpty()) {
            "$versionInfo|${BuildConfig.PERMIT_KEY_SALT}|${BuildConfig.PERMIT_HOST}"
        } else {
            "$versionInfo|$buildFor|${BuildConfig.PERMIT_KEY_SALT}|${BuildConfig.PERMIT_HOST}"
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
