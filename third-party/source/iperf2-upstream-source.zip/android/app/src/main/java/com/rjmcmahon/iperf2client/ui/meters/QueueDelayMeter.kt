package com.rjmcmahon.iperf2client.ui.meters

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.rjmcmahon.iperf2client.model.MeterStats
import kotlin.math.ln

// srtt - rtt_min (PragueCC::GetQueueInfo(), src/prague_cc.cpp) is *not*
// pure queueing delay, especially over Wi-Fi - see this file's own
// QueueDelayMeter doc comment for why rtt_min itself isn't a clean
// propagation-delay floor there (MCS/PHY rate adaptation, EDCA channel
// access). It's the same order of magnitude as TCP's own RTT regardless
// (built from the same kind of round-trip timestamp exchange, just with
// that imperfect floor subtracted out), so this reuses RttMeter's exact
// TCP thresholds - same dial, same scale, comparable at a glance rather
// than each mode inventing its own notion of "high" delay.
private const val MAX_DELAY_MS = 1_000.0
private const val DELAY_PIVOT_MS = 1.0
private const val DELAY_YELLOW_MS = 10.0
private const val DELAY_RED_MS = 100.0

private val GREEN = Color(0xFF2E7D32)
private val YELLOW = Color(0xFFFFD600)
private val RED = Color(0xFFE53935)

/**
 * Deliberately labeled "Load Delay", not "Queueing Delay" - current
 * smoothed RTT minus the connection's own tracked minimum RTT does *not*
 * cleanly isolate queueing delay, and the gap is bigger than just "some
 * other small delay sources are mixed in": rtt_min itself isn't a fixed
 * propagation-delay floor, especially over Wi-Fi. It's only the *best RTT
 * observed so far* - and that best case is still subject to MCS/PHY rate
 * adaptation (a later sample sent at a lower modulation/coding rate takes
 * longer over the air with zero queueing involved, purely from worse
 * channel conditions) and EDCA channel access (802.11's CSMA/CA has
 * inherent random backoff/AIFS variance even on a completely idle
 * channel). So "current - min" conflates real queueing/congestion with
 * legitimate rate-adaptation and MAC-contention variance that have
 * nothing to do with load in the "too much data queued" sense - per Koen
 * De Schepper's review (doc/email_koen_littles_law_review.txt), it also
 * folds in scheduler delay, A-MPDU formation time, and reverse-path ACK
 * delay. It's a real, useful signal of load on the path, just not a
 * literal physical queue-depth measurement, so the label shouldn't
 * overclaim precision. Same reasoning applies to TCP's own version of
 * this number.
 *
 * Shared by both TCP and UDP-L4S - same dial, same thresholds, same
 * underlying formula, just sourced from a different kernel/library:
 * UDP-L4S feeds it PragueCC's srtt - rtt_min (IntervalSample.queueDelayUs,
 * write/upload direction only - see that field's own doc comment on why
 * it's always -1 in --reverse); TCP feeds it the kernel's own tcpi_rtt -
 * tcpi_min_rtt (IperfViewModel.tcpExcessRttAcc). Caller computes
 * `rawValueMs` from whichever applies rather than this composable reading
 * an IntervalSample field directly, so one dial implementation covers both
 * modes for a genuine apples-to-apples A/B comparison instead of TCP's own
 * version being buried as a caption line under its RTT dial.
 *
 * min/avg/max text is this app's own running stat across intervals, fed
 * through the exact same StatAccumulator for both modes, for an
 * apples-to-apples comparison between the two test modes.
 */
@Composable
fun QueueDelayMeter(
    rawValueMs: Double,
    stats: MeterStats? = null,
    isRunning: Boolean = true,
    compact: Boolean = false,
    modifier: Modifier = Modifier,
) {
    // Once stopped, show the run's own worst case, same "a single bad spike
    // matters for latency" reasoning as RttMeter.
    val finalMs = stats?.max
    val available = if (!isRunning && finalMs != null) true else rawValueMs >= 0.0
    val valueMs = if (!isRunning && finalMs != null) finalMs else if (available) rawValueMs else 0.0

    val logSpan = ln(MAX_DELAY_MS / DELAY_PIVOT_MS + 1.0)
    fun logFractionOf(ms: Double) = (ln(ms / DELAY_PIVOT_MS + 1.0) / logSpan).toFloat()
    val logFraction = if (available) logFractionOf(valueMs) else 0f

    val color = when {
        !available -> Color.White
        valueMs >= DELAY_RED_MS -> RED
        valueMs >= DELAY_YELLOW_MS -> YELLOW
        else -> GREEN
    }
    val yellowFraction = logFractionOf(DELAY_YELLOW_MS)
    val redFraction = logFractionOf(DELAY_RED_MS)

    SpeedometerGauge(
        label = "Load Delay",
        mainText = if (available) "%.1f".format(valueMs) else "N/A",
        unitText = if (available) "ms" else "",
        fraction = logFraction,
        accentColor = color,
        colorAt = { position ->
            when {
                position >= redFraction -> RED
                position >= yellowFraction -> YELLOW
                else -> GREEN
            }
        },
        avgText = stats?.let { "avg %.1f".format(it.avg) },
        minMaxText = stats?.let { "min %.1f · max %.1f".format(it.min, it.max) },
        peakFraction = stats?.let { logFractionOf(it.max) },
        compact = compact,
        modifier = modifier,
    )
}
