package com.rjmcmahon.iperf2client.ui.meters

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import com.rjmcmahon.iperf2client.model.emdAgainstReference
import com.rjmcmahon.iperf2client.model.meanMs
import kotlin.math.ceil
import kotlin.math.floor

private val BAR_COLOR = Color(0xFF42A5F5)
private val AXIS_LABEL = Color(0xFFBDBDBD)
// CDF line's own color - white against both the blue bars and black
// background, same "primary trend line" role LiveSparkline's own mean
// line (also white) plays there. Its axis label paint is tinted to match,
// same convention RttFloorChart uses for its own floor-line corner label.
private val CDF_LINE = Color.White
// Single remaining percentile marker - the 99.7th percentile (three
// standard deviations), i.e. how far out the slow tail reaches. Red for
// the same "this is the number worth flagging" reasoning RttFloorChart's
// own outlier-adjacent colors use elsewhere in this app.
private val MARKER_P999 = Color(0xFFE53935)
// The absolute minimum observed - the first (lowest-numbered) populated
// bin, i.e. this run's own best-case latency floor. Same green
// RttFloorChart's own FLOOR_LINE uses for its floor reading, for the same
// "this is the best this connection ever did" role.
private val MARKER_MIN = Color(0xFF66BB6A)
// Golden reference's own CDF overlay (see BounceBackHistogramChart's
// showGoldenOverlay toggle) - a literal gold/amber tone, distinct from
// CDF_LINE's white so the two overlaid shapes read as "this run" vs "the
// reference" at a glance without needing the legend text to explain it.
private val GOLDEN_CDF_LINE = Color(0xFFFFD54F)
// Golden reference's own PDF overlay (hollow/outlined bars, see
// showGoldenPdf below) - deliberately its own color rather than reusing
// GOLDEN_CDF_LINE: both can be toggled on together, and two golden shapes
// sharing one color would blur into a single "golden" blob instead of
// reading as two independently-toggleable overlays. Purple, since it's the
// one hue not already claimed by BAR_COLOR (blue), CDF_LINE (white),
// MARKER_P999 (red), MARKER_MIN (green), or GOLDEN_CDF_LINE (gold) -
// distinct against the black canvas and against every other line already
// on this chart. Also deliberately unfilled (stroke-only), so a busy
// chart's already-solid current-run bars stay legible underneath/behind it
// rather than being visually replaced.
private val GOLDEN_PDF_OUTLINE = Color(0xFFAB47BC)
// EMD fill - the shaded region between the current run's CDF (white) and
// golden's own CDF (gold), i.e. a literal picture of
// EMD = integral |F_run(x) - F_ref(x)| dx: wider/taller shaded area means
// a bigger distance, and *where* it's shaded shows whether the two runs
// diverge across the whole distribution or only in one part of it (the
// single scalar EMD number on its own can't show that). Teal, the one
// remaining hue not already claimed by any other element on this chart.
// Alpha 0x80 (~50%) - against the plot's own black background even a
// fully-saturated fill only ever renders at its own alpha fraction of
// brightness (black contributes nothing), so this needed to be
// noticeably higher than a fill would on a light background to still
// read clearly; 0x4D (~30%), tried first, looked washed out on-device.
private val EMD_FILL = Color(0x8026C6DA)

/**
 * Builds one histogram's own CDF path on a shared x/y mapping - used for
 * both [BounceBackHistogramChart]'s always-drawn current-run CDF and its
 * optional golden-reference overlay, so the two lines are guaranteed to be
 * built the exact same way (same flat-segment-then-diagonal-ramp shape per
 * bin - see the original inline comment this was factored out of, still
 * below at the current-run call site, for why). [tailMs] is the chart's
 * own overall x-axis ceiling (not necessarily this histogram's own last
 * bin) so both lines end at the same right edge regardless of whether
 * they individually have data out that far.
 */
private fun buildCdfPath(h: BounceBackHistogram, tailMs: Double, xOfMs: (Double) -> Float, yOfCdfFraction: (Double) -> Float): Path {
    val totalCount = h.totalCount.coerceAtLeast(1)
    val path = Path()
    var cumulative = 0
    var cdfX = xOfMs(0.0)
    var cdfY = yOfCdfFraction(0.0)
    path.moveTo(cdfX, cdfY)
    h.bins.forEach { bin ->
        val lowerMs = (bin.binNumber - 1) * h.binWidthUs / 1000.0
        val upperMs = bin.binNumber * h.binWidthUs / 1000.0
        path.lineTo(xOfMs(lowerMs), cdfY)
        cumulative += bin.count
        cdfY = yOfCdfFraction(cumulative.toDouble() / totalCount)
        cdfX = xOfMs(upperMs)
        path.lineTo(cdfX, cdfY)
    }
    path.lineTo(xOfMs(tailMs), cdfY)
    return path
}

/**
 * Same flat-then-ramp CDF shape [buildCdfPath] draws, evaluated at one
 * arbitrary [ms] instead of traced as a whole path - the interpolation
 * point inside a bin's own ramp matters here (unlike buildCdfPath, which
 * only ever needs the two ramp endpoints), since [buildEmdFillPath] below
 * samples this at a fixed pixel stride that will usually land mid-ramp.
 */
private fun cdfFractionAt(h: BounceBackHistogram, ms: Double): Double {
    val totalCount = h.totalCount.coerceAtLeast(1)
    var cumulative = 0
    for (bin in h.bins) {
        val lowerMs = (bin.binNumber - 1) * h.binWidthUs / 1000.0
        val upperMs = bin.binNumber * h.binWidthUs / 1000.0
        if (ms < lowerMs) return cumulative.toDouble() / totalCount
        if (ms < upperMs) {
            val prevFrac = cumulative.toDouble() / totalCount
            val newFrac = (cumulative + bin.count).toDouble() / totalCount
            val t = (ms - lowerMs) / (upperMs - lowerMs)
            return prevFrac + t * (newFrac - prevFrac)
        }
        cumulative += bin.count
    }
    return cumulative.toDouble() / totalCount
}

/**
 * The EMD's own visual proof: a filled polygon tracing [run]'s CDF left to
 * right, then [ref]'s CDF right to left back to the start, closed into one
 * loop. Where the two curves cross, this naturally splits into separate
 * bowtie-shaped sub-loops on either side of the crossing - each one still
 * fills correctly under the default nonzero winding rule regardless of
 * which curve is "on top" in that stretch, so a crossing doesn't need to be
 * detected/split by hand here. Sampled at a fixed pixel stride (not per-bin
 * edge like buildCdfPath) since [run] and [ref] can have entirely different
 * bin boundaries - a shared x-sampling grid is the simplest way to get both
 * curves' y at the same x.
 */
private fun buildEmdFillPath(
    run: BounceBackHistogram,
    ref: BounceBackHistogram,
    minMs: Double,
    maxMs: Double,
    xOfMs: (Double) -> Float,
    yOfCdfFraction: (Double) -> Float,
): Path {
    val path = Path()
    val steps = 96
    for (i in 0..steps) {
        val ms = minMs + (maxMs - minMs) * i / steps
        val x = xOfMs(ms)
        val y = yOfCdfFraction(cdfFractionAt(run, ms))
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    for (i in steps downTo 0) {
        val ms = minMs + (maxMs - minMs) * i / steps
        val x = xOfMs(ms)
        val y = yOfCdfFraction(cdfFractionAt(ref, ms))
        path.lineTo(x, y)
    }
    path.close()
    return path
}

/**
 * BOUNCEBACK's one-per-run request/reply time distribution - see
 * CsvLineParser.parseBounceBackHistogram/IperfViewModel.bbHistogram's own
 * doc comments for where [histogram] comes from. This data only ever
 * exists as a single already-complete snapshot (iperf2's client prints it
 * exactly once, right after the last interval's own report, at the very
 * end of a completed run) - unlike every other chart in this app, there's
 * no "isRunning" live-update concern here: it renders once [histogram]
 * arrives (staying in the "Waiting for data…" state until then, same
 * empty-state convention as RttFloorChart/LiveSparkline) and then stays
 * static.
 *
 * X-axis is latency in ms ([BounceBackHistogram.binMidpointMs] - real
 * units, not raw bin indices). Two independent y-scales share it: the bars
 * (left axis) are each bin's own raw sample count, and the white CDF line
 * (right axis, 0-1) is the running fraction of the total that landed at or
 * below each latency - a standard "histogram + CDF" combo chart, not one
 * shared scale (a single bin's own count is usually a small slice of the
 * total, so forcing the CDF onto the same axis would send it off the top
 * of the chart almost immediately). Outlier/out-of-bounds counts don't fit
 * naturally on the chart itself (they're not latency values with an x
 * position), so they get their own caption line below it instead,
 * mirroring RttFloorChart's own "chart carries the shape, a corner/caption
 * label carries the number that doesn't fit the axes" split.
 */
@Composable
fun BounceBackHistogramChart(
    histogram: BounceBackHistogram?,
    // The current golden reference (IperfViewModel.goldenHistogram) -
    // deliberately the *same* value regardless of whether [histogram] is
    // the live run or a saved A/B/C/D preset, recomputed fresh via
    // HistogramDistance.emdAgainstReference below rather than only ever
    // trusting [histogram]'s own frozen emdVsBaseline field. See that
    // function's own doc comment for why: comparing every preset against
    // golden (not just presets against each other) only makes sense if
    // each one is measured against whatever's *currently* golden, not
    // whatever was golden back when that preset happened to be captured.
    //
    // Saving/viewing the golden reference itself both moved to
    // RunCompareTabs (IperfScreen.kt) - a slot's own tab is held to
    // promote it, and starred whenever it currently *is* golden - rather
    // than a separate Save/Show pair of buttons in this chart, which two
    // rounds of on-device feedback found unintuitive (three loosely-named
    // buttons bundling a storage action, a view-mode switch, and an
    // overlay toggle with none of them naming their object). This
    // composable only concerns itself with the overlay toggles below,
    // which stay genuinely chart-local (independent per slot you're
    // looking at).
    golden: BounceBackHistogram? = null,
    // Overlay toggle state - hoisted up to IperfScreen rather than local
    // remember state here, since the "Overlay CDF"/"Overlay PDF" buttons
    // that drive these now live next to RunCompareTabs (make the slots the
    // whole UI for reference controls), not down here next to the chart
    // they affect.
    showGoldenCdf: Boolean = false,
    // Separate toggle from showGoldenCdf above - a golden PDF (histogram
    // bars) overlay is a lot more visually busy than a single extra line,
    // so it defaults off and stays independently switchable rather than
    // bundled into the same button.
    showGoldenPdf: Boolean = false,
    // Shades the area between this run's and golden's own CDF - see
    // buildEmdFillPath's own doc comment. Independent toggle from
    // showGoldenCdf above, but implies it visually: turning EMD fill on
    // with the golden CDF line itself toggled off would shade a region
    // with only one of its two boundary curves actually drawn, so the
    // draw pass below forces golden's CDF line on whenever this is true
    // (see drawGoldenCdf below), regardless of showGoldenCdf's own state.
    showEmd: Boolean = false,
    // Rescales both axes to just this run's own slow tail (from its own
    // upper-CI bin, default 95th percentile, through the max) instead of
    // the whole distribution - same motivation as showEmd (see that
    // param's own doc comment): the tail is exactly where the two CDFs
    // are most likely to diverge, but at the whole-distribution scale
    // that divergence is a thin sliver hugging the right edge, both
    // narrow (a handful of ms wide, e.g. -3.3-30ms below) and short (a
    // few percent of the full 0-1 CDF height) - not something you can
    // actually see clearly. Independent toggle from showEmd (either can
    // be on without the other), but most useful together - see
    // tailBoundaryMs/yFloorFraction below for how the rescale itself
    // works.
    zoomTail: Boolean = false,
    // Whether the run currently being viewed, and separately golden's own
    // run, had --working-load background traffic active - one of "on"/
    // "off"/"bidir" each (IperfScreen's own workingLoadTag, shared with
    // configSummary's "wl=..." part so both read as the same three
    // states), folded into the same EMD/99.7% comparison line below as
    // "WL=<this run>/<golden>". Working load materially affects RPS/
    // latency: a "WL=on" run and golden's own "WL=off" run aren't really
    // comparable against each other even if their EMD happens to look
    // small, so *both* sides need to be visible right alongside that
    // number - showing only this run's own state wouldn't say whether it
    // actually matches golden's.
    workingLoadTag: String = "off",
    goldenWorkingLoadTag: String = "off",
    // Same idea as workingLoadTag/goldenWorkingLoadTag above, for the
    // congestion-control algorithm (IperfScreen's own ccaTag - "default"
    // when the run had no CCA pinned/enabled, "udp-l4s" when the probe
    // itself ran over UDP L4S rather than TCP, else the real algorithm
    // name - see that helper's own doc comment) - CCA affects RPS/latency
    // just as much as working load does, so a mismatch between this run's
    // and the reference's own algorithm needs to be visible right
    // alongside the EMD/99.7% numbers too, not just working load's.
    ccaTag: String = "default",
    goldenCcaTag: String = "default",
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val axisTextSizePx = with(density) { 12.sp.toPx() }
    val axisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
        }
    }
    val axisPaintRight = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }
    // Center-aligned - the x-axis's own interior tick labels (unlike the
    // 0ms/max-ms bounds at the very edges, which anchor to their own side
    // so they never clip off-canvas) sit squarely on their own tick mark.
    val axisPaintCenter = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = AXIS_LABEL.toArgb()
            textSize = axisTextSizePx
            textAlign = Paint.Align.CENTER
        }
    }
    val cdfAxisPaint = remember(axisTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = CDF_LINE.toArgb()
            textSize = axisTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }
    val markerTextSizePx = with(density) { 10.sp.toPx() }
    val p999Paint = remember(markerTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = MARKER_P999.toArgb()
            textSize = markerTextSizePx
        }
    }
    // Right-aligned twin of p999Paint/minPaint - see drawEdgeAwareMarker's
    // own doc comment for when this is picked over the plain left-aligned
    // one above.
    val p999PaintRight = remember(markerTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = MARKER_P999.toArgb()
            textSize = markerTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }
    val minPaint = remember(markerTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = MARKER_MIN.toArgb()
            textSize = markerTextSizePx
        }
    }
    val minPaintRight = remember(markerTextSizePx) {
        Paint().apply {
            isAntiAlias = true
            color = MARKER_MIN.toArgb()
            textSize = markerTextSizePx
            textAlign = Paint.Align.RIGHT
        }
    }
    Column(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(text = "Request/Reply Time Distribution", style = MaterialTheme.typography.labelLarge)

        if (histogram == null || histogram.bins.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().height(180.dp).padding(top = 4.dp, start = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(text = "Waiting for data…", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val totalCount = histogram.totalCount.coerceAtLeast(1)
            // Extended to cover p999Bin too, not just the tallest bin -
            // the 99.7th-percentile marker below can land past every
            // populated bin's own binNumber on a distribution with a long
            // thin tail, and an un-extended axis would clip its line/label
            // off the chart's own right edge.
            val histogramMaxMs = maxOf(histogram.bins.maxOf { it.binNumber }, histogram.p999Bin) *
                histogram.binWidthUs / 1000.0
            // Only widen for golden when it's actually on screen (an
            // overlay/EMD toggle is on) - otherwise the axis would visibly
            // change the moment *any* golden reference exists, even while
            // you're not looking at it, which reads as the chart moving on
            // its own for no visible reason. Golden's own binWidthUs, not
            // histogram's - the two runs can have been captured with
            // different bin widths, so comparing raw bin numbers instead of
            // ms would be wrong.
            val goldenVisible = golden != null && (showGoldenCdf || showGoldenPdf || showEmd)
            val goldenMaxMs = if (goldenVisible) {
                maxOf(golden!!.bins.maxOf { it.binNumber }, golden.p999Bin) * golden.binWidthUs / 1000.0
            } else {
                0.0
            }
            // Whichever run's own tail is actually longer defines the axis
            // ceiling - previously always histogram's, which silently
            // clipped golden's own tail off the right edge whenever golden
            // ran longer. axisCeilingIsGolden feeds the small "(ref)" tag
            // on the max-axis label below, so it's visible *why* the axis
            // is wider than this run's own data would need on its own.
            val maxMs = maxOf(histogramMaxMs, goldenMaxMs)
            val axisCeilingIsGolden = goldenMaxMs > histogramMaxMs
            val maxCount = histogram.bins.maxOf { it.count }
            // Headroom (15%, rounded out to a clean step) so the tallest
            // bar doesn't touch the canvas's own top edge - same "pad
            // before rounding" reasoning as LiveSparkline/RttFloorChart's
            // own niceAxisStep callers, just a plain integer step here
            // rather than magnitude-scaled since bin counts don't need
            // LiveSparkline's wide dynamic range handling.
            val axisMaxCount = ceil(maxCount * 1.15).toInt().coerceAtLeast(1)
            val p999Ms = histogram.binMidpointMs(histogram.p999Bin)
            // The first (lowest-numbered) populated bin's own *lower* edge
            // (not its midpoint, unlike p999Ms above) - histogram.bins is
            // already in ascending bin-number order (see
            // BounceBackHistogram.bins' own doc comment), so .first() is
            // the fastest bounce observed this run. The lower edge, not the
            // midpoint, is the genuine lower bound this value claims ("no
            // bounce was faster than this"): the midpoint could itself be
            // faster than any real sample in a wide bin.
            val minMs = (histogram.bins.first().binNumber - 1) * histogram.binWidthUs / 1000.0
            // Mirrors goldenMaxMs/axisCeilingIsGolden above, same bug on the
            // opposite edge: golden's own fastest bin, considered only when
            // actually visible. Without this, comparing a fast reference
            // (e.g. a local run) against a much slower live run left the
            // axis floor anchored at the live run's own minimum, silently
            // squeezing golden's entire distribution into a sliver near the
            // left edge - reported directly by a user overlaying a ~1ms
            // local reference against a ~120ms remote run.
            val goldenMinMs = if (goldenVisible) {
                (golden!!.bins.first().binNumber - 1) * golden.binWidthUs / 1000.0
            } else {
                Double.MAX_VALUE  // never wins the minOf() below when golden isn't visible
            }
            // Whichever run's own fastest bounce is actually faster sets the
            // axis floor - deliberately NOT reassigning minMs itself, which
            // stays this run's own minimum for the "min X.Xms" marker and
            // the summary text below (both genuinely per-run stats, not
            // axis concerns).
            val axisFloorSourceMs = minOf(minMs, goldenMinMs)
            val axisFloorIsGolden = goldenMinMs < minMs
            // X-axis floor - rounded down to a clean 10ms step below the
            // actual observed minimum, not always literal 0ms. Bounceback's
            // floor is a real network RTT (rarely near zero), and nothing
            // can ever be faster than the observed minimum, so anchoring
            // the axis to 0ms wastes most of the plot's width on a latency
            // range that's physically impossible to populate - the entire
            // real distribution ends up squeezed into a sliver at the
            // right edge. coerceAtMost(axisFloorSourceMs) guards the
            // degenerate case where axisFloorSourceMs itself is already
            // below one step (e.g. a sub-10ms LAN run) - rounding down
            // should never push the floor past the real minimum.
            val minAxisMs = (floor(axisFloorSourceMs / 10.0) * 10.0).coerceAtMost(axisFloorSourceMs).coerceAtLeast(0.0)
            // This run's own upper-CI bin lower edge - BOUNCEBACK's default
            // ciUpperPercent is 95.00 (Reports.c's isBounceBack histogram
            // init), so this is "this run's own 95th percentile" in the
            // common case, but reads off the histogram's own actual
            // ciUpperPercent rather than hardcoding 95 in case a run
            // configured different CI bounds. Lower edge (not
            // binMidpointMs), same "the genuine bound this value claims"
            // reasoning as minMs above - ciUpperBin is where the cumulative
            // count first *crosses* the threshold, so its lower edge is the
            // last point still below it.
            val tailBoundaryMs = ((histogram.ciUpperBin - 1) * histogram.binWidthUs / 1000.0).coerceIn(minMs, maxMs)

            Canvas(modifier = Modifier.fillMaxWidth().height(200.dp).padding(top = 4.dp)) {
                drawRect(color = Color.Black)

                val bottomMarginPx = 16.dp.toPx()
                val plotHeight = size.height - bottomMarginPx
                val plotWidth = size.width
                // zoomTail's own x-axis floor - the tail boundary computed
                // above instead of the whole-distribution minAxisMs, so the
                // visible x-range shrinks to just [tailBoundaryMs, maxMs].
                val effectiveMinAxisMs = if (zoomTail) tailBoundaryMs else minAxisMs
                // At least one bin's own width, so a near-single-bin
                // distribution (minAxisMs and maxMs almost coincide) can't
                // divide-by-near-zero into a degenerate/huge scale.
                val axisSpanMs = (maxMs - effectiveMinAxisMs).coerceAtLeast(histogram.binWidthUs / 1000.0)

                fun xOfMs(ms: Double): Float = ((ms - effectiveMinAxisMs) / axisSpanMs).toFloat().coerceIn(0f, 1f) * plotWidth
                // zoomTail's own bar-count scale - recomputed from only the
                // bins actually inside the zoomed x-window (not the whole
                // distribution's own tallest bin, usually near the median
                // and nowhere close to the tail) so the tail's own bars
                // rescale to fill the chart height instead of reading as a
                // flat, barely-visible sliver against the whole
                // distribution's real peak. Falls back to the
                // whole-distribution axisMaxCount if the zoomed window
                // happens to contain no populated bins at all (degenerate/
                // guard only - the tail boundary itself is always inside
                // [minMs, maxMs], so this is rare).
                val zoomedMaxCount = histogram.bins
                    .filter { (it.binNumber - 1) * histogram.binWidthUs / 1000.0 >= effectiveMinAxisMs }
                    .maxOfOrNull { it.count }
                val effectiveAxisMaxCount = if (zoomTail && zoomedMaxCount != null) {
                    ceil(zoomedMaxCount * 1.15).toInt().coerceAtLeast(1)
                } else {
                    axisMaxCount
                }
                fun yOfCount(count: Int): Float =
                    plotHeight - (count.toFloat() / effectiveAxisMaxCount).coerceIn(0f, 1f) * plotHeight

                // One bar per populated bin, spanning that bin's own real
                // [lower, upper) latency edge - not a fixed-width bar per
                // list index, since the sparse bin list (see
                // BounceBackHistogram.bins' own doc comment) can skip
                // several bin numbers between populated ones.
                val barGapPx = 1.dp.toPx()
                histogram.bins.forEach { bin ->
                    val lowerMs = (bin.binNumber - 1) * histogram.binWidthUs / 1000.0
                    val upperMs = bin.binNumber * histogram.binWidthUs / 1000.0
                    val left = xOfMs(lowerMs)
                    val right = (xOfMs(upperMs) - barGapPx).coerceAtLeast(left + 1f)
                    val top = yOfCount(bin.count)
                    drawRect(
                        color = BAR_COLOR,
                        topLeft = Offset(left, top),
                        size = Size(right - left, plotHeight - top),
                    )
                }

                // Golden reference's own PDF, overlaid as hollow/outlined
                // bars (not filled, unlike the current run's own bars above)
                // so the two shapes stay visually distinguishable without
                // one obscuring the other. Each bin's count is rescaled by
                // (this run's totalCount / golden's own totalCount) before
                // going through yOfCount - a raw count-vs-count overlay
                // would be meaningless whenever the two runs collected a
                // different number of samples, so this puts both bars on an
                // equivalent "as if it had this run's own sample size" scale.
                if (showGoldenPdf && golden != null) {
                    val goldenTotal = golden.totalCount.coerceAtLeast(1)
                    golden.bins.forEach { bin ->
                        val lowerMs = (bin.binNumber - 1) * golden.binWidthUs / 1000.0
                        val upperMs = bin.binNumber * golden.binWidthUs / 1000.0
                        val left = xOfMs(lowerMs)
                        val right = (xOfMs(upperMs) - barGapPx).coerceAtLeast(left + 1f)
                        val equivalentCount = (bin.count.toDouble() / goldenTotal * totalCount).toInt()
                        val top = yOfCount(equivalentCount)
                        drawRect(
                            color = GOLDEN_PDF_OUTLINE,
                            topLeft = Offset(left, top),
                            size = Size(right - left, plotHeight - top),
                            style = Stroke(width = 1.dp.toPx()),
                        )
                    }
                }

                // CDF overlay - its own independent right-side 0-1 axis
                // mapped across the *full* plot height (see this
                // composable's own doc comment for why it doesn't share
                // the bars' left axis). Flat segment up to each bin's own
                // lower edge (the cumulative total doesn't move across the
                // possibly many-bin-wide gap since the previous populated
                // bin - see BounceBackHistogram.bins' own doc comment on
                // why the list is sparse), then a diagonal ramp across the
                // bin's own width to the new cumulative level (not a hard
                // vertical step - this bin's count is spread somewhere
                // across its own [lowerMs, upperMs) range, not
                // concentrated at one exact instant the way a raw
                // per-sample CDF's vertical jumps would be) - see
                // buildCdfPath's own doc comment, this file's top level.
                // zoomTail's own y-axis floor - both curves are already
                // near their common ceiling (1.0) by the time x reaches the
                // tail boundary (that's what "tail" means), so mapping the
                // full 0-1 range to the chart height the way the
                // whole-distribution view does would leave both lines
                // pinned flat against the top few pixels, exactly the
                // "too short to actually see" problem zoomTail exists to
                // fix. Floors at the *lower* of this run's and (when shown)
                // golden's own CDF value right at the boundary, minus a
                // small pad, so whichever curve starts lower still has a
                // sliver of headroom below it rather than beginning flush
                // against the chart's own bottom edge. Not just this run's
                // own ciUpperPercent/100 (e.g. 0.95) - golden's CDF at that
                // same x can genuinely sit lower if golden is the slower
                // distribution there, and clipping it out would hide
                // exactly the divergence this view exists to show.
                val yFloorFraction = if (zoomTail) {
                    val runFloor = cdfFractionAt(histogram, effectiveMinAxisMs)
                    val goldenFloor = if ((showGoldenCdf || showEmd) && golden != null) cdfFractionAt(golden, effectiveMinAxisMs) else runFloor
                    (minOf(runFloor, goldenFloor) - 0.02).coerceIn(0.0, 0.99)
                } else {
                    0.0
                }
                fun yOfCdfFraction(frac: Double): Float =
                    plotHeight - ((frac.coerceIn(0.0, 1.0) - yFloorFraction) / (1.0 - yFloorFraction)).toFloat().coerceIn(0f, 1f) * plotHeight

                // EMD fill - drawn before both CDF lines below so they
                // stroke on top of it rather than being partly obscured by
                // its own (semi-transparent) fill. effectiveMinAxisMs/maxMs
                // (not 0/maxMs) so the shaded region's own left edge lines
                // up with the same x-axis floor the bars/CDF lines already
                // use - in zoomTail this naturally restricts the fill to
                // just the tail region too, since buildEmdFillPath only
                // ever samples within [minMs, maxMs] it's given.
                if (showEmd && golden != null) {
                    val fillPath = buildEmdFillPath(histogram, golden, effectiveMinAxisMs, maxMs, ::xOfMs, ::yOfCdfFraction)
                    drawPath(fillPath, color = EMD_FILL)
                }

                val cdfPath = buildCdfPath(histogram, maxMs, ::xOfMs, ::yOfCdfFraction)
                drawPath(cdfPath, color = CDF_LINE, style = Stroke(width = 2.dp.toPx()))

                // Golden reference's own CDF, overlaid on the exact same
                // x/y mapping as the current run's line above - only when
                // both the toggle is on and a golden reference actually
                // exists (the button itself is hidden otherwise, see
                // below, so showGoldenOverlay can only be true here if
                // golden was non-null when it was toggled on).
                if ((showGoldenCdf || showEmd) && golden != null) {
                    val goldenPath = buildCdfPath(golden, maxMs, ::xOfMs, ::yOfCdfFraction)
                    drawPath(goldenPath, color = GOLDEN_CDF_LINE, style = Stroke(width = 2.dp.toPx()))
                }

                // Right-side 0/1 scale bounds for the line above - same
                // "ticks carry the numbers a moving line alone can't"
                // convention as the left axis's own bound below.
                val cdfTopLabelYPx = (yOfCdfFraction(1.0) + axisTextSizePx).coerceAtMost(plotHeight - 2.dp.toPx())
                drawContext.canvas.nativeCanvas.drawText(
                    "CDF 1.0",
                    plotWidth - 2.dp.toPx(),
                    cdfTopLabelYPx,
                    cdfAxisPaint,
                )
                drawContext.canvas.nativeCanvas.drawText(
                    // zoomTail's own floor reads its real fraction (e.g.
                    // "0.93") instead of a misleading "0.0" - the bottom of
                    // this view is yFloorFraction, not the distribution's
                    // actual zero point.
                    if (zoomTail) "%.2f".format(yFloorFraction) else "0.0",
                    plotWidth - 2.dp.toPx(),
                    (yOfCdfFraction(yFloorFraction) - 2.dp.toPx()).coerceAtLeast(axisTextSizePx),
                    cdfAxisPaint,
                )

                // Shared by both percentile markers below - draws the
                // vertical tick plus its label, flipping the label to the
                // *left* of the line (right-aligned paint, ending at
                // x - 4dp) instead of its usual right side whenever
                // drawing it rightward would run past the canvas's own
                // right edge and clip. leftPaint/rightPaint must be the
                // same color/size, differing only in textAlign - see
                // p999Paint/p999PaintRight and minPaint/minPaintRight
                // above.
                fun drawEdgeAwareMarker(x: Float, label: String, color: Color, leftPaint: Paint, rightPaint: Paint, labelYPx: Float) {
                    drawLine(color = color, start = Offset(x, 0f), end = Offset(x, plotHeight), strokeWidth = 1.dp.toPx())
                    val wouldClipRight = (x + 4.dp.toPx() + leftPaint.measureText(label)) > plotWidth
                    if (wouldClipRight) {
                        drawContext.canvas.nativeCanvas.drawText(label, x - 4.dp.toPx(), labelYPx, rightPaint)
                    } else {
                        drawContext.canvas.nativeCanvas.drawText(label, x + 4.dp.toPx(), labelYPx, leftPaint)
                    }
                }

                // The 99.7th-percentile bin's own vertical tick, same
                // "ticks carry the number a moving line/bar shape alone
                // can't" convention LiveSparkline/RttFloorChart already use
                // for their own axis ticks. Its own row, one below "CDF
                // 1.0" (not level with it) - the 99.7th-percentile bin is
                // usually near the chart's own right edge, the same corner
                // "CDF 1.0" occupies, so sharing its row would overlap the
                // two labels.
                val p999LabelYPx = cdfTopLabelYPx + 12.dp.toPx()
                drawEdgeAwareMarker(xOfMs(p999Ms), "99.7% ${"%.1f".format(p999Ms)}ms", MARKER_P999, p999Paint, p999PaintRight, p999LabelYPx)

                // Absolute minimum - the first (lowest-numbered) populated
                // bin's own *lower* edge (see minMs's own doc comment
                // above). One row below the 99.7% label above - keeps all
                // three stacked top-to-bottom in the shared right-hand
                // corner rather than any two landing on the same row.
                // Skipped in zoomTail: minMs sits behind the zoomed
                // window's own left edge (effectiveMinAxisMs), so xOfMs
                // would clamp it to x=0 - drawing a marker there, labeled
                // with a value that isn't actually at that position, would
                // just be misleading rather than informative.
                if (!zoomTail) {
                    drawEdgeAwareMarker(xOfMs(minMs), "min ${"%.1f".format(minMs)}ms", MARKER_MIN, minPaint, minPaintRight, cdfTopLabelYPx + 24.dp.toPx())
                }

                // Left-side bin-count scale bound - without this the bar
                // heights carry no indication of what count range they span.
                drawLine(
                    color = AXIS_LABEL,
                    start = Offset(0f, yOfCount(effectiveAxisMaxCount)),
                    end = Offset(6.dp.toPx(), yOfCount(effectiveAxisMaxCount)),
                    strokeWidth = 1.dp.toPx(),
                )
                drawContext.canvas.nativeCanvas.drawText(
                    "%d".format(effectiveAxisMaxCount),
                    8.dp.toPx(),
                    (yOfCount(effectiveAxisMaxCount) + axisTextSizePx).coerceAtMost(plotHeight - 2.dp.toPx()),
                    axisPaint,
                )

                // X-axis scale - left edge is minAxisMs (see its own doc
                // comment for why that's not always literal 0ms), right
                // edge is maxMs (the longer of this run's and, when
                // visible, golden's own tail - see axisCeilingIsGolden
                // above), plus intermediate ticks (small vertical marks +
                // labels, same "ticks carry the numbers a moving shape
                // alone can't" convention as every other axis on this
                // chart) so reading a bar or the CDF/marker lines' own
                // x-position doesn't require eyeballing a bare two-label
                // span.
                val tickMarkPx = 4.dp.toPx()
                val labelYPx = size.height - 2.dp.toPx()
                // "(ref)" suffix mirrors the max-edge label below - only
                // meaningful outside zoomTail, where the floor is golden's
                // own tail boundary instead (see effectiveMinAxisMs above).
                drawContext.canvas.nativeCanvas.drawText(
                    if (axisFloorIsGolden && !zoomTail) "%.1fms (ref)".format(effectiveMinAxisMs) else "%.1fms".format(effectiveMinAxisMs),
                    2.dp.toPx(), labelYPx, axisPaint,
                )
                // Nice round step (niceAxisStep, LiveSparkline.kt - same
                // helper MiniSparkline/RttFloorChart/CwndInflightChart all
                // use) rather than splitting the span into a fixed number
                // of equal fractions - the old evenly-spaced ticks printed
                // whatever ugly decimal fell at each 1/4 mark (e.g.
                // "14.1"/"18.1"/"22.2") since neither axis endpoint is
                // itself a round number in general. Ticks land at multiples
                // of that step, skipping any that would coincide with (or
                // sit too close to) the min/max edge labels already drawn
                // separately, so the tick count varies with how many round
                // multiples actually fall inside the range rather than
                // always being exactly 3.
                val tickStep = niceAxisStep(axisSpanMs)
                val minTickGapMs = axisSpanMs * 0.06
                var tickMs = ceil(effectiveMinAxisMs / tickStep) * tickStep
                while (tickMs < maxMs - minTickGapMs) {
                    if (tickMs > effectiveMinAxisMs + minTickGapMs) {
                        val tickX = xOfMs(tickMs)
                        drawLine(
                            color = AXIS_LABEL,
                            start = Offset(tickX, plotHeight - tickMarkPx),
                            end = Offset(tickX, plotHeight),
                            strokeWidth = 1.dp.toPx(),
                        )
                        drawContext.canvas.nativeCanvas.drawText("%.1f".format(tickMs), tickX, labelYPx, axisPaintCenter)
                    }
                    tickMs += tickStep
                }
                // "(ref)" suffix when golden's own tail is what's actually
                // setting the ceiling - a plain number here would otherwise
                // look identical whether it came from this run or from
                // golden, and the axis widening for a reference you can't
                // see numbers from otherwise reads as unexplained.
                drawContext.canvas.nativeCanvas.drawText(
                    if (axisCeilingIsGolden) "%.1fms (ref)".format(maxMs) else "%.1fms".format(maxMs),
                    plotWidth - 2.dp.toPx(),
                    labelYPx,
                    axisPaintRight,
                )
            }

            Text(
                text = "Samples: %d · Min: %.1fms · 99.7%%: %.1fms".format(histogram.totalCount, minMs, p999Ms),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp),
            )
            Text(
                text = "Outliers: %d · out of bounds: %d/%d".format(
                    histogram.outlierCount, histogram.oobLower, histogram.oobUpper,
                ),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp),
            )
            // Earth Mover's Distance against the *current* golden reference
            // - recomputed fresh here (HistogramDistance.
            // emdAgainstReference) rather than reading histogram's own
            // frozen emdVsBaseline field, so viewing an older A/B/C/D
            // preset still compares it against whatever's golden right
            // now, not whatever was golden when that preset was captured
            // (see [golden]'s own doc comment above for why). Null (not
            // shown at all, rather than a "no golden saved yet"
            // placeholder line) until a golden reference actually exists,
            // same "only show what's real" convention as LiveSparkline's
            // own rttMinUs?.let.
            //
            // Signed with the mean-latency shift direction (see
            // HistogramDistance.meanMs's own doc comment for why that's a
            // principled choice, not an arbitrary one) - EMD itself is a
            // magnitude with no natural sign, so "+" here means "this run's
            // mean latency is higher (slower) than golden's", "-" means
            // lower (faster). A technician glancing at just the sign gets
            // the direction; the magnitude is still the real EMD, not a
            // signed approximation of it.
            golden?.let { g -> histogram.emdAgainstReference(g)?.let { emd -> g to emd } }?.let { (g, emd) ->
                val meanDelta = (histogram.meanMs() ?: 0.0) - (g.meanMs() ?: 0.0)
                val signedEmd = if (meanDelta >= 0) emd else -emd
                // 99.7% delta shares this line rather than getting its own -
                // same shift-direction framing as EMD, but for the tail
                // specifically (the 99.7th-percentile marker already drawn
                // on the chart itself) rather than the whole distribution's
                // shape. A run can have a similar EMD to golden while its
                // worst-case tail moved a lot, or vice versa, so this is a
                // genuinely different signal, not a restatement of EMD -
                // just compact enough to sit alongside it. Unlike EMD, this
                // one *is* a plain, literally-signed difference (two single
                // numbers, not a distance metric) - %+.3f alone is enough,
                // no separate sign derivation needed.
                val refP999Ms = g.binMidpointMs(g.p999Bin)
                val p999Delta = p999Ms - refP999Ms
                Text(
                    // Leads with an explicit "Run/Ref:" label rather than
                    // leaving the run-then-reference ordering implicit -
                    // every paired/signed value on this line (the EMD sign,
                    // the 99.7% pair/delta, and the cca=/wl=x/y tags)
                    // follows that same order, so naming it once up front
                    // is clearer than repeating "vs golden" or re-deriving
                    // the order from context each time. 99.7% now shows
                    // *both* sides' own absolute value (run/ref, e.g.
                    // "87.0/82.1ms") ahead of the delta - the delta alone
                    // means reading "82.1ms" would need mental subtraction
                    // from the run's own value shown elsewhere on the
                    // chart, and this is the one line meant to make that
                    // comparison at a glance. Two lines rather than one -
                    // EMD/99.7% is the actual measurement comparison, cca=/
                    // wl= below it are the "were these two runs even
                    // comparable" context - splitting them keeps neither
                    // line so dense it stops being skimmable, especially
                    // now that 99.7% carries three numbers instead of one.
                    // wl=<run>/<ref> - a small EMD/99.7% delta doesn't mean
                    // much if this run had background working-load traffic
                    // active and the reference's own run didn't (or vice
                    // versa), so both sides of that mismatch need to be
                    // visible right here, not left to a config summary
                    // elsewhere on screen. cca=<run>/<ref> alongside it for
                    // the same reason - a different congestion-control
                    // algorithm between the two runs is just as confounding
                    // for RPS/latency comparisons as a working-load
                    // mismatch is.
                    text = "Run/Ref: EMD %+.3f ms · 99.7%%: %.1f/%.1fms (%+.3f ms)\ncca=%s/%s · wl=%s/%s".format(
                        signedEmd, p999Ms, refP999Ms, p999Delta, ccaTag, goldenCcaTag, workingLoadTag, goldenWorkingLoadTag,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp),
                )
                // Tail-only EMD - restricts the same integral to
                // [tailBoundaryMs, max) instead of the whole distribution
                // (see HistogramDistance.emdAgainstReference's own fromMs
                // doc comment for the exact decomposition identity: this
                // number plus the same call over [0, tailBoundaryMs] sums
                // back to the signedEmd above). Same sign convention as
                // signedEmd (follows the whole-run meanDelta direction, not
                // a separately-derived tail-only sign) so both lines read
                // the same way - "+" always means "this run trends slower
                // than golden" whether you're looking at the whole
                // distribution or just the tail. Answers "how much of the
                // total distance above is actually coming from the slow
                // tail" - a run and golden can have a small whole-
                // distribution EMD while still diverging sharply just in
                // the tail, or vice versa.
                histogram.emdAgainstReference(g, fromMs = tailBoundaryMs)?.let { tailEmd ->
                    val signedTailEmd = if (meanDelta >= 0) tailEmd else -tailEmd
                    Text(
                        // One format call, %% properly escaped - splicing
                        // an already-formatted "95.0%" string into this
                        // template *before* it goes through .format() left
                        // a stray '%' for the real %+.3f call below to
                        // choke on (java.util.UnknownFormatConversionException:
                        // Conversion = ')' - crashed on-device at the end
                        // of every run once a golden reference existed).
                        text = "Tail (>%.1f%%): EMD %+.3f ms".format(histogram.ciUpperPercent, signedTailEmd),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }
        }
    }
}
