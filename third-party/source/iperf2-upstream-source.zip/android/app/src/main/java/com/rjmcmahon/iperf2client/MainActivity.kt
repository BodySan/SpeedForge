package com.rjmcmahon.iperf2client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.rjmcmahon.iperf2client.ui.IperfScreen
import com.rjmcmahon.iperf2client.ui.theme.IperfTheme
import com.rjmcmahon.iperf2client.ui.theme.ThemeMode
import com.rjmcmahon.iperf2client.ui.theme.ThemePreferenceStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Loaded once at process start, not re-read on every
            // recomposition - onThemeModeChange below both persists a new
            // choice AND updates this in-memory copy, so the sun/moon
            // toggle takes effect immediately without needing a restart to
            // pick up what it just wrote to disk.
            var themeMode by remember { mutableStateOf(ThemePreferenceStore.load(this)) }
            IperfTheme(themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    IperfScreen(
                        themeMode = themeMode,
                        onThemeModeChange = {
                            themeMode = it
                            ThemePreferenceStore.save(this, it)
                        },
                    )
                }
            }
        }
    }
}
