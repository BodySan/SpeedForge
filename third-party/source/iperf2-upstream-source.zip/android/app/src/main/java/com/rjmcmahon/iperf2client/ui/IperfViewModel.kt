package com.rjmcmahon.iperf2client.ui

import android.app.Application
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rjmcmahon.iperf2client.BuildConfig
import com.rjmcmahon.iperf2client.IperfForegroundService
import com.rjmcmahon.iperf2client.model.BounceBackHistogram
import com.rjmcmahon.iperf2client.model.IntervalSample
import com.rjmcmahon.iperf2client.model.MeterStats
import com.rjmcmahon.iperf2client.model.NetworkPreference
import com.rjmcmahon.iperf2client.model.RunSnapshot
import com.rjmcmahon.iperf2client.model.TestConfig
import com.rjmcmahon.iperf2client.model.TestMode
import com.rjmcmahon.iperf2client.runner.CcaProbe
import com.rjmcmahon.iperf2client.runner.CsvLineParser
import com.rjmcmahon.iperf2client.runner.IperfCommandBuilder
import com.rjmcmahon.iperf2client.runner.IperfProcessRunner
import com.rjmcmahon.iperf2client.runner.GoldenHistogramStore
import com.rjmcmahon.iperf2client.runner.NetworkTransport
import com.rjmcmahon.iperf2client.runner.RawRunLogStore
import com.rjmcmahon.iperf2client.runner.currentNetworkTransport
import com.rjmcmahon.iperf2client.runner.describeNetworkForLog
import com.rjmcmahon.iperf2client.runner.expectedLocalAddresses
import com.rjmcmahon.iperf2client.runner.parseNumericAddressOrNull
import com.rjmcmahon.iperf2client.runner.findNetworkInterfaceName
import com.rjmcmahon.iperf2client.runner.RunSnapshotStore
import com.rjmcmahon.iperf2client.runner.TestConfigStore
import com.rjmcmahon.iperf2client.stats.CwndInflightPoint
import com.rjmcmahon.iperf2client.stats.RttHistoryPoint
import com.rjmcmahon.iperf2client.stats.Timestamped
import com.rjmcmahon.iperf2client.stats.TimeSeriesPoint
import com.rjmcmahon.iperf2client.stats.WindowInflightPoint
import com.rjmcmahon.iperf2client.stats.WindowedSnapshot
import com.rjmcmahon.iperf2client.stats.WindowedWelfordStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.ArrayDeque

/**
 * Folds one metric's values into a running min/avg/max, in whatever unit the
 * caller feeds it (Mbps, ms, KB, pps - see IperfViewModel's three instances).
 * Not thread-safe by itself - only ever touched from the ViewModel's own
 * collect coroutine.
 */
private class StatAccumulator {
    private var min = Double.POSITIVE_INFINITY
    private var max = Double.NEGATIVE_INFINITY
    private var sum = 0.0
    private var count = 0

    fun add(value: Double) {
        if (value < min) min = value
        if (value > max) max = value
        sum += value
        count++
    }

    fun reset() {
        min = Double.POSITIVE_INFINITY
        max = Double.NEGATIVE_INFINITY
        sum = 0.0
        count = 0
    }

    fun snapshot(): MeterStats? = if (count == 0) null else MeterStats(min = min, avg = sum / count, max = max)

    // Running minimum so far, without taking a full snapshot - used for
    // TCP's own queueing-vs-network delay decomposition (rttOrJitterAcc's
    // running min doubles as a "best RTT observed so far" baseline, the
    // same role PragueCC's own m_rtt_min plays for UDP-L4S's Load Delay).
    // Null before the first sample, same "nothing to report yet" contract
    // as snapshot().
    fun currentMin(): Double? = if (count == 0) null else min
}

class IperfViewModel(application: Application) : AndroidViewModel(application) {
    private val runner = IperfProcessRunner()

    // Loaded from SharedPreferences (see TestConfigStore) rather than a bare
    // TestConfig() default, so host/port/toggle state survives the
    // Activity/ViewModel being recreated instead of resetting every time.
    private val _config = MutableStateFlow(TestConfigStore.load(application))
    val config: StateFlow<TestConfig> = _config.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    // Single choke point for every _isRunning transition (Start, normal
    // completion, the connect watchdog's own timeout, the Stop button, and
    // onCleared()'s teardown) - starts/stops IperfForegroundService in
    // lockstep, so the app (and the native iperf2 child process
    // IperfProcessRunner spawns) stays exempt from Android's background
    // execution limits for exactly the run's own duration, never longer.
    // Without this, backgrounding the app mid-test (screen lock, switching
    // apps) eventually freezes the whole process: the elapsed-time display
    // (a separate wall-clock coroutine) keeps ticking past the configured
    // duration, but no further interval samples arrive since the
    // subprocess itself is frozen, and the run never reaches its own
    // natural completion - no final histogram, nothing. Both
    // startForegroundService()/stopService() are plain, non-suspend Context
    // calls, so this is safe to call from onCleared() too (no coroutine
    // scope survives to call a suspend fn there - see that override's own
    // doc comment).
    private fun setRunning(running: Boolean) {
        _isRunning.value = running
        // A prior run's pause state must never leak into the next one -
        // reset alongside every stop transition (natural completion,
        // watchdog timeout, Stop button), same choke point as isRunning.
        if (!running) _isWorkingLoadPaused.value = false
        val context = getApplication<Application>()
        val intent = Intent(context, IperfForegroundService::class.java)
        if (running) {
            ContextCompat.startForegroundService(context, intent)
        } else {
            context.stopService(intent)
        }
    }

    // Local, optimistic UI state - the app has no channel to read the
    // native process's actual sWorkingLoadPaused back (SIGUSR1/SIGUSR2 are
    // fire-and-forget), so this just tracks what the user last asked for.
    // Only meaningful when the current run actually has a pausable
    // working-load stream - see IperfScreen's own canPauseWorkingLoad,
    // which gates the button that calls [onToggleWorkingLoadPause].
    private val _isWorkingLoadPaused = MutableStateFlow(false)
    val isWorkingLoadPaused: StateFlow<Boolean> = _isWorkingLoadPaused.asStateFlow()

    /**
     * Sends SIGUSR1/SIGUSR2 to the running iperf process to pause/resume
     * its working-load stream (see Client.cpp's sWorkingLoadPaused,
     * main.cpp's signal handlers). For UP (and bidir's own upload half)
     * this app's own process owns the writer directly. For DOWN (and
     * bidir's own download half) the real writer is server-spawned and
     * unreachable directly, but this app's process still owns the
     * *reader* for that direction (the client locally reverses roles for
     * -R-style directions) - pausing the reader pauses the stream too:
     * TCP via backpressure (Server::RunTCP), UDP-L4S via a wire-relayed
     * L4S_PAUSE flag the reader sets on its own ACKs (Server::RunUDPL4S /
     * Client::RunUDPL4S). So every direction is pausable this way.
     */
    fun onToggleWorkingLoadPause() {
        if (!_isRunning.value) return
        val pausing = !_isWorkingLoadPaused.value
        if (pausing) runner.pauseWorkingLoad() else runner.resumeWorkingLoad()
        _isWorkingLoadPaused.value = pausing
    }

    // Wall-clock progress toward the configured Duration, common to all
    // three modes (TCP/BOUNCEBACK/UDP_L4S all share the same -t <duration>
    // field) - driven by elapsed real time since the Start tap rather than
    // parsed from each mode's own CSV "time" field, so it updates smoothly
    // every tick instead of once per report interval and needs no per-mode
    // parsing. SystemClock.elapsedRealtime() (not wall-clock time) so a
    // device clock change mid-run can't skew it. Deliberately left at its
    // last value after the run ends/stops, same convention as the meters.
    private val _elapsedSecs = MutableStateFlow(0)
    val elapsedSecs: StateFlow<Int> = _elapsedSecs.asStateFlow()
    private val _testProgress = MutableStateFlow(0f)
    val testProgress: StateFlow<Float> = _testProgress.asStateFlow()

    // Wall-clock time-of-day the most recent run started - separate from
    // elapsedSecs/testProgress above (SystemClock.elapsedRealtime()-based,
    // deliberately immune to a device clock change mid-run) since this is
    // purely for display: correlating this run against external logs/
    // captures (e.g. a Wi-Fi concentrator, Sonde telemetry) needs the
    // actual wall-clock timestamp, not an elapsed duration. Same
    // "persists after stop" convention as elapsedSecs.
    private val _runStartedAtMillis = MutableStateFlow<Long?>(null)
    val runStartedAtMillis: StateFlow<Long?> = _runStartedAtMillis.asStateFlow()

    private val _latestSample = MutableStateFlow<IntervalSample?>(null)
    val latestSample: StateFlow<IntervalSample?> = _latestSample.asStateFlow()

    // Running min/avg/max per meter, folded in as each sample arrives (see
    // onStart()'s collect block) - reset at the start of every run. The very
    // first sample is deliberately excluded: its interval still has data
    // sitting in the socket's own send buffer that hasn't actually crossed
    // the network yet, so its throughput/rtt/in-flight numbers don't reflect
    // the path the rest of the test measures.
    private var sampleCount = 0
    private val throughputAcc = StatAccumulator() // Mbps
    private val rttOrJitterAcc = StatAccumulator() // ms (TCP rtt or UDP-L4S jitter)
    private val inFlightAcc = StatAccumulator() // TCP: bytesInFlight (KB); UDP-L4S: packetsPerSec
    // TCP only - packetsInFlight is a separate CSV field from bytesInFlight
    // (see IntervalSample), so it needs its own running max rather than
    // reusing inFlightAcc, to show "bytes (pkts) in flight" together once
    // the run stops instead of dropping the packet count from that final
    // reading. Unused (stays empty) in UDP-L4S mode, where inFlightAcc
    // itself already holds packetsPerSec, a different metric entirely.
    private val packetsInFlightAcc = StatAccumulator()
    // TCP only (forward and --reverse, see IntervalSample.cwndBytes/
    // tcpRetry's own doc comment on the reverse relay) - congestion window
    // (KB, same unit convention as inFlightAcc) and per-interval retry
    // count, each getting their own running stats for the same reason
    // packetsInFlightAcc does: distinct CSV fields, not derivable from
    // inFlightAcc's own bytesInFlight tracking. cwndAcc's max also backs
    // BytesInFlightMeter's red "available window" overlay behind the green
    // bytes-in-flight bar.
    private val cwndAcc = StatAccumulator() // KB
    // count per interval - only intervals with a nonzero retry count are
    // added (see the accumulation call site's own doc comment), so min/avg
    // reflect actual retry bursts rather than being pulled toward 0 by the
    // (usually many) healthy zero-retry intervals in between.
    private val retryAcc = StatAccumulator()
    // TCP only (forward and --reverse) - bytes written to the socket but
    // not yet sent (iperf_tcpstats.notsent_bytes, KB) - backs
    // BytesInFlightMeter's yellow "written, not yet on the wire" tier
    // between the green in-flight fill and the red CWND headroom overlay.
    private val notSentAcc = StatAccumulator() // KB
    // TCP only (forward and --reverse) - current RTT minus the kernel's own
    // continuously-updated minimum RTT for this connection
    // (iperf_tcpstats.rtt_min, Linux tcpi_min_rtt) - the exact same "excess
    // above best observed" formula as UDP-L4S's Load Delay (srtt -
    // rtt_min), just using TCP's own kernel-tracked baseline instead of
    // PragueCC's. Deliberately NOT decomposed any further (e.g. into
    // "queueing vs network") - notSentBytes was considered for that and
    // rejected: it reflects data not yet transmitted at all, unrelated to
    // the delay already experienced by packets currently in flight, so
    // subtracting a notSentBytes-derived estimate from this number would
    // not actually isolate anything real. See this session's own review
    // of that idea before it shipped.
    private val tcpExcessRttAcc = StatAccumulator() // ms
    // TCP only (forward and --reverse) - live, currently-autotuned send
    // socket buffer size (iperf_tcpstats.sndbuf_bytes, getsockopt
    // SO_SNDBUF, KB - see IntervalSample.sndBufKB's own doc comment).
    // Drives BytesInFlightMeter's CWND/inFlight/NotSent bar's own
    // log-scaled headroom zone (BarGraphGauge's headroomFraction) - the
    // bar's main scale stays driven by the three live series' own running
    // max, unchanged; the ceiling gets its own separately-scaled zone
    // since it's routinely orders of magnitude past the live data.
    private val sndBufAcc = StatAccumulator() // KB
    // TCP only (forward and --reverse) - mean per-write blocking time
    // (write_mmm.current.mean, --tcp-write-times - see
    // IntervalSample.writeTimeUs's own doc comment). Real measured
    // send-side backpressure/buffer-sojourn delay (the app's data socket
    // is always blocking - src/Client.cpp), an earlier and separate stage
    // from rttMicros, not a component of it. Backs its own compact bar
    // under BytesInFlightMeter's CWND/inFlight/NotSent row.
    private val writeTimeAcc = StatAccumulator() // us
    // TCP only (forward and --reverse) - this-interval deltas of the
    // kernel's own tcpi_sndbuf_limited/tcpi_rwnd_limited/tcpi_busy_time
    // (kernel 4.9+, see IntervalSample.sndBufLimitedUs et al's own doc
    // comment). Direct kernel measurements complementing writeTimeAcc's
    // per-write blocking measurement with a cumulative, kernel-tracked
    // figure of time spent capped by the local send buffer, the peer's
    // advertised receive window, and total time spent with data queued to
    // send at all.
    private val sndBufLimitedAcc = StatAccumulator() // us
    private val rwndLimitedAcc = StatAccumulator() // us
    private val busyTimeAcc = StatAccumulator() // us
    // busyTimeUs minus sndBufLimitedUs/rwndLimitedUs - active send time not
    // attributed to either buffer limit (see BytesInFlightMeter's own
    // "Flowing" doc comment for the precise, deliberately unclaimed
    // definition - this is Linux's own TCP_CHRONO_BUSY state, not a
    // tcp_is_cwnd_limited() measurement, so it can include cwnd
    // exhaustion, pacing, TSQ/qdisc/NIC queueing, Nagle, or loss recovery).
    private val flowingAcc = StatAccumulator() // us
    // UDP-L4S only - CE marks/sec (cntCE / interval duration, see
    // CsvLineParser). Mirrors packetsInFlightAcc's role above: a second
    // metric that isn't derivable from inFlightAcc's own pps tracking, so it
    // needs its own running stats to pair "avg pps" with "avg CE marks/sec"
    // once the run stops instead of falling back to a single live reading.
    private val ceMarksAcc = StatAccumulator()
    // UDP-L4S only - same marks/sec quantity as ceMarksAcc above, but only
    // fed on intervals where marking actually happened (sample.ceCount > 0).
    // ceMarksAcc's own min is legitimately 0 whenever some interval saw no
    // marking at all - a real "nothing to measure that second" reading, not
    // a bug - but averaged together with genuine marking intervals, it
    // answers a different question ("how much marking exposure across the
    // whole test") than this one does ("how intense is marking when it's
    // actually happening"). Both are real, distinct statistics - shown
    // side by side rather than picking one.
    private val ceMarksWhenMarkingAcc = StatAccumulator()
    // UDP-L4S only (upload/write direction; always -1/unavailable in
    // --reverse, see IntervalSample's doc comment) - PragueCC::
    // GetQueueInfo()'s sender-side queueing-delay estimate (ms) and its
    // Little's Law queue-occupancy estimate (KB), run through the exact
    // same StatAccumulator TCP's rttOrJitterAcc/inFlightAcc use, so the
    // resulting min/avg/max meters are directly comparable to TCP's RTT and
    // bytes-in-flight meters - same accumulation code path, same
    // statistical meaning, apples to apples.
    private val queueDelayAcc = StatAccumulator() // ms
    private val queueBytesAcc = StatAccumulator() // KB
    // Packets version of the same Little's Law estimate (see TestConfig's
    // queueUnitsPackets doc comment for why packets is the default) -
    // packetsPerSec * queueing delay, both already parsed off the CSV, so
    // this is a pure Kotlin derivation with no native/CSV changes needed.
    // Kept as its own accumulator (not derived from queueBytesAcc by
    // dividing by an assumed packet size) so it's exactly as accurate as
    // the bytes version, not a lossy approximation of it.
    private val queuePacketsAcc = StatAccumulator() // pkts
    // UDP-L4S only (upload/write direction, same availability rule as
    // queueDelayAcc above) - PragueCC::GetSmoothedRtt()'s raw RTT, the
    // value queueDelayAcc's own srtt-rtt_min estimate is derived from.
    // Shown as its own dial (see IperfScreen's second UDP-L4S dial row)
    // so a reader can sanity-check the derived load-delay number against
    // the real measured RTT it came from - see Koen De Schepper's review,
    // doc/email_koen_littles_law_review.txt.
    private val l4sRttAcc = StatAccumulator() // ms
    // UDP-L4S only (upload/write direction, same availability rule as
    // queueDelayAcc/l4sRttAcc above) - PragueCC's own congestion window/
    // actual in-flight packet count (direct, RTT-independent measurements,
    // unlike queueDelayAcc's RTT-derived estimate) and EWMA-smoothed
    // marking probability (distinct from ceMarksAcc's own raw per-interval
    // rate) - see Koen De Schepper's review, doc/email_koen_littles_law_
    // review.txt, for why comparing these against queueDelayAcc/l4sRttAcc
    // matters.
    private val l4sPacketWindowAcc = StatAccumulator() // pkts
    private val l4sInflightAcc = StatAccumulator() // pkts
    private val l4sMarkingProbAcc = StatAccumulator() // raw 0..1<<20 scale
    // UDP-L4S only (both directions - the reader's own locally-tracked
    // loss, no relay needed, unlike the sender-side-only PragueCC fields
    // above) - standard UDP datagram loss percentage, already reported by
    // the C side but never parsed for this mode until now. The "loss
    // probability" counterpart to l4sMarkingProbAcc's "marking probability".
    private val errPercentAcc = StatAccumulator() // %
    // BOUNCEBACK only - requests/sec, same role as ceMarksAcc above but for
    // bounceback's own rps field.
    private val bbRequestsAcc = StatAccumulator()
    // BOUNCEBACK + workingLoadEnabled only - the working load's own
    // interleaved throughput readings (Mbps), tracked as two separate
    // directions (see CsvLineParser.parseWorkingLoadUploadThroughput's doc
    // comment) rather than one combined number, so "bidir" gets its own
    // upload and download bar graphs instead of one readout alternating
    // between two different things every other interval.
    private val workingLoadUpAcc = StatAccumulator()
    private val workingLoadDownAcc = StatAccumulator()

    // BOUNCEBACK only - live windowed view of requestsPerSec (RPS is this
    // test's own hero metric - see IperfScreen's "Remove the dial
    // completely" comment on why bounce latency doesn't get a dial here).
    // Windowing many iid-ish per-interval RPS samples together is what
    // makes the windowed mean asymptotically Gaussian per the CLT (see
    // WindowedWelfordStats' own doc comment), independent of whatever
    // distribution the raw per-interval RPS values themselves have.
    // windowedStats is fed from the ingest side (the collect loop below);
    // the sparkline history and the 10Hz render tick that appends to it
    // are what decouples the UI's redraw rate from however fast CSV rows
    // actually arrive. LiveSparkline reads history.last() directly for its
    // own "current reading" text/ticks - no separate whole-session
    // accumulator, which would go stale (barely move) over a long run
    // instead of staying responsive to each incoming sample.
    private val windowedStats = WindowedWelfordStats(LIVE_WINDOW_SECS)
    // Timestamped, not a plain WindowedSnapshot list - each point's own x
    // position on LiveSparkline needs its *real* elapsed time, same "real
    // elapsed time, not index" convention every other history in this file
    // already follows (rttHistory, throughputHistory, etc.). A plain
    // index * RENDER_TICK_SECS would be wrong here specifically: this
    // render-tick loop starts ticking the moment onStart() fires, but
    // nothing actually gets appended until windowedStats.snapshot() first
    // returns non-null (see the append site below) - which needs the
    // connection established *and* the first couple of real samples fed
    // in. That gap means history[0] doesn't represent t=0, so index-based
    // positioning silently shifts the whole ribbon earlier than reality -
    // exactly the misalignment RpsVolatilityLine's raw overlay (positioned
    // by each of its own points' genuine elapsedSecs) exposed once the two
    // shared one axis.
    private val sparklineHistory = ArrayDeque<Timestamped<WindowedSnapshot>>()
    private val _sparklineHistoryFlow = MutableStateFlow<List<Timestamped<WindowedSnapshot>>>(emptyList())
    val sparklineHistoryFlow: StateFlow<List<Timestamped<WindowedSnapshot>>> = _sparklineHistoryFlow.asStateFlow()

    // BOUNCEBACK only - raw per-interval requestsPerSec, deliberately NOT
    // windowed like sparklineHistory above. windowedStats/LiveSparkline's
    // whole point is smoothing a bunch of iid-ish per-interval readings
    // into an asymptotically Gaussian mean (see windowedStats' own doc
    // comment) - exactly the thing that hides how jagged the raw RPS
    // gauge itself looks interval to interval. This is the other half:
    // the same "raw, not windowed" treatment throughputHistory/rttHistory
    // above already get, so RpsVolatilityLine can show that volatility
    // directly instead of it being averaged away before it ever reaches a
    // chart.
    private val bbRequestsHistory = ArrayDeque<TimeSeriesPoint>()
    private val _bbRequestsHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val bbRequestsHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _bbRequestsHistoryFlow.asStateFlow()

    // TCP and UDP-L4S both - one {current, floor} RTT point per interval
    // (see RttHistoryPoint's own doc comment), for RttFloorChart and the
    // MiniSparkline paired beside the RTT/Load Delay dials. Raw
    // per-interval points, not windowed like
    // sparklineHistory above - RTT is already kernel/PragueCC-smoothed
    // per interval, so there's no CLT-style justification needed for a
    // second layer of windowing on top of that. TCP sources tcpi_rtt/
    // tcpi_min_rtt (sample.rttMicros/rttMinMicros); UDP-L4S sources
    // PragueCC's own srtt directly (sample.l4sRttUs) and recovers rtt_min
    // algebraically from queueDelayUs (= srtt - rtt_min, see that field's
    // own doc comment) rather than needing a new relayed field - both are
    // already on the wire. Same cap/eviction convention as
    // HISTORY_SAFETY_CAP below.
    private val rttHistory = ArrayDeque<Timestamped<RttHistoryPoint>>()
    private val _rttHistoryFlow = MutableStateFlow<List<Timestamped<RttHistoryPoint>>>(emptyList())
    val rttHistoryFlow: StateFlow<List<Timestamped<RttHistoryPoint>>> = _rttHistoryFlow.asStateFlow()

    // TCP and UDP-L4S both - raw per-interval Mbps, for the MiniSparkline
    // paired beside the (now compact) ThroughputMeter dial. Same "raw, not
    // windowed" reasoning as rttHistory above - throughputAcc already tracks
    // the whole-run min/avg/max separately, this is just the trend line.
    private val throughputHistory = ArrayDeque<TimeSeriesPoint>()
    private val _throughputHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val throughputHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _throughputHistoryFlow.asStateFlow()

    // UDP-L4S only - raw per-interval CE mark episode duration (ms), for the
    // MiniSparkline paired beside RttMeter's UDP-L4S "CE Duration" reading.
    // TCP never appends to this (CeDurationPlaceholder has no real data to
    // chart - see that composable's own doc comment).
    private val ceDurationHistory = ArrayDeque<TimeSeriesPoint>()
    private val _ceDurationHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val ceDurationHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _ceDurationHistoryFlow.asStateFlow()

    // TCP only - raw per-interval write-block time (ms) and retry count, for
    // the MiniSparkline paired beside WriteBlockTimeMeter/RetriesMeter
    // (moved out of BytesInFlightMeter's own bar stack into this same
    // dial+sparkline treatment - see those composables' own doc comments).
    private val writeTimeHistory = ArrayDeque<TimeSeriesPoint>()
    private val _writeTimeHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val writeTimeHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _writeTimeHistoryFlow.asStateFlow()
    private val retryHistory = ArrayDeque<TimeSeriesPoint>()
    private val _retryHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val retryHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _retryHistoryFlow.asStateFlow()

    // TCP only - raw per-interval {CWND, inFlight, NotSent} triple (KB),
    // for BytesInFlightMeter's own combined mini chart paired beside the
    // CWND/inFlight/NotSent bar (see CwndInflightPoint's own doc comment).
    private val cwndInflightHistory = ArrayDeque<Timestamped<CwndInflightPoint>>()
    private val _cwndInflightHistoryFlow = MutableStateFlow<List<Timestamped<CwndInflightPoint>>>(emptyList())
    val cwndInflightHistoryFlow: StateFlow<List<Timestamped<CwndInflightPoint>>> = _cwndInflightHistoryFlow.asStateFlow()

    // UDP-L4S only - same idea as cwndInflightHistory above, for
    // BytesInFlightMeter's Window/Inflight/Queued mini chart (see
    // WindowInflightPoint's own doc comment).
    private val windowInflightHistory = ArrayDeque<Timestamped<WindowInflightPoint>>()
    private val _windowInflightHistoryFlow = MutableStateFlow<List<Timestamped<WindowInflightPoint>>>(emptyList())
    val windowInflightHistoryFlow: StateFlow<List<Timestamped<WindowInflightPoint>>> = _windowInflightHistoryFlow.asStateFlow()

    // UDP-L4S only - raw per-interval trend buffers for the four dials
    // moved out of BytesInFlightMeter's own bar stack (PacketsPerSecMeter/
    // CeMarksPerSecMeter/MarkingProbabilityMeter/LossProbabilityMeter, see
    // those composables' own doc comments) - same "own MiniSparkline"
    // treatment as every other converted metric this session.
    private val ppsHistory = ArrayDeque<TimeSeriesPoint>()
    private val _ppsHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val ppsHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _ppsHistoryFlow.asStateFlow()
    private val ceMarksPerSecHistory = ArrayDeque<TimeSeriesPoint>()
    private val _ceMarksPerSecHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val ceMarksPerSecHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _ceMarksPerSecHistoryFlow.asStateFlow()
    private val markProbHistory = ArrayDeque<TimeSeriesPoint>() // percent, 0..100
    private val _markProbHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val markProbHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _markProbHistoryFlow.asStateFlow()
    private val lossPercentHistory = ArrayDeque<TimeSeriesPoint>()
    private val _lossPercentHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val lossPercentHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _lossPercentHistoryFlow.asStateFlow()

    // BOUNCEBACK + workingLoadEnabled only - raw per-direction trend
    // buffers for WorkingLoadUpMeter/WorkingLoadDownMeter (moved out of
    // BytesInFlightMeter's own bar stack into the same [dial |
    // MiniSparkline] treatment as everything else this session - see those
    // composables' own doc comment). Timestamped from each reading's own
    // WorkingLoadReading.intervalEndSecs (the row's real IEND field), not a
    // guessed elapsed time - see that field's own doc comment
    // (CsvLineParser).
    private val workingLoadUpHistory = ArrayDeque<TimeSeriesPoint>()
    private val _workingLoadUpHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val workingLoadUpHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _workingLoadUpHistoryFlow.asStateFlow()
    private val workingLoadDownHistory = ArrayDeque<TimeSeriesPoint>()
    private val _workingLoadDownHistoryFlow = MutableStateFlow<List<TimeSeriesPoint>>(emptyList())
    val workingLoadDownHistoryFlow: StateFlow<List<TimeSeriesPoint>> = _workingLoadDownHistoryFlow.asStateFlow()

    private val _throughputStats = MutableStateFlow<MeterStats?>(null)
    val throughputStats: StateFlow<MeterStats?> = _throughputStats.asStateFlow()
    private val _rttStats = MutableStateFlow<MeterStats?>(null)
    val rttStats: StateFlow<MeterStats?> = _rttStats.asStateFlow()
    private val _inFlightStats = MutableStateFlow<MeterStats?>(null)
    val inFlightStats: StateFlow<MeterStats?> = _inFlightStats.asStateFlow()
    private val _packetsInFlightStats = MutableStateFlow<MeterStats?>(null)
    val packetsInFlightStats: StateFlow<MeterStats?> = _packetsInFlightStats.asStateFlow()
    private val _cwndStats = MutableStateFlow<MeterStats?>(null)
    val cwndStats: StateFlow<MeterStats?> = _cwndStats.asStateFlow()
    private val _retryStats = MutableStateFlow<MeterStats?>(null)
    val retryStats: StateFlow<MeterStats?> = _retryStats.asStateFlow()
    private val _notSentStats = MutableStateFlow<MeterStats?>(null)
    val notSentStats: StateFlow<MeterStats?> = _notSentStats.asStateFlow()
    private val _tcpExcessRttStats = MutableStateFlow<MeterStats?>(null)
    val tcpExcessRttStats: StateFlow<MeterStats?> = _tcpExcessRttStats.asStateFlow()
    private val _sndBufStats = MutableStateFlow<MeterStats?>(null)
    val sndBufStats: StateFlow<MeterStats?> = _sndBufStats.asStateFlow()
    private val _writeTimeStats = MutableStateFlow<MeterStats?>(null)
    val writeTimeStats: StateFlow<MeterStats?> = _writeTimeStats.asStateFlow()
    private val _sndBufLimitedStats = MutableStateFlow<MeterStats?>(null)
    val sndBufLimitedStats: StateFlow<MeterStats?> = _sndBufLimitedStats.asStateFlow()
    private val _rwndLimitedStats = MutableStateFlow<MeterStats?>(null)
    val rwndLimitedStats: StateFlow<MeterStats?> = _rwndLimitedStats.asStateFlow()
    private val _busyTimeStats = MutableStateFlow<MeterStats?>(null)
    val busyTimeStats: StateFlow<MeterStats?> = _busyTimeStats.asStateFlow()
    private val _flowingStats = MutableStateFlow<MeterStats?>(null)
    val flowingStats: StateFlow<MeterStats?> = _flowingStats.asStateFlow()
    private val _ceMarksStats = MutableStateFlow<MeterStats?>(null)
    val ceMarksStats: StateFlow<MeterStats?> = _ceMarksStats.asStateFlow()
    private val _ceMarksWhenMarkingStats = MutableStateFlow<MeterStats?>(null)
    val ceMarksWhenMarkingStats: StateFlow<MeterStats?> = _ceMarksWhenMarkingStats.asStateFlow()
    private val _queueDelayStats = MutableStateFlow<MeterStats?>(null)
    val queueDelayStats: StateFlow<MeterStats?> = _queueDelayStats.asStateFlow()
    private val _queueBytesStats = MutableStateFlow<MeterStats?>(null)
    val queueBytesStats: StateFlow<MeterStats?> = _queueBytesStats.asStateFlow()
    private val _queuePacketsStats = MutableStateFlow<MeterStats?>(null)
    val queuePacketsStats: StateFlow<MeterStats?> = _queuePacketsStats.asStateFlow()
    private val _l4sRttStats = MutableStateFlow<MeterStats?>(null)
    val l4sRttStats: StateFlow<MeterStats?> = _l4sRttStats.asStateFlow()
    private val _l4sPacketWindowStats = MutableStateFlow<MeterStats?>(null)
    val l4sPacketWindowStats: StateFlow<MeterStats?> = _l4sPacketWindowStats.asStateFlow()
    private val _l4sInflightStats = MutableStateFlow<MeterStats?>(null)
    val l4sInflightStats: StateFlow<MeterStats?> = _l4sInflightStats.asStateFlow()
    private val _l4sMarkingProbStats = MutableStateFlow<MeterStats?>(null)
    val l4sMarkingProbStats: StateFlow<MeterStats?> = _l4sMarkingProbStats.asStateFlow()
    private val _errPercentStats = MutableStateFlow<MeterStats?>(null)
    val errPercentStats: StateFlow<MeterStats?> = _errPercentStats.asStateFlow()
    private val _bbRequestsStats = MutableStateFlow<MeterStats?>(null)
    val bbRequestsStats: StateFlow<MeterStats?> = _bbRequestsStats.asStateFlow()
    // BOUNCEBACK only - latest sample.rttMinMicros (iperf_tcpstats.rtt_min,
    // kernel tcpi_min_rtt). Just the latest reading, not an accumulator
    // like bbRequestsStats above: the kernel already tracks this as a
    // connection-lifetime running minimum (monotonically non-increasing,
    // full per-ACK granularity), so the latest valid sample IS the current
    // all-time floor - no need for the app to also min-track it. Since
    // bounceback is strictly serialized (the client blocks on each reply
    // before sending the next request, see RunBounceBackTCP), 1000 /
    // (rttMinUs / 1000.0) is a real ceiling on achievable RPS - shown
    // alongside bbRequestsStats so a reader can tell a pacing-limited run
    // from a path-limited one.
    private val _bbRttMinUs = MutableStateFlow<Long?>(null)
    val bbRttMinUs: StateFlow<Long?> = _bbRttMinUs.asStateFlow()

    // BOUNCEBACK only - the full-run request/reply time distribution histogram iperf2's
    // client prints exactly once, right after the last interval's own
    // report (CsvLineParser.parseBounceBackHistogram, see that function's
    // own doc comment for the wire format). A single terminal value, not a
    // growing history list like sparklineHistory above - there's only ever
    // one such line per run, arriving once the whole test is already over,
    // so there's nothing to accumulate. Null until it arrives (which won't
    // happen until the run completes) and reset to null at the start of
    // every new run, same as bbRequestsStats/bbRttMinUs.
    private val _bbHistogram = MutableStateFlow<BounceBackHistogram?>(null)
    val bbHistogram: StateFlow<BounceBackHistogram?> = _bbHistogram.asStateFlow()
    // The exact raw CSV line _bbHistogram above was parsed from - lets
    // saveGoldenHistogram() write the native side's own untouched bytes
    // back out as a --histogram-baseline reference file, rather than
    // reformatting one from the parsed fields (which risks a subtle
    // float-formatting mismatch against what
    // histogram_emd_against_baseline()'s own field-by-position parser,
    // src/histogram.c, expects). Also frozen into RunSnapshot
    // (bbHistogramRawLine) so "save as golden" works from a saved A/B/C/D
    // preset too, not just this live value - see IperfScreen's own
    // effBbHistogramRawLine.
    private val _bbHistogramRawLine = MutableStateFlow<String?>(null)
    val bbHistogramRawLine: StateFlow<String?> = _bbHistogramRawLine.asStateFlow()

    // The current "golden" reference (see GoldenHistogramStore/
    // saveGoldenHistogram() below), parsed once here rather than re-read
    // from disk on every recomposition - IperfScreen recomputes EMD
    // against this on demand (HistogramDistance.emdAgainstReference) for
    // whichever histogram is currently being viewed, live or a saved
    // A/B/C/D preset, so every viewed slot's own comparison always
    // reflects whatever's *currently* golden rather than whatever was
    // golden when that slot was captured. Seeded from disk at startup;
    // refreshed the moment a new golden is saved.
    private val _goldenHistogram = MutableStateFlow(GoldenHistogramStore.load(application))
    val goldenHistogram: StateFlow<BounceBackHistogram?> = _goldenHistogram.asStateFlow()
    // The same golden reference's own raw bytes (trimmed, see
    // GoldenHistogramStore.loadRaw's own doc comment) - lets IperfScreen
    // tell whether whatever's currently being viewed (live or an A/B/C/D
    // preset) *is* the golden run, so BounceBackHistogramChart's own "Save
    // as golden" button can show "Saved" instead of inviting a pointless
    // re-save, and a technician can page through Live/A/B/C/D and see at a
    // glance which one is currently golden.
    private val _goldenHistogramRawLine = MutableStateFlow(GoldenHistogramStore.loadRaw(application))
    val goldenHistogramRawLine: StateFlow<String?> = _goldenHistogramRawLine.asStateFlow()
    // Which A/B/C/D preset (if any) was explicitly promoted to be the
    // golden reference - RunCompareTabs' own star uses this directly
    // (slot == goldenSlot), not a byte comparison against
    // goldenHistogramRawLine above. A byte comparison sounds equivalent
    // but isn't: if two different slots ever end up holding byte-identical
    // data (e.g. two "hold to save" gestures both capturing the same
    // still-live run before a fresh test actually ran), a byte comparison
    // would star *both* at once, breaking the "only ever one reference"
    // invariant this app promises - see GoldenHistogramStore.
    // saveSourceSlot's own doc comment. Explicit designation can't do
    // that: exactly one slot (or none) is ever recorded here. Persisted
    // alongside the golden file itself, so it survives an app restart too.
    private val _goldenSlot = MutableStateFlow(GoldenHistogramStore.loadSourceSlot(application))
    val goldenSlot: StateFlow<Char?> = _goldenSlot.asStateFlow()

    // BOUNCEBACK + workingLoadEnabled only - the working load's own CSV rows
    // are interleaved with the bounceback test's own rows in the same
    // stdout stream (see CsvLineParser.parseWorkingLoadUploadThroughput).
    // _workingLoadUpMbps/_workingLoadDownMbps are just the latest instant
    // reading per direction (drives each bar's own needle);
    // workingLoadUpAcc/DownAcc + _workingLoadUpStats/DownStats is the
    // running min/avg/max backing each one's "final reading is the
    // average" convention, same as bbRequestsStats.
    private val _workingLoadUpMbps = MutableStateFlow<Double?>(null)
    val workingLoadUpMbps: StateFlow<Double?> = _workingLoadUpMbps.asStateFlow()
    private val _workingLoadUpStats = MutableStateFlow<MeterStats?>(null)
    val workingLoadUpStats: StateFlow<MeterStats?> = _workingLoadUpStats.asStateFlow()
    private val _workingLoadDownMbps = MutableStateFlow<Double?>(null)
    val workingLoadDownMbps: StateFlow<Double?> = _workingLoadDownMbps.asStateFlow()
    private val _workingLoadDownStats = MutableStateFlow<MeterStats?>(null)
    val workingLoadDownStats: StateFlow<MeterStats?> = _workingLoadDownStats.asStateFlow()

    // Preset compare: four independent saved-run "preset" slots (car-radio-
    // preset semantics, see saveCurrentAs()/IperfScreen's RunCompareTabs) -
    // hold any slot to overwrite it with whatever's currently live, tap to
    // recall it. No slot is special; there's no "the last one is always the
    // latest run" rule. viewingSlot tracks which one (if any) the meters
    // currently render - null means "live", the just-run/in-progress test,
    // same as before this feature existed. It resets to null whenever a new
    // run starts (see onStart()) so an in-progress run's live meters aren't
    // hidden behind a stale preset. A saved slot carries its own full
    // TestConfig (RunSnapshot), so comparing across different test modes is
    // fine - IperfScreen doesn't filter by mode match.
    //
    // Seeded from TestConfigStore.loadPreset() rather than starting all-null
    // - only the config half survives a restart (see TestConfigStore's own
    // doc comment on why not the full RunSnapshot), so a slot restored this
    // way shows its saved host/port/mode/etc. immediately but every
    // *Stats/history field is null/empty until the user runs it again and
    // holds the slot to re-save. loadPresetSnapshot() below is the
    // config-to-placeholder-RunSnapshot mapping both this seed and
    // resetToDefaults() rely on.
    private val _savedRuns = MutableStateFlow(
        PRESET_SLOTS.associateWith { loadPresetSnapshot(application, it) },
    )
    val savedRuns: StateFlow<Map<Char, RunSnapshot?>> = _savedRuns.asStateFlow()
    private val _viewingSlot = MutableStateFlow<Char?>(null)
    val viewingSlot: StateFlow<Char?> = _viewingSlot.asStateFlow()

    // UDP-L4S only - which unit the "Queue (Little's Law)" bar displays
    // (BytesInFlightMeter). Deliberately NOT part of TestConfig: both units
    // are always computed and stored (queuePacketsStats/queueBytesStats, in
    // the live StateFlows and in RunSnapshot alike), so this is purely
    // "which one is the screen currently showing" - independent of whether
    // the screen is currently showing live (B) or a saved (A) run. Tying it
    // to TestConfig instead would break while viewing A: effConfig there
    // reads the *frozen* snapshot's config, so toggling the live config
    // wouldn't visibly change anything on screen. Packets by default -
    // L4S's own marking mechanism (DualPI2, RFC 9332) reasons in packets
    // and queueing delay, not byte occupancy - see QueueDelayMeter's doc
    // comment. Not persisted across app restarts (in-memory only) - a
    // low-stakes display toggle, unlike the real test parameters in
    // TestConfig/TestConfigStore.
    private val _queueUnitsPackets = MutableStateFlow(true)
    val queueUnitsPackets: StateFlow<Boolean> = _queueUnitsPackets.asStateFlow()
    fun setQueueUnitsPackets(packets: Boolean) {
        _queueUnitsPackets.value = packets
    }

    /** Last non-CSV line seen (connection errors, "Server listening", etc.) - not a full log. */
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    /**
     * Which transport (WiFi/Ethernet/cellular) this run's traffic is
     * actually going out over - see NetworkTransportProbe's own doc
     * comment for why reading the system's default route is accurate here.
     * Sampled once in onStart(), not continuously - null until a run has
     * actually started, and stays at whatever it was for the run just
     * finished/still running rather than clearing on its own, so it's
     * still visible on screen right after a run completes.
     *
     * Caveat for a forced (non-AUTO) preference: this is what onStart()
     * *requested* via `-c host%device`, assumed to have taken effect once
     * Android reports a live Network object for it - it is NOT verified
     * against real traffic. See [transportMismatch] for the actual check.
     */
    private val _activeTransport = MutableStateFlow<NetworkTransport?>(null)
    val activeTransport: StateFlow<NetworkTransport?> = _activeTransport.asStateFlow()

    // Every local IP the forced preference's resolved interface actually
    // owns (NetworkTransportProbe.expectedLocalAddresses, sampled once in
    // onStart() same as _activeTransport above) - held here only to
    // compare each incoming sample's own real srcaddress against below,
    // not exposed as a StateFlow since nothing on screen needs the raw
    // IPs, only whether one matched. A Set, not a single String - see
    // expectedLocalAddresses' own doc comment for why a single arbitrarily-
    // picked address produced real false-positive warnings on dual-stack
    // (IPv4+IPv6) networks.
    private var expectedLocalAddressesForRun: Set<java.net.InetAddress> = emptySet()

    // Which preference [transportMismatch] actually applies to - captured
    // once in onStart() alongside [_activeTransport] itself, so the
    // Network row's own per-chip warning badge (IperfScreen.kt) can target
    // the one preference this run actually tested, not whatever the live
    // picker happens to be showing right now. Without this, switching the
    // picker to a different chip after a mismatched run made the warning
    // badge silently "follow" the newly-selected chip instead of staying
    // on the one that was actually tested (confirmed on-device: Sebastian
    // Moeller, 2026-08-11).
    private val _transportMismatchPreference = MutableStateFlow<NetworkPreference?>(null)
    val transportMismatchPreference: StateFlow<NetworkPreference?> = _transportMismatchPreference.asStateFlow()

    /**
     * True once this run is known to not be using the requested WIFI/
     * ETHERNET/CELLULAR preference - either because a real sample's own
     * srcaddress (IntervalSample.srcAddress, the native socket's actual
     * local IP) doesn't match any of [expectedLocalAddressesForRun] (the `-c
     * host%device` SO_BINDTODEVICE bind silently didn't stick on this
     * device - confirmed as a real, on-device failure mode, not just a
     * theoretical gap), or because the requested interface couldn't even
     * be resolved to begin with (set immediately in onStart() in that
     * case, not deferred until a sample arrives - there's nothing to wait
     * for if the interface was never found). Either way [activeTransport]
     * is showing something other than what was actually requested. Never
     * un-set mid-run once true (same "sticky for the rest of this run"
     * contract as [everConnected]) - reset alongside it in
     * clearRunResults().
     */
    private val _transportMismatch = MutableStateFlow(false)
    val transportMismatch: StateFlow<Boolean> = _transportMismatch.asStateFlow()

    // Five sticky, "ever true this run" flags matching the native side's
    // own one-shot Reporter-thread log lines (Client::RunBounceBackUDP,
    // see HEADER_BBREQ_BLEACHED/HEADER_BBREQ_CONFIRMED's own doc comments,
    // payloads.h) - only meaningful for BOUNCEBACK's own UDP_L4S transport,
    // never set otherwise since those messages can't appear for TCP or
    // plain UDP. Deliberately not driven off any CSV field - this app
    // doesn't show CE stats for Bounceback (explicit call, not an
    // oversight), these are plain substring matches against the exact
    // native wording, same pattern _connectFailed below already uses.
    // Reset in clearRunResults() alongside transportMismatch.
    //
    // CE and ECT(1) are different signals. CE is the network queue's own
    // congestion mark - l4sCeConfirmed has no negative counterpart because
    // an absent CE mark doesn't confirm anything (could mean unsupported,
    // could just mean no congestion this run - see that flag's own native
    // doc comment). ECT(1) is the sender's L4S-capability mark, and
    // whether it arrives intact is what the two directions' real
    // affirmative/negative pair reports: *Confirmed means a clean read
    // arrived still ECT(1) (mark intact, not bleached), *BleachDetected
    // means one arrived stripped to Not-ECT - native only ever logs one
    // or the other per direction, never both, so IperfScreen's own badge
    // rendering can treat them as mutually exclusive per slot.
    private val _l4sCeConfirmed = MutableStateFlow(false)
    val l4sCeConfirmed: StateFlow<Boolean> = _l4sCeConfirmed.asStateFlow()
    private val _l4sReplyBleachDetected = MutableStateFlow(false)
    val l4sReplyBleachDetected: StateFlow<Boolean> = _l4sReplyBleachDetected.asStateFlow()
    private val _l4sReqBleachDetected = MutableStateFlow(false)
    val l4sReqBleachDetected: StateFlow<Boolean> = _l4sReqBleachDetected.asStateFlow()
    private val _l4sReplyConfirmed = MutableStateFlow(false)
    val l4sReplyConfirmed: StateFlow<Boolean> = _l4sReplyConfirmed.asStateFlow()
    private val _l4sReqConfirmed = MutableStateFlow(false)
    val l4sReqConfirmed: StateFlow<Boolean> = _l4sReqConfirmed.asStateFlow()

    // Capacity's own UDP L4S stream (Client::RunUDPL4S, not Bounceback) -
    // a single continuous flow, so only one direction's worth of marking-
    // integrity exists here (unlike the two Bounceback pairs above).
    // Native latches these the same way: at most one of the two ever
    // fires per run, matching PragueState.m_error_L4S's own permanent-
    // once-set behavior (prague_cc.h) - see that log line's own doc
    // comment in Client.cpp for why. Deliberately separate StateFlows
    // from the Bounceback ones above (not reused) so a Capacity run can
    // never accidentally show a Bounceback badge or vice versa.
    private val _capacityL4sConfirmed = MutableStateFlow(false)
    val capacityL4sConfirmed: StateFlow<Boolean> = _capacityL4sConfirmed.asStateFlow()
    private val _capacityL4sBleachDetected = MutableStateFlow(false)
    val capacityL4sBleachDetected: StateFlow<Boolean> = _capacityL4sBleachDetected.asStateFlow()

    // True once this run's raw output shows Bounceback UDP discarded at
    // least one stale reply (RunBounceBackUDP's own staleReplyCount, see
    // its doc comment in Client.cpp) - a late reply to an earlier,
    // already-timed-out request landing after the next request was
    // already sent. Routine under real congestion/loss, not a sign of a
    // broken run, but worth surfacing since (before the fix that added
    // this detection) it used to silently corrupt the reported RPS.
    private val _bbStaleReplyDetected = MutableStateFlow(false)
    val bbStaleReplyDetected: StateFlow<Boolean> = _bbStaleReplyDetected.asStateFlow()

    // True when this run's status line matched iperf2's own TCP connect
    // failure message (Reporter.c: "tcp connect to %s port %d failed (%s)
    // on %s") - drives a simple red-LED indicator rather than making the
    // user parse the raw status text themselves. Cleared back to false the
    // moment a real sample arrives (see the sample-ingest block below) -
    // my_connect() retries internally, so this can legitimately latch true
    // once and then still go on to a fully successful run.
    private val _connectFailed = MutableStateFlow(false)
    val connectFailed: StateFlow<Boolean> = _connectFailed.asStateFlow()

    // Together with [connectFailed], drives the three-state (red/yellow/
    // green) connection LED (IperfScreen's ConnectionStatusIndicator) -
    // green alone isn't enough to say "connected cleanly," since
    // my_connect()'s internal retries mean a run can still reach a real
    // sample after one or more printed "tcp connect to ... failed" lines.
    // [everConnected] latches true the moment the first real sample this
    // run arrives and, unlike connectFailed, is never cleared back to
    // false mid-run - it answers "has this run *ever* had a working
    // connection," which is what distinguishes red (never connected) from
    // yellow (connected, but not cleanly) once connectFailed is also true
    // again later. [hadConnectRetry] latches true the moment any "tcp
    // connect to ... failed" line is seen, connected or not - if that ever
    // happens before the run eventually reaches a real sample, the
    // connection needed more than one attempt (yellow, not green), even
    // though connectFailed itself has since cleared back to false. Both
    // reset to false alongside connectFailed in clearRunResults().
    private val _everConnected = MutableStateFlow(false)
    val everConnected: StateFlow<Boolean> = _everConnected.asStateFlow()
    private val _hadConnectRetry = MutableStateFlow(false)
    val hadConnectRetry: StateFlow<Boolean> = _hadConnectRetry.asStateFlow()

    // Read straight from the bundled binary's own "--version" output rather
    // than hardcoding a version string here, so this can never drift from
    // whatever iperf2 commit actually got cross-compiled into this build.
    private val _versionInfo = MutableStateFlow<String?>(null)
    val versionInfo: StateFlow<String?> = _versionInfo.asStateFlow()

    /** Congestion control algorithm names this device's kernel actually supports - see CcaProbe. */
    private val _ccaOptions = MutableStateFlow<List<String>>(emptyList())
    val ccaOptions: StateFlow<List<String>> = _ccaOptions.asStateFlow()

    // Most-recently-used host/port, for the Host/Port fields' dropdown
    // suggestions (see TestConfigStore) - updated when a test actually
    // starts, not on every keystroke.
    private val _recentHosts = MutableStateFlow(TestConfigStore.loadRecentHosts(application))
    val recentHosts: StateFlow<List<String>> = _recentHosts.asStateFlow()
    private val _recentPorts = MutableStateFlow(TestConfigStore.loadRecentPorts(application))
    val recentPorts: StateFlow<List<Int>> = _recentPorts.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _versionInfo.value = try {
                val proc = ProcessBuilder(IperfCommandBuilder.binaryPath(getApplication()), "--version")
                    .redirectErrorStream(true)
                    .start()
                val text = proc.inputStream.bufferedReader().readText().trim()
                proc.waitFor()
                text.ifBlank { null }
            } catch (e: Exception) {
                null
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            _ccaOptions.value = CcaProbe.availableAlgorithms(getApplication(), REQUIRED_CCA_ALGORITHMS)
        }
    }

    fun updateConfig(newConfig: TestConfig) {
        // Clear whatever's currently displayed on the Live tab whenever the
        // reconfiguration changes which meters even render / what shape
        // their data is (mode - TCP/UDP_L4S/BOUNCEBACK - and, for
        // BOUNCEBACK, its own transport, since both TCP and UDP_L4S
        // bounceback share TestMode.BOUNCEBACK but have incompatible field
        // shapes, see CsvLineParser). Without this, switching e.g.
        // bouncebackTransport from TCP to UDP_L4S left the previous TCP
        // run's stale RTT/bytes-in-flight numbers on screen even though the
        // meters themselves had already switched to the UDP_L4S set - a
        // config change, not a real answer to "what did the last UDP_L4S
        // run look like". Guarded on !isRunning since these controls are
        // already disabled while a run is live, so this only ever fires
        // between runs.
        val oldConfig = _config.value
        if (!_isRunning.value && (oldConfig.mode != newConfig.mode || oldConfig.bouncebackTransport != newConfig.bouncebackTransport)) {
            clearRunResults()
        }
        val application = getApplication<Application>()
        // manualPermitKey is host-scoped, not a plain field of this config -
        // see TestConfig.manualPermitKey's own doc comment. Two cases:
        // the host itself changed (dropdown pick or typing a new one), in
        // which case swap in whatever key (if any) is saved for the *new*
        // host rather than carrying the old host's key over; or the key
        // field itself was edited, in which case persist it against the
        // current host so it's remembered next time. Never both in the same
        // call - updateConfig fires once per field edit.
        val resolved = if (newConfig.host != oldConfig.host) {
            newConfig.copy(manualPermitKey = TestConfigStore.loadPermitKeyForHost(application, newConfig.host))
        } else {
            if (newConfig.manualPermitKey != oldConfig.manualPermitKey) {
                TestConfigStore.savePermitKeyForHost(application, newConfig.host, newConfig.manualPermitKey)
            }
            newConfig
        }
        _config.value = resolved
        TestConfigStore.save(application, resolved)
    }

    /**
     * Clears every piece of live/completed-run state - meters, elapsed-
     * time row, which preset is being viewed - shared by [resetToDefaults]
     * and [onStart].
     * Deliberately does NOT touch [_isRunning] or [_runStartedAtMillis]:
     * callers set those themselves since the two need opposite values
     * (onStart is about to go true/now, resetToDefaults wants false/null).
     */
    private fun clearRunResults() {
        _latestSample.value = null
        _statusMessage.value = null
        _connectFailed.value = false
        _everConnected.value = false
        _hadConnectRetry.value = false
        _transportMismatch.value = false
        _transportMismatchPreference.value = null
        _l4sCeConfirmed.value = false
        _l4sReplyBleachDetected.value = false
        _l4sReqBleachDetected.value = false
        _l4sReplyConfirmed.value = false
        _l4sReqConfirmed.value = false
        _capacityL4sConfirmed.value = false
        _capacityL4sBleachDetected.value = false
        _bbStaleReplyDetected.value = false
        // A/B compare: don't leave the user staring at a frozen preset -
        // or, for resetToDefaults, a preset that's about to be wiped out
        // from under it - while the live view (which this always switches
        // back to) is what should be showing.
        _viewingSlot.value = null

        sampleCount = 0
        throughputAcc.reset()
        rttOrJitterAcc.reset()
        inFlightAcc.reset()
        packetsInFlightAcc.reset()
        cwndAcc.reset()
        retryAcc.reset()
        notSentAcc.reset()
        tcpExcessRttAcc.reset()
        sndBufAcc.reset()
        writeTimeAcc.reset()
        sndBufLimitedAcc.reset()
        rwndLimitedAcc.reset()
        busyTimeAcc.reset()
        flowingAcc.reset()
        ceMarksAcc.reset()
        ceMarksWhenMarkingAcc.reset()
        queueDelayAcc.reset()
        queueBytesAcc.reset()
        queuePacketsAcc.reset()
        l4sRttAcc.reset()
        l4sPacketWindowAcc.reset()
        l4sInflightAcc.reset()
        l4sMarkingProbAcc.reset()
        errPercentAcc.reset()
        bbRequestsAcc.reset()
        workingLoadUpAcc.reset()
        workingLoadDownAcc.reset()
        windowedStats.reset()
        sparklineHistory.clear()
        bbRequestsHistory.clear()
        rttHistory.clear()
        throughputHistory.clear()
        ceDurationHistory.clear()
        writeTimeHistory.clear()
        retryHistory.clear()
        cwndInflightHistory.clear()
        windowInflightHistory.clear()
        ppsHistory.clear()
        ceMarksPerSecHistory.clear()
        markProbHistory.clear()
        lossPercentHistory.clear()
        workingLoadUpHistory.clear()
        workingLoadDownHistory.clear()
        _throughputStats.value = null
        _rttStats.value = null
        _inFlightStats.value = null
        _packetsInFlightStats.value = null
        _cwndStats.value = null
        _retryStats.value = null
        _notSentStats.value = null
        _tcpExcessRttStats.value = null
        _sndBufStats.value = null
        _writeTimeStats.value = null
        _sndBufLimitedStats.value = null
        _rwndLimitedStats.value = null
        _busyTimeStats.value = null
        _flowingStats.value = null
        _ceMarksStats.value = null
        _ceMarksWhenMarkingStats.value = null
        _queueDelayStats.value = null
        _queueBytesStats.value = null
        _queuePacketsStats.value = null
        _l4sRttStats.value = null
        _l4sPacketWindowStats.value = null
        _l4sInflightStats.value = null
        _l4sMarkingProbStats.value = null
        _errPercentStats.value = null
        _bbRequestsStats.value = null
        _bbRttMinUs.value = null
        _bbHistogram.value = null
        _bbHistogramRawLine.value = null
        _workingLoadUpMbps.value = null
        _workingLoadUpStats.value = null
        _workingLoadDownMbps.value = null
        _workingLoadDownStats.value = null
        _sparklineHistoryFlow.value = emptyList()
        _bbRequestsHistoryFlow.value = emptyList()
        _rttHistoryFlow.value = emptyList()
        _throughputHistoryFlow.value = emptyList()
        _ceDurationHistoryFlow.value = emptyList()
        _writeTimeHistoryFlow.value = emptyList()
        _retryHistoryFlow.value = emptyList()
        _cwndInflightHistoryFlow.value = emptyList()
        _windowInflightHistoryFlow.value = emptyList()
        _ppsHistoryFlow.value = emptyList()
        _ceMarksPerSecHistoryFlow.value = emptyList()
        _markProbHistoryFlow.value = emptyList()
        _lossPercentHistoryFlow.value = emptyList()
        _workingLoadUpHistoryFlow.value = emptyList()
        _workingLoadDownHistoryFlow.value = emptyList()
        _elapsedSecs.value = 0
        _testProgress.value = 0f
    }

    /** Escape hatch back to known-good defaults, once persisted values are in play. */
    fun resetToDefaults() {
        val defaults = TestConfig()
        _config.value = defaults
        TestConfigStore.save(getApplication(), defaults)
        // "Reset to none" for the MRU dropdowns too, not just the form
        // fields - otherwise Reset would still leave stale host/port
        // history around.
        TestConfigStore.clearRecentHosts(getApplication())
        TestConfigStore.clearRecentPorts(getApplication())
        _recentHosts.value = emptyList()
        _recentPorts.value = emptyList()
        // Also clears latestSample/the meter stats/A-B presets (see
        // clearRunResults' own doc comment) - without this, a completed
        // run from before the reset would leave latestSample non-null and
        // the hold-to-save gesture (IperfScreen's canSaveRun) would still
        // be armed, letting a preset be saved from stale, pre-reset data
        // that isn't even on screen as "N/A" anymore, just gone.
        clearRunResults()
        _runStartedAtMillis.value = null
        // Preset compare slots' config half is persisted (see
        // saveCurrentAs()/TestConfigStore.savePreset), but "reset to
        // known-good defaults" should still clear them - otherwise a stale
        // preset from a previous session's config would survive the reset
        // and could still be recalled.
        PRESET_SLOTS.forEach {
            TestConfigStore.clearPreset(getApplication(), it)
            RunSnapshotStore.clear(getApplication(), it)
        }
        _savedRuns.value = PRESET_SLOTS.associateWith { null }
        // The golden reference is only ever meaningful as a designation on
        // one of the A/B/C/D slots just wiped above (see [_goldenSlot]'s
        // own doc comment) - leaving it pointing at a now-cleared slot
        // would show no star anywhere while GoldenHistogramStore's own
        // file (and the EMD/overlay comparisons it drives) silently kept
        // comparing against stale data nothing on screen still represents.
        _goldenSlot.value = null
        GoldenHistogramStore.clearSourceSlot(getApplication())
        GoldenHistogramStore.clear(getApplication())
        _goldenHistogram.value = null
        _goldenHistogramRawLine.value = null
    }

    fun onStart() {
        if (_isRunning.value) return // guard against double-start from the UI side too
        clearRunResults()
        setRunning(true)
        _runStartedAtMillis.value = System.currentTimeMillis()
        // Reflects what IperfCommandBuilder.buildArgs is about to do: when a
        // forced WIFI/ETHERNET/CELLULAR preference actually resolves to a
        // live interface, that's what the `-c host%device` argument will
        // bind the native process's socket to (see findNetworkInterfaceName's
        // own doc comment - NOT ConnectivityManager.bindProcessToNetwork(),
        // which doesn't survive exec() into the separate native binary), so
        // showing the forced choice here - rather than sampling the system
        // default route, which %device deliberately overrides - is what
        // keeps this indicator accurate. Falls back to the sampled default
        // route for AUTO or when the requested transport isn't currently up
        // (buildArgs falls back to a plain, unsuffixed host in that case too).
        val forcedPreference = _config.value.networkPreference
        val forcedTransport = when (forcedPreference) {
            NetworkPreference.WIFI -> NetworkTransport.WIFI
            NetworkPreference.ETHERNET -> NetworkTransport.ETHERNET
            NetworkPreference.CELLULAR -> NetworkTransport.CELLULAR
            NetworkPreference.AUTO -> null
        }
        val forcedInterfaceResolved = forcedTransport != null && findNetworkInterfaceName(getApplication(), forcedPreference) != null
        _activeTransport.value = if (forcedInterfaceResolved) forcedTransport else currentNetworkTransport(getApplication())
        // Only meaningful when a preference was actually forced - null for
        // AUTO, so the Network row's per-chip badge never lights up an
        // AUTO chip (there's nothing to have "not honored").
        _transportMismatchPreference.value = if (forcedTransport != null) forcedPreference else null
        if (forcedTransport != null && !forcedInterfaceResolved) {
            // The requested interface couldn't be resolved to a live
            // Network at all (buildArgs is about to fall back to a plain,
            // unsuffixed host) - that's already known to be a mismatch
            // right now, no need to wait for a sample to confirm it.
            _transportMismatch.value = true
        }
        // Only meaningful when a preference was actually forced AND
        // resolved above - empty otherwise (AUTO, or the requested
        // transport wasn't up), same "nothing to compare against" contract
        // expectedLocalAddresses() itself uses. See [transportMismatch]'s own
        // doc comment for how this gets used once real samples start
        // arriving.
        expectedLocalAddressesForRun = if (forcedInterfaceResolved) expectedLocalAddresses(getApplication(), forcedPreference) else emptySet()
        _recentHosts.value = TestConfigStore.recordHostUse(getApplication(), _config.value.host)
        _recentPorts.value = TestConfigStore.recordPortUse(getApplication(), _config.value.port)

        val mode = _config.value.mode
        val isReverse = _config.value.reverseEnabled
        val bouncebackTransport = _config.value.bouncebackTransport
        val serverPort = _config.value.port
        val durationSecs = _config.value.durationSecs
        val args = IperfCommandBuilder.buildArgs(getApplication(), _config.value, _versionInfo.value)
        // Substitutes for the native CLI's own connect banner, which -y C
        // (this app's own CSV output mode) always suppresses - see
        // describeNetworkForLog's own doc comment. "command:" reconstructs
        // the exact invocation for anyone reading a shared diag log
        // (RawRunLogStore) later - args[0] (the absolute libiperf.so path,
        // an internal implementation detail no one debugging a test would
        // want to type) is swapped for the plain "iperf" a user would
        // actually run by hand. --permit-key's value is redacted - it's a
        // live credential valid against the app's own bundled public
        // server fleet, and a diag log may end up pasted into a public
        // ticket, unlike the wire itself (see doc/PERMIT_KEY_NOTES) which
        // already requires active interception to capture.
        val commandForLog = args.drop(1).joinToString(" ") { arg ->
            if (arg.startsWith("--permit-key=")) "--permit-key=<redacted>" else arg
        }
        val rawLogHeader = listOf(
            "command: iperf $commandForLog",
            "host: ${_config.value.host} port: ${_config.value.port}",
            "device: ${describeNetworkForLog(getApplication(), forcedPreference)}",
            "app: iperf2 Client ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})" +
                BuildConfig.PERMIT_KEY_BUILD_FOR.let { if (it.isEmpty()) "" else " for $it" },
            "version: ${_versionInfo.value ?: "unknown"}",
        )
        // Duration progress ticker - unconditional (unlike the
        // BOUNCEBACK-only sparkline ticker below), since all three modes
        // share the same Duration field and benefit from the same "how much
        // longer" indicator.
        val startElapsedRealtime = SystemClock.elapsedRealtime()
        viewModelScope.launch {
            while (_isRunning.value) {
                val elapsedMs = SystemClock.elapsedRealtime() - startElapsedRealtime
                _elapsedSecs.value = (elapsedMs / 1000L).toInt()
                _testProgress.value = if (durationSecs > 0) {
                    (elapsedMs / 1000f / durationSecs).coerceIn(0f, 1f)
                } else 0f
                delay(LIVE_RENDER_TICK_MS)
            }
        }
        // Decoupled render tick (see WindowedWelfordStats' doc comment) -
        // independent of however fast CSV rows actually arrive, appends
        // one sparkline point at a fixed 10Hz regardless of ingest rate.
        // Only meaningful for BOUNCEBACK (windowedStats is never fed
        // otherwise), but harmless to run for any mode - snapshot() just
        // stays null and nothing gets appended.
        if (mode == TestMode.BOUNCEBACK) {
            viewModelScope.launch {
                while (_isRunning.value) {
                    delay(LIVE_RENDER_TICK_MS)
                    windowedStats.snapshot()?.let { snap ->
                        // Same clock as _elapsedSecs/_testProgress above,
                        // not index * RENDER_TICK_SECS - see
                        // sparklineHistory's own doc comment for why a
                        // plain tick count silently drifts from real
                        // elapsed time here.
                        val elapsedSecs = (SystemClock.elapsedRealtime() - startElapsedRealtime) / 1000.0
                        sparklineHistory.addLast(Timestamped(snap, elapsedSecs))
                        if (sparklineHistory.size > HISTORY_SAFETY_CAP) sparklineHistory.removeFirst()
                        _sparklineHistoryFlow.value = sparklineHistory.toList()
                    }
                }
            }
        }
        viewModelScope.launch {
            try {
                runner.start(args, rawLogFile = RawRunLogStore.file(getApplication()), rawLogHeader = rawLogHeader).collect { line ->
                    val sample = CsvLineParser.parse(line, mode, isReverse, bouncebackTransport)
                    // iperf2's own final cumulative summary line restarts at
                    // istart=0.0 spanning the *whole* test (e.g. "0.0,5.7"
                    // vs a normal interval's own "5.0,5.7") - unlike every
                    // other CSV row it isn't a new instantaneous
                    // measurement, so treating it as just another sample
                    // would both flash a misleading number in the live
                    // gauge and double-count the whole test as one more
                    // sample in the running min/avg/max. sampleCount > 0
                    // guards against mistaking the genuine first interval
                    // (which legitimately also starts at 0.0) for this.
                    val isFinalSummaryLine = sample != null && sampleCount > 0 && sample.intervalStartSecs == 0.0
                    // A connection the server rejected outright (e.g. a
                    // permit-key mismatch - test_permit_key(),
                    // src/Listener.cpp) never completes a real second of
                    // reporting, so iperf2 emits one near-zero-duration
                    // report for it instead of a real interval. Require at
                    // least one full second of actual elapsed time before
                    // trusting a report - simpler than exact istart==iend
                    // equality, and doesn't depend on whether the "write
                    // failed" status message happens to arrive before or
                    // after this line: Client.cpp's write loop can still
                    // push a few -l-sized (default 128K) writes into the
                    // local socket send buffer - accepted there regardless
                    // of what the server's already done - before the
                    // client notices the connection is actually dead, so a
                    // rejected connection's own report can otherwise look
                    // deceptively like real activity.
                    //
                    // Only apply this to the 0-to-1 interval (istart ==
                    // 0.0), though: a legitimate test's *trailing* interval
                    // is also frequently under a second whenever -t doesn't
                    // land on an exact -i boundary - iperf2's own
                    // FINALPARTIAL reporting (reporter_set_timestamps_time,
                    // src/Reporter.c) emits that last partial interval down
                    // to 25% of the configured interval (PARTIALPERCENT,
                    // include/Reporter.h), and -R's burst-relayed timing
                    // (Server::RunTCP) makes a short final read especially
                    // common. A rejected connection, by contrast, always
                    // fails on its very first interval (istart == 0.0), so
                    // keying off istart rather than sampleCount still
                    // catches every rejection - straight from the report's
                    // own data, not this method's local bookkeeping - while
                    // no longer mistaking a successful test's own tail
                    // interval for one.
                    //
                    // sampleCount == 0 additionally excludes the *final*
                    // cumulative summary line (isFinalSummaryLine above),
                    // which also legitimately starts at istart==0.0 and, on
                    // a short-duration test, can itself span well under a
                    // second - without this guard a perfectly healthy short
                    // BOUNCEBACK run's own closing summary line (received
                    // at the very *end* of the run, right before the
                    // histogram line - see CsvLineParser.
                    // parseBounceBackHistogram's own doc comment) would be
                    // misread as a rejected connection, latching the red
                    // "Connect failed" LED with nothing left afterward to
                    // clear it back (no further interval line ever
                    // arrives). A truly rejected connection is always the
                    // very first line this run has seen (sampleCount is
                    // still 0), so this doesn't weaken the rejection check
                    // itself.
                    val isDegenerateReport = sample != null && sampleCount == 0 && sample.intervalStartSecs == 0.0 && (sample.intervalEndSecs - sample.intervalStartSecs) < 1.0
                    if (isDegenerateReport) {
                        _connectFailed.value = true
                        _hadConnectRetry.value = true
                        _latestSample.value = null
                        _throughputStats.value = null
                        _rttStats.value = null
                        _inFlightStats.value = null
                        _packetsInFlightStats.value = null
                        _cwndStats.value = null
                        _retryStats.value = null
                        _notSentStats.value = null
                        _tcpExcessRttStats.value = null
                        _sndBufStats.value = null
                        _writeTimeStats.value = null
                        _ceMarksStats.value = null
                        _ceMarksWhenMarkingStats.value = null
                        _queueDelayStats.value = null
                        _queueBytesStats.value = null
                        _queuePacketsStats.value = null
                        _l4sRttStats.value = null
                        _l4sPacketWindowStats.value = null
                        _l4sInflightStats.value = null
                        _l4sMarkingProbStats.value = null
                        _errPercentStats.value = null
                        _bbRequestsStats.value = null
                        _bbRttMinUs.value = null
                        _bbHistogram.value = null
                    } else if (sample != null && !isFinalSummaryLine) {
                        _latestSample.value = sample
                        // Ground-truth check for a forced preference - see
                        // [transportMismatch]'s own doc comment. Only ever
                        // set true, never back to false, and skipped
                        // entirely once already true (no point re-checking
                        // - and expectedLocalAddressesForRun/sample.srcAddress
                        // being merely absent on some malformed line
                        // shouldn't clear a real mismatch already found).
                        // Membership, not equality - see expectedLocalAddresses()'
                        // own doc comment for why a dual-stack interface
                        // needs this rather than one arbitrarily-picked
                        // address.
                        if (!_transportMismatch.value) {
                            // Parsed to bytes, not compared as text: the CSV
                            // renders IPv6 via inet_ntop() ("2600:3c01::1")
                            // while Java's own getHostAddress() never
                            // run-compresses ("2600:3c01:0:0:0:0:0:1"), so a
                            // string compare reported a mismatch on every
                            // dual-stack run that resolved over IPv6 even
                            // though the forced interface had been honored -
                            // see expectedLocalAddresses' own doc comment.
                            // An unparseable/absent address is "no evidence",
                            // never evidence of a mismatch.
                            val actual = parseNumericAddressOrNull(sample.srcAddress)
                            if (expectedLocalAddressesForRun.isNotEmpty() && actual != null &&
                                actual !in expectedLocalAddressesForRun) {
                                _transportMismatch.value = true
                            }
                        }
                        // A real sample is proof the connection is actually
                        // up, even if _connectFailed got latched true
                        // earlier this run - my_connect() (src/Client.cpp)
                        // retries a failed connect() internally within its
                        // own connect_retry_time window, printing this run's
                        // "tcp connect to ... failed" status line (the
                        // literal-match branch above) on every attempt that
                        // fails, including ones a later attempt in the same
                        // call then recovers from. Without this, a
                        // transient first-attempt failure left the red LED
                        // lit for a test that then ran and reported real
                        // data start to finish - confusing on a real
                        // network (a public server, a flaky WiFi/cellular
                        // hop) where a lone retry is unremarkable. The
                        // isDegenerateReport branch above already covers
                        // the "genuinely rejected" case on its own terms
                        // (short first interval) and isn't reachable here.
                        _connectFailed.value = false
                        _everConnected.value = true
                        // Updated unconditionally (not gated behind
                        // sampleCount > 1 like the accumulators below) -
                        // this is just "latest known reading," not
                        // something being averaged, so the first sample's
                        // value is exactly as valid as any later one.
                        if (mode == TestMode.BOUNCEBACK) {
                            sample.rttMinMicros.takeIf { it >= 0 }?.let { _bbRttMinUs.value = it }
                        }
                        sampleCount++
                        if (sampleCount > 1) {
                            // Not the first sample - fold it into the running stats.
                            if (mode == TestMode.BOUNCEBACK) {
                                sample.requestsPerSec.takeIf { it >= 0.0 }?.let {
                                    windowedStats.add(sample.intervalEndSecs, it)
                                    bbRequestsHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                    if (bbRequestsHistory.size > HISTORY_SAFETY_CAP) bbRequestsHistory.removeFirst()
                                    _bbRequestsHistoryFlow.value = bbRequestsHistory.toList()
                                }
                            }
                            throughputAcc.add(sample.speedBitsPerSec / 1_000_000.0)
                            val rttOrCeDurationOrBbMs = when (mode) {
                                TestMode.TCP -> sample.rttMicros.takeIf { it >= 0 }?.let { it / 1000.0 }
                                TestMode.UDP_L4S -> sample.ceDurationAvgMs.takeIf { it >= 0.0 }
                                TestMode.BOUNCEBACK -> sample.bbAvgMs.takeIf { it >= 0.0 }
                            }
                            rttOrCeDurationOrBbMs?.let { rttOrJitterAcc.add(it) }
                            val inFlight = when (mode) {
                                TestMode.TCP -> sample.bytesInFlight.takeIf { it >= 0 }?.toDouble()
                                TestMode.UDP_L4S -> sample.packetsPerSec.takeIf { it >= 0.0 }
                                TestMode.BOUNCEBACK -> null // uses bbRequestsAcc below instead
                            }
                            inFlight?.let { inFlightAcc.add(it) }
                            // See rttHistory's own doc comment above for the
                            // TCP/UDP-L4S source formulas. Unconditional
                            // append (a timestamped null when unavailable
                            // this interval, not a skipped one) for the two
                            // modes RTT applies to at all - see
                            // Timestamped's own doc comment - but BOUNCEBACK
                            // still doesn't touch rttHistory at all (not
                            // "gapped," genuinely not applicable to that
                            // mode).
                            val rttHistoryPoint = when (mode) {
                                TestMode.TCP -> if (sample.rttMicros >= 0 && sample.rttMinMicros >= 0) {
                                    RttHistoryPoint(sample.rttMicros / 1000.0, sample.rttMinMicros / 1000.0)
                                } else {
                                    null
                                }
                                TestMode.UDP_L4S -> if (sample.l4sRttUs >= 0 && sample.queueDelayUs >= 0) {
                                    RttHistoryPoint(sample.l4sRttUs / 1000.0, (sample.l4sRttUs - sample.queueDelayUs) / 1000.0)
                                } else {
                                    null
                                }
                                TestMode.BOUNCEBACK -> null
                            }
                            if (mode != TestMode.BOUNCEBACK) {
                                rttHistory.addLast(Timestamped(rttHistoryPoint, sample.intervalEndSecs))
                                if (rttHistory.size > HISTORY_SAFETY_CAP) rttHistory.removeFirst()
                                _rttHistoryFlow.value = rttHistory.toList()
                            }
                            // MiniSparkline pairs, same cap/eviction as
                            // rttHistory above. Throughput's own dial is
                            // shown for every non-BOUNCEBACK mode (see
                            // IperfScreen), so this appends regardless of
                            // mode too, same as throughputAcc just above.
                            throughputHistory.addLast(TimeSeriesPoint(sample.speedBitsPerSec / 1_000_000.0, sample.intervalEndSecs))
                            if (throughputHistory.size > HISTORY_SAFETY_CAP) throughputHistory.removeFirst()
                            _throughputHistoryFlow.value = throughputHistory.toList()
                            if (mode == TestMode.UDP_L4S) {
                                // Unconditional append (a timestamped null
                                // when unavailable, not a skipped interval)
                                // - see TimeSeriesPoint's own doc comment.
                                sample.ceDurationAvgMs.takeIf { it >= 0.0 }.let {
                                    ceDurationHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                    if (ceDurationHistory.size > HISTORY_SAFETY_CAP) ceDurationHistory.removeFirst()
                                    _ceDurationHistoryFlow.value = ceDurationHistory.toList()
                                }
                            }
                            when (mode) {
                                TestMode.TCP -> {
                                    sample.packetsInFlight.takeIf { it >= 0 }?.let { packetsInFlightAcc.add(it.toDouble()) }
                                    // Also populated in --reverse now (relayed
                                    // from the server's own gettcpinfo() sample,
                                    // see Client::WriteTcpTxHdr/Server::RunTCP) -
                                    // -1 sentinel still means "not available"
                                    // either way, same >= 0 guard as everywhere
                                    // else in this file.
                                    sample.cwndBytes.takeIf { it >= 0 }?.let { cwndAcc.add(it.toDouble()) }
                                    // Atomic triple, only a real value when
                                    // all three are available on this same
                                    // interval - see CwndInflightPoint's own
                                    // doc comment for why three independently
                                    // guarded buffers would risk the lines
                                    // drifting out of alignment instead.
                                    // Unconditional append either way (a
                                    // timestamped null otherwise, not a
                                    // skipped interval) - see Timestamped's
                                    // own doc comment.
                                    val cwndInflightPoint = if (sample.cwndBytes >= 0 && sample.bytesInFlight >= 0 && sample.notSentBytes >= 0) {
                                        CwndInflightPoint(
                                            sample.cwndBytes.toDouble(),
                                            sample.bytesInFlight.toDouble(),
                                            sample.notSentBytes.toDouble(),
                                        )
                                    } else {
                                        null
                                    }
                                    cwndInflightHistory.addLast(Timestamped(cwndInflightPoint, sample.intervalEndSecs))
                                    if (cwndInflightHistory.size > HISTORY_SAFETY_CAP) cwndInflightHistory.removeFirst()
                                    _cwndInflightHistoryFlow.value = cwndInflightHistory.toList()
                                    // > 0, not >= 0: an interval with zero
                                    // retries isn't a meaningful "sample" of
                                    // retry behavior, it's the absence of
                                    // one - counting it would drag min (and
                                    // avg) down to a misleading 0 on any run
                                    // that's mostly healthy but has a few
                                    // real retry bursts, the same
                                    // "exclude the non-events" reasoning
                                    // ceMarksWhenMarkingStats already uses
                                    // for CE marks/sec.
                                    sample.tcpRetry.takeIf { it > 0 }?.let { retryAcc.add(it.toDouble()) }
                                    sample.notSentBytes.takeIf { it >= 0 }?.let { notSentAcc.add(it.toDouble()) }
                                    // Current RTT minus the kernel's own
                                    // tracked minimum for this connection -
                                    // see tcpExcessRttAcc's own doc comment.
                                    // Clamped to >= 0: rtt_min updates
                                    // in-kernel continuously, so a given
                                    // interval's rtt sample can occasionally
                                    // land at/below the min purely from
                                    // measurement timing, not a real
                                    // negative excess.
                                    if (sample.rttMicros >= 0 && sample.rttMinMicros >= 0) {
                                        tcpExcessRttAcc.add(((sample.rttMicros - sample.rttMinMicros) / 1000.0).coerceAtLeast(0.0))
                                    }
                                    sample.sndBufKB.takeIf { it >= 0 }?.let { sndBufAcc.add(it.toDouble()) }
                                    sample.writeTimeUs.takeIf { it >= 0 }?.let { writeTimeAcc.add(it.toDouble()) }
                                    // MiniSparkline pair, every interval
                                    // (not the > 0 exclusion retryHistory
                                    // uses below) - a genuinely zero
                                    // write-block time is still a real,
                                    // plottable reading for this metric.
                                    // Unconditional append (timestamped null
                                    // when unavailable) - see
                                    // TimeSeriesPoint's own doc comment.
                                    sample.writeTimeUs.takeIf { it >= 0 }?.let { it / 1000.0 }.let {
                                        writeTimeHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                        if (writeTimeHistory.size > HISTORY_SAFETY_CAP) writeTimeHistory.removeFirst()
                                        _writeTimeHistoryFlow.value = writeTimeHistory.toList()
                                    }
                                    // Every interval, including zero-retry
                                    // ones - unlike retryAcc's own > 0
                                    // exclusion (that accumulator is a
                                    // "retry behavior when it happens"
                                    // summary; this is a trend line, where
                                    // skipping the healthy intervals would
                                    // misleadingly connect two retry bursts
                                    // directly together with no flat
                                    // stretch between them). Unconditional
                                    // append (timestamped null when
                                    // unavailable) - see TimeSeriesPoint's
                                    // own doc comment.
                                    sample.tcpRetry.takeIf { it >= 0 }?.let { it.toDouble() }.let {
                                        retryHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                        if (retryHistory.size > HISTORY_SAFETY_CAP) retryHistory.removeFirst()
                                        _retryHistoryFlow.value = retryHistory.toList()
                                    }
                                    // No -1 sentinel to guard against here (unlike
                                    // the fields above) - 0 is both "unavailable"
                                    // and a legitimate reading for these kernel
                                    // cumulative counters, see IntervalSample's
                                    // own doc comment - so every sample counts.
                                    sndBufLimitedAcc.add(sample.sndBufLimitedUs.toDouble())
                                    rwndLimitedAcc.add(sample.rwndLimitedUs.toDouble())
                                    busyTimeAcc.add(sample.busyTimeUs.toDouble())
                                    flowingAcc.add(
                                        (sample.busyTimeUs - sample.sndBufLimitedUs - sample.rwndLimitedUs).coerceAtLeast(0).toDouble(),
                                    )
                                }
                                TestMode.UDP_L4S -> {
                                    // CE marks/sec, not the raw per-interval count -
                                    // cntCE is scoped to whatever -i interval length
                                    // is configured (see CsvLineParser), so dividing
                                    // by the interval's own duration keeps this a
                                    // rate comparable to pps instead of assuming -i 1.
                                    val intervalSecs = sample.intervalEndSecs - sample.intervalStartSecs
                                    // MiniSparkline pair for
                                    // CeMarksPerSecMeter - every interval
                                    // (including zero-mark ones), unlike
                                    // ceMarksWhenMarkingAcc's own > 0
                                    // exclusion just below - a trend line
                                    // needs the flat zero stretches to
                                    // read the bursts against. null (a
                                    // timestamped gap, see TimeSeriesPoint's
                                    // own doc comment) when ceCount itself
                                    // is unavailable or this interval was
                                    // degenerate (zero-length, can't derive
                                    // a rate) - always appended either way.
                                    val ceMarksPerSec = if (sample.ceCount >= 0 && intervalSecs > 0.0) sample.ceCount / intervalSecs else null
                                    ceMarksPerSec?.let { ceMarksAcc.add(it) }
                                    ceMarksPerSecHistory.addLast(TimeSeriesPoint(ceMarksPerSec, sample.intervalEndSecs))
                                    if (ceMarksPerSecHistory.size > HISTORY_SAFETY_CAP) ceMarksPerSecHistory.removeFirst()
                                    _ceMarksPerSecHistoryFlow.value = ceMarksPerSecHistory.toList()
                                    // Same rate, only on intervals where marking
                                    // actually happened - see ceMarksWhenMarkingAcc's
                                    // own doc comment for why this is a distinct,
                                    // equally real statistic, not a duplicate.
                                    if (sample.ceCount > 0 && intervalSecs > 0.0) {
                                        ceMarksWhenMarkingAcc.add(sample.ceCount / intervalSecs)
                                    }
                                    // MiniSparkline pair for PacketsPerSecMeter.
                                    // Unconditional append (timestamped null
                                    // when unavailable) - see
                                    // TimeSeriesPoint's own doc comment.
                                    sample.packetsPerSec.takeIf { it >= 0.0 }.let {
                                        ppsHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                        if (ppsHistory.size > HISTORY_SAFETY_CAP) ppsHistory.removeFirst()
                                        _ppsHistoryFlow.value = ppsHistory.toList()
                                    }
                                    // Little's Law queueing estimate (write/
                                    // upload direction only - see IntervalSample's
                                    // doc comment on why these are -1 in --reverse).
                                    // Unit conversions (us->ms, Bytes->KB) mirror
                                    // rttMicros/bytesInFlight's own conventions
                                    // above/below, so the resulting meters are
                                    // apples-to-apples with TCP's RTT/bytes-in-
                                    // flight meters, not just visually similar.
                                    sample.queueDelayUs.takeIf { it >= 0 }?.let { queueDelayAcc.add(it / 1000.0) }
                                    sample.queueBytes.takeIf { it >= 0 }?.let { queueBytesAcc.add(it / 1024.0) }
                                    // Packets version of the same Little's Law estimate
                                    // (see TestConfig.queueUnitsPackets) - packetsPerSec
                                    // * queueing delay, both already parsed off this same
                                    // sample, so no native/CSV change needed for it.
                                    val liveQueuePackets = if (sample.packetsPerSec >= 0.0 && sample.queueDelayUs >= 0) {
                                        sample.packetsPerSec * (sample.queueDelayUs / 1_000_000.0)
                                    } else {
                                        null
                                    }
                                    liveQueuePackets?.let { queuePacketsAcc.add(it) }
                                    // Raw RTT queueDelayAcc's own estimate is
                                    // derived from - see l4sRttAcc's own doc
                                    // comment above for why this gets shown
                                    // as its own dial rather than only ever
                                    // appearing pre-subtracted.
                                    sample.l4sRttUs.takeIf { it >= 0 }?.let { l4sRttAcc.add(it / 1000.0) }
                                    // Direct, RTT-independent window/inflight/
                                    // marking-probability measurements - see
                                    // l4sPacketWindowAcc's own doc comment.
                                    sample.l4sPacketWindow.takeIf { it >= 0 }?.let { l4sPacketWindowAcc.add(it.toDouble()) }
                                    sample.l4sInflight.takeIf { it >= 0 }?.let { l4sInflightAcc.add(it.toDouble()) }
                                    // Atomic triple, only a real value when all
                                    // three are available on this same interval -
                                    // same "keep the three lines aligned"
                                    // reasoning as cwndInflightHistory's own doc
                                    // comment. Unconditional append either way (a
                                    // timestamped null otherwise, not a skipped
                                    // interval) - see Timestamped's own doc
                                    // comment.
                                    val windowInflightPoint = if (sample.l4sPacketWindow >= 0 && sample.l4sInflight >= 0 && liveQueuePackets != null) {
                                        WindowInflightPoint(
                                            sample.l4sPacketWindow.toDouble(),
                                            sample.l4sInflight.toDouble(),
                                            liveQueuePackets,
                                        )
                                    } else {
                                        null
                                    }
                                    windowInflightHistory.addLast(Timestamped(windowInflightPoint, sample.intervalEndSecs))
                                    if (windowInflightHistory.size > HISTORY_SAFETY_CAP) windowInflightHistory.removeFirst()
                                    _windowInflightHistoryFlow.value = windowInflightHistory.toList()
                                    sample.l4sMarkingProb.takeIf { it >= 0 }?.let { l4sMarkingProbAcc.add(it.toDouble()) }
                                    // MiniSparkline pair for
                                    // MarkingProbabilityMeter - converted to
                                    // percent here (same as l4sMarkingProbAcc's
                                    // own raw 0..1<<20 scale->percent
                                    // conversion at display time), so the
                                    // history is already in the unit the
                                    // dial/chart actually show. Unconditional
                                    // append (timestamped null when
                                    // unavailable) - see TimeSeriesPoint's
                                    // own doc comment.
                                    sample.l4sMarkingProb.takeIf { it >= 0 }?.let { 100.0 * it / (1 shl 20) }.let {
                                        markProbHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                        if (markProbHistory.size > HISTORY_SAFETY_CAP) markProbHistory.removeFirst()
                                        _markProbHistoryFlow.value = markProbHistory.toList()
                                    }
                                    // Reader's own locally-tracked loss - both
                                    // directions, not write/upload-only like
                                    // the PragueCC fields above. Unconditional
                                    // append (timestamped null when
                                    // unavailable) - see TimeSeriesPoint's
                                    // own doc comment.
                                    sample.errPercent.takeIf { it >= 0.0 }?.let { errPercentAcc.add(it) }
                                    sample.errPercent.takeIf { it >= 0.0 }.let {
                                        lossPercentHistory.addLast(TimeSeriesPoint(it, sample.intervalEndSecs))
                                        if (lossPercentHistory.size > HISTORY_SAFETY_CAP) lossPercentHistory.removeFirst()
                                        _lossPercentHistoryFlow.value = lossPercentHistory.toList()
                                    }
                                }
                                TestMode.BOUNCEBACK -> {
                                    sample.requestsPerSec.takeIf { it >= 0.0 }?.let { bbRequestsAcc.add(it) }
                                    // CE marks/sec - both TCP bounceback (kernel
                                    // TCP_INFO tcpi_delivered_ce/tcpi_delivered)
                                    // and UDP-L4S bounceback (PragueCC) now
                                    // populate sample.ceCount/cePercent, so this
                                    // mirrors the same accumulator logic
                                    // TestMode.UDP_L4S above already uses - see
                                    // ceMarksAcc/ceMarksWhenMarkingAcc's own
                                    // doc comments for the distinction between
                                    // them.
                                    val intervalSecs = sample.intervalEndSecs - sample.intervalStartSecs
                                    val ceMarksPerSec = if (sample.ceCount >= 0 && intervalSecs > 0.0) sample.ceCount / intervalSecs else null
                                    ceMarksPerSec?.let { ceMarksAcc.add(it) }
                                    ceMarksPerSecHistory.addLast(TimeSeriesPoint(ceMarksPerSec, sample.intervalEndSecs))
                                    if (ceMarksPerSecHistory.size > HISTORY_SAFETY_CAP) ceMarksPerSecHistory.removeFirst()
                                    _ceMarksPerSecHistoryFlow.value = ceMarksPerSecHistory.toList()
                                    if (sample.ceCount > 0 && intervalSecs > 0.0) {
                                        ceMarksWhenMarkingAcc.add(sample.ceCount / intervalSecs)
                                    }
                                }
                            }
                            _throughputStats.value = throughputAcc.snapshot()
                            _rttStats.value = rttOrJitterAcc.snapshot()
                            _inFlightStats.value = inFlightAcc.snapshot()
                            _packetsInFlightStats.value = packetsInFlightAcc.snapshot()
                            _cwndStats.value = cwndAcc.snapshot()
                            _retryStats.value = retryAcc.snapshot()
                            _notSentStats.value = notSentAcc.snapshot()
                            _tcpExcessRttStats.value = tcpExcessRttAcc.snapshot()
                            _sndBufStats.value = sndBufAcc.snapshot()
                            _writeTimeStats.value = writeTimeAcc.snapshot()
                            _sndBufLimitedStats.value = sndBufLimitedAcc.snapshot()
                            _rwndLimitedStats.value = rwndLimitedAcc.snapshot()
                            _busyTimeStats.value = busyTimeAcc.snapshot()
                            _flowingStats.value = flowingAcc.snapshot()
                            _ceMarksStats.value = ceMarksAcc.snapshot()
                            _ceMarksWhenMarkingStats.value = ceMarksWhenMarkingAcc.snapshot()
                            _queueDelayStats.value = queueDelayAcc.snapshot()
                            _queueBytesStats.value = queueBytesAcc.snapshot()
                            _queuePacketsStats.value = queuePacketsAcc.snapshot()
                            _l4sRttStats.value = l4sRttAcc.snapshot()
                            _l4sPacketWindowStats.value = l4sPacketWindowAcc.snapshot()
                            _l4sInflightStats.value = l4sInflightAcc.snapshot()
                            _l4sMarkingProbStats.value = l4sMarkingProbAcc.snapshot()
                            _errPercentStats.value = errPercentAcc.snapshot()
                            _bbRequestsStats.value = bbRequestsAcc.snapshot()
                        }
                    } else if (isFinalSummaryLine) {
                        // Deliberately ignored - see comment above. Not a
                        // status message either, so don't fall through to
                        // the branch below and show raw CSV text as one.
                    } else if (mode == TestMode.BOUNCEBACK && config.value.workingLoadEnabled &&
                        (CsvLineParser.parseWorkingLoadUploadThroughput(line, serverPort)?.let { reading ->
                            // Deliberate SIGUSR1 pause: this app is the one
                            // that sent the signal (onToggleWorkingLoadPause),
                            // so isWorkingLoadPaused.value is already an
                            // authoritative "am I paused right now" signal -
                            // no need to round-trip a marker through the CSV
                            // itself (reading.paused, TCP-write shape only,
                            // never existed for UDP-L4S or for the reversed/
                            // down direction at all). Covers every transport/
                            // direction uniformly instead of just TCP-up.
                            //
                            // The live readout still shows 0, but the
                            // history gets a timestamped null (TimeSeriesPoint's
                            // own established convention - see its doc
                            // comment) rather than a real 0.0 point:
                            // MiniSparkline already breaks the line across a
                            // null instead of interpolating through it, so
                            // the chart shows a genuine gap - not a
                            // misleading zero dip indistinguishable from a
                            // real stall - while its x-axis keeps advancing
                            // on wall-clock time regardless (every point is
                            // timestamped by its own elapsed time, not
                            // index). Deliberately NOT added to
                            // workingLoadUpAcc either - a paused interval's
                            // 0 Mbps shouldn't skew the running min/avg/max.
                            if (_isWorkingLoadPaused.value || reading.paused) {
                                _workingLoadUpMbps.value = 0.0
                                workingLoadUpHistory.addLast(TimeSeriesPoint(null, reading.intervalEndSecs))
                                if (workingLoadUpHistory.size > HISTORY_SAFETY_CAP) workingLoadUpHistory.removeFirst()
                                _workingLoadUpHistoryFlow.value = workingLoadUpHistory.toList()
                            } else {
                                val mbps = reading.speedBitsPerSec / 1_000_000.0
                                _workingLoadUpMbps.value = mbps
                                workingLoadUpAcc.add(mbps)
                                _workingLoadUpStats.value = workingLoadUpAcc.snapshot()
                                workingLoadUpHistory.addLast(TimeSeriesPoint(mbps, reading.intervalEndSecs))
                                if (workingLoadUpHistory.size > HISTORY_SAFETY_CAP) workingLoadUpHistory.removeFirst()
                                _workingLoadUpHistoryFlow.value = workingLoadUpHistory.toList()
                            }
                        } ?: CsvLineParser.parseWorkingLoadDownloadThroughput(line, serverPort)?.let { reading ->
                            // Same reasoning as the up-direction branch above -
                            // isWorkingLoadPaused.value is what makes a
                            // deliberate SIGUSR1 pause on the reversed/down
                            // direction distinguishable from a real stall
                            // here too, which nothing else did before (the
                            // reversed writer is server-spawned/wire-relayed,
                            // so there was never a CSV marker for this
                            // direction to check in the first place).
                            if (_isWorkingLoadPaused.value) {
                                _workingLoadDownMbps.value = 0.0
                                workingLoadDownHistory.addLast(TimeSeriesPoint(null, reading.intervalEndSecs))
                                if (workingLoadDownHistory.size > HISTORY_SAFETY_CAP) workingLoadDownHistory.removeFirst()
                                _workingLoadDownHistoryFlow.value = workingLoadDownHistory.toList()
                            } else {
                                val mbps = reading.speedBitsPerSec / 1_000_000.0
                                _workingLoadDownMbps.value = mbps
                                workingLoadDownAcc.add(mbps)
                                _workingLoadDownStats.value = workingLoadDownAcc.snapshot()
                                workingLoadDownHistory.addLast(TimeSeriesPoint(mbps, reading.intervalEndSecs))
                                if (workingLoadDownHistory.size > HISTORY_SAFETY_CAP) workingLoadDownHistory.removeFirst()
                                _workingLoadDownHistoryFlow.value = workingLoadDownHistory.toList()
                            }
                        }) != null
                    ) {
                        // Working load's own interleaved report line (either
                        // direction) - see parseWorkingLoadUploadThroughput's
                        // doc comment. Already handled above (the relevant
                        // bar graph's live value and running stats were
                        // just updated); explicitly not falling through to
                        // the status-message branch below for it.
                    } else if (CsvLineParser.isSumRow(line)) {
                        // iperf2's own "Sum" aggregate row (see
                        // CsvLineParser.isSumRow) - not real per-connection
                        // data, [parse] already rejected it as a sample
                        // (sample == null here), so just discard it rather
                        // than let it fall through and flash as a raw CSV
                        // status message once per interval.
                    } else if (CsvLineParser.isBenignBounceBackEndOfTestInterrupt(line)) {
                        // Expected on every completed bounceback run (see
                        // CsvLineParser.isBenignBounceBackEndOfTestInterrupt)
                        // - discard rather than show as if something failed.
                    } else if (mode == TestMode.BOUNCEBACK &&
                        CsvLineParser.parseBounceBackHistogram(line)?.let {
                            _bbHistogram.value = it
                            // The exact raw bytes the native side itself
                            // printed, not a Kotlin-reconstructed row - see
                            // saveGoldenHistogram()'s own doc comment for
                            // why this needs to be the untouched original
                            // rather than reformatted from the parsed
                            // BounceBackHistogram fields.
                            _bbHistogramRawLine.value = line
                        } != null
                    ) {
                        // The full-run request/reply time distribution summary (see
                        // CsvLineParser.parseBounceBackHistogram's own doc
                        // comment) - printed exactly once, right after the
                        // last interval's own report, so this naturally
                        // fires at most once per run. Guarded to
                        // TestMode.BOUNCEBACK the same way the working-load
                        // branch above is - the "BB8"-named-histogram match
                        // inside the parser itself is already specific
                        // enough on its own, but this keeps the check
                        // consistent with every other mode-gated branch
                        // here. Explicitly not falling through to the
                        // status-message branch below for it, same as every
                        // other already-handled special line above.
                    } else if (line.isNotBlank() && !CsvLineParser.isHeaderLine(line)) {
                        _statusMessage.value = line
                        // Matches Reporter.c's own wording ("tcp connect to
                        // %s port %d failed (%s) on %s") rather than a
                        // generic "contains 'failed'" check, so unrelated
                        // warnings don't light the LED.
                        if (line.contains("tcp connect to") && line.contains("failed")) {
                            _connectFailed.value = true
                            _hadConnectRetry.value = true
                        }
                        // Exact substring match against Client.cpp's own
                        // wording (PostReport(InitStringReport(...)), see
                        // that call site's own doc comment) - not derived
                        // from any parsed CSV field, see _l4sCeConfirmed's
                        // own doc comment above for why.
                        if (line.contains("L4S CE marking confirmed")) {
                            _l4sCeConfirmed.value = true
                        }
                        if (line.contains("L4S reply-direction ECN bleaching detected")) {
                            _l4sReplyBleachDetected.value = true
                        }
                        if (line.contains("L4S request-direction ECN bleaching detected")) {
                            _l4sReqBleachDetected.value = true
                        }
                        if (line.contains("L4S reply-direction ECN confirmed intact")) {
                            _l4sReplyConfirmed.value = true
                        }
                        if (line.contains("L4S request-direction ECN confirmed intact")) {
                            _l4sReqConfirmed.value = true
                        }
                        // Capacity's own UDP L4S stream (Client::RunUDPL4S) -
                        // see _capacityL4sConfirmed's own doc comment above.
                        if (line.contains("L4S ECN confirmed intact")) {
                            _capacityL4sConfirmed.value = true
                        }
                        if (line.contains("L4S ECN bleaching detected")) {
                            _capacityL4sBleachDetected.value = true
                        }
                        // Matches Client.cpp's own end-of-run summary line
                        // (WARN_REPORT_FMT, "udp bounceback: %u stale
                        // replies discarded this run") - substring only,
                        // not the count, since that varies per run. Fires
                        // once at test teardown, so this only ever flips
                        // false->true near the very end of a run.
                        if (line.contains("stale replies discarded this run")) {
                            _bbStaleReplyDetected.value = true
                        }
                    }
                }
            } catch (e: Exception) {
                // A launch failure (e.g. the binary missing/not executable)
                // must not crash the app - surface it in the status line
                // instead. This is exactly what caught the useLegacyPackaging
                // packaging bug: ProcessBuilder.start() threw an uncaught
                // IOException here before this try/catch existed.
                _statusMessage.value = "Failed to start: ${e.message}"
            }
            // Flow completed - either the test finished (duration elapsed),
            // the process was stopped, or it failed to start; either way
            // we're back to idle.
            setRunning(false)
        }
        startConnectWatchdog()
    }

    // Client::my_connect() (src/Client.cpp) is a plain blocking connect() on
    // Linux/Android - for an actively-refused host that returns almost
    // instantly (ECONNREFUSED), but for an unreachable/black-holed host
    // there's no app-level bound at all, only the kernel's own TCP SYN-retry
    // timeout (commonly 20-130+ seconds). Rather than changing that
    // cross-platform C connect logic, this is an app-side watchdog: if no
    // sample has arrived within a few seconds of Start, treat it the same
    // as iperf2's own connect-failure message (red LED + status text) and
    // stop the hung process ourselves.
    private fun startConnectWatchdog() {
        val timeoutMs = maxOf(CONNECT_WATCHDOG_MIN_MS, (_config.value.intervalSecs * 2 * 1000).toLong())
        viewModelScope.launch {
            delay(timeoutMs)
            if (_isRunning.value && _latestSample.value == null) {
                _connectFailed.value = true
                _statusMessage.value = "Connect timed out after ${timeoutMs / 1000}s"
                runner.stop()
                setRunning(false)
            }
        }
    }

    fun onStop() {
        viewModelScope.launch {
            runner.stop()
            setRunning(false)
        }
    }

    /**
     * A/B compare: freezes the current (just-completed) run's meter stats -
     * full [TestConfig] included, not just host/port/duration, so a saved
     * preset always shows exactly what was set (mode, tcp-cca, everything)
     * without the user needing to reopen the settings panel - into preset
     * [slot] (one of [PRESET_SLOTS]). Car-radio-preset semantics: safe to
     * call again later to overwrite that slot with a newer run: there's
     * only ever one saved run per slot, not a multi-run history. Also
     * switches straight to viewing the slot just saved (a car radio jumps
     * to the station you just held down a preset for - there's nothing
     * else useful to look at right after saving it).
     */
    fun saveCurrentAs(slot: Char) {
        val snapshot = RunSnapshot(
            config = _config.value,
            savedAtMillis = System.currentTimeMillis(),
            throughputStats = _throughputStats.value,
            rttStats = _rttStats.value,
            inFlightStats = _inFlightStats.value,
            packetsInFlightStats = _packetsInFlightStats.value,
            cwndStats = _cwndStats.value,
            retryStats = _retryStats.value,
            notSentStats = _notSentStats.value,
            tcpExcessRttStats = _tcpExcessRttStats.value,
            sndBufStats = _sndBufStats.value,
            writeTimeStats = _writeTimeStats.value,
            sndBufLimitedStats = _sndBufLimitedStats.value,
            rwndLimitedStats = _rwndLimitedStats.value,
            busyTimeStats = _busyTimeStats.value,
            flowingStats = _flowingStats.value,
            ceMarksStats = _ceMarksStats.value,
            ceMarksWhenMarkingStats = _ceMarksWhenMarkingStats.value,
            queueDelayStats = _queueDelayStats.value,
            queueBytesStats = _queueBytesStats.value,
            queuePacketsStats = _queuePacketsStats.value,
            l4sRttStats = _l4sRttStats.value,
            l4sPacketWindowStats = _l4sPacketWindowStats.value,
            l4sInflightStats = _l4sInflightStats.value,
            l4sMarkingProbStats = _l4sMarkingProbStats.value,
            errPercentStats = _errPercentStats.value,
            bbRequestsStats = _bbRequestsStats.value,
            bbHistogram = _bbHistogram.value,
            bbRttMinUs = _bbRttMinUs.value,
            bbHistogramRawLine = _bbHistogramRawLine.value,
            workingLoadUpStats = _workingLoadUpStats.value,
            workingLoadDownStats = _workingLoadDownStats.value,
            workingLoadUpHistory = _workingLoadUpHistoryFlow.value,
            workingLoadDownHistory = _workingLoadDownHistoryFlow.value,
            sparklineHistory = _sparklineHistoryFlow.value,
            bbRequestsHistory = _bbRequestsHistoryFlow.value,
            rttHistory = _rttHistoryFlow.value,
            throughputHistory = _throughputHistoryFlow.value,
            ceDurationHistory = _ceDurationHistoryFlow.value,
            writeTimeHistory = _writeTimeHistoryFlow.value,
            retryHistory = _retryHistoryFlow.value,
            cwndInflightHistory = _cwndInflightHistoryFlow.value,
            windowInflightHistory = _windowInflightHistoryFlow.value,
            ppsHistory = _ppsHistoryFlow.value,
            ceMarksPerSecHistory = _ceMarksPerSecHistoryFlow.value,
            markProbHistory = _markProbHistoryFlow.value,
            lossPercentHistory = _lossPercentHistoryFlow.value,
        )
        _savedRuns.value = _savedRuns.value + (slot to snapshot)
        _viewingSlot.value = slot
        // Config half (host/port/mode/every toggle) via TestConfigStore,
        // results half (every *Stats/history/histogram field) via
        // RunSnapshotStore - see RunSnapshotStore's own doc comment for why
        // these are two separate stores rather than one. Together they let
        // loadPresetSnapshot() rebuild this slot's full charts on the next
        // app start, not just its config.
        TestConfigStore.savePreset(getApplication(), slot, _config.value, snapshot.savedAtMillis)
        RunSnapshotStore.save(getApplication(), slot, snapshot)
        // Overwriting the reference slot's own content demotes it back to a
        // plain checkmark: the star was earned by the data that used to be
        // here, not this new run, so it needs a fresh promote hold (see
        // promoteSlotToGolden) before it counts as "the reference" again.
        if (_goldenSlot.value == slot) {
            _goldenSlot.value = null
            GoldenHistogramStore.clearSourceSlot(getApplication())
        }
    }

    /** Preset compare: switches which slot's meters are shown - null = live. See [viewingSlot]. */
    fun setViewingSlot(slot: Char?) {
        _viewingSlot.value = slot
    }

    /**
     * Promotes the run already saved in preset [slot] to be the reference -
     * RunCompareTabs' own second hold on an already-checkmarked slot
     * (IperfScreen.kt; see that composable's own class doc comment for the
     * full one-hold/two-hold state machine). The three-state button/star
     * itself is mode-agnostic - works the same for TCP, BOUNCEBACK, and
     * UDP-L4S presets alike, a plain "this is my baseline to compare
     * everything else against" bookmark. Only [saveGoldenHistogram]'s own
     * raw-bytes write is BOUNCEBACK-specific (there's no equivalent
     * histogram-baseline concept for TCP/UDP-L4S), so it's gated separately
     * and just skipped when the slot has no histogram data - deliberately
     * *not* cleared in that case either: the previous BOUNCEBACK golden
     * data is still perfectly valid, just dormant while the star happens
     * to point at a different-mode slot, and the run it came from might
     * get starred again later. It's never lost either way - it lives in
     * that other slot's own RunSnapshot.bbHistogramRawLine, untouched by
     * this function - but leaving GoldenHistogramStore's own file as-is
     * means a BOUNCEBACK view in the meantime still gets a working EMD
     * comparison instead of "no reference" for no real reason.
     * [_goldenSlot] itself always gets set regardless of mode, since that's
     * the actual "only one reference at a time" enforcement, not
     * [saveGoldenHistogram]. Reads straight from [_savedRuns] rather than
     * trusting whatever RunSnapshot the caller's own composition last saw -
     * that value can still be the pre-save one mid-gesture (Compose hasn't
     * recomposed with the just-written slot yet), while this ViewModel's
     * own state is always current the instant saveCurrentAs() returns.
     * A no-op if the slot has nothing saved at all (e.g. RunCompareTabs
     * somehow fired this on an empty slot).
     *
     * Whichever slot was previously the reference is implicitly demoted
     * the instant this reassigns _goldenSlot (its own RunCompareTabs tab
     * falls back to a plain checkmark, since it's still saved - just no
     * longer *the* reference).
     */
    fun promoteSlotToGolden(slot: Char) {
        val snapshot = _savedRuns.value[slot] ?: return
        snapshot.bbHistogramRawLine?.let { saveGoldenHistogram(it) }
        _goldenSlot.value = slot
        GoldenHistogramStore.saveSourceSlot(getApplication(), slot)
    }

    /**
     * Saves [rawCsvLine] (whatever histogram is currently being viewed -
     * live or a saved A/B/C/D preset, see IperfScreen's own
     * effBbHistogramRawLine) as the "golden" reference future runs compare
     * against (see GoldenHistogramStore, IperfCommandBuilder's own
     * --histogram-baseline wiring) - the exact raw CSV line the native
     * binary printed, not a Kotlin-reconstructed row.
     *
     * Deliberately only ever called from a user tap (BounceBackHistogramChart's
     * own "Save as golden" button, IperfScreen) - never automatic, and
     * never set up *before* a run the way the native CLI's own
     * --histogram-baseline-save flag can be (that flag is standalone/
     * CLI-only, e.g. for a scripted calibration run - see that option's
     * own doc comment, Settings.cpp - and is never something this app
     * itself passes). A "golden" run should be one the user actually
     * looked at and judged good - which is exactly why this works from a
     * saved preset too, not just the live view: reviewing which run
     * deserves to be golden is naturally something you do by looking back
     * at a preset, not necessarily while it's still live.
     */
    fun saveGoldenHistogram(rawCsvLine: String) {
        GoldenHistogramStore.save(getApplication(), rawCsvLine)
        _goldenHistogram.value = GoldenHistogramStore.load(getApplication())
        _goldenHistogramRawLine.value = GoldenHistogramStore.loadRaw(getApplication())
    }

    // viewModelScope being cancelled on ViewModel clear does NOT by itself
    // destroy() the subprocess - the collect{} coroutine is typically
    // parked in a blocking read (see IperfProcessRunner.start()), which
    // isn't cancellation-aware, so a cleared ViewModel could otherwise
    // leave iperf running orphaned in the background for the rest of its
    // -t duration. destroyNow() is the explicit, synchronous fix (no
    // coroutine scope survives into onCleared() to call suspend fun stop()).
    // setRunning(false) (also plain/synchronous, not suspend) stops
    // IperfForegroundService alongside it - nothing should hold that
    // exemption once there's no ViewModel left to ever call setRunning(true)
    // again.
    override fun onCleared() {
        super.onCleared()
        runner.destroyNow()
        setRunning(false)
    }
}

// Floor for the connect watchdog - see startConnectWatchdog(). Scaled up by
// the configured interval (rather than left fixed) so a legitimately large
// --interval doesn't get mistaken for a hung connect: the first CSV row
// can't arrive before the first interval boundary elapses anyway.
private const val CONNECT_WATCHDOG_MIN_MS = 5_000L

// BOUNCEBACK live sparkline - see WindowedWelfordStats. An 8-second window
// keeps the mean responsive to a working-load pause/resume within a few
// report intervals, while still averaging enough iid-ish samples for the
// CLT justification in WindowedWelfordStats' own doc comment to hold. A
// raw sample COUNT (the previous approach) doesn't work here: since
// LiveSparkline's chart axis spans the whole run rather than scrolling, a
// count-based window the same size as (or larger than) a typical run's
// total sample count silently degrades into a lifetime/cumulative average
// for that whole run - exactly what let it track an early transition (the
// initial dip) but barely respond to a later one. Neither this value nor
// the 10Hz render tick below is tied to any iperf2-side constant.
private const val LIVE_WINDOW_SECS = 8.0
private const val LIVE_RENDER_TICK_MS = 100L

// Every *History field above is retention-capped at this, sparklineHistory
// included (it appends 10x faster, at LIVE_RENDER_TICK_MS, than the
// others' one-per-reporting-interval rate). This is purely a defensive
// backstop against unbounded growth on a "run until Stop" test
// (TestConfig.durationSecs == -1, no fixed end) left running a very long
// time - NOT the thing that determines how much history a chart actually
// shows. That's now driven by the chart's own axis span (fixed at the
// run's configured duration when known - see MiniSparkline.kt's
// axisSpanSecs doc comment), so points stay positioned by real elapsed
// time instead of by list index, and this cap can stay generously large
// without affecting correctness the way a small one used to (a small cap
// used to force the chart to silently roll to a fixed trailing window well
// before a test ended, e.g. sparklineHistory rolling after ~10s regardless
// of run length - see MiniSparkline's own doc comment for the full story).
// 20,000 covers hours of runtime even at sparklineHistory's 10Hz rate.
private const val HISTORY_SAFETY_CAP = 20_000

/** Preset compare slot names, in display/tab order - see [IperfViewModel.savedRuns]. */
val PRESET_SLOTS = listOf('A', 'B', 'C', 'D')

/**
 * Rebuilds [slot]'s full [RunSnapshot] from whatever TestConfigStore.
 * loadPreset()/RunSnapshotStore.load() persisted, or null if [slot] was
 * never saved (or was cleared). RunSnapshotStore.load() returning null
 * (results file missing, or unparseable - e.g. an older install predating
 * a field this version added) falls back to the same stats-null,
 * empty-history placeholder this app used before RunSnapshotStore existed -
 * the meters already know how to render that (null-stats, isRunning=false)
 * state, same as any freshly-saved-but-not-yet-run slot, so a technician
 * still sees the slot's host/port/mode/etc. immediately even without its
 * charts.
 */
private fun loadPresetSnapshot(application: Application, slot: Char): RunSnapshot? {
    val (config, savedAtMillis) = TestConfigStore.loadPreset(application, slot) ?: return null
    RunSnapshotStore.load(application, slot, config, savedAtMillis)?.let { return it }
    return RunSnapshot(
        config = config,
        savedAtMillis = savedAtMillis,
        throughputStats = null,
        rttStats = null,
        inFlightStats = null,
        packetsInFlightStats = null,
        cwndStats = null,
        retryStats = null,
        notSentStats = null,
        tcpExcessRttStats = null,
        sndBufStats = null,
        writeTimeStats = null,
        sndBufLimitedStats = null,
        rwndLimitedStats = null,
        busyTimeStats = null,
        flowingStats = null,
        ceMarksStats = null,
        ceMarksWhenMarkingStats = null,
        queueDelayStats = null,
        queueBytesStats = null,
        queuePacketsStats = null,
        l4sRttStats = null,
        l4sPacketWindowStats = null,
        l4sInflightStats = null,
        l4sMarkingProbStats = null,
        errPercentStats = null,
        bbRequestsStats = null,
        bbHistogram = null,
        bbRttMinUs = null,
        bbHistogramRawLine = null,
        workingLoadUpStats = null,
        workingLoadDownStats = null,
        sparklineHistory = emptyList(),
        bbRequestsHistory = emptyList(),
        workingLoadUpHistory = emptyList(),
        workingLoadDownHistory = emptyList(),
        rttHistory = emptyList(),
        throughputHistory = emptyList(),
        ceDurationHistory = emptyList(),
        writeTimeHistory = emptyList(),
        retryHistory = emptyList(),
        cwndInflightHistory = emptyList(),
        windowInflightHistory = emptyList(),
        ppsHistory = emptyList(),
        ceMarksPerSecHistory = emptyList(),
        markProbHistory = emptyList(),
        lossPercentHistory = emptyList(),
    )
}

// Always shown in the --tcp-cca chip row (IperfScreen), greyed out/disabled
// when CcaProbe finds the kernel doesn't actually support one (e.g.
// "prague" needs a patched kernel most stock devices don't have) - a fixed,
// predictable set of choices reads better than a row that silently changes
// shape per device, even though only the available ones are selectable.
val REQUIRED_CCA_ALGORITHMS = listOf("cubic", "reno", "bbr", "prague")
