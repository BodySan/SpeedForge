import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Properties
import javax.inject.Inject

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Read straight from local.properties (gitignored) rather than chasing
// AGP's DSL surface for this - same reasoning/pattern as the sdk.dir/ndk.dir
// read further down for the native-build task. Declared up here (before the
// android{} block) so defaultConfig's buildConfigField below can see it.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

// Same source-of-truth files the release APK filename below derives its
// own version from (configure.ac's AC_INIT, include/version.h's
// IPERF_VERSION_DATE) - computed once up here, before defaultConfig,
// rather than duplicated where the filename logic used to parse these
// again on its own, so versionName/the filename can never drift apart.
val repoRootDir = project.layout.projectDirectory.dir("../..")
val iperfVersion = Regex("""AC_INIT\(\[Iperf\],\s*\[([^\]]+)\]""")
    .find(repoRootDir.file("configure.ac").asFile.readText())
    ?.groupValues?.get(1) ?: "unknown-version"
val iperfVersionDate = Regex("""IPERF_VERSION_DATE\s+"([^"]+)"""")
    .find(repoRootDir.file("include/version.h").asFile.readText())
    ?.groupValues?.get(1)?.replace(" ", "") ?: "unknown-date"

// Play Console rejects any upload whose versionCode doesn't strictly
// increase over every previous upload of this applicationId, forever -
// git's own commit count is a natural fit: monotonic as long as this
// branch only ever gains commits (true for how this repo is worked - see
// the git-workflow guidance in CLAUDE.md/session conventions, no rebase/
// amend on pushed history), and - unlike a wall-clock timestamp -
// reproducible from source alone and immune to clock skew between
// machines (relevant now that builds happen from more than one machine).
// Falls back to 1 rather than failing the build outright if git isn't
// available at all (e.g. a source tarball with no .git directory) - an
// actual Play Store upload from a state that degraded state would very
// likely fail its own versionCode check downstream anyway, but a source
// build for local testing shouldn't hard-fail just because of this.
val gitCommitCount = try {
    ProcessBuilder("git", "rev-list", "--count", "HEAD")
        .directory(repoRootDir.asFile)
        .redirectErrorStream(true)
        .start()
        .let { process ->
            val out = process.inputStream.bufferedReader().readText().trim()
            process.waitFor()
            out.toIntOrNull()
        }
} catch (e: Exception) {
    null
} ?: 1

// Escape hatch for when Play Console's already-uploaded max versionCode has
// gotten ahead of gitCommitCount (e.g. a prior manual/out-of-band upload, or
// re-uploading the same commit after a rejected/consumed code - Play never
// lets a versionCode be reused). Optional, gitignored, dev-machine-local -
// same local.properties pattern as permitKeySalt above. Unset (the normal
// case) falls straight back to gitCommitCount; set it only long enough to
// get back ahead of Play Console, then remove it so future builds resume
// tracking commits automatically.
val versionCodeOverride = localProps.getProperty("versionCodeOverride")?.toIntOrNull()

android {
    namespace = "com.rjmcmahon.iperf2client"
    // Matches the test device (Pixel 10 Pro, Android 16/API 36); also the
    // minimum compileSdk the 2025.09 Compose BOM/AndroidX libraries require.
    compileSdk = 36
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.rjmcmahon.iperf2client"
        // Matches the API level the NDK cross-compile targets below
        // (aarch64-linux-android24-clang etc.) - raising minSdk above this is
        // safe but pointless; lowering it means re-validating the NDK build
        // against an older API level first.
        minSdk = 24
        targetSdk = 36
        // See gitCommitCount/versionCodeOverride/iperfVersion+
        // iperfVersionDate's own doc comments above for where these come
        // from and why.
        versionCode = versionCodeOverride ?: gitCommitCount
        versionName = "$iperfVersion-$iperfVersionDate"

        // Secret salt mixed into the silent public-server permit-key (see
        // runner/PermitKeyProvider.kt) - lives only in the gitignored
        // local.properties, never in the public repo. Empty string (not a
        // real secret) if a developer hasn't set one, which just means the
        // computed permit-key won't match any real server - intentional,
        // not a build failure.
        buildConfigField("String", "PERMIT_KEY_SALT", "\"${localProps.getProperty("permitKeySalt", "")}\"")
        // Who this build is for, mixed into the silent permit-key as its own
        // ingredient (see runner/PermitKeyProvider.kt). Set by the build
        // engineer after checkout via local.properties `permitKeyBuildFor=`,
        // never committed. Empty by default, which leaves it out of the hash
        // entirely (plain versionInfo|salt|host formula).
        buildConfigField("String", "PERMIT_KEY_BUILD_FOR", "\"${localProps.getProperty("permitKeyBuildFor", "")}\"")
        // The public server this build's silent permit-key is meant to
        // authenticate against - see PermitKeyProvider for how it's used.
        // A plain compile-time constant (not from local.properties) since
        // it's not secret, just the one thing that's easy to get wrong if
        // ever changed without updating both client and server.
        buildConfigField("String", "PERMIT_HOST", "\"responde.fi-wi.com\"")
    }

    signingConfigs {
        // Release keystore lives entirely outside the repo (see
        // ~/.android-keystores/) - path/password/alias come from
        // local.properties (gitignored), same pattern as permitKeySalt
        // above. Only registered when all three are actually configured,
        // so a plain `assembleDebug` checkout with no release keystore set
        // up doesn't fail evaluating this block.
        if (localProps.getProperty("releaseKeystorePath") != null) {
            create("release") {
                storeFile = file(localProps.getProperty("releaseKeystorePath"))
                storePassword = localProps.getProperty("releaseKeystorePassword")
                keyAlias = localProps.getProperty("releaseKeyAlias")
                keyPassword = localProps.getProperty("releaseKeystorePassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (localProps.getProperty("releaseKeystorePath") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        // Matches the one complete JDK (with javac) available on the dev
        // machine (java-11-temurin-jdk; the java-17/21/25-openjdk entries
        // are JRE-only installs missing javac). Bump alongside installing a
        // newer *-devel/full JDK package.
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        // useLegacyPackaging = true forces AGP to actually extract native
        // libraries to a real file under nativeLibraryDir at install time
        // (the pre-API-23 "legacy" behavior). false (the modern default)
        // instead loads libiperf.so directly out of the APK zip via mmap,
        // with no file ever written to nativeLibraryDir - fine for a real
        // JNI shared library loaded via System.loadLibrary(), but fatal
        // here: ProcessBuilder needs a real file to exec(), and got none,
        // which is why the app crashed immediately on Start (confirmed via
        // `adb shell run-as ... ls lib/arm64/` showing that directory
        // completely empty).
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

// Self-describing release APK filename (e.g. iperf2.2.2_7July2026_android.apk)
// instead of AGP's generic app-release.apk - iperfVersion/iperfVersionDate
// computed once, above, alongside versionCode/versionName.
androidComponents {
    onVariants(selector().withBuildType("release")) { variant ->
        val apkName = "iperf${iperfVersion}_${iperfVersionDate}_android.apk"
        variant.outputs.forEach { output -> output.outputFileName.set(apkName) }
    }
}

// Explicit toolchain request so Gradle actually resolves a JDK with a real
// compiler for the Java compile tasks (see gradle.properties'
// org.gradle.java.installations.paths) rather than silently trying to use
// whatever JRE-only JVM happens to be running Gradle itself.
java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(11))
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    // Wifi/Cable were previously pulled from material-icons-extended, but
    // that library bundles ~11k classes (every icon x 5 style variants) for
    // just two icons - see ui/NetworkIcons.kt, which defines local copies of
    // just those two icons' path data instead. Removing this dependency
    // recovered ~4MB of unused classes.dex from the release APK.
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    // NotificationCompat, for IperfForegroundService's own ongoing
    // notification - the exemption a running test needs from Android's
    // background execution limits once the app is backgrounded.
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

// ---------------------------------------------------------------------------
// Native build: cross-compile the existing iperf2 CLI (../../.. from here is
// the repo root) with the Android NDK, per ABI, and drop the resulting
// binary into jniLibs/<abi>/libiperf.so. No source changes to iperf2 itself;
// this reuses the exact same ./configure && make build used everywhere else
// in the repo, just pointed at the NDK's per-API-level clang wrappers.
//
// Why shell out to autotools instead of porting to CMake/ndk-build: configure.ac
// has dozens of AC_CHECK_FUNCS/AC_CHECK_MEMBERS feature probes (IPv6, multicast,
// tcpstats/TCP_INFO members including the bytes-in-flight fields this app's
// meters depend on, sendmmsg/recvmmsg, etc.) that would otherwise need
// reimplementing as a second, drifting source of truth in CMake.
// ---------------------------------------------------------------------------

abstract class BuildIperfNativeTask : org.gradle.api.DefaultTask() {
    @get:Input
    abstract val abi: org.gradle.api.provider.Property<String>

    @get:Input
    abstract val hostTriple: org.gradle.api.provider.Property<String>

    @get:Input
    abstract val clangPrefix: org.gradle.api.provider.Property<String>

    @get:Input
    abstract val apiLevel: org.gradle.api.provider.Property<Int>

    // @Internal, not @InputDirectory: the NDK is a large, effectively-static
    // install - hashing it for up-to-date checks on every build is wasteful,
    // and it never changes within a project's lifetime in practice.
    @get:Internal
    abstract val ndkDir: org.gradle.api.file.DirectoryProperty

    // Used at execution time to resolve relative paths and run git ls-files;
    // not itself tracked for up-to-date checking (sourceFiles below, scoped
    // to just the directories/files actually read, is what's tracked -
    // declaring the whole repo root as an input would overlap with this
    // Android project's own jniLibs output dirs and confuse Gradle's
    // per-sibling-task dependency validation).
    @get:Internal
    abstract val repoRoot: org.gradle.api.file.DirectoryProperty

    // The actual incremental-build-relevant inputs: iperf2's C/C++ sources
    // and the autotools files needed to configure/build them. Scoped
    // precisely (not the whole repo root) so it doesn't overlap with this
    // task's own or its siblings' jniLibs/<abi>/libiperf.so outputs.
    @get:InputFiles
    @get:PathSensitive(org.gradle.api.tasks.PathSensitivity.RELATIVE)
    abstract val sourceFiles: org.gradle.api.file.ConfigurableFileCollection

    @get:OutputFile
    abstract val outputSo: org.gradle.api.file.RegularFileProperty

    // Set at configuration time from layout.buildDirectory (see registration
    // below) rather than read via Task.project at execution time, which is
    // deprecated (incompatible with the configuration cache).
    @get:Internal
    abstract val scratchBaseDir: org.gradle.api.file.DirectoryProperty

    @get:Inject
    abstract val execOps: org.gradle.process.ExecOperations

    @TaskAction
    fun build() {
        val abiValue = abi.get()
        val api = apiLevel.get()
        val ndk = ndkDir.get().asFile
        val root = repoRoot.get().asFile
        val scratch = File(scratchBaseDir.get().asFile, "native-src/$abiValue")

        // Fresh copy every time - autotools' own config.status/.deps make
        // incremental rebuilds fast once configure has run once per ABI, and
        // this Gradle task itself is skipped entirely on unrelated rebuilds
        // via the @InputFiles/@OutputFile declarations below.
        scratch.deleteRecursively()
        scratch.mkdirs()

        // Copy exactly the git-tracked files needed to build the CLI -
        // avoids any risk of stale generated artifacts (this repo's own
        // Linux-configured config.h/Makefile sitting in the working tree)
        // contaminating the cross-compile.
        val trackedFiles = ByteArrayOutputStream().use { out ->
            execOps.exec {
                commandLine(
                    "git", "-C", root.absolutePath, "ls-files",
                    "src", "include", "compat",
                    "configure", "config.h.in", "Makefile.in", "aclocal.m4",
                    "install-sh", "depcomp", "missing", "compile",
                    "config.guess", "config.sub", "test-driver",
                    // configure's AC_CONFIG_FILES lists these Makefiles even
                    // though the binary doesn't need their directories' full
                    // content - config.status refuses to run without them.
                    "doc/Makefile.in", "flows/Makefile.in", "man/Makefile.in"
                )
                standardOutput = out
            }
            out.toString(Charsets.UTF_8.name())
        }
        trackedFiles.lineSequence().filter { it.isNotBlank() }.forEach { relPath ->
            val src = File(root, relPath)
            val dst = File(scratch, relPath)
            dst.parentFile.mkdirs()
            src.copyTo(dst, overwrite = true)
            // File.copyTo() doesn't preserve POSIX permissions - configure
            // and the autotools aux scripts (install-sh, config.guess, etc.)
            // need their executable bit restored or ./configure can't run.
            if (src.canExecute()) dst.setExecutable(true)
        }

        val toolchainBin = File(ndk, "toolchains/llvm/prebuilt/linux-x86_64/bin")
        val cc = File(toolchainBin, "${clangPrefix.get()}$api-clang").absolutePath
        val cxx = File(toolchainBin, "${clangPrefix.get()}$api-clang++").absolutePath
        val ar = File(toolchainBin, "llvm-ar").absolutePath
        val ranlib = File(toolchainBin, "llvm-ranlib").absolutePath
        val strip = File(toolchainBin, "llvm-strip").absolutePath

        val env = mapOf(
            "CC" to cc, "CXX" to cxx, "AR" to ar, "RANLIB" to ranlib, "STRIP" to strip,
            "PATH" to "${toolchainBin.absolutePath}:${System.getenv("PATH")}"
        )

        execOps.exec {
            workingDir = scratch
            environment(env)
            // --enable-professional: makes the bundled binary's own `-v`
            // output include "(professional)" and "(compiled by
            // <IPERF_BUILD_USER>)" (IPERF_BUILD_USER itself comes from
            // `whoami` at configure time, not a flag - see configure.ac -
            // so it reflects whichever account runs this Gradle build).
            // PermitKeyProvider hashes this exact version string into the
            // silent permit-key, so this flag needs to be set consistently
            // for every build meant to authenticate against the public
            // server, matching the original client-gating design (professional
            // edition + compiled-by tag, not just "any udp-l4s build").
            // This alone is also what turns on UDP L4S support itself -
            // configure.ac no longer has a separate --enable-udp-l4s flag
            // (nor the old git-branch auto-detect, which never fired here
            // anyway since scratch/ is a plain file copy with no .git dir -
            // see trackedFiles above); --enable-professional implies it.
            commandLine(
                "./configure", "--host=${hostTriple.get()}", "--target=${hostTriple.get()}",
                "--enable-professional",
                "CC=$cc", "CXX=$cxx", "AR=$ar", "RANLIB=$ranlib", "STRIP=$strip"
            )
        }
        execOps.exec {
            workingDir = scratch
            environment(env)
            // -static-libstdc++: no libc++_shared.so on the device's default
            // library search path when run standalone via ProcessBuilder.
            // -Wl,-z,max-page-size=16384: 2025+ Play Store native library
            // 16KB page-size requirement.
            // Build only compat/ (libcompat.a, a link dependency of src/iperf)
            // and src/ (the CLI itself) - doc/man/flows aren't needed for the
            // binary and their actual content wasn't copied into scratch
            // (only their Makefile.in stubs, which config.status needs to
            // exist but which `make all` at the top level would otherwise
            // recurse into and fail on).
            commandLine(
                "make", "-C", "compat", "-j${Runtime.getRuntime().availableProcessors()}"
            )
        }
        execOps.exec {
            workingDir = scratch
            environment(env)
            commandLine(
                "make", "-C", "src", "-j${Runtime.getRuntime().availableProcessors()}",
                "LDFLAGS=-static-libstdc++ -Wl,-z,max-page-size=16384"
            )
        }

        val builtBinary = File(scratch, "src/iperf")
        val out = outputSo.get().asFile
        out.parentFile.mkdirs()
        builtBinary.copyTo(out, overwrite = true)
        execOps.exec {
            commandLine(strip, out.absolutePath)
        }
    }
}

data class IperfAbiTarget(val abiName: String, val hostTriple: String, val clangPrefix: String)

val iperfAbiTargets = listOf(
    IperfAbiTarget("arm64-v8a", "aarch64-linux-android", "aarch64-linux-android"),
    IperfAbiTarget("armeabi-v7a", "arm-linux-androideabi", "armv7a-linux-androideabi"),
    IperfAbiTarget("x86_64", "x86_64-linux-android", "x86_64-linux-android"),
    // 32-bit x86 is emulator-only in practice, but AndroidX pulls its own
    // x86 .so into the bundle, so Play generates an x86 split regardless -
    // without libiperf.so in it that split installs and then fails at Start.
    IperfAbiTarget("x86", "i686-linux-android", "i686-linux-android"),
)

// sdk.dir/ndk.dir straight from local.properties rather than chasing AGP's
// DSL surface for this (android.sdkDirectory/ndkDirectory aren't exposed the
// same way across AGP versions) - localProps itself is declared up near the
// top of the file (before android{}, for defaultConfig's buildConfigField).
val sdkDir = localProps.getProperty("sdk.dir") ?: System.getenv("ANDROID_HOME")
?: error("Set sdk.dir in local.properties or ANDROID_HOME env var")
val ndkPath = File(
    localProps.getProperty("ndk.dir") ?: System.getenv("ANDROID_NDK_HOME")
    ?: "$sdkDir/ndk/27.2.12479018"
)
// repoRootDir itself is declared up near the top of the file, alongside
// iperfVersion/gitCommitCount - same directory, no need for a second copy.

val nativeBuildTasks = iperfAbiTargets.map { target ->
    tasks.register<BuildIperfNativeTask>("buildIperfNative-${target.abiName}") {
        group = "build"
        description = "Cross-compiles iperf2 for ${target.abiName} and stages it as jniLibs/${target.abiName}/libiperf.so"
        abi.set(target.abiName)
        hostTriple.set(target.hostTriple)
        clangPrefix.set(target.clangPrefix)
        apiLevel.set(android.defaultConfig.minSdk)
        ndkDir.set(ndkPath)
        repoRoot.set(repoRootDir)
        sourceFiles.from(
            repoRootDir.dir("src"), repoRootDir.dir("include"), repoRootDir.dir("compat"),
            repoRootDir.file("configure"), repoRootDir.file("config.h.in"), repoRootDir.file("Makefile.in"),
            repoRootDir.file("aclocal.m4")
        )
        outputSo.set(layout.projectDirectory.file("src/main/jniLibs/${target.abiName}/libiperf.so"))
        scratchBaseDir.set(layout.buildDirectory)
    }
}

// Make sure the binaries exist before AGP merges/packages native libs.
tasks.matching { it.name.startsWith("merge") && it.name.contains("JniLibFolders") }.configureEach {
    dependsOn(nativeBuildTasks)
}
tasks.named("preBuild").configure {
    dependsOn(nativeBuildTasks)
}
