# No special rules needed - this app has no reflection-heavy libraries and
# ships iperf2 as a plain subprocess binary, not a JNI library, so there's
# nothing R8 needs to be told to keep beyond the default Compose/AndroidX rules.
