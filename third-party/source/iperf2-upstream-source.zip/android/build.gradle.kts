// Top-level build file: declares plugin versions used by subprojects (applied per-module below).
// AGP 9+ has built-in Kotlin support (https://kotl.in/gradle/agp-built-in-kotlin),
// so there's no separate org.jetbrains.kotlin.android plugin to apply - only
// the Compose compiler plugin is still needed.
plugins {
    id("com.android.application") version "9.2.1" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.0" apply false
}
