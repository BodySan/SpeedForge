# iperf2 Android Client - User Guide

A client-only iperf2 app. It runs the real iperf2 CLI in the background and
shows live meters while a test runs. Two test types are supported: **TCP**
and **UDP L4S** (a low-latency, low-loss, scalable-throughput UDP mode using
PragueCC congestion control).

## Fields

**Host / Port** - the iperf2 server to connect to, and the port it's
listening on (iperf2's default is 5001).

**Duration (s)** - how long the test runs, in seconds. Enter `-1` to run
until you tap Stop instead of stopping automatically.

**Interval (s)** - how often the meters update, in seconds. Accepts
fractions (e.g. `0.1` for 10 updates/sec).

**Parallel** - number of simultaneous streams (iperf2's `-P`). Local/private
addresses (192.168.x.x, 10.x.x.x, 172.16-31.x.x, 127.0.0.1, link-local) allow
up to 20; any other address is capped at 8 to match what a shared public
server will accept per client.

**Test type (TCP / UDP L4S)** - selects which kind of test to run. Switching
modes changes which options are shown below and what the meters measure.

**Start / Stop** - begins or ends the test using whichever settings are
currently set above.

### TCP-only options
Shown only when Test type is TCP.

- **Write prefetch (TCP_NOTSENT_LOWAT)** - on by default. Sets
  `TCP_NOTSENT_LOWAT` and switches to event-driven writes, which usually
  reduces bytes/packets sitting in the kernel's send queue. The **Prefetch
  size** field (e.g. `128K`, `1M`) sets the low-water mark.
- **Congestion control (--tcp-cca)** - off by default. Turning it on shows a
  row of algorithm chips (e.g. cubic, reno, bbr) - only algorithms this
  specific device's kernel actually supports are listed (the app checks at
  startup, so this list can vary by phone).

## Meters

**Throughput** - bits/sec, both modes. Fixed scale, full dial at 2.5 Gbps.

**RTT / Jitter** - round-trip time in TCP mode, jitter in UDP L4S mode (same
dial, different metric, since jitter is what's actually meaningful for a
UDP-L4S sender). Log-scaled dial so both very small and very large values
stay readable. Colored by severity:
| Color | RTT | Jitter |
|---|---|---|
| Green | 0-10 ms | 0-10 ms |
| Yellow | 10-100 ms | 10-30 ms |
| Red | above 100 ms | above 30 ms |

Shows "N/A" when the value isn't available yet (e.g. UDP L4S jitter on the
final summary line, which iperf2 doesn't compute a value for).

**Bytes (pkts) in flight / Packets-sec** - TCP mode shows bytes and packets
currently in flight (unacknowledged data), colored relative to your Write
prefetch size: green under 3x the prefetch size, yellow from 3x-10x, red
above 10x. UDP L4S mode instead shows packets/sec and, when available, the
PragueCC congestion-experienced mark count and percentage (`CE n (x.x%)`) -
these come from the server echoing back what congestion it observed, so they
only appear once real L4S ACK feedback has arrived.

Both bar-graph and dial meters also show "N/A" whenever the underlying data
isn't available for the current test configuration (e.g. `-P` greater than 1
sum rows don't carry per-connection bytes-in-flight).

## Notes

- This app is TCP/UDP-L4S client only - no server mode.
- The version string under the app title (e.g. `iperf 2.2.2 (3 July 2026)
  pthreads (community)`) is read live from the bundled binary's own `-v`
  output, not hardcoded, so it always matches whatever was actually
  compiled in.
