/*---------------------------------------------------------------
 * Copyright (c) 2021 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * gettcpinfo.c
 * Suppport for tcp info in a portable way
 *
 * Hi Bob,
 *
 * I would suggest that the most interesting metrics from tcp_info would be:
 *
 * double ecn_mark_rate = (double)tcpi_delivered_ce / (double)tcpi_delivered
 * double retransmit_rate = (double)(tcpi_total_retrans - tcpi_dsack_dups) /
 *(double)tcpi_data_segs_out double smoothed_rtt = tcpi_rtt
 *
 * neal
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#include "headers.h"
#include "gettcpinfo.h"
#ifdef HAVE_THREAD_DEBUG
// needed for thread_debug
#include "Thread.h"
#endif

#if HAVE_TCP_STATS
inline void gettcpinfo(int sock, struct iperf_tcpstats *stats) {
    assert(stats);
    // Independent of TCP_INFO below (basic sockets API, not part of
    // struct tcp_info) - sampled unconditionally so it's still populated
    // even on platforms/kernels where the TCP_INFO getsockopt itself
    // fails or isn't available.
#ifdef SO_SNDBUF
    {
        int sndbuf_val = -1;
        socklen_t sndbuf_len = sizeof(sndbuf_val);
        if ((sock > 0) && !(getsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char *)&sndbuf_val, &sndbuf_len) < 0)) {
            stats->sndbuf_bytes = sndbuf_val / 1024;
        } else {
            stats->sndbuf_bytes = -1;
        }
    }
#else
    stats->sndbuf_bytes = -1;
#endif
#if HAVE_DECL_TCP_INFO
    struct tcp_info tcp_info_buf;
    socklen_t tcp_info_length = sizeof(struct tcp_info);
    if ((sock > 0) && !(getsockopt(sock, IPPROTO_TCP, TCP_INFO, &tcp_info_buf, &tcp_info_length) < 0)) {
#if HAVE_STRUCT_TCP_INFO_TCPI_SND_CWND
        stats->cwnd_packets = tcp_info_buf.tcpi_snd_cwnd;
#else
        stats->cwnd_packets = -1;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_SND_CWND && HAVE_STRUCT_TCP_INFO_TCPI_SND_MSS
        stats->cwnd = tcp_info_buf.tcpi_snd_cwnd * tcp_info_buf.tcpi_snd_mss / 1024;
#else
        stats->cwnd = -1;
#endif
        stats->rtt = tcp_info_buf.tcpi_rtt;
        stats->rttvar = tcp_info_buf.tcpi_rttvar;
        stats->retry_tot = tcp_info_buf.tcpi_total_retrans;
#if HAVE_STRUCT_TCP_INFO_TCPI_SND_MSS
        stats->mss_negotiated = tcp_info_buf.tcpi_snd_mss;
#else
        stats->mss_negotiated = -1;
#endif
#if HAVE_TCP_INFLIGHT
        stats->packets_in_flight =
            (tcp_info_buf.tcpi_unacked - tcp_info_buf.tcpi_sacked - tcp_info_buf.tcpi_lost + tcp_info_buf.tcpi_retrans);
        stats->bytes_in_flight = stats->packets_in_flight * tcp_info_buf.tcpi_snd_mss / 1024;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_NOTSENT_BYTES
        stats->notsent_bytes = tcp_info_buf.tcpi_notsent_bytes / 1024;
#else
        stats->notsent_bytes = -1;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_MIN_RTT
        stats->rtt_min = tcp_info_buf.tcpi_min_rtt;
#else
        stats->rtt_min = -1;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_SNDBUF_LIMITED
        stats->sndbuf_limited_tot = tcp_info_buf.tcpi_sndbuf_limited;
#else
        stats->sndbuf_limited_tot = 0;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_RWND_LIMITED
        stats->rwnd_limited_tot = tcp_info_buf.tcpi_rwnd_limited;
#else
        stats->rwnd_limited_tot = 0;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_BUSY_TIME
        stats->busy_time_tot = tcp_info_buf.tcpi_busy_time;
#else
        stats->busy_time_tot = 0;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED_CE
        stats->ce_marks_tot = tcp_info_buf.tcpi_delivered_ce;
#else
        stats->ce_marks_tot = 0;
#endif
#if HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED
        stats->delivered_tot = tcp_info_buf.tcpi_delivered;
#else
        stats->delivered_tot = 0;
#endif
        stats->isValid = true;
#elif HAVE_DECL_TCP_CONNECTION_INFO
    struct tcp_connection_info tcp_info_buf;
    socklen_t tcp_info_length = sizeof(struct tcp_connection_info);
    if ((sock > 0) && !(getsockopt(sock, IPPROTO_TCP, TCP_CONNECTION_INFO, &tcp_info_buf, &tcp_info_length) < 0)) {
#ifdef __APPLE__
        stats->cwnd = tcp_info_buf.tcpi_snd_cwnd / 1024;
        stats->cwnd_packets = -1;
#else
        stats->cwnd = tcp_info_buf.tcpi_snd_cwnd * tcp_info_buf.tcpi_maxseg / 1024;
        stats->cwnd_packets = tcp_info_buf.tcpi_snd_cwnd;
#endif
        stats->rtt = tcp_info_buf.tcpi_rttcur * 1000;  // OS X units is ms
        stats->rttvar = tcp_info_buf.tcpi_rttvar;
        stats->retry_tot = tcp_info_buf.tcpi_txretransmitpackets;
        stats->mss_negotiated = tcp_info_buf.tcpi_maxseg;
        stats->isValid = true;
        // No true in-flight accounting on the public Darwin API (see
        // sndbuf_occupied_bytes's own doc comment in gettcpinfo.h) -
        // packets_in_flight/bytes_in_flight stay explicit "unavailable"
        // sentinels here rather than uninitialized, same -1-wrapped-to-
        // UINT32_MAX convention this file already uses for cwnd_packets
        // above when a field genuinely can't be filled in.
        stats->packets_in_flight = -1;
        stats->bytes_in_flight = -1;
#ifdef __APPLE__
        stats->sndbuf_occupied_bytes = tcp_info_buf.tcpi_snd_sbbytes / 1024;
#else
        stats->sndbuf_occupied_bytes = -1;
#endif
        stats->notsent_bytes = -1;
        stats->rtt_min = -1;
        stats->sndbuf_limited_tot = 0;
        stats->rwnd_limited_tot = 0;
        stats->busy_time_tot = 0;
#endif
    } else {
        stats->rtt = 1;
        stats->isValid = false;
    }
}
inline void tcpstats_copy(struct iperf_tcpstats *stats_dst, struct iperf_tcpstats *stats_src) {
    stats_dst->cwnd = stats_src->cwnd;
    stats_dst->cwnd_packets = stats_src->cwnd_packets;
    stats_dst->rtt = stats_src->rtt;
    stats_dst->rttvar = stats_src->rttvar;
    stats_dst->mss_negotiated = stats_src->mss_negotiated;
    stats_dst->retry_tot = stats_src->retry_tot;
    stats_dst->connecttime = stats_src->connecttime;
    stats_dst->isValid = stats_src->isValid;
    // HAVE_TCP_STATS, not the narrower HAVE_TCP_INFLIGHT - the fields
    // exist in the struct whenever HAVE_TCP_STATS is set (see
    // gettcpinfo.h), and gettcpinfo() itself now always assigns them on
    // every HAVE_TCP_STATS platform, either real values (Linux, when
    // HAVE_TCP_INFLIGHT) or an explicit -1 "unavailable" sentinel
    // (Darwin's TCP_CONNECTION_INFO branch) - HAVE_TCP_INFLIGHT alone
    // would skip the copy entirely on Darwin and leave stats_dst holding
    // whatever was already there instead of that sentinel.
#if HAVE_TCP_STATS
    stats_dst->packets_in_flight = stats_src->packets_in_flight;
    stats_dst->bytes_in_flight = stats_src->bytes_in_flight;
    stats_dst->sndbuf_occupied_bytes = stats_src->sndbuf_occupied_bytes;
#endif
    stats_dst->notsent_bytes = stats_src->notsent_bytes;
    stats_dst->rtt_min = stats_src->rtt_min;
    stats_dst->sndbuf_bytes = stats_src->sndbuf_bytes;
    stats_dst->sndbuf_limited_tot = stats_src->sndbuf_limited_tot;
    stats_dst->rwnd_limited_tot = stats_src->rwnd_limited_tot;
    stats_dst->busy_time_tot = stats_src->busy_time_tot;
    stats_dst->ce_marks_tot = stats_src->ce_marks_tot;
    stats_dst->delivered_tot = stats_src->delivered_tot;
}
#else
#if WIN32
inline void gettcpinfo(SOCKET sock, struct iperf_tcpstats *stats) {
#else
inline void gettcpinfo(int sock, struct iperf_tcpstats *stats) {
#endif
    stats->rtt = 1;
    stats->isValid = false;
#ifdef SO_SNDBUF
    {
        int sndbuf_val = -1;
        socklen_t sndbuf_len = sizeof(sndbuf_val);
        if ((sock > 0) && !(getsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char *)&sndbuf_val, &sndbuf_len) < 0)) {
            stats->sndbuf_bytes = sndbuf_val / 1024;
        } else {
            stats->sndbuf_bytes = -1;
        }
    }
#else
    stats->sndbuf_bytes = -1;
#endif
};
inline void tcpstats_copy(struct iperf_tcpstats *stats_dst, struct iperf_tcpstats *stats_src) {
    stats_dst->rtt = stats_src->rtt;
    stats_dst->isValid = stats_src->isValid;
    stats_dst->sndbuf_bytes = stats_src->sndbuf_bytes;
}
#endif
