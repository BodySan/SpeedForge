/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * signal.c
 * by Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * standard signal installer
 * ------------------------------------------------------------------- */

#include "headers.h"
#include "util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32

/* list of signal handlers. _NSIG is number of signals defined. */

static SigfuncPtr handlers[_NSIG] = {0};

/* -------------------------------------------------------------------
 * sig_dispatcher
 *
 * dispatches the signal to appropriate signal handler. This emulates
 * the signal handling of Unix.
 *
 * ------------------------------------------------------------------- */

BOOL WINAPI sig_dispatcher(DWORD type) {
    SigfuncPtr h = NULL;
    int signo;

    switch (type) {
        case CTRL_C_EVENT:
            signo = SIGINT;
            h = handlers[SIGINT];
            break;

        case CTRL_CLOSE_EVENT:
        case CTRL_LOGOFF_EVENT:
        case CTRL_SHUTDOWN_EVENT:
            signo = SIGTERM;
            h = handlers[SIGTERM];
            break;

        default:
            break;
    }

    if (h != NULL) {
        // call the signal handler
        h(signo);
        return 1;
    } else {
        return 0;
    }
}

/* -------------------------------------------------------------------
 * my_signal
 *
 * installs a  signal handler. I emulate Unix signals by storing the
 * function pointers and dispatching events myself, using the
 * sig_dispatcher above.
 * ------------------------------------------------------------------- */

SigfuncPtr my_signal(int inSigno, SigfuncPtr inFunc) {
    SigfuncPtr old = NULL;

    if (inSigno >= 0 && inSigno < _NSIG) {
        old = handlers[inSigno];
        handlers[inSigno] = inFunc;
    }

    return old;
} /* end my_signal */

#else /* not WIN32 */

/* -------------------------------------------------------------------
 * my_signal
 *
 * installs a signal handler, and returns the old handler.
 * This emulates the semi-standard signal() function in a
 * standard way using the Posix sigaction function.
 *
 * from Stevens, 1998, section 5.8
 * ------------------------------------------------------------------- */

SigfuncPtr my_signal(int inSigno, SigfuncPtr inFunc) {
    struct sigaction theNewAction, theOldAction;

    assert(inFunc != NULL);

    theNewAction.sa_handler = inFunc;
    sigemptyset(&theNewAction.sa_mask);
    theNewAction.sa_flags = 0;

    if ((inSigno == SIGALRM)
#ifdef SIGHUP
        // SIGHUP triggers a --permit-key-file reload (Listener.cpp/main.cpp) -
        // needs to actually interrupt the listener's blocking select()/
        // accept() (EINTR) so the reload happens promptly instead of being
        // silently swallowed and retried until the next real connection or
        // timeout, same reasoning as SIGALRM's per-thread timer delivery.
        || (inSigno == SIGHUP)
#endif
        ) {
#ifdef SA_INTERRUPT
        theNewAction.sa_flags |= SA_INTERRUPT; /* SunOS 4.x */
#endif
    } else {
#ifdef SA_RESTART
        theNewAction.sa_flags |= SA_RESTART; /* SVR4, 4.4BSD */
#endif
    }

    if (sigaction(inSigno, &theNewAction, &theOldAction) < 0) {
        return SIG_ERR;
    } else {
        return theOldAction.sa_handler;
    }
} /* end my_signal */

#endif /* not WIN32 */

/* -------------------------------------------------------------------
 * sig_exit
 *
 * Quietly exits. This protects some against being called multiple
 * times. (TODO: should use a mutex to ensure (num++ == 0) is atomic.)
 * ------------------------------------------------------------------- */

void sig_exit(int inSigno) {
    static int num = 0;
    if (num++ == 0) {
        fflush(0);
        _exit(0);
    }
} /* end sig_exit */

// Per-thread test-duration timer, used when available in preference to
// plain setitimer()/ITIMER_REAL: that's a single process-wide clock, so on
// a multi-client server every new connection's set_itimer() call re-arms
// the *same* shared timer, silently clobbering whatever cutoff any other
// already-running connection was expecting - the SIGALRM handler then sets
// one global flag (sInterupted) that every connection's InProgress() reads,
// so one connection's timeout can truncate a completely different,
// unrelated connection. timer_create()+SIGEV_THREAD_ID (Linux/glibc)
// delivers the signal to one specific thread only, and Sig_Interupt()
// (main.cpp) sets a per-thread flag (tInterupted) for it instead, so this
// is entirely per-connection with no cross-talk.
#if HAVE_STRUCT_SIGEVENT_SIGEV_NOTIFY_THREAD_ID
// Newer glibc: the documented convenience macro exists.
#define IPERF_SIGEV_TID_FIELD sigev_notify_thread_id
#elif HAVE_STRUCT_SIGEVENT__SIGEV_UN__TID
// Some current glibc still lacks that macro - same ABI field, just
// reached through the underlying union member directly.
#define IPERF_SIGEV_TID_FIELD _sigev_un._tid
#endif

#if HAVE_TIMER_CREATE && HAVE_TIMER_SETTIME && HAVE_TIMER_DELETE && HAVE_DECL_SIGEV_THREAD_ID && \
    defined(IPERF_SIGEV_TID_FIELD) && HAVE_GETTID_SYSCALL
#define IPERF_HAVE_PERTHREAD_TIMER 1
#include <sys/syscall.h>
static IPERF_THREAD_LOCAL timer_t tls_timerid;
static IPERF_THREAD_LOCAL int tls_timer_armed = 0;
#endif

void disarm_itimer(void) {
#if IPERF_HAVE_PERTHREAD_TIMER
    if (tls_timer_armed) {
        timer_delete(tls_timerid);
        tls_timer_armed = 0;
    }
#elif defined(HAVE_SETITIMER)
    struct itimerval it;
    memset(&it, 0, sizeof(it));
    setitimer(ITIMER_REAL, &it, NULL);
#endif
}

int set_itimer(uintmax_t usecs) {
    int err = 0;
#if IPERF_HAVE_PERTHREAD_TIMER
    struct itimerspec its;
    memset(&its, 0, sizeof(its));
    its.it_value.tv_sec = (time_t)(usecs / 1000000);
    its.it_value.tv_nsec = (long)((usecs % 1000000) * 1000);
    if (!tls_timer_armed) {
        struct sigevent sev;
        memset(&sev, 0, sizeof(sev));
        sev.sigev_notify = SIGEV_THREAD_ID;
        sev.sigev_signo = SIGALRM;
        sev.IPERF_SIGEV_TID_FIELD = (pid_t)syscall(SYS_gettid);
        if (timer_create(CLOCK_REALTIME, &sev, &tls_timerid) != 0) {
            WARN(1, "timer_create failed, per-thread test-duration timer disabled this connection");
            return -1;
        }
        tls_timer_armed = 1;
    }
    err = timer_settime(tls_timerid, 0, &its, NULL);
#elif defined(HAVE_SETITIMER)
    if (usecs < 0) {
        WARN(1, "set_itimer value invalid");
    } else {
        struct itimerval it;
        memset(&it, 0, sizeof(it));
        it.it_value.tv_sec = (int)(usecs / 1000000);
        it.it_value.tv_usec = (int)(usecs % 1000000);
        err = setitimer(ITIMER_REAL, &it, NULL);
    }
#endif
    return err;
}

#ifdef __cplusplus
} /* end extern "C" */
#endif
