#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for the bytes/packets-in-flight columns added to
# reportCSV_bw_tcp_write_enhanced_format (src/Locale.c) and their four
# call-site variants in tcp_output_write_enhanced_csv() (src/ReportOutputs.c).
# This is exactly the class of bug t21_lint_report_formats.sh's static
# checker guards against (format string vs. call site argument-count
# drift) but for a field added to *all* variants at once - a live run
# exercises the actual argument list the checker's preprocessor-only
# analysis can't substitute values into, and confirms the two new columns
# stay structurally in sync with the rest of the row, not just present
# somewhere in the output.
#
# FIELD_COUNT and the header regex below must track
# reportCSV_bw_tcp_write_enhanced_header's actual current column count/
# order (src/Locale.c) - both have drifted before when a field was added
# to the format without updating this test (tcpnotsent/tcpminrtt/
# tcpsndbuf/tcpwritetimeus/tcpsndbuflimitedus/tcprwndlimitedus/tcpbusyus/
# tcppaused all landed after this test was first written).
# The header check intentionally doesn't anchor to end-of-string ($) -
# tcppktsinflight/tcpbytesinflight aren't the last columns anymore and
# more fields are likely to follow them again in the future; anchoring
# just to confirm these two specific columns still exist, in order,
# survives that.

FIELD_COUNT=27

server_log=$(mktemp)
# -P 1 makes the server self-terminate after exactly one connection
# (Listener::mCount) instead of relying solely on run_timeout's SIGTERM to
# kill it: a signal sent to the process can land on any thread, and if it
# lands on a thread other than the one blocked in the listener's select()
# loop, that thread never wakes up and `wait $SPID` below hangs until the
# outer test-suite timeout kills the whole test. Matches the same -P 1
# pattern t26_udp_l4s.sh already uses for its background server.
run_timeout 4 src/iperf -s -P 1 -p $port -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
# Poll for the server's "listening" banner instead of a blind sleep - a
# fixed sleep races under system load (e.g. parallel builds elsewhere on
# the machine can easily push server startup past 0.5s), which showed up
# as an intermittent hang in `wait $SPID` below when the client connected
# before the server was actually ready.
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done
client_out=$(run_timeout 4 src/iperf -c $ip -p $port -e -y C -i 1 -t 2 2>&1)
wait $SPID

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|failed|not\ valid ]]; then
    echo "FAIL: unexpected error/warning text in client output"
    exit 1
fi

header=$(echo "$client_out" | grep "^time,")
if [[ -z "$header" ]]; then
    echo "FAIL: no CSV header line found"
    exit 1
fi
if [[ ! "$header" =~ ,tcppktsinflight,tcpbytesinflight ]]; then
    echo "FAIL: CSV header is missing the tcppktsinflight/tcpbytesinflight columns"
    exit 1
fi

data_lines=$(echo "$client_out" | grep -v "^time," | grep "^-\?[0-9]")
if [[ -z "$data_lines" ]]; then
    echo "FAIL: no CSV data lines found"
    exit 1
fi

fail=0
while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    count=$(awk -F',' '{print NF}' <<< "$line")
    if [[ "$count" -ne "$FIELD_COUNT" ]]; then
        echo "FAIL: CSV data line has $count fields, expected $FIELD_COUNT: $line"
        fail=1
    fi
done <<< "$data_lines"

exit $fail
