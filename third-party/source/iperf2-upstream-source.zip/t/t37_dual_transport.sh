#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for --dual-transport (server-only; FLAG_DUAL_TRANSPORT,
# Settings.hpp/Launch.cpp's listeners_init) - a server given --dual-
# transport opens a second listener one port off its main one, for
# whichever of TCP/UDP-L4S it *isn't* already serving on the main port,
# so one server process can serve both a main test and a working-load
# stream regardless of which protocol each side picks. Main listener here
# is UDP-L4S on $port; the auxiliary TCP listener should come up on
# $port-1. Verifies both are actually independently connectable, not just
# that the flag parses without error.

lport=$((port - 1))

server_log=$(mktemp)
run_timeout 6 src/iperf -s -u --udp-l4s -p $port --dual-transport -i 1 -t 4 -e > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done
sleep 0.3

udp_out=$(run_timeout 4 src/iperf -c $ip -u --udp-l4s -p $port -t 1 2>&1)
tcp_out=$(run_timeout 4 src/iperf -c $ip -p $lport -t 1 2>&1)
wait $SPID 2>/dev/null || true

echo "--- udp client (main, port $port) ---"
echo "$udp_out"
echo "--- tcp client (auxiliary, port $lport) ---"
echo "$tcp_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$udp_out" =~ unrecognized|ignoring|not\ valid ]] || [[ "$tcp_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: settings error reported"
    exit 1
fi
if [[ "$udp_out" != *"connected with"* ]]; then
    echo "FAIL: UDP-L4S client never connected on main port $port"
    exit 1
fi
if [[ "$tcp_out" != *"connected with"* ]]; then
    echo "FAIL: TCP client never connected on auxiliary port $lport"
    exit 1
fi

exit 0
