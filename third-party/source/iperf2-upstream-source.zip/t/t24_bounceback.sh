#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# usage:
# run_iperf -s server args   -c client args
#
# --bounceback exercises the BB (round-trip request/reply) output_handler
# functions and MeanMinMaxStats accounting, previously untested by this
# suite.

run_iperf    \
    -match "BB cnt=" \
    -s -i 1 -t 3     \
    -c $ip --bounceback -i 1 -t 1
