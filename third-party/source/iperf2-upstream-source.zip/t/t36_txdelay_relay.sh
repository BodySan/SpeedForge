#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for --txdelay-time's relay to the server's own reverse-
# writer thread (HEADER_EPOCH_DELAY, payloads.h; Settings_
# GenerateClientSettings's relayed_holdback snapshot-before-unset logic,
# Settings.cpp; Client::StartSynch's isServerReverse+isTxHoldback branch,
# Client.cpp). Before this fix, --txdelay-time was silently stripped for
# any server-spawned reverse/full-duplex thread (unconditional
# unsetTxHoldback), so the server started sending immediately regardless
# of the requested delay - only the client's own local holdback (for a
# plain, non-reverse direction) ever worked.
#
# Real wall-clock elapsed time is the only thing that actually proves the
# server held back rather than just accepting and ignoring the relayed
# value - per-interval report labels alone can't distinguish "genuinely
# delayed" from "started immediately, mislabeled." A clean loopback run
# with holdback=2s and -t=2s should take ~4s real time; if the relay
# silently regresses back to a no-op, it'd only take ~2s.

HOLDBACK=2
DURATION=2
# Comfortably wide bounds: real time must be at least holdback+duration
# minus a little scheduling slack, but not blow past holdback+duration by
# more than a few seconds (which would suggest something hung rather than
# just being slow).
MIN_EXPECTED=$(awk "BEGIN{print $HOLDBACK + $DURATION - 0.5}")
MAX_EXPECTED=$(awk "BEGIN{print $HOLDBACK + $DURATION + 4}")

server_log=$(mktemp)
run_timeout 15 src/iperf -s -p $port -P 1 -t $((HOLDBACK + DURATION + 5)) > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done

start_ts=$(date +%s.%N)
client_out=$(run_timeout 15 src/iperf -c $ip -p $port -R --txdelay-time $HOLDBACK -t $DURATION 2>&1)
end_ts=$(date +%s.%N)
kill $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true

elapsed=$(awk "BEGIN{print $end_ts - $start_ts}")

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"
echo "elapsed=${elapsed}s (expected between ${MIN_EXPECTED}s and ${MAX_EXPECTED}s)"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --txdelay-time -R reported a settings error"
    exit 1
fi

if [[ "$client_out" != *"connected with"* ]]; then
    echo "FAIL: client never connected"
    exit 1
fi

below=$(awk "BEGIN{print ($elapsed < $MIN_EXPECTED)}")
above=$(awk "BEGIN{print ($elapsed > $MAX_EXPECTED)}")
if [[ "$below" == "1" ]]; then
    echo "FAIL: real elapsed time ($elapsed s) was under the holdback+duration floor - server likely didn't honor the relayed --txdelay-time"
    exit 1
fi
if [[ "$above" == "1" ]]; then
    echo "FAIL: real elapsed time ($elapsed s) was well over holdback+duration - test may have hung"
    exit 1
fi

exit 0
