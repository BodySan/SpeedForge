#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for --working-load/--working-load-cca alongside a UDP-
# L4S bounceback main flow (Settings.cpp OPT_WORKING_LOAD_CCA,
# Launch.cpp's client_init routing). Uses the *default* (TCP) working-
# load transport deliberately, not --working-load-transport udp-l4s -
# combining --bounceback with an explicitly-UDP-L4S working-load stream
# hits a known, separate dispatch-collision bug where both flows end up
# sharing one server UDP port (tracked separately, not this test's
# concern - see the project memory on that hang bug for the repro).
#
# --dual-transport on the server is required here, not optional - the
# main flow is UDP-L4S but the working-load stream above is plain TCP
# (the default), and client_init's own port-shift logic (Launch.cpp,
# `isUDP(clients) != isWorkingLoadL4S(clients)`) always redirects a
# working-load stream whose transport differs from the main flow's own
# to the adjacent port, regardless of which direction that mismatch runs
# - not just the both-UDP-L4S collision case described above. Without a
# real listener there, the working-load-down TCP connect fails outright
# (immediate "Connection refused", not a race - confirmed via repeated
# isolated runs, with and without an added settle delay, all deterministic).
#
# This intentionally does NOT use run_iperf, for the same reason
# t26/t33/t34 don't: run_iperf's blanket failure grep can false-positive
# on best-effort UDP fin/ack exchange warnings unrelated to whether the
# working-load stream itself came up correctly.

server_log=$(mktemp)
run_timeout 5 src/iperf -s -u -p $port -P 1 -i 1 -t 3 -e --dual-transport > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

client_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --udp-l4s --bounceback \
    --working-load=down --working-load-cca cubic \
    -i 1 -t 2 -e 2>&1)
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --working-load/--working-load-cca reported a settings error"
    exit 1
fi
if [[ "$client_out" == *"Connection refused"* || "$client_out" == *"fatal"* ]]; then
    echo "FAIL: a connection was refused or hit a fatal error"
    exit 1
fi
if [[ "$client_out" != *"bb req/reply"* ]]; then
    echo "FAIL: main bounceback flow never came up"
    exit 1
fi
if [[ "$client_out" != *"(reverse)"* ]]; then
    echo "FAIL: no evidence of the working-load down (reverse TCP) stream in client output"
    exit 1
fi

exit 0
