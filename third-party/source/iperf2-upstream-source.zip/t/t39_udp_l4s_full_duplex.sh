#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for full-duplex UDP L4S (clientside_client_fullduplex_udp,
# Launch.cpp) - before 2ecf26c6, both directions shared one socket
# assuming TCP's independent read/write streams, which is broken for UDP
# since recv() on a shared fd returns whichever datagram arrives next
# regardless of which logical thread "wants" it, starving one direction.
#
# Was shipped stubbed to skip for a while: writing this test surfaced a
# real, reliably reproducible follow-on bug (not this commit's own
# regression, but a much-more-likely-to-trigger exposure of a pre-existing
# one) - the reverse/reader direction's own Server::ReadWithRxTimestamp()
# (reused for --reverse's receive role) treated a transient ECONNREFUSED
# as a fatal peer-close, when it's actually the well-known
# Listener::udp_accept()/my_listen() handoff-gap race (ticket 357) that
# --full-duplex's own two-near-simultaneous-new-connections setup makes
# far likelier to hit than ordinary single-connection usage ever does.
# Fixed by excluding ECONNREFUSED from FATALUDPREADERR (include/util.h,
# matching FATALUDPWRITERR's own existing convention) plus a small stagger
# between the two connects (Launch.cpp) to make the race itself rarer.
# A single transient "Connection refused"/"sendmsg failed" line can still
# legitimately appear in output even on a fully successful run (the
# WARN_errno in writemsg_delay_tos() prints unconditionally, regardless of
# whether the caller treats it as fatal) - so this test checks for actual
# completion (both directions sending/receiving a real volume of
# datagrams across the full run, not a handful) rather than the mere
# presence of that diagnostic text.

server_log=$(mktemp)
# No -P here (deliberately - see below). Full-duplex UDP-L4S needs the
# server to accept TWO independent new flows (forward and reverse each
# get their own connection, Launch.cpp's clientside_client_fullduplex_udp)
# for what is, to a technician, a single logical client. -P 1 makes
# Listener.cpp count exactly one expected connection (mCount=1), so
# my_listen() never re-arms a listening socket after accepting the
# first of the two - the second flow then gets a real, permanent
# Connection-refused, not the transient accept-race this test targets.
# That's a genuine, narrower, separate gap (a full-duplex client
# silently can't work against a -P 1 server) worth its own issue, but
# isn't what this test is regression-covering.
run_timeout 6 src/iperf -s -u -p $port -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

client_out=$(run_timeout 6 src/iperf -c $ip -u -p $port --udp-l4s --full-duplex -i 1 -t 3 2>&1)
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --full-duplex --udp-l4s reported a settings error"
    exit 1
fi

# Starvation (2ecf26c6's own fix target) shows up as one direction
# reading a literal "0.00 Bytes" final summary - the other direction ate
# every read()/sendmsg() on the shared socket.
if [[ "$client_out" == *"0.00 Bytes"* ]]; then
    echo "FAIL: one direction reported 0.00 Bytes transferred - looks starved (socket-sharing regression)"
    exit 1
fi

# The accept-race bug this test was stubbed for: one direction's own
# "Sent N datagrams" final count stuck at a low, truncated value (the
# original repro reliably died at exactly 98) rather than the tens of
# thousands a full 3-second run at even modest rates produces - a real
# sign the direction terminated early, not just a benign transient
# warning already tolerated by FATALUDPREADERR/FATALUDPWRITERR.
sent_counts=$(echo "$client_out" | grep -oP 'Sent \K[0-9]+(?= datagrams)')
if [[ -z "$sent_counts" ]]; then
    echo "FAIL: no 'Sent N datagrams' summary found for either direction"
    exit 1
fi
while read -r n; do
    if [[ "$n" -lt 1000 ]]; then
        echo "FAIL: a direction only sent $n datagrams - looks like the accept-race early-termination bug"
        exit 1
    fi
done <<< "$sent_counts"

exit 0
