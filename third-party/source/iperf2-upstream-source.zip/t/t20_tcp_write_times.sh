#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for --tcp-write-times (tcp_output_write_enhanced_write()
# in ReportOutputs.c, which printf()s through report_write_enhanced_write_format
# in Locale.c). The !(HAVE_TCP_STATS) build variant of that format string
# had one more %-specifier than the call site supplied arguments for (a
# stray %s left over from a copy/pasted netpower field), so every argument
# after WriteCnt/WriteErr was fed to the wrong specifier - undefined
# behavior, crash-prone on platforms lacking tcp_info (e.g. mingw/Windows
# builds, where HAVE_TCP_STATS is undefined; this dev/CI build most likely
# has HAVE_TCP_STATS=1, so this test won't reproduce the crash itself, but
# it guards against the general class of Locale.c/ReportOutputs.c argument
# drift, which -Wformat cannot catch since these format strings are never
# literals at their call sites).

run_iperf    \
    -s -P 1 -i 1 -t 3     \
    -c $ip -P 1 -i 1 -t 2 --tcp-write-times -match "Write/Err"
