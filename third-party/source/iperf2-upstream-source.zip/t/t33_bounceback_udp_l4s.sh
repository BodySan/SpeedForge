#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for the discrete stop-and-wait UDP-L4S bounceback
# transport (struct bounceback_udp_hdr, src/Client.cpp's RunBounceBackUDP/
# WriteUdpTxBBHdr, src/Server.cpp's RunBounceBackUDP, src/Listener.cpp's
# apply_client_settings_udp_bounceback) - same RPS measurement as TCP
# bounceback (t24_bounceback.sh), but over ECT(1)-marked UDP so it can be
# A/B compared directly against it.
#
# This intentionally does NOT use run_iperf, for the same reason
# t26_udp_l4s.sh doesn't: run_iperf's blanket failure grep can false-
# positive on best-effort UDP fin/ack exchange warnings unrelated to
# whether the bounceback exchange itself worked.

server_log=$(mktemp)
run_timeout 4 src/iperf -s -u -p $port -P 1 -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done
client_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --bounceback -i 1 -t 1 2>&1)
wait $SPID

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|failed|not\ valid ]]; then
    echo "FAIL: unexpected error/warning text in client output"
    exit 1
fi

if [[ "$client_out" != *"BB cnt="* ]]; then
    echo "FAIL: client output did not show bounceback (BB cnt=) stats"
    exit 1
fi

exit 0
