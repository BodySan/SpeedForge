#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for UDP bounceback's --trip-times OWD/relative-OWD CSV
# row (reportCSV_client_bb_owd_format, Locale.c/print_bb_owd_csv,
# ReportOutputs.c) and its per-direction loss attribution CSV row
# (reportCSV_client_bb_loss_format/print_bb_loss_csv), both gated for the
# loss row unconditionally and for the OWD row on isTripTime - see
# Reporter.c's reporter_handle_packet_bb_client for the derivation. A
# clean loopback run has no real loss, so this only asserts the rows show
# up with the right header/shape and non-garbage OWD numbers, not that
# loss attribution actually counts something - t33's own scope (RPS
# stats) mirrors this same "shape correctness, not induced-fault" scope.
#
# This intentionally does NOT use run_iperf, for the same reason
# t26/t33/t34 don't: run_iperf's blanket failure grep can false-positive
# on best-effort UDP fin/ack exchange warnings unrelated to whether the
# OWD/loss rows themselves are correct.

server_log=$(mktemp)
run_timeout 4 src/iperf -s -u -p $port -P 1 -i 1 -t 3 -e -y C > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

client_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --udp-l4s --bounceback --trip-times -e -i 1 -t 1 -y C 2>&1)
wait $SPID

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --trip-times bounceback reported a settings error"
    exit 1
fi

if [[ "$client_out" != *"owdtocnt,owdtoavg"* ]]; then
    echo "FAIL: OWD CSV header not found in client output"
    exit 1
fi
if [[ "$client_out" != *"owdtorelavg,owdtorelmin"* ]]; then
    echo "FAIL: relative-OWD CSV header not found in client output"
    exit 1
fi
if [[ "$client_out" != *"bbrequestssent,bbrepliesreceived"* ]]; then
    echo "FAIL: loss-attribution CSV header not found in client output"
    exit 1
fi

# Pull the first OWD data row (right after its own header line) and check
# owdtocnt (field 9, 1-indexed) is a positive integer - a clean loopback
# run should see every bounce's OWD sample land, so a zero count here
# would mean the row shape is right but nothing was actually measured.
owd_data_line=$(echo "$client_out" | grep -A1 "^time,srcaddress.*owdtocnt" | tail -1)
owdtocnt=$(echo "$owd_data_line" | cut -d, -f9)
if [[ -z "$owdtocnt" || "$owdtocnt" -le 0 ]]; then
    echo "FAIL: owdtocnt was not a positive integer (got '$owdtocnt')"
    exit 1
fi

exit 0
