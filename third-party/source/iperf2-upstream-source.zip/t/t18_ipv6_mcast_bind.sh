#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test: -B ff02::1%<iface> (IPv6 multicast address with
# link-local scope) used to fail bind() with EINVAL because the %<iface>
# suffix was only ever applied to the later multicast group join, never
# to sin6_scope_id on the bind address itself (see SockAddr_isLinkScope /
# SockAddr_localAddr). The loopback interface always exists, so use it as
# the device (name isn't portable: "lo" on Linux, "lo0" on BSD/Darwin -
# see loop_iface in base.sh); actual multicast delivery over loopback
# isn't required for this check, only that bind()/join() succeed.

out=$(run_timeout 2 src/iperf -s -u -V -B ff02::1%$loop_iface -i 1 2>&1) || true
echo "$out"

if [[ "$out" =~ "bind failed" ]] || [[ "$out" =~ "Invalid argument" ]]; then
    echo "FAIL: server failed to bind to a link-local scope multicast address"
    exit 1
fi
if [[ ! "$out" =~ "listening" ]]; then
    echo "FAIL: server did not reach the listening state"
    exit 1
fi

exit 0
