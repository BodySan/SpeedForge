#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
# - the main flow here is UDP-L4S bounceback specifically (see below for
# why), not just plain TCP bounceback.
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for SIGUSR1/SIGUSR2-driven working-load pause/resume
# (FLAG_WORKING_LOAD_THREAD, sWorkingLoadPaused - main.cpp/Client.cpp).
# Sending SIGUSR1 to a running client should stop its working-load
# thread's own writes (without tearing the connection down) while the
# main bounceback flow keeps running untouched; SIGUSR2 should resume it.
#
# Main flow is UDP-L4S bounceback (--udp-l4s --bounceback), not plain TCP
# bounceback, specifically so its own "BB Loss Req=x/y Reply=x/y" line
# (this session's earlier per-direction loss attribution work) is
# available to assert zero loss against - plain TCP bounceback doesn't
# print that line at all (TCP's own reliability makes "requests lost" a
# UDP-only concept). The working-load stream is ALSO UDP-L4S
# (--working-load-transport udp-l4s) rather than the default TCP - not
# just for symmetry: this app-facing test only starts one combined
# server process, and a working-load transport that *differs* from the
# main flow's own expects a second, separate listener on the adjacent
# port (the real two-process-per-protocol deployment topology this
# app/client targets, see client_init's own port-shift comment,
# Launch.cpp) that doesn't exist here (--dual-transport would supply it,
# but isn't what this test is regression-covering). Matching both sides
# to UDP-L4S also exercises the trickier of the two pause code paths -
# RunUDPL4S's own ACK-timeout-avoidance logic, not just the simpler TCP
# write loop - the more valuable case to have real coverage on.
#
# Client-writer direction only (--working-load=up) - this intentionally
# does NOT cover --working-load=down, whose own writer is a thread the
# *server* spawns in response to the reverse-mode connection, a different
# process a signal sent to this test's own client can't reach. Pausing
# that direction needs the working-load flag relayed to the server over
# the wire plus the same check added to Server.cpp's own write loop -
# not implemented yet, tracked separately.
#
# This intentionally does NOT use run_iperf, same reason t38/t40 don't -
# the client needs to keep running in the background so this script can
# signal it mid-test, which run_iperf's synchronous $(...) capture can't
# do.

server_log=$(mktemp)
client_log=$(mktemp)
run_timeout 10 src/iperf -s -u -p $port -i 1 -t 8 -e > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

# Deliberately NOT run_timeout/timeout here, unlike every other test in
# this suite - this test needs to send SIGUSR1/SIGUSR2 to the *actual*
# iperf client process, and timeout(1) has no handler for either (nor
# does it forward arbitrary signals sent to itself, only the one it's
# configured to send its own child on its own duration expiry), so
# signaling timeout's own PID just kills timeout via that signal's
# default disposition, taking the whole job down before iperf ever
# sees it. A manual watchdog (matching run_timeout's own POSIX-portable
# fallback branch, base.sh) provides the same hang-safety net instead.
src/iperf -c $ip -u -p $port --udp-l4s --bounceback --working-load=up \
    --working-load-transport udp-l4s --working-load-cca reno -i 1 -t 8 -e > "$client_log" 2>&1 &
CPID=$!
( sleep 10; kill -TERM $CPID 2>/dev/null ) &
WATCHDOG=$!

sleep 2.5
kill -USR1 $CPID 2>/dev/null || true
sleep 2.5
kill -USR2 $CPID 2>/dev/null || true

wait $CPID 2>/dev/null
client_rc=$?
kill $WATCHDOG 2>/dev/null || true
wait $WATCHDOG 2>/dev/null || true
wait $SPID 2>/dev/null || true

client_out=$(cat "$client_log")
echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log" "$client_log"

if [[ $client_rc -ne 0 ]]; then
    echo "FAIL: client exited $client_rc (possibly killed by run_timeout - a hang regression)"
    exit 1
fi
if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --bounceback --working-load=up reported a settings error"
    exit 1
fi
if [[ "$client_out" == *"Connection refused"* || "$client_out" == *"fatal"* ]]; then
    echo "FAIL: a connection was refused or hit a fatal error"
    exit 1
fi
if [[ "$client_out" != *"req/reply"* ]]; then
    echo "FAIL: main bounceback flow never came up"
    exit 1
fi

# The working-load thread's own per-interval line must show at least one
# fully-paused interval (0 bytes, 0 writes - proof SIGUSR1 actually
# stopped its writes) and at least one real, nonzero interval both before
# pausing and after resuming (proof it wasn't just stalled for the whole
# run, and genuinely resumed rather than the connection having quietly
# died). Identified by content, not a hardcoded bracket ID - bounceback
# and working-load are two independently-connecting threads racing to
# connect first, so which one ends up "[  1]" vs "[  2]" isn't
# deterministic run to run. Bounceback's own per-interval line always
# carries "RPS=" (its own requests/sec column); working-load's plain
# throughput line never does - filtering that out, plus the "BB8"/"BB
# Loss"/"SUM" lines, leaves only working-load's own per-interval rows.
working_load_lines=$(echo "$client_out" | grep -E '^\[ *[0-9]+\] [0-9.]+-[0-9.]+ sec' | grep -v "RPS=\|BB8\|BB Loss\|SUM" || true)
paused_intervals=$(echo "$working_load_lines" | grep -c "0.000 Bytes" || true)
active_intervals=$(echo "$working_load_lines" | grep -vc "0.000 Bytes" || true)
if [[ "$paused_intervals" -lt 1 ]]; then
    echo "FAIL: no fully-paused (0.000 Bytes) working-load interval found - SIGUSR1 had no effect"
    exit 1
fi
if [[ "$active_intervals" -lt 2 ]]; then
    echo "FAIL: fewer than 2 active working-load intervals (need one before the pause, one after resume)"
    exit 1
fi

# Bounceback's own request/reply loss must stay zero throughout - proof
# the main traffic thread was never affected by pausing the working-load
# thread alongside it. Every "BB Loss" line must read "Req=0/" (a nonzero
# numerator anywhere is a real loss); grep -c confirms at least one such
# line exists at all, so an empty match set (bounceback line format
# changed, or bounceback never reported) can't silently pass.
bb_loss_lines=$(echo "$client_out" | grep "BB Loss" || true)
if [[ -z "$bb_loss_lines" ]]; then
    echo "FAIL: no 'BB Loss' lines found at all - bounceback never reported"
    exit 1
fi
if echo "$bb_loss_lines" | grep -qv "Req=0/"; then
    echo "FAIL: bounceback's own request loss wasn't cleanly zero throughout"
    exit 1
fi

exit 0
