#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for --tcp-cca over --bounceback (src/Listener.cpp's
# HEADER_BBCCA branch, src/Client.cpp's RunBounceBackTCP/WriteTcpTxBBHdr).
#
# Bounceback connections take a wire path entirely separate from plain TCP
# (struct bounceback_hdr, not client_tcp_testhdr's cca_field), so the
# client's requested CCA used to never reach the server at all - the
# server-side socket silently kept whatever its listener defaulted to,
# and the server's own connect report never showed a "(<cca>)" annotation
# for bounceback the way it always has for plain TCP.
#
# The client always prints its own "(<cca>)" for itself regardless of
# whether the server ever heard about it, so this test specifically checks
# the SERVER's own log (not the combined/client output run_iperf's generic
# -match works against) - that's the side the fix actually changes.
#
# cubic (not bbr) - universally available, unlike bbr which needs a kernel
# module that isn't guaranteed present on every machine running this suite.

server_log=$(mktemp)
run_timeout 4 src/iperf -s -P 1 -p $port -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done
client_out=$(run_timeout 4 src/iperf -c $ip -p $port --bounceback --tcp-cca cubic -i 1 -t 1 2>&1)
wait $SPID

echo "$client_out"
echo "--- server ---"
cat "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|failed|not\ valid ]]; then
    echo "FAIL: unexpected error/warning text in client output"
    rm -f "$server_log"
    exit 1
fi

server_connect_line=$(grep "bb w/quickack" "$server_log" || true)
rm -f "$server_log"
if [[ -z "$server_connect_line" ]]; then
    echo "FAIL: no bounceback connect line found in server output"
    exit 1
fi
if [[ ! "$server_connect_line" =~ \(cubic\) ]]; then
    echo "FAIL: server-side bounceback connect report is missing the (cubic) CCA annotation - --tcp-cca isn't reaching the server (HEADER_BBCCA regression)"
    exit 1
fi
exit 0
