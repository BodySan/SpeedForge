#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# --cca reno, under --udp-l4s: an explicit, user-selectable Reno-style
# congestion response for UDP L4S (src/prague_cc.cpp's ACKReceived - the
# CE-triggered gentle/alpha-proportional decrease is suppressed, the
# loss-triggered flat halving stays active either way) alongside the
# existing Prague default. This just confirms the flag is accepted,
# threaded through to PragueCC's construction (Client::RunUDPL4S), and the
# resulting ccamode shows up correctly in CSV output - not that the
# congestion behavior itself measurably differs, which a short synthetic
# loopback run can't assert on reliably (matches t26_udp_l4s.sh's own
# pragmatic scope).
#
# This intentionally does NOT use run_iperf, for the same reason
# t26_udp_l4s.sh doesn't: run_iperf's blanket failure grep can false-
# positive on best-effort UDP fin/ack exchange warnings (write_UDP_AckFIN,
# Reports.c) unrelated to whether the CCA selection itself worked.

server_log=$(mktemp)
run_timeout 4 src/iperf -s -u -p $port -P 1 -i 1 -t 3 -e -y C > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

# Explicit reno
reno_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --udp-l4s --cca reno -e -i 1 -t 1 -y C 2>&1)
# Default (prague)
prague_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --udp-l4s -e -i 1 -t 1 -y C 2>&1)
wait $SPID

echo "$reno_out"
echo "--- prague (default) ---"
echo "$prague_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$reno_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --cca reno reported a settings error"
    exit 1
fi
if [[ "$prague_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: default (prague) run reported a settings error"
    exit 1
fi
if [[ "$reno_out" != *",reno"* ]]; then
    echo "FAIL: --cca reno's CSV output did not show ccamode=reno"
    exit 1
fi
if [[ "$prague_out" != *",prague"* ]]; then
    echo "FAIL: default run's CSV output did not show ccamode=prague"
    exit 1
fi

# --cca is dual-purpose by design (a literal TCP algorithm name, or
# prague/reno when --udp-l4s is also set) - unlike the old dedicated
# --udp-l4s-cca flag, there's no "meaningless without --udp-l4s" case to
# reject: --cca reno without --udp-l4s is simply a request for the real
# Linux TCP reno algorithm, not an error.

exit 0
