# common test setup
set -o pipefail
#set -x

lo=localhost
ip=127.0.0.1
ip6=::1

# Loopback interface name isn't portable: Linux uses "lo", BSD/Darwin use "lo0"
case "$(uname -s)" in
    Linux) loop_iface=lo ;;
    *) loop_iface=lo0 ;;
esac

# Some versions of expr can't handle can't mix regexp and math
test=$(expr $0 : '.*/t\([0-9]*\)_')
port=$(expr 5000 + $test)
lport=$(expr 6000 - $test)

@() { echo "+ $@"; "$@"; }

# Portable stand-in for GNU coreutils' timeout(1), which macOS and some
# BSDs don't ship at all (and FreeBSD's base system doesn't either).
# Prefers a real timeout/gtimeout if present, otherwise a plain
# background-process-plus-watchdog fallback.
run_timeout() {
    dur=$1; shift
    if command -v timeout >/dev/null 2>&1; then
	timeout "$dur" "$@"
    elif command -v gtimeout >/dev/null 2>&1; then
	gtimeout "$dur" "$@"
    else
	"$@" &
	cmdpid=$!
	( sleep "$dur"; kill -TERM "$cmdpid" 2>/dev/null ) &
	watchdog=$!
	wait "$cmdpid" 2>/dev/null
	rc=$?
	kill "$watchdog" 2>/dev/null
	wait "$watchdog" 2>/dev/null
	return $rc
    fi
}

run_iperf() {
    mode=server
    server=(-s)
    client=(-c)
    match=""
    # Split server and client args lists
    while [ $# -gt 0 ]; do
	case $1 in
	    (-c) mode=client;;
	    (-s) mode=server;;
	    (-match) shift; match=$1;;
	    (*)
		case $mode in
		    (server) server+=($1);;
		    (client) client+=($1);;
		esac
	esac
	shift
    done
    # Start server in the background against its own log file (rather than
    # piping the server directly into the client stage) so we can explicitly
    # kill it once the client is done. -t on the server only bounds that one
    # connection's traffic-thread duration now, not the listener's own
    # accept-loop lifetime (see Listener.cpp), so the server would otherwise
    # keep running/hang the enclosing command substitution forever.
    server_log=$(mktemp)
    @ src/iperf -p $port "${server[@]}" > "$server_log" 2>&1 &
    server_pid=$!

    # Wait for "listening"
    for _ in $(seq 1 100); do
	grep -q "listening" "$server_log" 2>/dev/null && break
	sleep 0.1
    done

    # Start client
    client_out=$(@ src/iperf -p $port "${client[@]}" 2>&1)

    # Server's job is done - explicitly end it rather than relying on -t
    kill $server_pid 2>/dev/null || true
    wait $server_pid 2>/dev/null || true

    # Merge server and client output
    # Store results for additional processing and also copy to stderr for progress
    results="$(cat "$server_log")
$client_out"
    rm -f "$server_log"
    echo "$results" >&2

    # Check for known error messages
    if [[ "$results" =~ unrecognized|ignoring|failed|not\ valid ]]; then
	exit 1
    fi
    if [[ -n "$match" && ! ("$results" =~ "$match") ]]; then
       exit 1
    fi
    exit 0
}
