#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Static lint, not a functional test: cross-checks printf/fprintf/snprintf
# argument counts against the %-specifier counts of the Locale.c report_*
# format strings used in Reports.c/ReportOutputs.c, across every relevant
# #if/#ifdef build variant (see t/check_report_format_strings.py for why
# this can't be done with -Wformat, and doc/RELEASE_NOTES 2.2.2 for the
# five real bugs this check found by hand before being automated here).

python3 "$(dirname $0)/check_report_format_strings.py"
