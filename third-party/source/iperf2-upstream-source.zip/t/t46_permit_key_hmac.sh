#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# --permit-key-hmac closes the plaintext-replay hole in the original
# --permit-key design (static shared secret, sent in the clear, plain
# strncmp - see doc/PERMIT_KEY_NOTES) without adding a new round trip:
# the client sends "HMAC1:<ts>:<hmac>" instead of the raw secret, and the
# server verifies it self-describes as HMAC1 (vs. falling through to the
# legacy plaintext path unchanged) with no separate server-side mode flag.
# This test only requires the professional edition (--permit-key itself is
# gated there) - no UDP L4S/etc dependency. Gate on config.h, not --help:
# community builds list the --permit-key options too (tagged "professional
# edition"), so grepping --help never skips.
if ! grep -q "HAVE_PROFESSIONAL 1" config.h 2>/dev/null; then
    exit 77
fi

SECRET="t46-test-secret-value"
WRONG="t46-wrong-secret-value"

# A valid --permit-key-vendor-id must exactly match
# "fi-wi-<first 12 hex chars of sha256(this binary's own trimmed iperf -v
# output)>" (compute_version_based_vendor_id(), Listener.cpp/ReportOutputs.c) -
# not just start with "fi-wi". Compute the real expected value here rather
# than a hardcoded string, so this test tracks the native formula instead
# of asserting a value that only happened to work once.
VALID_VENDOR_ID=$(python3 -c "
import hashlib, sys
v = sys.stdin.read().rstrip()
print('fi-wi-' + hashlib.sha256(v.encode()).hexdigest()[:12])
" <<< "$(src/iperf -v 2>&1)")

# --- 0: vendored SHA-256/HMAC-SHA256 against RFC 4231 / FIPS 180-4 vectors ---
# Exercises compat/sha256.c directly (no server round trip) - see
# build_permit_key_wire_value()'s own doc comment (Settings.cpp) for why
# this was vendored rather than linked from a crypto library.
tmpsrc=$(mktemp /tmp/t46_shaXXXXXX.c)
tmpbin=$(mktemp /tmp/t46_shaXXXXXX)
cat > "$tmpsrc" << 'EOF'
#include <stdio.h>
#include <string.h>
#include "sha256.h"
static void hex(const unsigned char *d, size_t n, char *out) {
    for (size_t i = 0; i < n; i++) sprintf(out + i * 2, "%02x", d[i]);
}
int main(void) {
    unsigned char digest[SHA256_DIGEST_LENGTH];
    char h[2 * SHA256_DIGEST_LENGTH + 1];
    int rc = 0;

    sha256((const unsigned char *)"abc", 3, digest);
    hex(digest, sizeof(digest), h);
    if (strcmp(h, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") != 0) {
        fprintf(stderr, "FAIL sha256(abc): %s\n", h); rc = 1;
    }

    unsigned char key[20];
    memset(key, 0x0b, sizeof(key));
    hmac_sha256(key, sizeof(key), (const unsigned char *)"Hi There", 8, digest);
    hex(digest, sizeof(digest), h);
    if (strcmp(h, "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7") != 0) {
        fprintf(stderr, "FAIL hmac rfc4231 tc1: %s\n", h); rc = 1;
    }
    return rc;
}
EOF
${CC:-cc} -I"${srcdir:-.}/include" -o "$tmpbin" "$tmpsrc" "${srcdir:-.}/compat/sha256.c"
"$tmpbin"
rc=$?
rm -f "$tmpsrc" "$tmpbin"
if [ $rc -ne 0 ]; then
    echo "FAIL: vendored SHA-256/HMAC-SHA256 does not match known test vectors"
    exit 1
fi

# --- 1: legacy plaintext mode unchanged (no --permit-key-hmac anywhere) ---
server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 2 --permit-key="$SECRET" > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
legacy_out=$(run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$SECRET" 2>&1)
wait $SPID
if [[ "$legacy_out" =~ unrecognized|ignoring|not\ valid|refused|failed ]]; then
    echo "FAIL: legacy plaintext permit-key mode regressed"
    echo "$legacy_out"; echo "--- server ---"; cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
if ! grep -q "legacy plaintext --permit-key, which is deprecated" "$server_log"; then
    echo "FAIL: legacy plaintext connection did not print the deprecation WARN"
    cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

# --- 2: HMAC mode, matching key - should succeed ---
server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 2 --permit-key="$SECRET" > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
hmac_out=$(run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$SECRET" --permit-key-hmac 2>&1)
wait $SPID
if [[ "$hmac_out" =~ unrecognized|ignoring|not\ valid|refused|failed ]]; then
    echo "FAIL: HMAC mode with a matching key was rejected"
    echo "$hmac_out"; echo "--- server ---"; cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
if ! grep -q "contact licensing@fi-wi.com to get a valid vendor id" "$server_log"; then
    echo "FAIL: server with no --permit-key-vendor-id did not print the startup registration notice"
    cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

# --- 3: HMAC mode, wrong key - should be rejected ---
server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 2 --permit-key="$SECRET" > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
wrong_out=$(run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$WRONG" --permit-key-hmac 2>&1 || true)
wait $SPID 2>/dev/null || true
if [[ ! ( "$wrong_out" =~ refused|failed|closed|reset|denied|error|ERROR ) ]]; then
    echo "FAIL: HMAC mode with a wrong key was NOT rejected"
    echo "$wrong_out"; echo "--- server ---"; cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

# --- 4: a hand-crafted, deliberately stale HMAC1 value is rejected ---
# Passed as a plain --permit-key value (no --permit-key-hmac) so it's sent
# byte-for-byte verbatim (build_permit_key_wire_value with hmacMode=false) -
# the server's own detection of the HMAC1 format is purely based on the
# received string's "HMAC1:" prefix, independent of how the client decided
# to build it, so this is a legitimate way to exercise the server's
# timestamp-skew rejection without waiting a real hour.
stale_key=$(python3 -c "
import hmac, hashlib, struct, sys, time
key = sys.argv[1].encode()
ts = int(time.time()) - 3600  # 1 hour old, well past the 30s default window
mac = hmac.new(key, struct.pack('>I', ts & 0xffffffff), hashlib.sha256).hexdigest()
print('HMAC1:%08x:%s' % (ts & 0xffffffff, mac))
" "$SECRET")
server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 2 --permit-key="$SECRET" > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
stale_out=$(run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$stale_key" 2>&1 || true)
wait $SPID 2>/dev/null || true
if [[ ! ( "$stale_out" =~ refused|failed|closed|reset|denied|error|ERROR ) ]]; then
    echo "FAIL: a stale (1-hour-old) HMAC1 value was NOT rejected"
    echo "$stale_out"; echo "--- server ---"; cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

# --- 5: a valid (exactly matching) --permit-key-vendor-id silences the
# startup registration notice; an arbitrary fi-wi-prefixed guess does not ---
server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 1 --permit-key="$SECRET" \
    --permit-key-vendor-id=fi-wi-not-the-real-one > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$SECRET" --permit-key-hmac > /dev/null 2>&1
wait $SPID
if ! grep -q "contact licensing@fi-wi.com to get a valid vendor id" "$server_log"; then
    echo "FAIL: an arbitrary fi-wi-prefixed (but non-matching) vendor ID incorrectly silenced the notice"
    cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

server_log=$(mktemp)
run_timeout 4 src/iperf -s -p $port -P 1 -i 1 -t 2 --permit-key="$SECRET" \
    --permit-key-vendor-id="$VALID_VENDOR_ID" > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
vendor_out=$(run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$SECRET" --permit-key-hmac 2>&1)
wait $SPID
if [[ "$vendor_out" =~ unrecognized|ignoring|not\ valid|refused|failed ]]; then
    echo "FAIL: HMAC mode with a vendor ID set was rejected"
    echo "$vendor_out"; echo "--- server ---"; cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
if grep -q "contact licensing@fi-wi.com to get a valid vendor id" "$server_log"; then
    echo "FAIL: a valid --permit-key-vendor-id did not silence the startup notice"
    cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

# --- 6: the usage-based notice fires every PERMITKEY_VENDOR_NAG_INTERVAL-th
# (25) HMAC connection when no vendor ID is set - not on every connection ---
# No -P on the server here (unlike every sub-test above) - server-side -P N
# sets Listener's own mCount, capping it to exactly N accepted connections
# ever (Listener.cpp), which is fine for the single-connection sub-tests
# above but would stop this server dead after connection 1.
server_log=$(mktemp)
run_timeout 60 src/iperf -s -p $port -i 1 -t 1 --permit-key="$SECRET" \
    --permit-key-timeout 120 > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
for i in $(seq 1 25); do
    run_timeout 4 src/iperf -c $ip -p $port -P 1 -t 1 --permit-key="$SECRET" --permit-key-hmac > /dev/null 2>&1
done
# $SPID is the backgrounded run_timeout subshell, not iperf itself -
# killing it orphans the server (under timeout 60) still bound to $port,
# so an immediate rerun fails "Address already in use". Signal its
# children instead (GNU timeout forwards TERM to iperf; in run_timeout's
# no-timeout fallback iperf is a direct child) and let the subshell exit
# on its own, so the wait below returns only once iperf's graceful
# shutdown has actually released the port.
pkill -TERM -P $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true
usage_notice_count=$(grep -c "has authenticated 25 clients via --permit-key-hmac" "$server_log" || true)
if [ "$usage_notice_count" -ne 1 ]; then
    echo "FAIL: expected exactly one usage notice at the 25th HMAC connection, saw $usage_notice_count"
    cat "$server_log"
    rm -f "$server_log"
    exit 1
fi
rm -f "$server_log"

echo "PASS"
exit 0
