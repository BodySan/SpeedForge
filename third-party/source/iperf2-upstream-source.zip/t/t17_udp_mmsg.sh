#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if sendmmsg/recvmmsg were not compiled in
if ! grep -q "HAVE_SENDMMSG 1" config.h || ! grep -q "HAVE_RECVMMSG 1" config.h; then
    exit 77
fi

run_iperf \
    -match "send mmsg array: 8" \
    -s -P 1 -u -i 1 -t 3 -e --recvmmsg 8 \
    -c $ip -P 1 -u -b 10m -i 1 -t 2 -e --sendmmsg 8
