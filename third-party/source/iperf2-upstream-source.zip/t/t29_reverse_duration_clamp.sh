#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for clamping a client-requested reverse-mode duration to
# the server's own -t (Settings.cpp Settings_GenerateClientSettings()):
# in -R/full-duplex/dual-test modes, the server sends data back per a
# duration read directly from the connecting client's own -t request
# (Settings_ReadClientSettingsV1() sets reversed_thread->mAmount from the
# client's header). Without a cap, that request alone controlled how long
# the server would send for - a client could ask for an arbitrarily long
# reverse transfer regardless of the server's own configured limit.
#
# This starts a server with a short -t (its own safety cap) and connects a
# reverse-mode client requesting a much LONGER duration. The server's own
# report must show it stopped at close to its own -t, not the client's
# longer request.

SERVER_T=3
CLIENT_T=10  # deliberately much longer than SERVER_T

server_log=$(mktemp)
run_timeout 20 src/iperf -s -p $port -t $SERVER_T -e > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done

client_out=$(run_timeout 15 src/iperf -c $ip -p $port -R -t $CLIENT_T -e 2>&1)
rc=$?

# Give the server a brief moment to flush its own final summary report line
# before killing it - the connection closing and the report thread printing
# its summary aren't synchronous.
for _ in $(seq 1 30); do
    grep -qE '0\.00-[0-9]+\.[0-9]+ sec' "$server_log" 2>/dev/null && break
    sleep 0.1
done

kill $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true

server_out=$(cat "$server_log")
rm -f "$server_log"

echo "--- client (requested -t $CLIENT_T, reverse) ---"
echo "$client_out"
echo "--- server (own -t $SERVER_T) ---"
echo "$server_out"

if [[ $rc -ne 0 ]]; then
    echo "FAIL: client exited $rc"
    exit 1
fi

server_end=$(echo "$server_out" | grep -oE '0\.00-[0-9]+\.[0-9]+ sec' | tail -1 | sed -E 's/^0\.00-([0-9]+\.[0-9]+) sec$/\1/')
if [[ -z "$server_end" ]]; then
    echo "FAIL: could not parse server's reported interval end time"
    exit 1
fi

# The server must have stopped close to its own SERVER_T, not the client's
# much longer CLIENT_T request.
server_end_int=${server_end%.*}
if (( server_end_int > (SERVER_T + 2) )); then
    echo "FAIL: server ran for ${server_end} sec - expected close to its own ${SERVER_T} sec cap, not the client's requested ${CLIENT_T} sec"
    exit 1
fi

exit 0
