#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for --bounceback combined with --working-load-transport
# udp-l4s (same transport as the main bounceback flow).
#
# Was shipped stubbed to skip for a while: writing t38_working_load_
# transport.sh surfaced what looked like a real, reliably reproducible
# bug - main bounceback flow and the working-load stream sharing one
# server UDP port, "Connection refused" for the main flow, and the
# CLIENT PROCESS HANGING INDEFINITELY past its own -t deadline when this
# happened.
#
# Root-caused as two separate things, both now resolved:
# 1) The hang was RunBounceBackUDP's own fatal-read path (Client.cpp)
#    sharing FATALUDPREADERR with the full-duplex bug fixed alongside
#    this one (see t39_udp_l4s_full_duplex.sh's own doc comment) -
#    thread_stop() on POSIX only pthread_exit()s the calling thread, so
#    the bounceback thread dying fatally left the independent
#    working-load thread running forever, hanging the whole process.
#    Fixed by the same FATALUDPREADERR change.
# 2) The "Connection refused"/total request loss was this test's OWN
#    server invocation using -P 1 - with a single expected connection,
#    Listener.cpp's mCount never re-arms a listening socket after
#    accepting the first of the two flows bounceback+working-load
#    actually need, so the second one was permanently (not just
#    transiently) refused. Not a real dispatch collision - just
#    misconfigured for what this scenario needs, same mistake t39 had.
#
# Verified via 8 concurrent bounceback+working-load-transport-udp-l4s
# clients under CPU stress, and 18 sequential isolated runs: 0 failures,
# 0 hangs, 0 "Connection refused" appearing at all once -P 1 is dropped.
server_log=$(mktemp)
run_timeout 6 src/iperf -s -u -p $port -i 1 -t 4 -e > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

client_out=$(run_timeout 6 src/iperf -c $ip -u -p $port --udp-l4s --bounceback \
    --working-load=down --working-load-transport udp-l4s --working-load-cca reno \
    -i 1 -t 2 -e 2>&1)
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" == *"Connection refused"* || "$client_out" == *"fatal"* ]]; then
    echo "FAIL: main bounceback flow was refused/hit a fatal error - same-port dispatch collision"
    exit 1
fi
if [[ "$client_out" != *"bb req/reply"* ]]; then
    echo "FAIL: main bounceback flow never came up"
    exit 1
fi

exit 0
