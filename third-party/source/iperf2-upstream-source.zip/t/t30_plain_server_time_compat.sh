#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for compatibility: a PLAIN (non-permit-key) server given
# -t must still bound the WHOLE listener accept-loop lifetime, timed from
# process start - not just each accepted connection's own traffic duration.
#
# This is the long-standing, documented behavior most existing scripts and
# single-session server invocations rely on: start the server, run one
# client (optionally with -P N parallel streams as part of the same
# session), and expect the server process to also clean itself up via its
# own -t if a client connection never arrives - exactly the case where a
# timeout matters most, and one a timer that only arms once a connection is
# accepted can't provide.
#
# See t28_listener_forever.sh for the --permit-key case, where -t is scoped
# to just each connection's own duration instead (a persistent/shared
# service scenario, gated on --permit-key specifically).
#
# This starts a plain server with a short -t, waits well past that -t
# WITHOUT ever connecting a client, then tries a new connection - it must
# be refused, since the listener should have already stopped.

SERVER_T=3
WAIT_PAST_T=8  # comfortably more than 2x SERVER_T

server_log=$(mktemp)
run_timeout 20 src/iperf -s -p $port -t $SERVER_T -e > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done

sleep $WAIT_PAST_T

client_out=$(run_timeout 5 src/iperf -c $ip -p $port -e -t 2 2>&1) || true

kill $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ "connected with" ]]; then
    echo "FAIL: client connected after server's own -t should have ended the listener - plain -t no longer bounds the whole listener lifetime"
    exit 1
fi
if [[ ! ("$client_out" =~ "refused"|"failed") ]]; then
    echo "FAIL: expected a connection-refused/failed client message, got something else"
    exit 1
fi

exit 0
