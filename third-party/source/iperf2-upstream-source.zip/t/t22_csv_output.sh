#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# usage:
# run_iperf -s server args   -c client args
#
# CSV report style (-y C) exercises a distinct set of output_handler
# functions (udp/tcp_output_*_csv in ReportOutputs.c) from the default
# human-readable reports, previously untested by this suite. -y C is only
# applied on the client: each side's report format is independent, and
# the server's normal "Server listening" banner is what run_iperf's sync
# step waits for - CSV mode suppresses that text entirely, so a -y C
# server never gets noticed as ready and the client races it.

run_iperf    \
    -match ",127.0.0.1," \
    -s -P 1 -i 1 -t 3     \
    -c $ip -P 1 -i 1 -t 2 -y C
