#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# usage:
# run_iperf -s server args   -c client args
#
# --isochronous exercises the isoch output_handler functions and
# IsochStats accounting, previously untested by this suite. Note
# --isochronous is optional_argument (getopt_long), so the value must
# be attached with '=' rather than a following space-separated token,
# or it's silently dropped and treated as a stray positional argument.

run_iperf    \
    -match "Isochronous:" \
    -s -u -P 1 -i 1 -t 3     \
    -c $ip -u -P 1 --isochronous=60:15m,1m -i 1 -t 2
