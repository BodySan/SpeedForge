#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for SIGUSR1/SIGUSR2-driven pause/resume of a REVERSED
# (--working-load=down) UDP-L4S working-load stream.
#
# Companion to t43_working_load_pause_reverse_tcp.sh (same reversed
# direction, TCP transport, pure backpressure - no wire relay needed)
# and t42_working_load_pause.sh (forward/up direction). UDP has no
# backpressure, so pausing the down-direction UDP-L4S writer - a thread
# the *server* spawns in response to the reverse-mode connection, a
# different process this test's own SIGUSR1/SIGUSR2 can't reach directly
# - needs an actual wire-protocol relay: the reader (Server::RunUDPL4S,
# which - like TCP's reader - runs in this test's own client process via
# the same local role-reversal) sets a new level-triggered L4S_PAUSE bit
# (include/payloads.h) on every ACK it sends while locally paused; the
# writer (Client::RunUDPL4S, running in the server's own process) parses
# that bit out of received ACKs and gates its own send loop on it.
#
# A UDP ACK is normally sent only in reaction to receiving data, so once
# the writer honors a pause and stops sending, the reader has nothing
# left to acknowledge - meaning the writer could never learn of a later
# resume, and its own pre-existing "no ACK for 1s" dead-peer check
# (Client.cpp) could fire and tear the connection down mid-pause. Fixed
# by a timer-driven heartbeat ACK the reader sends every 0.2s while
# genuinely paused, independent of data receipt (Server::RunUDPL4S).
# This test's own pause window is deliberately held past that 1-second
# dead-peer threshold - the whole point is regression coverage for that
# heartbeat, not just "the writer reacts to the flag at all".
#
# Main flow is UDP-L4S bounceback, same reasoning as t42/t40 - its own
# "BB Loss Req=x/y Reply=x/y" line is available to assert zero loss
# against, proving the main flow was never affected by pausing the
# working-load thread running alongside it.
server_log=$(mktemp)
client_log=$(mktemp)
run_timeout 18 src/iperf -s -u -p $port -i 1 -t 14 -e > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

# Deliberately NOT run_timeout/timeout here, same reason as t42/t43 -
# this test needs to send SIGUSR1/SIGUSR2 to the actual iperf client
# process.
src/iperf -c $ip -u -p $port --udp-l4s --bounceback --working-load=down \
    --working-load-transport udp-l4s --working-load-cca reno -i 1 -t 14 -e > "$client_log" 2>&1 &
CPID=$!
( sleep 18; kill -TERM $CPID 2>/dev/null ) &
WATCHDOG=$!

sleep 3
kill -USR1 $CPID 2>/dev/null || true
sleep 3
kill -USR2 $CPID 2>/dev/null || true

wait $CPID 2>/dev/null
client_rc=$?
kill $WATCHDOG 2>/dev/null || true
wait $WATCHDOG 2>/dev/null || true
wait $SPID 2>/dev/null || true

client_out=$(cat "$client_log")
echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log" "$client_log"

# A non-zero exit here means the watchdog had to TERM the client - a
# hang, which is exactly the dead-peer/deadlock regression this test
# guards against (the pause window below is held past the 1-second
# dead-peer threshold specifically to exercise that).
if [[ $client_rc -ne 0 ]]; then
    echo "FAIL: client exited $client_rc (possibly killed by the watchdog - a hang/dead-peer regression)"
    exit 1
fi
if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --bounceback --working-load=down --working-load-transport udp-l4s reported a settings error"
    exit 1
fi
if [[ "$client_out" == *"Connection refused"* || "$client_out" == *"fatal"* ]]; then
    echo "FAIL: a connection was refused or hit a fatal error"
    exit 1
fi
if [[ "$client_out" != *"req/reply"* ]]; then
    echo "FAIL: main bounceback flow never came up"
    exit 1
fi

# The reversed working-load reader's own per-interval line (marked "*",
# e.g. "[ *2]", and identified by its "pps" column, which the bounceback
# line's own format never has) must show a reporting gap of more than 2
# seconds somewhere in the run - proof the pause genuinely held for a
# multi-second span rather than the writer just reacting to one dropped
# ACK. Excludes the always-present final cumulative summary row (its own
# "0.00-14.00"-style span would trivially satisfy a ">2s gap" check on
# its own, whether or not a real pause ever happened) via `head -n -1`.
working_load_lines=$(echo "$client_out" | grep -E '^\[[ *]*[0-9]+\][[:space:]]+[0-9.]+-[0-9.]+ sec' | grep " pps ")
if [[ -z "$working_load_lines" ]]; then
    echo "FAIL: no working-load-down UDP-L4S per-interval lines found at all"
    exit 1
fi
per_interval_lines=$(echo "$working_load_lines" | head -n -1)
max_gap=$(echo "$per_interval_lines" | grep -oE '[0-9]+\.[0-9]+-[0-9]+\.[0-9]+ sec' | awk -F'[- ]' '{d=$2-$1; if (d>max) max=d} END{print max+0}')
if ! awk -v mg="$max_gap" 'BEGIN{exit !(mg>2)}'; then
    echo "FAIL: no working-load-down interval gap greater than 2s found (max gap ${max_gap}s) - SIGUSR1 had no lasting effect"
    exit 1
fi

# Bounceback's own request/reply loss must stay zero throughout - proof
# the main traffic thread was never affected by pausing the reversed
# working-load thread alongside it.
bb_loss_lines=$(echo "$client_out" | grep "BB Loss" || true)
if [[ -z "$bb_loss_lines" ]]; then
    echo "FAIL: no 'BB Loss' lines found at all - bounceback never reported"
    exit 1
fi
if echo "$bb_loss_lines" | grep -qv "Req=0/"; then
    echo "FAIL: bounceback's own request loss wasn't cleanly zero throughout"
    exit 1
fi

exit 0
