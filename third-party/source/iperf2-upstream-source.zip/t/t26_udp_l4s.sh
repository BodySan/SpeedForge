#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# --udp-l4s exercises the *_l4s output_handler functions (udp_output_read_
# enhanced_l4s, udp_output_read_triptime_l4s, etc.) and CE-mark accounting,
# previously untested by this suite.
#
# This intentionally does NOT use run_iperf, because its blanket failure
# grep (unrecognized|ignoring|failed|not valid) false-positives here: the
# server's final-stats ack to the client is a best-effort UDP exchange
# with a fixed retry budget (write_UDP_AckFIN in Reports.c), and can
# legitimately print "WARNING: ack of last datagram failed" under L4S's
# bursty high-rate traffic pattern even when the test itself completed
# fine. (Separately, this same timing surfaced a real bug where the
# client's relayed "Server Report" summary line can show a garbage huge
# Lost count - filed as a SourceForge ticket; not asserted on here since
# it isn't root-caused/fixed yet and would make this test flaky.)

server_log=$(mktemp)
run_timeout 4 src/iperf -s -u -p $port -P 1 -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
sleep 0.5
client_out=$(run_timeout 4 src/iperf -c $ip -u -p $port -P 1 --udp-l4s -e -i 1 -t 2 2>&1)
wait $SPID

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: client reported a settings error"
    exit 1
fi
if [[ "$client_out" != *"L4S"* ]]; then
    echo "FAIL: client output did not mention L4S"
    exit 1
fi

exit 0
