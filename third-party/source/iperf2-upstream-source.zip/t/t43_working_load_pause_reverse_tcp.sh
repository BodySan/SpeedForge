#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for SIGUSR1/SIGUSR2-driven pause/resume of a REVERSED
# (--working-load=down) TCP working-load stream.
#
# Companion to t42_working_load_pause.sh, which intentionally only covers
# --working-load=up because its own writer thread lives in this test's
# own client process. For --working-load=down, the writer thread is
# spawned by the *server* in response to the reverse-mode connection
# (serverside_client_fullduplex/bidir, Launch.cpp) - a different process
# a signal sent to this test's client can't reach directly.
#
# TCP's own reader for the down direction, though, is a Server-class
# thread that DOES run in this test's own client process
# (clientside_client_reverse, Launch.cpp - the client locally reverses
# roles for -R-style directions) - so pausing it needs no wire-protocol
# relay at all. It's implemented as pure backpressure: the reader
# (Server::RunTCP) just stops calling recv() while
# sWorkingLoadPaused is set, and TCP's own flow control (zero
# advertised window) naturally stalls the remote writer - see
# Server::RunTCP's pause-check block, src/Server.cpp.
server_log=$(mktemp)
client_log=$(mktemp)
run_timeout 10 src/iperf -s -p $port -i 1 -t 8 -e > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

# Deliberately NOT run_timeout/timeout here, same reason as t42 - this
# test needs to send SIGUSR1/SIGUSR2 to the actual iperf client process.
src/iperf -c $ip -p $port --bounceback --working-load=down \
    --working-load-transport tcp -i 1 -t 8 -e > "$client_log" 2>&1 &
CPID=$!
( sleep 10; kill -TERM $CPID 2>/dev/null ) &
WATCHDOG=$!

sleep 2.5
kill -USR1 $CPID 2>/dev/null || true
sleep 2.5
kill -USR2 $CPID 2>/dev/null || true

wait $CPID 2>/dev/null
client_rc=$?
kill $WATCHDOG 2>/dev/null || true
wait $WATCHDOG 2>/dev/null || true
wait $SPID 2>/dev/null || true

client_out=$(cat "$client_log")
echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log" "$client_log"

if [[ $client_rc -ne 0 ]]; then
    echo "FAIL: client exited $client_rc (possibly killed by the watchdog - a hang regression)"
    exit 1
fi
if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: --bounceback --working-load=down reported a settings error"
    exit 1
fi
if [[ "$client_out" == *"Connection refused"* || "$client_out" == *"fatal"* ]]; then
    echo "FAIL: a connection was refused or hit a fatal error"
    exit 1
fi
if [[ "$client_out" != *"req/reply"* ]]; then
    echo "FAIL: main bounceback flow never came up"
    exit 1
fi

# The reversed working-load reader's own per-interval line (marked "*"
# by the client's reverse-thread reporting, e.g. "[ *2]") must show at
# least one fully-paused interval (0 bytes - proof SIGUSR1's backpressure
# actually stalled the remote writer) and at least one real, nonzero
# interval both before pausing and after resuming (proof the connection
# didn't just stall permanently, and genuinely resumed). Identified by
# content, not a hardcoded bracket ID, same reasoning as t42.
working_load_lines=$(echo "$client_out" | grep -E '^\[[ *]*[0-9]+\] [0-9.]+-[0-9.]+ sec' | grep -v "RPS=\|BB8\|BB Loss\|SUM")
paused_intervals=$(echo "$working_load_lines" | grep -c "0.000 Bytes" || true)
active_intervals=$(echo "$working_load_lines" | grep -vc "0.000 Bytes" || true)
if [[ "$paused_intervals" -lt 1 ]]; then
    echo "FAIL: no fully-paused (0.000 Bytes) working-load interval found - SIGUSR1 had no effect"
    exit 1
fi
if [[ "$active_intervals" -lt 2 ]]; then
    echo "FAIL: fewer than 2 active working-load intervals (need one before the pause, one after resume)"
    exit 1
fi

# Bounceback's own per-interval line (identified by its "RPS=" column,
# same reasoning as t42) must show all 10 requests completing in at
# least 8 distinct intervals (one per second of the 8-second test) -
# proof the main traffic thread was never affected by pausing the
# reversed working-load thread alongside it. This is TCP (not UDP-L4S)
# bounceback, so there's no "BB Loss" request/reply-loss line to check
# instead (TCP's own reliability makes "requests lost" a UDP-only
# concept, same reasoning as t42's own comment on the *other*
# transport) - the leading "10=" on the bbcnt field is the per-interval
# completed-request count; deliberately not asserting against the final
# cumulative summary line too, whose own count is the run-wide total
# (e.g. 80=), not 10.
full_intervals=$(echo "$client_out" | grep "RPS=" | grep -c " 10=" || true)
if [[ "$full_intervals" -lt 8 ]]; then
    echo "FAIL: fewer than 8 bounceback intervals completed all 10 requests (found $full_intervals)"
    exit 1
fi

exit 0
