#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for plain (unmarked) UDP bounceback - BouncebackTransport.UDP
# in the Android app, native --udp --bounceback (as opposed to the existing
# --udp-l4s --bounceback covered by t33_bounceback_udp_l4s.sh). Same discrete
# stop-and-wait request/reply measurement, deliberately NOT ECT(1)-marked, so
# the two can be A/B compared against the same path (see
# BouncebackTransport's own doc comment, android/.../model/TestConfig.kt).
#
# Server is started with --dual-transport (TCP main + UDP-L4S auxiliary one
# port up, Launch.cpp's listeners_init), matching how the real deployed
# public servers actually run - not a bare `-s -u -p N`. This matters: the
# auxiliary listener's own mSettings has isUDPL4S unconditionally true
# (listeners_init always calls setUDPL4S() on it), so a server-side bug that
# read that static per-listener flag instead of the per-request HEADER_BBL4S
# wire bit would mark every reply regardless of what the client actually
# asked for, and this exact topology is what would catch it.
#
# TOS-byte verification via tcpdump is best-effort, not a hard requirement -
# skips gracefully (not a FAIL) if tcpdump isn't usable in this environment,
# same as any other optional capability check in this suite. Where it *is*
# available, it's the only way to actually verify the wire-level marking
# claim - the CLI/CSV output alone can't distinguish marked from unmarked.

lport=$((port + 1))

server_log=$(mktemp)
run_timeout 8 src/iperf -s -p $port --dual-transport -i 1 -t 5 -e > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done
sleep 0.3

can_capture=0
plain_pcap=$(mktemp --suffix=.pcap 2>/dev/null || mktemp)
l4s_pcap=$(mktemp --suffix=.pcap 2>/dev/null || mktemp)
if command -v tcpdump >/dev/null 2>&1; then
    # Checks process survival, not packet arrival - a `-c 1` probe with a
    # short timeout depends on incidental ambient traffic showing up
    # within the window (usually doesn't, on a quiet loopback), which is
    # unrelated to whether capture permission itself is actually granted
    # and false-skips almost always. No count limit here, so it only
    # exits early if tcpdump itself fails (e.g. "You don't have
    # permission to capture on that device").
    probe_log=$(mktemp)
    tcpdump -i "$loop_iface" -n >"$probe_log" 2>&1 &
    probe_pid=$!
    sleep 0.3
    if kill -0 "$probe_pid" 2>/dev/null; then
        can_capture=1
        kill "$probe_pid" 2>/dev/null || true
        wait "$probe_pid" 2>/dev/null || true
    fi
    rm -f "$probe_log"
fi

if [[ $can_capture -eq 1 ]]; then
    run_timeout 3 tcpdump -i "$loop_iface" -n udp port $lport -w "$plain_pcap" >/dev/null 2>&1 &
    TDPID=$!
    sleep 0.3
fi
plain_out=$(run_timeout 4 src/iperf -c $ip -u -p $lport --bounceback -i 1 -t 1 2>&1)
if [[ $can_capture -eq 1 ]]; then
    wait $TDPID 2>/dev/null || true
fi

if [[ $can_capture -eq 1 ]]; then
    run_timeout 3 tcpdump -i "$loop_iface" -n udp port $lport -w "$l4s_pcap" >/dev/null 2>&1 &
    TDPID=$!
    sleep 0.3
fi
l4s_out=$(run_timeout 4 src/iperf -c $ip -u --udp-l4s -p $lport --bounceback -i 1 -t 1 2>&1)
if [[ $can_capture -eq 1 ]]; then
    wait $TDPID 2>/dev/null || true
fi

wait $SPID 2>/dev/null || true

echo "--- plain udp bounceback client ---"
echo "$plain_out"
echo "--- udp-l4s bounceback client (control) ---"
echo "$l4s_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$plain_out" =~ unrecognized|ignoring|failed|not\ valid ]]; then
    echo "FAIL: unexpected error/warning text in plain UDP bounceback client output"
    exit 1
fi
if [[ "$plain_out" != *"BB cnt="* ]]; then
    echo "FAIL: plain UDP bounceback client output did not show bounceback (BB cnt=) stats"
    exit 1
fi
if [[ "$l4s_out" =~ unrecognized|ignoring|failed|not\ valid ]]; then
    echo "FAIL: unexpected error/warning text in udp-l4s bounceback client output"
    exit 1
fi
if [[ "$l4s_out" != *"BB cnt="* ]]; then
    echo "FAIL: udp-l4s bounceback client output did not show bounceback (BB cnt=) stats"
    exit 1
fi

if [[ $can_capture -eq 1 ]]; then
    # -v's per-packet "IP (tos 0x.., ...)" line is the only one that
    # carries the TOS byte - the second "src.port > dst.port: UDP,
    # length N" line every packet also produces would trivially count as
    # "not ECT(1)" regardless of actual marking, so both totals and
    # marked counts must come from this same one-line-per-packet basis.
    plain_total=$(tcpdump -r "$plain_pcap" -n -v 2>/dev/null | grep -c "tos 0x" || true)
    plain_marked=$(tcpdump -r "$plain_pcap" -n -v 2>/dev/null | grep -c "tos 0x.*ECT(1)" || true)
    l4s_total=$(tcpdump -r "$l4s_pcap" -n -v 2>/dev/null | grep -c "tos 0x" || true)
    l4s_marked=$(tcpdump -r "$l4s_pcap" -n -v 2>/dev/null | grep -c "tos 0x.*ECT(1)" || true)
    echo "--- tos verification: plain-run ECT(1) packets=$plain_marked of $plain_total (want 0), l4s-run ECT(1) packets=$l4s_marked of $l4s_total (want all) ---"
    if [[ "$plain_total" -gt 0 && "$plain_marked" -ne 0 ]]; then
        echo "FAIL: plain UDP bounceback sent/received $plain_marked ECT(1)-marked packet(s) out of $plain_total - wire-level marking regression (HEADER_BBL4S/isUDPL4S conditional)"
        rm -f "$plain_pcap" "$l4s_pcap"
        exit 1
    fi
    if [[ "$l4s_total" -gt 0 && "$l4s_marked" -ne "$l4s_total" ]]; then
        echo "FAIL: udp-l4s bounceback only had $l4s_marked/$l4s_total ECT(1)-marked packets - marking regression"
        rm -f "$plain_pcap" "$l4s_pcap"
        exit 1
    fi
else
    echo "--- tcpdump not usable in this environment, skipping wire-level TOS verification (functional check above still ran) ---"
fi
rm -f "$plain_pcap" "$l4s_pcap"

exit 0
