#!/usr/bin/env python3
"""
Cross-checks printf/fprintf/snprintf argument counts against the
%-specifier counts of the Locale.c report_* format-string constants
used in src/Reports.c and src/ReportOutputs.c.

-Wformat cannot do this check: these format strings are always plain
'const char[]' variables at their call sites, never literals, so gcc
and clang both explicitly decline to verify them (-Wformat-nonliteral).
This script found three real bugs by hand during a manual review (see
doc/RELEASE_NOTES 2.2.2):
  - report_l2statistics was missing a trailing %s, silently dropping
    the --omit indicator.
  - report_write_enhanced_write_format's !(HAVE_TCP_STATS) variant had
    a stray unfed %s, misaligning every argument after it.
  - report_peer_dev's !HAVE_IPV6 branch passed one argument twice,
    shifting two port numbers into %s slots.

All three were gated behind a single HAVE_* macro that isn't the
default on this dev machine's build (HAVE_TCP_STATS and HAVE_IPV6 are
both usually defined here), so a check that only looked at the
*currently configured* build would have missed them too. Instead this
runs the real C preprocessor once per config.h with each relevant
HAVE_*/WIN32 macro flipped, one at a time, from the baseline
configuration - so both states of every #if/#ifdef branch that gates
a report_* string or its call site get checked, using the compiler's
own macro expansion and branch selection instead of a hand-rolled
approximation of the preprocessor.
"""
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_H = os.path.join(ROOT, "config.h")
LOCALE_C = os.path.join(ROOT, "src", "Locale.c")
CALL_SITE_FILES = [
    os.path.join(ROOT, "src", "ReportOutputs.c"),
    os.path.join(ROOT, "src", "Reports.c"),
]

# config.h (autoheader "#define X 1" / "/* #undef X */") toggleable macros
# that gate a report_* format string definition or one of its call sites.
CONFIG_H_MACROS = [
    "HAVE_AF_PACKET", "HAVE_DECL_SO_MAX_PACING_RATE", "HAVE_DECL_SO_TXTIME",
    "HAVE_DECL_TCP_CONGESTION", "HAVE_DECL_TCP_NOTSENT_LOWAT", "HAVE_DECL_TCP_QUICKACK",
    "HAVE_DECL_TCP_TX_DELAY", "HAVE_DECL_TCP_WINDOW_CLAMP", "HAVE_FASTSAMPLING",
    "HAVE_INT64_T", "HAVE_IPV6", "HAVE_KALMAN", "HAVE_LINUX_FILTER_H",
    "HAVE_POSIX_THREAD", "HAVE_RECVMMSG", "HAVE_ROLE_REVERSAL_ID",
    "HAVE_SCHED_SETSCHEDULER", "HAVE_SENDMMSG", "HAVE_STRUCT_TCP_INFO_TCPI_SND_CWND",
    "HAVE_TCP_STATS", "HAVE_THREAD_DEBUG", "HAVE_WIN32_THREAD",
]
# HAVE_TCP_INFLIGHT is intentionally omitted from CONFIG_H_MACROS above: it's
# a derived expression (see include/gettcpinfo.h) that a config.h flip can't
# reliably override since the header unconditionally recomputes it; flipping
# HAVE_TCP_STATS already forces it off in one direction. WIN32 isn't in
# config.h at all (it's set via a real mingw ./configure --host, not a
# flippable macro - see configure_mingw_tree() below).

CC = os.environ.get("CC", "cc")
CPPFLAGS = ["-I", os.path.join(ROOT, "include"), "-I", os.path.join(ROOT, "src"), "-I", ROOT]


def read_config_h():
    return open(CONFIG_H).read()


def write_variant_config_h(base_text, macro, tmpdir):
    """Write a config.h to tmpdir with `macro` flipped from its state in base_text."""
    define_re = re.compile(r'^#define\s+' + re.escape(macro) + r'\b.*$', re.M)
    undef_re = re.compile(r'^/\*\s*#undef\s+' + re.escape(macro) + r'\s*\*/\s*$', re.M)
    if define_re.search(base_text):
        text = define_re.sub("/* #undef %s */" % macro, base_text, count=1)
    elif undef_re.search(base_text):
        text = undef_re.sub("#define %s 1" % macro, base_text, count=1)
    else:
        # Macro not present in config.h at all; nothing to flip here.
        return None
    path = os.path.join(tmpdir, "config.h")
    with open(path, "w") as f:
        f.write(text)
    return tmpdir


class PreprocessError(Exception):
    pass


def preprocess(src_path, config_dir, extra_defines, cc=None):
    cmd = [cc or CC, "-E", "-DHAVE_CONFIG_H"]
    if config_dir:
        cmd += ["-I", config_dir]
    cmd += CPPFLAGS
    for d in extra_defines:
        cmd += ["-D", d]
    cmd.append(src_path)
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise PreprocessError("preprocess failed for %s: %s" % (src_path, p.stderr[-2000:]))
    return p.stdout


LINEMARK_RE = re.compile(r'^# (\d+) "([^"]*)"')


def extract_own_text(preprocessed, target_path):
    """Return (line_no, text_line) pairs contributed by target_path itself,
    filtering out anything pulled in from #included headers."""
    target_base = os.path.basename(target_path)
    out = []
    cur_file = None
    cur_line = 0
    for line in preprocessed.splitlines():
        m = LINEMARK_RE.match(line)
        if m:
            cur_line = int(m.group(1))
            cur_file = os.path.basename(m.group(2))
            continue
        if cur_file == target_base:
            out.append((cur_line, line))
        cur_line += 1
    return out


def merge_adjacent_string_literals(text):
    """cpp doesn't merge adjacent string literals (that's a later translation
    phase); do it ourselves so concatenated pieces (e.g. "%s" IPERFTimeFrmt
    " sec") read as one literal for specifier counting."""
    return re.sub(r'"\s*"', "", text)


def load_locale_defs(config_dir, extra_defines, cc=None):
    pre = preprocess(LOCALE_C, config_dir, extra_defines, cc=cc)
    lines = extract_own_text(pre, LOCALE_C)
    text = "\n".join(l for _, l in lines)
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    defs = {}
    for m in re.finditer(r'const\s+char\s+(\w+)\s*\[\]\s*=\s*(.*?);', text, flags=re.S):
        name, body = m.group(1), m.group(2)
        defs[name] = merge_adjacent_string_literals(body)
    return defs


# Width and/or precision can be a literal number OR a '*' (dynamic - reads
# an extra int argument at that position, before the value itself). Each
# '*' found is an additional argument consumed, not just the specifier's
# own value argument.
SPEC_RE = re.compile(
    r'%[-+ #0]*(\*|[0-9]*)(?:\.(\*|[0-9]*))?(?:hh|h|ll|l|L|q|j|z|t)?[diouxXeEfFgGaAcspn]')


def count_specifiers(literal_body):
    # literal_body is the concatenated string still containing the quotes;
    # strip them out, keep only the literal characters.
    chars = re.findall(r'"((?:[^"\\]|\\.)*)"', literal_body)
    combined = "".join(chars).replace("%%", "\x00")
    nargs = 0
    for width, prec in SPEC_RE.findall(combined):
        nargs += 1  # the specifier's own value argument
        nargs += (width == "*") + (prec == "*")
    return nargs, combined


def find_calls(text, fname):
    calls = []
    for m in re.finditer(r'\b' + fname + r'\s*\(', text):
        start = m.end()
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        calls.append((m.start(), text[start:i - 1]))
    return calls


def split_top_level_commas(s):
    depth = 0
    parts = []
    cur = ""
    in_str = False
    esc = False
    for c in s:
        if in_str:
            cur += c
            if esc:
                esc = False
            elif c == '\\':
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
            cur += c
        elif c in '([{':
            depth += 1
            cur += c
        elif c in ')]}':
            depth -= 1
            cur += c
        elif c == ',' and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += c
    if cur.strip():
        parts.append(cur)
    return [p.strip() for p in parts]


def check_call_sites(config_dir, extra_defines, defs, label, findings, cc=None):
    for src in CALL_SITE_FILES:
        pre = preprocess(src, config_dir, extra_defines, cc=cc)
        lines = extract_own_text(pre, src)
        # keep a mapping from character offset in the joined text back to
        # the original line number for diagnostics
        joined = []
        offsets = []
        pos = 0
        for lineno, l in lines:
            joined.append(l)
            offsets.append((pos, lineno))
            pos += len(l) + 1
        text = "\n".join(joined)

        def lineno_at(offset):
            best = offsets[0][1] if offsets else 0
            for off, ln in offsets:
                if off > offset:
                    break
                best = ln
            return best

        for fname, skip in (("printf", 0), ("fprintf", 1), ("snprintf", 2), ("sprintf", 1)):
            for start, args_text in find_calls(text, fname):
                parts = split_top_level_commas(args_text)
                if len(parts) <= skip:
                    continue
                fmt_arg = parts[skip].strip()
                m = re.match(r'^(\w+)$', fmt_arg)
                if not m or m.group(1) not in defs:
                    continue
                name = m.group(1)
                nspec, combined = count_specifiers(defs[name])
                nargs = len(parts) - skip - 1
                if nspec != nargs:
                    findings.append({
                        "config": label,
                        "file": os.path.relpath(src, ROOT),
                        "line": lineno_at(start),
                        "func": fname,
                        "name": name,
                        "nspec": nspec,
                        "nargs": nargs,
                        "fmt": combined,
                    })


def run_variant(label, config_dir, extra_defines, findings, skipped, cc=None):
    try:
        defs = load_locale_defs(config_dir, extra_defines, cc=cc)
        check_call_sites(config_dir, extra_defines, defs, label, findings, cc=cc)
    except PreprocessError as e:
        skipped.append((label, str(e).splitlines()[0] if str(e) else "unknown error"))


def find_mingw_cc():
    import shutil
    for candidate in ("x86_64-w64-mingw32-gcc", "i686-w64-mingw32-gcc"):
        if shutil.which(candidate):
            return candidate
    return None


def configure_mingw_tree(mingw_cc, tmpdir):
    """Run a real `./configure --host=...` so config.h reflects an actual
    mingw build (HAVE_NET_IF_H, HAVE_TCP_STATS, etc. all correctly probed
    for that target) rather than the native config.h with a single
    -DWIN32=1 bolted on, which leaves every other HAVE_* macro wrong and
    headers.h reaching for Linux-only headers under WIN32.

    autoconf refuses to configure out-of-tree from a srcdir that's already
    configured in-place (which ROOT normally is, since that's how this
    project is built day to day), so clone a clean checkout first - a
    plain git clone has none of the generated Makefile/config.status
    clutter that trips that check."""
    checkout = os.path.join(tmpdir, "src-clean")
    p = subprocess.run(["git", "clone", "-q", "--depth=1", ROOT, checkout],
                        capture_output=True, text=True)
    if p.returncode != 0:
        return None
    host = mingw_cc.replace("-gcc", "")
    cxx = mingw_cc.replace("-gcc", "-g++")
    p = subprocess.run(
        ["./configure", "--host=%s" % host, "CC=%s" % mingw_cc, "CXX=%s" % cxx],
        cwd=checkout, capture_output=True, text=True)
    if p.returncode != 0 or not os.path.exists(os.path.join(checkout, "config.h")):
        return None
    return checkout


def main():
    if not os.path.exists(CONFIG_H):
        print("SKIP: %s not found (run ./configure first)" % CONFIG_H)
        return 77  # automake SKIP convention
    base_text = read_config_h()

    findings = []
    skipped = []

    with tempfile.TemporaryDirectory() as base_tmp:
        # Baseline: the actual configured build.
        run_variant("baseline", None, [], findings, skipped)

        for macro in CONFIG_H_MACROS:
            with tempfile.TemporaryDirectory() as tmpdir:
                cfgdir = write_variant_config_h(base_text, macro, tmpdir)
                if cfgdir is None:
                    continue
                run_variant("%s flipped" % macro, cfgdir, [], findings, skipped)

        # The WIN32 build path needs its own correctly-probed config.h (not
        # just -DWIN32=1 grafted onto the native one, which leaves every
        # other HAVE_* macro wrong and headers.h reaching for Linux-only
        # headers); use a real mingw cross-compiler if one is installed -
        # this is what actually found the mSockDrop/gmtime_r regressions
        # during the manual review - otherwise skip gracefully.
        mingw_cc = find_mingw_cc()
        if mingw_cc:
            with tempfile.TemporaryDirectory() as mingw_tmp:
                mingw_cfgdir = configure_mingw_tree(mingw_cc, mingw_tmp)
                if mingw_cfgdir:
                    run_variant("WIN32 (%s)" % mingw_cc, mingw_cfgdir, [], findings, skipped, cc=mingw_cc)
                else:
                    skipped.append(("WIN32", "mingw ./configure --host failed; see manually"))
        else:
            skipped.append(("WIN32", "no mingw cross-compiler on PATH; install e.g. mingw64-gcc to cover this"))

    # De-duplicate: the same real mismatch typically shows up under many
    # variants (e.g. an IPv6-gated bug appears in every non-HAVE_IPV6-related
    # flip too), so collapse to one entry per unique (file, line, func, name).
    unique = {}
    for f in findings:
        key = (f["file"], f["line"], f["func"], f["name"])
        if key not in unique:
            unique[key] = f
        # nspec/nargs should be identical for the SAME call site regardless
        # of which unrelated macro was flipped; if the count itself differs
        # across configs it's a distinct branch and worth noting separately.
        elif (unique[key]["nspec"], unique[key]["nargs"]) != (f["nspec"], f["nargs"]):
            unique[(f["file"], f["line"], f["func"], f["name"], f["config"])] = f

    total_variants = 1 + len(CONFIG_H_MACROS) + 1  # baseline + flips + mingw/WIN32
    checked = total_variants - len(skipped)
    for label, reason in skipped:
        print("SKIP variant [%s]: %s" % (label, reason))

    # A checker that verified nothing must not report success: the baseline
    # variant in particular requires nothing beyond the compiler already
    # used to build this project, so if even that failed, the toolchain
    # itself is broken and every other "OK" in this run would be a false
    # negative, not an absence of bugs.
    if checked == 0:
        print("FAIL: every build variant failed to preprocess; nothing was "
              "actually checked (toolchain problem, not a source problem)")
        return 1
    if any(label == "baseline" for label, _ in skipped):
        print("FAIL: the baseline variant (this project's own configured "
              "toolchain) failed to preprocess - environment problem")
        return 1

    if not unique:
        print("OK: no printf/fprintf/snprintf argument-count mismatches found "
              "against Locale.c format strings (%d/%d build variants checked)"
              % (checked, total_variants))
        return 0

    for f in sorted(unique.values(), key=lambda f: (f["file"], f["line"])):
        print("MISMATCH [%s]: %s:%d: %s(%s, ...) expects %d specifier(s), got %d argument(s)" % (
            f["config"], f["file"], f["line"], f["func"], f["name"], f["nspec"], f["nargs"]))
        print("    fmt: %r" % f["fmt"])
    print("\nFAIL: %d argument-count mismatch(es) found" % len(unique))
    return 1


if __name__ == "__main__":
    sys.exit(main())
