#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# usage:
# run_iperf -s server args   -c client args
#
# -P > 1 triggers the SumReport machinery and *_output_sum_*/*_output_sumcnt_*
# output_handler functions in Reports.c/ReportOutputs.c. t9_parallel.sh
# already exercises -P > 1 but never asserts on the [SUM] line itself, so
# it wouldn't catch a bug in those handlers (like the missing-argument
# printf bug t21 found in udp_output_sumcnt_enhanced). Explicitly match
# on [SUM] appearing in the output here.

run_iperf    \
    -match "[SUM]" \
    -s -P 3 -i 1 -t 3     \
    -c $ip -P 3 -i 1 -t 2
