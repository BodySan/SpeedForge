#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip on a community edition build - --permit-key/--permit-key-file
# require the professional edition (see Settings.cpp's
# ModalOptions_CommonBailChecks), so a community build's server refuses to
# even start with this test's --permit-key-file option.
if ! grep -q "HAVE_PROFESSIONAL 1" config.h; then
    exit 77
fi

# Regression test for the listener accept-loop lifetime being decoupled
# from -t/mAmount specifically for --permit-key servers (src/Listener.cpp).
#
# Background: --permit-key servers are a persistent/shared service (e.g. a
# public iperf2 responder); -t there is meant to cap each accepted
# connection's own traffic-thread duration (see Server.cpp's per-connection
# mEndTime), while the listener's own lifetime is meant to be bound by
# --permit-key-timeout instead (mListenerTimeout, independent of -t), or by
# -P N (mCount, decremented per accept, e.g. -s -P 1 stops after one).
#
# Before this fix, a permit-key server given -t for connection safety would
# ALSO have its listener's own accept-loop cutoff armed from -t (relative to
# when the server PROCESS started), silently ignoring a much longer
# --permit-key-timeout and stopping the listener from accepting *any new*
# connections once that shorter -t elapsed - exactly the production bug
# this was diagnosed from (a public responder logging a long
# --permit-key-timeout but dying far sooner).
#
# NOTE: this behavior is deliberately scoped to --permit-key servers only.
# A PLAIN server (no --permit-key) keeps the original, documented behavior
# of -t bounding the whole listener lifetime, for compatibility with single-
# session server invocations (see t30_plain_server_time_compat.sh) - per
# team feedback, most scripts assume -t bounds the entire server process,
# not just each connection, and a timer that only starts once a connection
# is accepted can't clean up a server that's still waiting on a connect
# that never arrives.
#
# This starts a --permit-key server with a short -t, waits well past that
# -t from the server's own start time WITHOUT ever connecting a client (so
# the old buggy code's listener-lifetime cutoff would have already fired
# and stopped the accept loop), then tries a brand new connection using the
# same permit key - it must still succeed.

SERVER_T=3
WAIT_PAST_T=8  # comfortably more than 2x SERVER_T
PERMIT_KEY=t28listenerforevertestkey

server_log=$(mktemp)
run_timeout 20 src/iperf -s -p $port -t $SERVER_T -e --permit-key=$PERMIT_KEY --permit-key-timeout 60 > "$server_log" 2>&1 &
SPID=$!
for _ in $(seq 1 40); do
    grep -q "listening" "$server_log" 2>/dev/null && break
    sleep 0.1
done

sleep $WAIT_PAST_T

client_out=$(run_timeout 5 src/iperf -c $ip -p $port -e -t 2 --permit-key=$PERMIT_KEY 2>&1)
rc=$?

kill $SPID 2>/dev/null || true
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ $rc -ne 0 ]]; then
    echo "FAIL: client exited $rc - permit-key listener likely stopped accepting after its own -t elapsed"
    exit 1
fi
if [[ "$client_out" =~ "connection refused"|"failed" ]]; then
    echo "FAIL: connection was refused - permit-key listener stopped accepting new connections"
    exit 1
fi
if [[ ! "$client_out" =~ "connected with" ]]; then
    echo "FAIL: no successful connection banner in client output"
    exit 1
fi

exit 0
