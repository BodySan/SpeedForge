#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# usage:
# run_iperf -s server args   -c client args
#
# client args should contain $ip or -V $ip6
#
# IPv6 counterpart to t24_bounceback.sh - --bounceback's own accept/parse
# path (Listener.cpp's apply_client_settings_tcp bounceback branch) never
# had IPv6 coverage, only plain TCP (t2_tcp6.sh) and UDP (t4_udp6.sh) did.

run_iperf    \
    -match "BB cnt=" \
    -s --ipv6_domain -i 1 -t 3     \
    -c $ip6 -V --bounceback -i 1 -t 1
