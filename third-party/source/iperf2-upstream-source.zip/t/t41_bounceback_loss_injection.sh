#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Skip if UDP L4S was not compiled in (requires ./configure --enable-professional)
if ! grep -q "HAVE_UDP_L4S 1" config.h; then
    exit 77
fi

# Regression test for UDP bounceback's per-direction loss attribution
# (bbreqloss/bbreplyloss, print_bb_loss_csv, ReportOutputs.c) under REAL
# induced loss - t35_bounceback_owd_loss.sh only checks the CSV row's
# shape on a clean, loss-free loopback run, never that the counters
# actually respond correctly when something is genuinely dropped (the
# feature's whole point). Uses the server's IPERF_TEST_BB_DROP_REPLY_
# MODULO debug hook (ProcessBounceBackUDP, Server.cpp) - a test-only
# fault injection mechanism, not a real CLI feature - to silently
# withhold every 3rd reply, then asserts:
#   - bbreqloss stays 0 (only replies are dropped here, not requests -
#     every request the client sent genuinely reached the server)
#   - bbreplyloss is > 0 (the withheld replies show up as reply-
#     direction loss, not request-direction)
# This is what proves the loss-attribution split (request-direction vs
# reply-direction, not just an aggregate loss count) is actually correct,
# not just that the row has the right columns.
#
# bbreqloss is allowed to be 0 or 1, not asserted strictly 0: if the very
# LAST request's own reply happens to land on a dropped slot, the client
# has no way to confirm that request ever reached the server (no later
# reply's echoed bbserverreceived count arrives to prove it) - a genuine,
# documented ambiguity (see bbserverreceived's own doc comment,
# ReportOutputs.c/print_bb_loss_csv), not a bug.

server_log=$(mktemp)
IPERF_TEST_BB_DROP_REPLY_MODULO=3 run_timeout 5 src/iperf -s -u -p $port -P 1 -i 1 -t 3 > "$server_log" 2>&1 &
SPID=$!
sleep 0.5

client_out=$(run_timeout 4 src/iperf -c $ip -u -p $port --udp-l4s --bounceback -e -i 1 -t 2 -y C 2>&1)
wait $SPID 2>/dev/null || true

echo "$client_out"
echo "--- server ---"
cat "$server_log"
rm -f "$server_log"

if [[ "$client_out" =~ unrecognized|ignoring|not\ valid ]]; then
    echo "FAIL: settings error reported"
    exit 1
fi

# Final (last) loss row is the lifetime total across the whole run -
# fields are time,srcaddress,srcport,dstaddr,dstport,transferid,istart,
# iend,bbrequestssent,bbrepliesreceived,bbserverreceived,bbreqloss,
# bbreplyloss (13 fields, bbreqloss is field 12, bbreplyloss is field 13).
loss_data_line=$(echo "$client_out" | grep -A100 "^time,srcaddress.*bbrequestssent" | grep -v "^time,srcaddress\|^---" | tail -1)
echo "sanity: final loss row: $loss_data_line"
bbreqloss=$(echo "$loss_data_line" | cut -d, -f12)
bbreplyloss=$(echo "$loss_data_line" | cut -d, -f13)

if [[ -z "$bbreqloss" || -z "$bbreplyloss" ]]; then
    echo "FAIL: could not parse the final loss row's bbreqloss/bbreplyloss fields"
    exit 1
fi
if [[ "$bbreqloss" -gt 1 ]]; then
    echo "FAIL: bbreqloss was $bbreqloss, expected 0 or 1 (only replies were dropped, not requests - a value of 1 is the documented trailing-ambiguity case)"
    exit 1
fi
if [[ "$bbreplyloss" -le 0 ]]; then
    echo "FAIL: bbreplyloss was $bbreplyloss, expected > 0 (every 3rd reply was withheld)"
    exit 1
fi

exit 0
