#!/usr/bin/env bash
set -e
. $(dirname $0)/base.sh

# Regression test for the client-side counterpart of t18: -c ff02::1%<iface>
# must retain the %<iface> scope suffix (so getaddrinfo() can resolve
# sin6_scope_id for a link-local scope multicast target), and the
# multicast-only option validation (--reverse/--full-duplex/etc) must
# still fire even though the address gets zeroed and re-resolved along
# the way (see the isMcastHost capture in ModalOptions_ClientHostAddress).
# The loopback interface always exists (see loop_iface in base.sh);
# actual delivery over loopback isn't required here.

fail=0

out=$(run_timeout 2 src/iperf -c ff02::1%$loop_iface -u -V -t 1 2>&1) || true
echo "$out"
if [[ ! "$out" =~ "ff02::1%$loop_iface" ]]; then
    echo "FAIL: client dropped the %$loop_iface device suffix for a link-local scope multicast target"
    fail=1
fi
if [[ "$out" =~ "requires a device specifier" ]]; then
    echo "FAIL: client incorrectly reported a missing device specifier"
    fail=1
fi

out2=$(src/iperf -c ff02::1%$loop_iface -u -V --reverse 2>&1) || true
echo "$out2"
if [[ ! "$out2" =~ "not supported with multicast addresses" ]]; then
    echo "FAIL: --reverse was not rejected for a link-local scope multicast target"
    fail=1
fi

exit $fail
