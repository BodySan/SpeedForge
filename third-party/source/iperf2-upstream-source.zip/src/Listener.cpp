/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003 The Board of Trustees of the
 * University of Illinois All Rights Reserved.
 * ---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTRIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Listener.cpp
 * by Mark Gates <mgates@nlanr.net>
 * &  Ajay Tirumala <tirumala@ncsa.uiuc.edu>
 * rewritten by Robert McMahon
 * -------------------------------------------------------------------
 * Listener sets up a socket listening on the server host. For each
 * connected socket that accept() returns, this creates a Server
 * socket and spawns a thread for it.
 *
 * Changes to the latest version. Listener will run as a daemon
 * Multicast Server is now Multi-threaded
 * -------------------------------------------------------------------
 * headers
 * uses
 *   <stdlib.h>
 *   <stdio.h>
 *   <string.h>
 *   <errno.h>
 *
 *   <sys/types.h>
 *   <unistd.h>
 *
 *   <netdb.h>
 *   <netinet/in.h>
 *   <sys/socket.h>
 * ------------------------------------------------------------------- */
#define HEADERS()

#include "headers.h"
#include "Listener.hpp"
#include "SocketAddr.h"
#include "PerfSocket.hpp"
#include "active_hosts.h"
#include "util.h"
#include "version.h"
#include "Locale.h"
#include "SocketAddr.h"
#include "payloads.h"
#include "delay.h"
#include "bpfs.h"
#include "sha256.h"
#include <cstdlib>
#include <ctime>

/* -------------------------------------------------------------------
 * --permit-key-file: server-side list of valid keys, reloadable via
 * SIGHUP without a restart (see main.cpp's Sig_ReloadPermitKeyFile). The
 * *initial* load happens exactly once, centrally, from main() before any
 * listener thread starts (see Listener.hpp's own doc comment on
 * load_permit_key_file() for why - --dual-transport can spawn more than
 * one listener thread, and this data is process-global, not per-listener).
 * The SIGHUP *reload*, though, is still detected independently by each
 * listener thread's own accept loop below (there's no single always-alive
 * thread past startup convenient to centralize that on), so with
 * --dual-transport's two listener threads, two reloads can still race each
 * other on a real SIGHUP - sPermitKeyFileMutex protects the shared
 * array/count against that (a previous version of this code had neither
 * the single-caller startup fix nor this mutex, and two listener threads
 * both resetting-then-repopulating the same unprotected static array
 * concurrently at startup doubled the reported key count, e.g. "Loaded 7"
 * immediately followed by "Loaded 14" for the same 7-line file).
 * File format is systemd
 * EnvironmentFile=-compatible (NAME=VALUE lines, '#' comments, blank
 * lines ignored) so the exact same file already used for a systemd
 * unit's EnvironmentFile= (e.g. /etc/iperf2/permit-key.env holding
 * PERMIT_KEY=<value>) can be pointed at directly with --permit-key-file -
 * any line whose NAME contains "PERMIT_KEY" contributes its VALUE as one
 * valid key, so adding more such lines (a second PERMIT_KEY=, or
 * PERMIT_KEY_PREV=, etc.) extends the accepted list without changing
 * what systemd itself does with the file. Plain fixed-size arrays here,
 * not std::vector/std::string, to match this codebase's existing
 * C-style conventions (no STL used elsewhere in src). Both functions
 * below use a single exit point (goto DONE / one loop-computed return),
 * matching this file's existing apply_client_settings_tcp() convention.
 * ------------------------------------------------------------------- */
#define MAX_PERMIT_KEY_FILE_ENTRIES 64
static char sPermitKeyFileKeys[MAX_PERMIT_KEY_FILE_ENTRIES][MAX_PERMITKEY_LEN + 1];
static int sPermitKeyFileKeyCount = 0;
// Protects the two static members above against a concurrent SIGHUP reload
// racing either another listener thread's own reload (--dual-transport) or
// a connection-handling thread's read via permit_key_file_contains() - see
// this section's own doc comment above for the full reasoning. Not static:
// main.cpp initializes/destroys it in the same central place it does every
// other process-lifetime mutex (transferid_mutex etc., see main.cpp) -
// that's the one point in the process guaranteed to run single-threaded
// before any listener thread exists, so there's no bootstrapping race on
// the mutex's own initialization either.
Mutex sPermitKeyFileMutex;

// Soft, non-cryptographic nags for --permit-key-hmac connections/legacy
// plaintext connections respectively - see test_permit_key()'s own use
// sites below. A benign race across concurrent connection threads on
// either is acceptable (matches this file's existing tolerance for
// unsynchronized WARN-style prints elsewhere) - worst case is an
// occasional off-by-one on which exact connection triggers the nag.
static unsigned long sHmacConnectionCount = 0;
static bool sLegacyPermitKeyWarned = false;
#define PERMITKEY_VENDOR_NAG_INTERVAL 25  // every Nth HMAC connection

bool load_permit_key_file(const char *path) {
    FILE *fp = NULL;
    Mutex_Lock(&sPermitKeyFileMutex);
    sPermitKeyFileKeyCount = 0;
    if (!path || !path[0]) {
        goto DONE;
    }
    fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "WARN: --permit-key-file '%s' could not be opened, no keys loaded from it\n", path);
        goto DONE;
    }
    {
        char line[512];
        int lineno = 0;
        bool full = false;
        while (!full && fgets(line, sizeof(line), fp)) {
            lineno++;
            size_t len = strlen(line);
            while ((len > 0) && ((line[len - 1] == '\n') || (line[len - 1] == '\r'))) {
                line[--len] = '\0';
            }
            char *p = line;
            while ((*p == ' ') || (*p == '\t')) {
                p++;
            }
            char *eq = ((*p == '\0') || (*p == '#')) ? NULL : strchr(p, '=');
            if (eq) {
                *eq = '\0';
                char *name = p;
                char *value = eq + 1;
                char *nameend = eq - 1;
                while ((nameend >= name) && ((*nameend == ' ') || (*nameend == '\t'))) {
                    *nameend = '\0';
                    nameend--;
                }
                if (strstr(name, "PERMIT_KEY")) {
                    while ((*value == ' ') || (*value == '\t')) {
                        value++;
                    }
                    size_t vlen = strlen(value);
                    while ((vlen > 0) && ((value[vlen - 1] == ' ') || (value[vlen - 1] == '\t'))) {
                        value[--vlen] = '\0';
                    }
                    // systemd EnvironmentFile= values may be quoted - strip a
                    // single matching pair so a quoted key isn't rejected as
                    // "too long" by 2.
                    if ((vlen >= 2) && (((value[0] == '"') && (value[vlen - 1] == '"')) ||
                                        ((value[0] == '\'') && (value[vlen - 1] == '\'')))) {
                        value[vlen - 1] = '\0';
                        value++;
                        vlen -= 2;
                    }
                    if (((int)vlen < MIN_PERMITKEY_LEN) || ((int)vlen > MAX_PERMITKEY_LEN)) {
                        fprintf(stderr, "WARN: --permit-key-file '%s' line %d ignored (key length %d outside %d-%d)\n",
                                path, lineno, (int)vlen, MIN_PERMITKEY_LEN, MAX_PERMITKEY_LEN);
                    } else if (sPermitKeyFileKeyCount >= MAX_PERMIT_KEY_FILE_ENTRIES) {
                        fprintf(stderr, "WARN: --permit-key-file '%s' has more than %d keys, ignoring the rest\n",
                                path, MAX_PERMIT_KEY_FILE_ENTRIES);
                        full = true;
                    } else {
                        strncpy(sPermitKeyFileKeys[sPermitKeyFileKeyCount], value, MAX_PERMITKEY_LEN);
                        sPermitKeyFileKeys[sPermitKeyFileKeyCount][MAX_PERMITKEY_LEN] = '\0';
                        sPermitKeyFileKeyCount++;
                    }
                }
            }
        }
        fclose(fp);
        fprintf(stdout, "Loaded %d permit key(s) from %s\n", sPermitKeyFileKeyCount, path);
        // A reload triggered by SIGHUP has no other nearby output that
        // would otherwise flush this for us (unlike the startup banner's
        // own fflush(stdout) right after the initial load) - without this,
        // an operator tailing the log wouldn't see confirmation until
        // something else happened to flush stdout much later.
        fflush(stdout);
    }
DONE:
    {
        bool ok = (sPermitKeyFileKeyCount > 0);
        Mutex_Unlock(&sPermitKeyFileMutex);
        return ok;
    }
}

static bool permit_key_file_contains(const char *key, int keylen) {
    bool found = false;
    int i;
    Mutex_Lock(&sPermitKeyFileMutex);
    for (i = 0; !found && (i < sPermitKeyFileKeyCount); i++) {
        if (((int)strlen(sPermitKeyFileKeys[i]) == keylen) && (strncmp(sPermitKeyFileKeys[i], key, keylen) == 0)) {
            found = true;
        }
    }
    Mutex_Unlock(&sPermitKeyFileMutex);
    return found;
}

// HMAC1-mode sibling of permit_key_file_contains() above - same locking,
// same static table, but each candidate key is used as an HMAC-SHA256 key
// over the presented timestamp rather than compared directly (see
// Listener::test_permit_key()'s own doc comment for the overall design).
static bool permit_key_file_contains_hmac(const unsigned char ts_be[4], const char *presented_mac_hex) {
    bool found = false;
    int i;
    Mutex_Lock(&sPermitKeyFileMutex);
    for (i = 0; !found && (i < sPermitKeyFileKeyCount); i++) {
        unsigned char mac[SHA256_DIGEST_LENGTH];
        hmac_sha256(reinterpret_cast<const unsigned char *>(sPermitKeyFileKeys[i]), strlen(sPermitKeyFileKeys[i]),
                    ts_be, 4, mac);
        char machex[2 * SHA256_DIGEST_LENGTH + 1];
        for (int j = 0; j < SHA256_DIGEST_LENGTH; j++) {
            snprintf(machex + (j * 2), 3, "%02x", mac[j]);
        }
        if (strcmp(machex, presented_mac_hex) == 0) {
            found = true;
        }
    }
    Mutex_Unlock(&sPermitKeyFileMutex);
    return found;
}

/* -------------------------------------------------------------------

 * Stores local hostname and socket info.
 * ------------------------------------------------------------------- */

Listener::Listener(thread_Settings *inSettings) {
    mClients = inSettings->mThreads;
    ListenSocket = INVALID_SOCKET;
    /*
     * These thread settings are stored in three places
     *
     * 1) Listener thread
     * 2) Reporter Thread (per the ReportSettings())
     * 3) Server thread
     */
    mSettings = inSettings;
    drain_count = 0;
    duplicate_count = 0;
}  // end Listener

/* -------------------------------------------------------------------
 * Delete memory (buffer).
 * ------------------------------------------------------------------- */
Listener::~Listener() {
#if HAVE_THREAD_DEBUG
    thread_debug("Listener destructor close sock=%d", ListenSocket);
#endif
    if (ListenSocket != INVALID_SOCKET) {
        int rc = close(ListenSocket);
        WARN_errno(rc == SOCKET_ERROR, "listener close");
    }
}  // end ~Listener

/* -------------------------------------------------------------------
 * This is the main Listener thread loop, listens and accept new
 * connections and starts traffic threads
 *
 * Flow is
 * o) suspend on traffic done for single client case
 * o) hang a select() then accept() on the listener socket
 * o) read or, more accurately, peak the socket for initial messages
 * o) determine and set server's settings flags
 * o) instantiate new settings for listener's clients if needed
 * o) instantiate and bind sum and bidir report objects as needed
 * o) start the threads needed
 *
 * ------------------------------------------------------------------- */
void Listener::Run() {
    // mCount is set True if -P was passed to the server
    mCount = ((mSettings->mThreads != 0) ? mSettings->mThreads : -1);

    // This is a listener launched by the client per -r or -d
    if (mSettings->clientListener) {
        SockAddr_remoteAddr(mSettings);
    }
    if (!isUDP(mSettings)) {
        // TCP needs just one listen
        if (!my_listen())  // This will set ListenSocket to a new sock fd
            return;
    }
    // For a plain (non-permit-key) server, -t bounds the WHOLE listener
    // accept-loop lifetime, timed from process start - this is the
    // long-standing, documented behavior that existing single-session
    // scripts rely on (start server, run a client/-P set, expect the server
    // to also self-terminate on its own -t if nothing ever connects; a
    // timer that only starts once a connection is accepted can't do that).
    //
    // --permit-key servers are different: they're a persistent/shared
    // service (e.g. a public iperf2 responder), where -t is meant to cap
    // each accepted connection's own traffic-thread duration (see
    // Server.cpp's per-connection mEndTime) and the listener's own lifetime
    // is bound instead by --permit-key-timeout (mListenerTimeout,
    // independent of -t) or -P N (mCount, decremented per accept below).
    // Conflating the two meant a permit-key server given -t for connection
    // safety would ALSO have its listener stop accepting new connections
    // after just that -t, ignoring a much longer --permit-key-timeout.
    bool mMode_Time = isServerModeTime(mSettings) && !isDaemon(mSettings) && !isPermitKey(mSettings);
    if (mMode_Time) {
        mEndTime.setnow();
        mEndTime.add(mSettings->mAmount / 100.0);
    } else if (isPermitKey(mSettings) && (mSettings->mListenerTimeout > 0)) {
        mEndTime.setnow();
        mEndTime.add(mSettings->mListenerTimeout);
    }
    // The *initial* --permit-key-file load (including the fatal-if-empty
    // bail check) happens once in main(), before this or any other listener
    // thread starts - see Listener.hpp's load_permit_key_file() doc
    // comment. Nothing to do here at startup; only the SIGHUP reload below
    // is this thread's own responsibility.
    Timestamp now;
    bool need_listen = true;
#define SINGLECLIENTDELAY_DURATION 50000  // units is microseconds

    while (!sInterupted && mCount) {
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Listener main loop port %d ", mSettings->mPort);
#endif
#ifndef WIN32
        if (sReloadPermitKeyFile) {
            sReloadPermitKeyFile = 0;
            if (mSettings->mPermitKeyFile) {
                load_permit_key_file(mSettings->mPermitKeyFile);
            }
        }
#endif
        now.setnow();
        if ((mMode_Time || (mSettings->mListenerTimeout > 0)) && mEndTime.before(now)) {
#ifdef HAVE_THREAD_DEBUG
            thread_debug("Listener port %d (loop timer expired)", mSettings->mPort);
#endif
            break;
        }
        // Serialize in the event the -1 option or --singleclient is set
        int tc = 0;
        if (isSingleClient(mSettings) && mCount && (tc = (thread_numtrafficthreads()) > 0)) {
            // Start with a delay in the event some traffic
            // threads are pending to be scheduled and haven't
            // had a chance to update the traffic thread count.
            // An event system between listener thread and traffic threads
            // might better but also more complex. This delay
            // really should be good enough unless the os scheduler sucks
            delay_loop(SINGLECLIENTDELAY_DURATION);
#ifdef HAVE_THREAD_DEBUG
            thread_debug("Listener single client loop mc/t/mcast/sc %d/%d/%d/%d", mCount, tc, isMulticast(mSettings),
                         isSingleClient(mSettings));
#endif
            continue;
        }
        // This will set ListenSocket to a new sock fd
        if (isUDP(mSettings) && need_listen) {
            // UDP needs a new listen per every new socket
            if (!my_listen()) {
                break;
            } else {
                need_listen = false;
            }
        }
        // Use a select() with a timeout if -t is set or if this is a v1 -r or
        // -d test
        fd_set set;
        if (((mMode_Time || isCompat(mSettings)) && (!isPermitKey(mSettings) && (mSettings->mAmount != 0))) ||
            (isPermitKey(mSettings) && (mSettings->mListenerTimeout != 0))) {
            // Hang a select w/timeout on the listener socket
            struct timeval timeout;
            if (!isPermitKey(mSettings)) {
                timeout.tv_sec = mSettings->mAmount / 100;
                timeout.tv_usec = (mSettings->mAmount % 100) * 10000;
            } else {
                timeout.tv_sec = static_cast<long>(mSettings->mListenerTimeout);
                timeout.tv_usec = (static_cast<long>(mSettings->mListenerTimeout) * 1000000) % 1000000;
                // Poll more often than the full listener timeout when a
                // --permit-key-file is in use, so a SIGHUP-triggered reload
                // (load_permit_key_file() above) gets picked up promptly
                // instead of waiting up to the entire timeout for the next
                // real connection - relying solely on the signal
                // interrupting this select() isn't reliable in a
                // multi-threaded process, since a plain process-directed
                // signal can land on any thread, not necessarily this one.
                if (mSettings->mPermitKeyFile && (timeout.tv_sec > 1)) {
                    timeout.tv_sec = 1;
                    timeout.tv_usec = 0;
                }
            }
            FD_ZERO(&set);
            FD_SET(ListenSocket, &set);
            if (!(select(ListenSocket + 1, &set, NULL, NULL, &timeout) > 0)) {
#ifdef HAVE_THREAD_DEBUG
                thread_debug("Listener select timeout");
#endif
                if (isCompat(mSettings)) {
                    fprintf(stderr, "ERROR: expected reverse connect did not occur\n");
                    break;
                } else
                    continue;
            }
        }
        if (!setsock_blocking(mSettings->mSock, true)) {
            WARN(1, "Failed setting socket to blocking mode");
        }
        // Instantiate another settings object to be used by the server thread
        Settings_Copy(mSettings, &server, DEEP_COPY);
        FAIL(!server, "Failed memory allocation for server settings", mSettings);
        server->mThreadMode = kMode_Server;
        if (!isDataReport(mSettings)) setNoDataReport(server);

        // accept a new socket and assign it to the server thread
        int accept_sock = my_accept(server);
        if (!(accept_sock > 0)) {
            assert(server != mSettings);
#ifdef HAVE_THREAD_DEBUG
            thread_debug("Listener thread accept fail %d", accept_sock);
#endif
            Settings_Destroy(server);
            continue;
        }
        // tInterupted (IPERF_THREAD_LOCAL) is scoped per-thread, not
        // per-connection - it's set true by recvn()/writen() on a fatal
        // I/O error (socket_io.c) so a normal retry loop can bail without
        // touching the process-wide sInterupted flag (see that fix's
        // commit). But this Listener thread is long-lived and reused
        // across every accepted connection's own apply_client_settings_tcp()
        // -> recvn() call below: without resetting it here, the *first*
        // connection this thread ever sees a fatal read error on (e.g. any
        // scanner/bad client) permanently poisons it, and every connection
        // accepted afterward - for the rest of this process's uptime -
        // gets an instant, synchronous nread=0 ("peer close") from
        // recvn(), since its own retry loop's `!tInterupted` check fails
        // before recv() is ever called. Reset here so each new connection
        // starts its own I/O with a clean slate, same as a freshly-spawned
        // per-connection server thread already gets for free.
        tInterupted = 0;
        need_listen = true;
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Listener thread accepted server sock=%d transferID", server->mSock, server->mTransferID);
#endif
        // Decrement the -P counter, commonly usd to kill the listener
        // after one test, i.e. -s -P 1
        if (mCount > 0) {
            mCount--;
        }
        // These are some exception cases where the accepted socket shouldn't
        // have been accepted but the accept() was first required to figure this
        // out
        //
        // 1) When a client started the listener per -d or -r (but not
        // --reverse.)
        //    What's done here is to see if the server peer opening the
        //    socket matches the expected peer per a compare of the ip addresses
        //    For the case of a *client Listener* the server and  host must
        //    match Note: it's a good idea to prefer --reverse and full duplex
        //    socket vs this -d,-r legacy approach. Still support it though in
        //    the name of legacy usage
        //
        // 2) The peer is using a V6 address but the listener/server didn't get
        // -V (for v6) on
        //    it's command line
        //
        if ((mSettings->clientListener && SockAddr_Hostare_Equal(&mSettings->peer, &server->peer)) ||
            (!isIPV6(mSettings) && SockAddr_isIPv6(&server->peer))) {
            // Not allowed, reset things and restart the loop
            // Don't forget to delete the UDP entry (inserted in my_accept)
            Iperf_remove_host(server);
            close(server->mSock);
            assert(server != mSettings);
            Settings_Destroy(server);
            continue;
        }
        // isCompat is a version 1.7 test, basically it indicates there is
        // nothing in the first messages so don't try to process them. Later
        // iperf versions use the first message to convey test request and test
        // settings information.  This flag is also used for threads that are
        // children so-to-speak, e.g. a -d or -r client, which cannot have test
        // flags otherwise there would be "test setup recursion" Time to read
        // the very first packet received (per UDP) or the test flags (TCP) to
        // get the client's requested test information. Note 1: It's important
        // to know that this will also populate mBuf with enough information for
        // the listener to perform test info exchange later in the code Note 2:
        // The mBuf read is a peek so the server's traffic thread started later
        // will also process the first message from an accounting perspective.
        // This is required for accurate traffic statistics
        if (!isCompat(server) && (isConnectOnly(server) || !apply_client_settings(server))) {
            if (isConnectionReport(server) && !isSumOnly(server)) {
                // setTransferID() must run before InitConnectionReport() -
                // the latter's common_copy() snapshots server->mTransferIDStr
                // into the report's own common->transferIDStr right then,
                // not lazily. This early-exit branch (isConnectOnly/failed
                // apply_client_settings - e.g. a stray/duplicate/late UDP
                // packet on an already-closed connection's quintuple,
                // misidentified as a new flow) used to skip straight to
                // InitConnectionReport() without ever calling setTransferID()
                // first (unlike the normal-flow path below, which always
                // calls it beforehand) - so a connection report only ever
                // reached from *this* branch had a permanently-NULL
                // transferIDStr, printing "(null)" as its ID prefix instead
                // of "[ N] ". setTransferID() itself is idempotent (a no-op
                // once mTransferIDStr is already set), so this is safe to
                // call here unconditionally.
                setTransferID(server, NORMAL);
                struct ReportHeader *reporthdr = InitConnectionReport(server);
                assert(reporthdr);
                struct ConnectionInfo *cr = static_cast<struct ConnectionInfo *>(reporthdr->this_report);
                cr->connect_timestamp.tv_sec = server->accept_time.tv_sec;
                cr->connect_timestamp.tv_usec = server->accept_time.tv_usec;
                PostReport(reporthdr);
            }
            Iperf_remove_host(server);
            close(server->mSock);
            assert(server != mSettings);
            Settings_Destroy(server);
            continue;
        }
        // server settings flags should now be set per the client's first
        // message exchange so the server setting's flags per the client can now
        // be checked
        if (isUDP(server)) {
            if (!isCompat(mSettings) && !isTapDev(mSettings) &&
                (isL2LengthCheck(mSettings) || isL2LengthCheck(server)) && !L2_setup(server, server->mSock)) {
                // Requested L2 testing but L2 setup failed
                Iperf_remove_host(server);
                if (server->mSock > 0) close(server->mSock);
#if defined(HAVE_LINUX_FILTER_H) && defined(HAVE_AF_PACKET)
                if (server->mSockDrop > 0) close(server->mSockDrop);
#endif
                assert(server != mSettings);
                Settings_Destroy(server);
                continue;
            }
        }
        setTransferID(server, NORMAL);
        if ((mSettings->mReportMode == kReport_CSV) && server->mSumReport && !server->mSumReport->sum_reverse_set) {
            format_ips_port_string(&server->mSumReport->info, 1);
            server->mSumReport->sum_reverse_set = true;
        } else if (isTripTime(server) && server->mSumReport) {
            SetSumHandlers(server,
                           server->mSumReport);  // this needs to be done again
                                                 // after first read
        }

        // Read any more test settings and test values (not just the flags) and
        // instantiate any settings objects for client threads (e.g. bidir or
        // full duplex) This will set the listener_client_settings to NULL if
        // there is no need for the Listener to start a client
        //
        // Note: the packet payload pointer for this information has different
        // offsets per TCP or UDP. Basically, TCP starts at byte 0 but UDP
        // has to skip over the UDP seq no, etc.
        //
        if (!isCompat(server) && !isCompat(mSettings) &&
            (isFullDuplex(server) || isServerReverse(server) || (server->mMode != kTest_Normal))) {
            thread_Settings *listener_client_settings = NULL;
            // read client header for reverse settings
            Settings_GenerateClientSettings(server, &listener_client_settings, server->mBuf);
            if (listener_client_settings) {
                if (server->mMode != kTest_Normal) listener_client_settings->mTransferID = 0;
                setTransferID(listener_client_settings, REVERSED);
                if (isFullDuplex(listener_client_settings) || isReverse(listener_client_settings))
                    Iperf_push_host(listener_client_settings);
                if (isFullDuplex(server)) {
                    assert(server->mSumReport != NULL);
                    if (!server->mSumReport->sum_fd_set) {
                        // Reset the sum output routine for the server sum
                        // report now that it's know to be full duplex. This
                        // wasn't known during accept()
                        SetSumHandlers(server, server->mSumReport);
                        server->mSumReport->sum_fd_set = true;
                    }
                    server->mFullDuplexReport = InitSumReport(server, server->mSock, true);
                    listener_client_settings->mFullDuplexReport = server->mFullDuplexReport;
#if HAVE_THREAD_DEBUG
                    thread_debug("FullDuplex report client=%p/%p server=%p/%p", (void *)listener_client_settings,
                                 (void *)listener_client_settings->mFullDuplexReport, (void *)server,
                                 (void *)server->mFullDuplexReport);
#endif
                    server->runNow = listener_client_settings;
                } else if (server->mMode != kTest_Normal) {
#if HAVE_THREAD_DEBUG
                    thread_debug(
                        "V1 test (-d or -r) sum report client=%p/%p "
                        "server=%p/%p",
                        (void *)listener_client_settings, (void *)listener_client_settings->mFullDuplexReport,
                        (void *)server, (void *)server->mFullDuplexReport);
#endif
                    if (listener_client_settings->mMode == kTest_DualTest) {
#ifdef HAVE_THREAD
                        server->runNow = listener_client_settings;
#else
                        server->runNext = listener_client_settings;
#endif
                    } else {
                        server->runNext = listener_client_settings;
                    }
                }
            }
        }
        setTransferID(server, NORMAL);
        if (isConnectionReport(server) && !isSumOnly(server)) {
            struct ReportHeader *reporthdr = InitConnectionReport(server);
            struct ConnectionInfo *cr = static_cast<struct ConnectionInfo *>(reporthdr->this_report);
            cr->connect_timestamp.tv_sec = server->accept_time.tv_sec;
            cr->connect_timestamp.tv_usec = server->accept_time.tv_usec;
            assert(reporthdr);
            PostReport(reporthdr);
        }
        // Now start the server side traffic threads
        if (isUDP(server)) {
            Condition_Initialize(&server->receiving);
        }
        thread_start_all(server);
        // For normal UDP server mode, Server::RunUDP signals receiving as soon
        // as the thread is ready, so this wait returns immediately.  For
        // reverse mode the spawned thread is a client sender that never signals
        // receiving, causing a 1-second timeout per stream that serializes -P N
        // connection setup.  Skip the wait for reverse mode.
        if (isUDP(server) && (mCount != 0) && !isServerReverse(server)) {
            Condition_Lock(server->receiving);
            Condition_TimedWait(&server->receiving, 1);
            Condition_Unlock(server->receiving);
        }
    }
#if HAVE_THREAD_DEBUG
    if (isUDP(mSettings) && isEnhanced(mSettings) && ((drain_count > 0) || (duplicate_count > 0))) {
        int len = snprintf(NULL, 0,
                           "[Info] Listener thread filtered and dropped %" PRIdMAX
                           " packets (stale/duplicates=%" PRIdMAX "/%" PRIdMAX ")\n",
                           (drain_count + duplicate_count), drain_count, duplicate_count);
        char *text = (char *)calloc(len + 1, sizeof(char));
        if (text) {
            snprintf(text, len,
                     "[Info] Listener thread filtered and dropped %" PRIdMAX " packets (stale/duplicates=%" PRIdMAX
                     "/%" PRIdMAX ")\n",
                     (drain_count + duplicate_count), drain_count, duplicate_count);
            PostReport(InitStringReport(text));
            FREE_ARRAY(text);
        }
    }
#endif
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Listener exiting port/sig/threads %d/%d/%d", mSettings->mPort, sInterupted, mCount);
#endif
}  // end Run

/* -------------------------------------------------------------------
 * Setup a socket listening on a port.
 * For TCP, this calls bind() and listen().
 * For UDP, this just calls bind().
 * If inLocalhost is not null, bind to that address rather than the
 * wildcard server address, specifying what incoming interface to
 * accept connections on.
 * ------------------------------------------------------------------- */
bool Listener::my_listen() {
    int rc;
    int type;
    int domain;
    SockAddr_localAddr(mSettings);

    if (ListenSocket != INVALID_SOCKET) return true;

#if (((HAVE_TUNTAP_TUN) || (HAVE_TUNTAP_TAP)) && (AF_PACKET))
    if (isTapDev(mSettings)) {
        ListenSocket = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
        FAIL_errno(ListenSocket == SOCKET_ERROR, "tuntap socket()", mSettings);
        mSettings->mSock = ListenSocket;
        rc = SockBPF_v4_Accept(ListenSocket, mSettings->mPort);
        WARN_errno((rc == SOCKET_ERROR), "tap accept bpf");
        SetSocketOptions(mSettings);
    } else
#endif
    {
        // create an AF_INET socket for the accepts
        // for the case of L2 testing and UDP, a new AF_PACKET
        // will be created to supercede this one
        type = (isUDP(mSettings) ? SOCK_DGRAM : SOCK_STREAM);
        domain = SockAddr_getAFdomain(&mSettings->local);

#ifdef WIN32
        if (SockAddr_isMulticast(&mSettings->multicast_group)) {
            // Multicast on Win32 requires special handling
            ListenSocket = WSASocket(domain, type, 0, 0, 0, WSA_FLAG_MULTIPOINT_C_LEAF | WSA_FLAG_MULTIPOINT_D_LEAF);
            WARN_errno(ListenSocket == INVALID_SOCKET, "socket");
        } else
#endif
        {
            ListenSocket = socket(domain, type, 0);
            WARN_errno(ListenSocket == INVALID_SOCKET, "socket");
        }
        mSettings->mSock = ListenSocket;
        SetSocketOptions(mSettings);
        SetSocketBindToDeviceIfNeeded(mSettings);
        rc = SOCKET_ERROR;
        if (isUDP(mSettings) && SockAddr_isMulticast(&mSettings->multicast_group)) {
#if HAVE_MULTICAST
#ifdef WIN32
            // Multicast on Win32 requires special handling
            rc = WSAJoinLeaf(ListenSocket, reinterpret_cast<sockaddr *>(&mSettings->local), mSettings->size_local, 0, 0,
                             0, 0, JL_BOTH);
            WARN_errno(rc == SOCKET_ERROR, "WSAJoinLeaf (aka bind)");
#else
#if 0 && (HAVE_DECL_IP_ADD_MEMBERSHIP || HAVE_DECL_MCAST_JOIN_GROUP)  // possible future, bind to
                                                                      // all including unicast
                iperf_sockaddr tmp;
                memcpy(&tmp, &mSettings->local, sizeof(tmp));
                SockAddr_setAddressAny(&tmp); // the multicast join will take care of this
                rc = bind(ListenSocket, reinterpret_cast<sockaddr*>(&tmp), mSettings->size_local);
                printf("***** any bind\n");
#else
            rc = bind(ListenSocket, reinterpret_cast<sockaddr *>(&mSettings->local), mSettings->size_local);
            //	    printf("***** single bind\n");
#endif
            FAIL_errno(rc == SOCKET_ERROR, "listener bind", mSettings);
            // if UDP and multicast, join the group
            if (iperf_multicast_join(mSettings) != IPERF_MULTICAST_JOIN_SUCCESS) {
                rc = SOCKET_ERROR;
            }
#endif
#else
            fprintf(stderr, "Multicast not supported");
#endif  // HAVE_MULTICAST
        } else {
            // bind socket for unicast
            rc = bind(ListenSocket, reinterpret_cast<sockaddr *>(&mSettings->local), mSettings->size_local);
        }
        FAIL_errno(rc == SOCKET_ERROR, "listener bind", mSettings);
    }
    // update the reporter thread
    if (isSettingsReport(mSettings)) {
        struct ReportHeader *tmp = InitSettingsReport(mSettings);
        setNoSettReport(mSettings);
        assert(tmp != NULL);
        PostReport(tmp);
    }

    // listen for connections (TCP only).
    // use large (INT_MAX) backlog allowing multiple simultaneous connections
    if (!isUDP(mSettings)) {
        if (isSingleClient(mSettings)) {
            rc = listen(ListenSocket, 0 + mSettings->mThreads);
        } else {
            rc = listen(ListenSocket, INT_MAX);
        }
        WARN_errno(rc == SOCKET_ERROR, "listen");
    }
    return true;
}  // end my_listen()

bool Listener::L2_setup(thread_Settings *server, int sockfd) {
#if defined(HAVE_LINUX_FILTER_H) && defined(HAVE_AF_PACKET)
    //
    //  Supporting parallel L2 UDP threads is a bit tricky.  Below are some
    //  notes as to why and the approach used.
    //
    //  The primary issues for UDP are:
    //
    //  1) We want the listener thread to hand off the flow to a server thread
    //  and not be burdened by that flow 2) For -P support, the listener thread
    //  neads to detect new flows which will share the same UDP port
    //     and UDP is stateless
    //
    //  The listener thread needs to detect new traffic flows and hand them to a
    //  new server thread, and then rehang a listen/accept.  For standard iperf
    //  the "flow routing" is done using connect() per the ip quintuple. The OS
    //  will then route established connected flows to the socket descriptor
    //  handled by a server thread and won't burden the listener thread with
    //  these packets.
    //
    //  For L2 verification, we have to create a two sockets that will exist for
    //  the life of the flow.  A new packet socket (AF_PACKET) will receive L2
    //  frames and bypasses the OS network stack.  The original AF_INET socket
    //  will still send up packets to the network stack.
    //
    //  When using packet sockets there is inherent packet duplication, the hand
    //  off to a server thread is not so straight forward as packets will
    //  continue being sent up to the listener thread (technical problem is that
    //  packet sockets do not support connect() which binds the IP quintuple as
    //  the forwarding key) Since the Listener uses recvfrom(), there is no OS
    //  mechanism to detect new flows nor to drop packets.  The listener can't
    //  listen on quintuple based connected flows because the client's source
    //  port is unknown.  Therefore the Listener thread will continue to receive
    //  packets from all established flows sharing the same dst port which will
    //  impact CPU utilization and hence performance.
    //
    //  The technique used to address this is to open an AF_PACKET socket and
    //  leave the AF_INET socket open. (This also aligns with BSD based systems)
    //  The original AF_INET socket will remain in the (connected) state so the
    //  network stack has it's connected state.  A cBPF is then used to cause
    //  the kernel to fast drop those packets.  A cBPF is set up to drop such
    //  packets. The test traffic will then only come over the packet (raw)
    //  socket and not the AF_INET socket. If we were to try to close the
    //  original AF_INET socket (vs leave it open w/the fast drop cBPF) then the
    //  existing traffic will be sent up by the network stack to he Listener
    //  thread, flooding it with packets, again something we want to avoid.
    //
    //  On the packet (raw) socket itself, we do two more things to better
    //  handle performance
    //
    //  1)  Use a full quintuple cBPF allowing the kernel to filter packets
    //  (allow) per the quintuple 2)  Use the packet fanout option to assign a
    //  CBPF to a socket and hence to a single server thread minimizing
    //      duplication (reduce all cBPF's filtering load)
    //
    bool result = false;
    struct sockaddr *p = reinterpret_cast<sockaddr *>(&server->peer);
    struct sockaddr *l = reinterpret_cast<sockaddr *>(&server->local);
    int rc = 0;

    //
    // Establish a packet (raw) socket to be used by the server thread giving it
    // full L2 packets
    //
    struct sockaddr s;
    socklen_t len = sizeof(s);
    getpeername(sockfd, &s, &len);
    if (isIPV6(server)) {
        server->mSock = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IPV6));
        WARN_errno(server->mSock == INVALID_SOCKET, "ip6 packet socket (AF_PACKET)");
        server->l4offset = IPV6HDRLEN + sizeof(struct ether_header);
    } else {
        server->mSock = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
        WARN_errno(server->mSock == INVALID_SOCKET, "ip packet socket (AF_PACKET)");
        unsetIPV6(server);
        server->l4offset = sizeof(struct iphdr) + sizeof(struct ether_header);
    }
    // Didn't get a valid socket, bail out now
    if (server->mSock < 0) {
        // The original AF_INET socket (sockfd) is otherwise unrecoverable
        // once this function returns, since server->mSock (the caller's
        // only handle to it) has just been overwritten above
        close(sockfd);
        goto DONE;
    }
    // More per thread settings based on using a packet socket
    server->l4payloadoffset = server->l4offset + sizeof(struct udphdr);
    server->recvflags = MSG_TRUNC;
    // The original AF_INET socket only exists to keep the connected state
    // in the OS for this flow. Fast drop packets there as
    // now packets will use the AF_PACKET (raw) socket
    // Also, store the original AF_INET socket descriptor so it can be
    // closed in the Server's destructor.  (Note: closing the
    // socket descriptors will also free the cBPF.)
    //
    server->mSockDrop = sockfd;
    rc = SockBPF_Drop_All(sockfd);
    WARN_errno(rc == SOCKET_ERROR, "l2 all drop bpf");

    // Now optimize packet flow up the raw socket
    // Establish the flow BPF to forward up only "connected" packets to this raw
    // socket
    if (l->sa_family == AF_INET6) {
#if HAVE_IPV6
        struct in6_addr *v6peer = SockAddr_get_in6_addr(&server->peer);
        struct in6_addr *v6local = SockAddr_get_in6_addr(&server->local);
        if (isIPV6(server)) {
            rc = SockBPF_v6_Connect(server->mSock, v6local, v6peer,
                                    (reinterpret_cast<struct sockaddr_in6 *>(l))->sin6_port,
                                    (reinterpret_cast<struct sockaddr_in6 *>(p))->sin6_port);
            WARN_errno(rc == SOCKET_ERROR, "l2 connect ipv6 bpf");
        } else {
            // This is an ipv4 address in a v6 family (structure), just pull the
            // lower 32 bits for the v4 addr
            rc = SockBPF_v4_Connect(server->mSock, v6local->s6_addr32[3], v6peer->s6_addr32[3],
                                    (reinterpret_cast<struct sockaddr_in6 *>(l))->sin6_port,
                                    (reinterpret_cast<struct sockaddr_in6 *>(p))->sin6_port);
            WARN_errno(rc == SOCKET_ERROR, "l2 v4in6 connect ip bpf");
        }
#else
        fprintf(stderr, "Unfortunately, IPv6 is not supported on this platform\n");
        rc = -1;
#endif /* HAVE_IPV6 */
    } else {
        rc = SockBPF_v4_Connect(server->mSock, (reinterpret_cast<struct sockaddr_in *>(l))->sin_addr.s_addr,
                                (reinterpret_cast<struct sockaddr_in *>(p))->sin_addr.s_addr,
                                (reinterpret_cast<struct sockaddr_in *>(l))->sin_port,
                                (reinterpret_cast<struct sockaddr_in *>(p))->sin_port);
        WARN_errno(rc == SOCKET_ERROR, "l2 connect ip bpf");
    }
    result = (rc >= 0);
DONE:
    return result;
#else
    fprintf(stderr, "Client requested --l2checks but not supported on this platform\n");
    return false;
#endif
}

bool Listener::tap_setup(thread_Settings *server, int sockfd) {
#if defined(HAVE_IF_TUNTAP) && defined(HAVE_AF_PACKET) && defined(HAVE_DECL_SO_BINDTODEVICE)
    struct sockaddr *p = reinterpret_cast<sockaddr *>(&server->peer);
    struct sockaddr *l = reinterpret_cast<sockaddr *>(&server->local);
    int rc = 0;

    //
    // Establish a packet (raw) socket to be used by the server thread giving it
    // full L2 packets
    //
    struct sockaddr s;
    socklen_t len = sizeof(s);
    getpeername(sockfd, &s, &len);
    if (isIPV6(server)) {
        server->l4offset = IPV6HDRLEN + sizeof(struct ether_header);
    } else {
        server->l4offset = sizeof(struct iphdr) + sizeof(struct ether_header);
    }
    // Didn't get a valid socket, return now
    if (server->mSock < 0) {
        return false;
    }
    // More per thread settings based on using a packet socket
    server->l4payloadoffset = server->l4offset + sizeof(struct udphdr);
    server->recvflags = MSG_TRUNC;
    // Now optimize packet flow up the raw socket
    // Establish the flow BPF to forward up only "connected" packets to this raw
    // socket
    if (l->sa_family == AF_INET6) {
#if HAVE_IPV6
        struct in6_addr *v6peer = SockAddr_get_in6_addr(&server->peer);
        struct in6_addr *v6local = SockAddr_get_in6_addr(&server->local);
        if (isIPV6(server)) {
            rc = SockAddr_v6_Connect_BPF(server->mSock, v6local, v6peer,
                                         (reinterpret_cast<struct sockaddr_in6 *>(l))->sin6_port,
                                         (reinterpret_cast<struct sockaddr_in6 *>(p))->sin6_port);
            WARN_errno(rc == SOCKET_ERROR, "l2 connect ipv6 bpf");
        } else {
            // This is an ipv4 address in a v6 family (structure), just pull the
            // lower 32 bits for the v4 addr
            rc = SockAddr_v4_Connect_BPF(server->mSock, v6local->s6_addr32[3], v6peer->s6_addr32[3],
                                         (reinterpret_cast<struct sockaddr_in6 *>(l))->sin6_port,
                                         (reinterpret_cast<struct sockaddr_in6 *>(p))->sin6_port);
            WARN_errno(rc == SOCKET_ERROR, "l2 v4in6 connect ip bpf");
        }
#else
        fprintf(stderr, "Unfortunately, IPv6 is not supported on this platform\n");
        return false;
#endif /* HAVE_IPV6 */
    } else {
        rc = SockAddr_v4_Connect_BPF(server->mSock, (reinterpret_cast<struct sockaddr_in *>(l))->sin_addr.s_addr,
                                     (reinterpret_cast<struct sockaddr_in *>(p))->sin_addr.s_addr,
                                     (reinterpret_cast<struct sockaddr_in *>(l))->sin_port,
                                     (reinterpret_cast<struct sockaddr_in *>(p))->sin_port);
        WARN_errno(rc == SOCKET_ERROR, "l2 connect ip bpf");
    }
    return rc >= 0;
#else
    fprintf(stderr, "Client requested --l2checks but not supported on this platform\n");
    return false;
#endif
}

/* ------------------------------------------------------------------------
 * Do the equivalent of an accept() call for UDP sockets. This checks
 * a listening UDP socket for new or first received datagram
 * ------------------------------------------------------------------- ----*/
int Listener::udp_accept(thread_Settings *server) {
    assert(server != NULL);
    int nread = 0;
    assert(ListenSocket > 0);
    // Preset the server socket to INVALID, hang recvfrom on the Listener's
    // socket The INVALID socket is used to keep the while loop going
    server->mSock = INVALID_SOCKET;
    bool drainstalepkts = true;
    struct UDP_datagram *mBuf_UDP = reinterpret_cast<struct UDP_datagram *>(server->mBuf);
    // Look for a UDP packet with a postive seq no while draining any neg seq no
    // packets The UDP client traffic thread uses negative seq numbers to
    // indicate to the server that traffic is over. Some of those "final"
    // packets can be in the stack/network pipeline after the server thread has
    // ended and closed its reporting. The Listener will now receive them as if
    // they are "first packets. Any "new" packets seen by the Listener causes a
    // new "udp accept" per UDP's stateless design. So, in the case of negative
    // seq nos, we know that this is most likely not a new client thread
    // requiring a new server thread, but remnants of an old one that already
    // ended. Hence, the Listener should ignore "first packets" when they have
    // negative seq numbers.
RETRYREAD:
    do {
        nread = recvfrom(ListenSocket, server->mBuf, server->mBufLen, 0,
                         reinterpret_cast<struct sockaddr *>(&server->peer), &server->size_peer);
        if (nread > 0) {
            struct client_udp_testhdr *hdr = reinterpret_cast<struct client_udp_testhdr *>(server->mBuf);
            uint32_t flags = ntohl(hdr->base.flags);
            setSeqNo64b(server);
            if (!isCompat(mSettings) && (nread >= 4) && !(flags & HEADER_SEQNO64B)) {
                unsetSeqNo64b(server);
            }
            // filter and ignore negative sequence numbers, these can be
            // heldover from a previous run
            if (isSeqNo64b(server)) {
                // New client - Signed PacketID packed into unsigned id2,id
                intmax_t packetID64 =
                    (static_cast<uint32_t>(ntohl(mBuf_UDP->id))) | (static_cast<uintmax_t>(ntohl(mBuf_UDP->id2)) << 32);
                if (packetID64 > 0) drainstalepkts = false;
            } else {
                // Old client - Signed PacketID in Signed id
                int32_t packetID32 = static_cast<int32_t>(ntohl(mBuf_UDP->id));
                if (packetID32 > 0) drainstalepkts = false;
            }
            if (drainstalepkts) drain_count++;
        }
    } while ((nread > 0) && drainstalepkts && !sInterupted);
    FAIL_errno(nread == SOCKET_ERROR, "recvfrom", mSettings);
    if ((nread > 0) && !sInterupted) {
        Timestamp now;
        server->accept_time.tv_sec = now.getSecs();
        server->accept_time.tv_usec = now.getUsecs();
        // Drop duplicates, may need to use a BPF drop for better performance
        // or ebfs
        if (!Iperf_push_host(server)) {
            duplicate_count++;
            goto RETRYREAD;
        } else {
            int rc;
            if (isUDP(server)) {
                if (isSeqNo64b(server)) {
                    // New client - Signed PacketID packed into unsigned id2,id
                    server->first_packetID = (static_cast<uint32_t>(ntohl(mBuf_UDP->id))) |
                                             (static_cast<uintmax_t>(ntohl(mBuf_UDP->id2)) << 32);
                } else {
                    // Old client - Signed PacketID in Signed id
                    server->first_packetID = static_cast<int32_t>(ntohl(mBuf_UDP->id));
                }
            }
            // We have a new UDP flow (based upon key of quintuple)
            // so let's hand off this socket
            // to the server and create a new listener socket
            server->mSock = ListenSocket;
            ListenSocket = INVALID_SOCKET;
            // This connect() will allow the OS to only
            // send packets with the ip quintuple up to the server
            // socket and, hence, to the server thread (yet to be created)
            // This connect() routing is only supported with AF_INET or AF_INET6
            // sockets, e.g. AF_PACKET sockets can't do this.  We'll handle
            // packet sockets later All UDP accepts here will use AF_INET.  This
            // is intentional and needed
            //
            // There are two choices for connect() and full quintuple matching
            // 1) Open a new socket and connect it as the server thread socket
            // 2) Use the listener thread socket, connect it, and hand it to the
            // server, then openb/bind a new listener socket
            //
            // In case 1, the challenge is packets enqueued won't be made
            // available to the server thread In case 2, there is time period
            // that there is no recvfrom open on the Listener port, can cause
            // port refusal ICMP messages
            //
            // See ticket 357 https://sourceforge.net/p/iperf2/tickets/357/
            if (!isMulticast(server)) {
                rc = connect(server->mSock, reinterpret_cast<struct sockaddr *>(&server->peer), server->size_peer);
                FAIL_errno(rc == SOCKET_ERROR, "connect UDP", mSettings);
                if ((mCount < 0) || (mCount > 1)) my_listen();
                server->size_local = sizeof(iperf_sockaddr);
                getsockname(server->mSock, reinterpret_cast<sockaddr *>(&server->local), &server->size_local);
                SockAddr_Ifrname(server);
            } else {
                server->size_multicast_group = sizeof(iperf_sockaddr);
                iperf_sockaddr sent_dstaddr;
                getsockname(server->mSock, reinterpret_cast<sockaddr *>(&sent_dstaddr), &server->size_multicast_group);
                int join_send_match = SockAddr_Hostare_Equal(&sent_dstaddr, &server->multicast_group);
                rc = connect(server->mSock, reinterpret_cast<struct sockaddr *>(&server->peer), server->size_peer);
                FAIL_errno(rc == SOCKET_ERROR, "mcast connect UDP", mSettings);
                if ((mCount < 0) || (mCount > 1)) my_listen();
#if DEBUG_MCAST
                char joinaddr[200];
                char pktaddr[200];
                size_t len = 200;
                SockAddr_getHostAddress(&sent_dstaddr, joinaddr, len);
                SockAddr_getHostAddress(&server->multicast_group, pktaddr, len);
                printf("mcast(%d): join addr %s pkt group addr %s\n", join_send_match, joinaddr, pktaddr);
#endif
                WARN(!join_send_match, "mcast join and packet group addr");
                // RJM - use a cmesg to read the interface name
            }
            server->firstreadbytes = nread;
        }
    }
    return server->mSock;
}

#if (((HAVE_TUNTAP_TUN) || (HAVE_TUNTAP_TAP)) && (AF_PACKET))
int Listener::tuntap_accept(thread_Settings *server) {
    int rc = recv(
        server->mSock, server->mBuf,
        (server->mBufLen + TAPBYTESSLOP + sizeof(struct iphdr) + sizeof(struct ether_header) + sizeof(struct udphdr)),
        0);
    if (rc <= 0) return 0;
    //	rc = udpchecksum((void *)ip_hdr, (void *)udp_hdr, udplen,
    //(isIPV6(mSettings) ? 1 : 0));
    struct iphdr *l3hdr = (struct iphdr *)((char *)server->mBuf + sizeof(struct ether_header));
    struct udphdr *l4hdr = (struct udphdr *)((char *)server->mBuf + sizeof(struct iphdr) + sizeof(struct ether_header));
    //    uint16_t ipver = (uint16_t) ntohs(mBuf + sizeof(struct ether_header));
    //    printf ("*** version = %d\n", ipver);
    // Note: sockaddrs are stored in network bytes order
    struct sockaddr_in *local = (struct sockaddr_in *)&server->local;
    struct sockaddr_in *peer = (struct sockaddr_in *)&server->peer;
    server->size_peer = sizeof(iperf_sockaddr);
    server->size_local = sizeof(iperf_sockaddr);
    peer->sin_family = AF_INET;
    local->sin_family = AF_INET;
    peer->sin_addr.s_addr = l3hdr->saddr;
    local->sin_addr.s_addr = l3hdr->daddr;
    peer->sin_port = l4hdr->source;
    local->sin_port = l4hdr->dest;
    server->l4offset = sizeof(struct iphdr) + sizeof(struct ether_header);
    SockBPF_v4_Connect_TAP(server->mSock, local->sin_addr.s_addr, peer->sin_addr.s_addr, local->sin_port,
                           peer->sin_port);
    server->l4payloadoffset = sizeof(struct iphdr) + sizeof(struct ether_header) + sizeof(struct udphdr);
    server->firstreadbytes = rc;
    return server->mSock;
}
#endif
/* -------------------------------------------------------------------
 * This is called by the Listener thread main loop, return a socket or error
 * ------------------------------------------------------------------- */
int Listener::my_accept(thread_Settings *server) {
    assert(server != NULL);
#ifdef HAVE_THREAD_DEBUG
    if (isUDP(server)) {
        thread_debug("Listener thread listening for UDP (sock=%d)", ListenSocket);
    } else {
        thread_debug("Listener thread listening for TCP (sock=%d)", ListenSocket);
    }
#endif
    SockAddr_zeroAddress(&server->peer);
    server->size_peer = sizeof(iperf_sockaddr);
    server->accept_time.tv_sec = 0;
    server->accept_time.tv_usec = 0;
    if (isUDP(server)) {
#if (((HAVE_TUNTAP_TUN) || (HAVE_TUNTAP_TAP)) && (AF_PACKET))
        if (isTapDev(server) || isTunDev(server)) {
            server->mSock = tuntap_accept(server);
        } else
#endif
        {
            server->mSock = udp_accept(server);
        }
        // note udp_accept will update the active host table
    } else {
        // accept a TCP  connection
        server->mSock = accept(ListenSocket, reinterpret_cast<sockaddr *>(&server->peer), &server->size_peer);
        if (server->mSock > 0) {
            Timestamp now;
            server->accept_time.tv_sec = now.getSecs();
            server->accept_time.tv_usec = now.getUsecs();
            server->size_local = sizeof(iperf_sockaddr);
            getsockname(server->mSock, reinterpret_cast<sockaddr *>(&server->local), &server->size_local);
            SockAddr_Ifrname(server);
            Iperf_push_host(server);
        }
#if HAVE_RECVMMSG && HAVE_DECL_SO_RCVLOWAT
        if (server->mSock != INVALID_SOCKET) {
            if (setsockopt(server->mSock, SOL_SOCKET, SO_RCVLOWAT, mSettings->recvlowat, sizeof(*mSettings->recvlowat)) != 0) {
                WARN(1, "Failed setting recv low-water mark for the socket");
            }
        }
#endif /* HAVE_RECVMMSG && HAVE_DECL_SO_RCVLOWAT */
    }
    return server->mSock;
}  // end my_accept

// Read deep enough into the packet to get the client settings
// Read the headers but don't pull them from the queue in order to
// preserve server thread accounting, i.e. these exchanges will
// be part of traffic accounting. Return false if it's determined
// this traffic shouldn't be accepted for a test run
// Description of bits and fields is in include/payloads.h
bool Listener::apply_client_settings(thread_Settings *server) {
    assert(server != NULL);
    bool rc = false;

    // Set the receive timeout for the very first read. mListenerTimeout
    // is shared with --permit-key-timeout, whose own scale is days/weeks
    // (it's also this Listener's own overall accept-loop lifetime - see
    // Run() above) - using it directly here as a per-connection socket
    // read timeout overflows the microsecond/int conversion once it's
    // more than ~35 minutes (e.g. a 30-day --permit-key-timeout overflows
    // by ~1200x). The overflowed (negative) value fails
    // setsockopt(SO_RCVTIMEO) silently (just a WARN - see
    // SetSocketOptionsReceiveTimeout), leaving the accepted socket with
    // an effectively infinite receive timeout. Since this is the only
    // accept loop for this port (no thread pool), a single client that
    // completes the TCP handshake but never finishes sending its header -
    // a port scanner, a health-check probe, an abruptly-dropped
    // connection, all things a public listener sees routinely - then
    // wedges this thread forever, and every connection after it piles up
    // unaccepted (confirmed in production: a stuck, non-draining Recv-Q
    // on the listening socket, cleared only by a full service restart).
    // Clamp to MAX_TESTEXCHANGETIMEOUT regardless of mListenerTimeout's
    // own much larger-scale value - a real client finishing its header
    // exchange in under that ceiling is the only case this timeout is
    // actually meant to bound.
    if (mSettings->mListenerTimeout >= 0) {
        double timeout_us = mSettings->mListenerTimeout * 1000000.0;
        int rcvtimer = (timeout_us > MAX_TESTEXCHANGETIMEOUT) ? MAX_TESTEXCHANGETIMEOUT : (int)timeout_us;
        SetSocketOptionsReceiveTimeout(server, rcvtimer);
    } else {
        int sorcvtimer = DEFAULT_TESTEXCHANGETIMEOUT;  // in usecs
        SetSocketOptionsReceiveTimeout(server, sorcvtimer);
    }
    server->peer_version_u = 0;
    server->peer_version_l = 0;
    server->mMode = kTest_Normal;

    if (isUDP(server)) {
        rc = apply_client_settings_udp(server);
    } else if (!isConnectOnly(server)) {
        rc = apply_client_settings_tcp(server);
    }
    if (isOverrideTOS(server)) {
        SetSocketOptionsIPTos(server, server->mRTOS);
    } else if (server->mTOS) {
        SetSocketOptionsIPTos(server, server->mTOS);
    }
    return rc;
}

// "fi-wi-<first 12 hex chars of sha256(version)>" - same formula the
// standalone generator page uses (paste `iperf -v` output, get this same
// value), so an operator can read a ready-to-quote ID straight off their
// own server's nag output without needing to visit that page at all.
// Canonicalizes by trimming trailing whitespace (the trailing "\n" baked
// into Locale.c's version[]/branch_version[] constants) before hashing -
// the page trims whatever's pasted the same way, so both sides must agree
// or a copy-pasted value silently wouldn't match.
static void compute_version_based_vendor_id(char *out, size_t outsize) {
    size_t len = strlen(version);
    while ((len > 0) &&
           ((version[len - 1] == '\n') || (version[len - 1] == '\r') ||
            (version[len - 1] == ' ') || (version[len - 1] == '\t'))) {
        len--;
    }
    unsigned char digest[SHA256_DIGEST_LENGTH];
    sha256(reinterpret_cast<const unsigned char *>(version), len, digest);
    char hex[13];
    for (int j = 0; j < 6; j++) {
        snprintf(hex + (j * 2), 3, "%02x", digest[j]);
    }
    snprintf(out, outsize, "fi-wi-%s", hex);
}

// Accepts a key matching EITHER the single inline --permit-key value (exact
// length+content match, original behavior) OR membership in the
// --permit-key-file list (permit_key_file_contains(), Listener.cpp top),
// whichever was configured. Single exit point (one `return ok`) - see
// load_permit_key_file()/permit_key_file_contains() above for why.
// HMAC1 wire format constants - see build_permit_key_wire_value()'s own
// doc comment (Settings.cpp) for the full design. Format:
// "HMAC1:" + 8 hex ts + ":" + 64 hex HMAC-SHA256(key, ts_be).
static const char PERMITKEY_HMAC_PREFIX[] = "HMAC1:";
#define PERMITKEY_HMAC_PREFIX_LEN (static_cast<int>(sizeof(PERMITKEY_HMAC_PREFIX) - 1))
#define PERMITKEY_HMAC_TS_HEXLEN 8
#define PERMITKEY_HMAC_MAC_HEXLEN (2 * SHA256_DIGEST_LENGTH)
#define PERMITKEY_HMAC_TOTAL_LEN (PERMITKEY_HMAC_PREFIX_LEN + PERMITKEY_HMAC_TS_HEXLEN + 1 + PERMITKEY_HMAC_MAC_HEXLEN)

inline bool Listener::test_permit_key(uint32_t flags, thread_Settings *server, int keyoffset) {
    bool ok = false;
    if (flags & HEADER_KEYCHECK) {
        struct permitKey *thiskey =
            reinterpret_cast<struct permitKey *>(server->mBuf + (keyoffset - sizeof(thiskey->length)));
        int keylen = ntohs(thiskey->length);
        if ((keylen >= MIN_PERMITKEY_LEN) && (keylen <= MAX_PERMITKEY_LEN)) {
            if (!isUDP(server)) {
                int nread = recvn(server->mSock, reinterpret_cast<char *>(&thiskey->value), keylen, 0);
                FAIL_errno((nread < keylen), "read key", server);
            }
            // Record the client's presented key for later display (e.g. the
            // transfer-ID prefix, connection banner) regardless of which
            // mechanism below actually validates it. Exactly the keylen
            // bytes actually presented (memcpy+explicit terminator, not
            // strncpy's own "stop at the first null found within
            // MAX_PERMITKEY_LEN" behavior) - correctness matters here now
            // that this value also drives the HMAC1-prefix parse below,
            // where running past the real end into uninitialized buffer
            // bytes would corrupt the parse.
            memcpy(server->mPermitKey, thiskey->value, keylen);
            server->mPermitKey[keylen] = '\0';

            if ((keylen == PERMITKEY_HMAC_TOTAL_LEN) &&
                (strncmp(server->mPermitKey, PERMITKEY_HMAC_PREFIX, PERMITKEY_HMAC_PREFIX_LEN) == 0) &&
                (server->mPermitKey[PERMITKEY_HMAC_PREFIX_LEN + PERMITKEY_HMAC_TS_HEXLEN] == ':')) {
                // Self-describing HMAC1 value (see build_permit_key_wire_value()) -
                // verified independently of the legacy plaintext path below,
                // so a server upgraded to understand this format still
                // accepts unmodified legacy clients (the prefix simply
                // won't match their raw secret) with no separate mode flag
                // of its own.
                const char *ts_hex = server->mPermitKey + PERMITKEY_HMAC_PREFIX_LEN;
                const char *mac_hex = server->mPermitKey + PERMITKEY_HMAC_PREFIX_LEN + PERMITKEY_HMAC_TS_HEXLEN + 1;
                char *endptr = NULL;
                unsigned long ts_val = strtoul(ts_hex, &endptr, 16);
                if (endptr == (ts_hex + PERMITKEY_HMAC_TS_HEXLEN)) {
                    uint32_t ts = static_cast<uint32_t>(ts_val);
                    long skew = labs(static_cast<long>(time(NULL)) - static_cast<long>(ts));
                    if (skew <= mSettings->mPermitKeyHmacWindowSecs) {
                        unsigned char ts_be[4] = {
                            static_cast<unsigned char>(ts >> 24), static_cast<unsigned char>(ts >> 16),
                            static_cast<unsigned char>(ts >> 8), static_cast<unsigned char>(ts),
                        };
                        if (mSettings->mPermitKey[0] != '\0') {
                            unsigned char mac[SHA256_DIGEST_LENGTH];
                            hmac_sha256(reinterpret_cast<const unsigned char *>(mSettings->mPermitKey),
                                        strlen(mSettings->mPermitKey), ts_be, sizeof(ts_be), mac);
                            char machex[2 * SHA256_DIGEST_LENGTH + 1];
                            for (int j = 0; j < SHA256_DIGEST_LENGTH; j++) {
                                snprintf(machex + (j * 2), 3, "%02x", mac[j]);
                            }
                            if (strcmp(machex, mac_hex) == 0) {
                                ok = true;
                            }
                        }
                        if (!ok && permit_key_file_contains_hmac(ts_be, mac_hex)) {
                            ok = true;
                        }
                    }
                }
                char expectedVendorId[32];
                compute_version_based_vendor_id(expectedVendorId, sizeof(expectedVendorId));
                bool hasVendorId = mSettings->mPermitKeyVendorId &&
                    (strcmp(mSettings->mPermitKeyVendorId, expectedVendorId) == 0);
                if (ok && !hasVendorId &&
                    ((++sHmacConnectionCount % PERMITKEY_VENDOR_NAG_INTERVAL) == 0)) {
                    fprintf(stdout, "NOTICE: this server has authenticated %lu clients "
                            "via --permit-key-hmac without a --permit-key-vendor-id "
                            "set - contact licensing@fi-wi.com to get a valid vendor "
                            "id.\n", sHmacConnectionCount);
                    fflush(stdout);
                }
            } else if (((mSettings->mPermitKey[0] != '\0') &&
                        (keylen == static_cast<int>(strlen(mSettings->mPermitKey))) &&
                        (strncmp(server->mPermitKey, mSettings->mPermitKey, keylen) == 0)) ||
                       permit_key_file_contains(server->mPermitKey, keylen)) {
                ok = true;
                if (!sLegacyPermitKeyWarned) {
                    sLegacyPermitKeyWarned = true;
                    fprintf(stdout, "WARN: this connection authenticated via legacy "
                            "plaintext --permit-key, which is deprecated - see "
                            "--permit-key-hmac and doc/PERMIT_KEY_NOTES.\n");
                    fflush(stdout);
                }
            }
        }
    }
    server->mKeyCheck = ok;
    return ok;
}

bool Listener::apply_client_settings_udp(thread_Settings *server) {
    bool rc = true;
    int avail = server->firstreadbytes - server->l4payloadoffset;
    if (avail < (int)(sizeof(struct UDP_datagram) + sizeof(struct client_hdr_v1))) {
        rc = false;
        goto DONE;
    }
    {
    struct client_udp_testhdr *hdr =
        reinterpret_cast<struct client_udp_testhdr *>(server->mBuf + server->l4payloadoffset);
    uint32_t flags = ntohl(hdr->base.flags);
#ifdef HAVE_DEBUG_TESTFLAGS
    printf("Server test flags = %X(%x)\n", flags, hdr->base.flags);
#endif
    if (flags != 0x36373839) {  // 36373839 is the background pattern
        uint16_t upperflags = 0;
        uint16_t lowerflags = 0;
#if HAVE_THREAD_DEBUG
        thread_debug("UDP test flags = %X", flags);
#endif
#if HAVE_UDP_L4S
        if (flags & HEADER_BOUNCEBACK) {
            // struct bounceback_udp_hdr is a wholly separate wire format
            // from client_udp_testhdr (same relationship TCP bounceback's
            // HEADER_BOUNCEBACK branch in apply_client_settings_tcp has to
            // client_tcp_testhdr) - branch out before any of the general
            // UDP header parsing below, which assumes client_udp_testhdr's
            // shape.
            rc = apply_client_settings_udp_bounceback(server, flags);
            goto DONE;
        }
#endif
        if (flags & HEADER32_SMALL_TRIPTIMES) {
#if HAVE_THREAD_DEBUG
            thread_debug("UDP small header");
#endif
            struct client_udpsmall_testhdr *smallhdr =
                reinterpret_cast<struct client_udpsmall_testhdr *>(server->mBuf + server->l4payloadoffset);
            server->sent_time.tv_sec = ntohl(hdr->seqno_ts.tv_sec);
            server->sent_time.tv_usec = ntohl(hdr->seqno_ts.tv_usec);
            server->txstart_epoch.tv_sec = ntohl(smallhdr->start_tv_sec);
            server->txstart_epoch.tv_usec = ntohl(smallhdr->start_tv_usec);
            uint32_t seqno = ntohl(hdr->seqno_ts.id);
            if (server->txstart_epoch.tv_sec > 0) {
                setTxStartTime(server);
            }
            if (seqno != 1) {
                fprintf(stderr,
                        "WARN: first received packet (id=%d) was not first sent "
                        "packet, report "
                        "start time will be off\n",
                        seqno);
            }
            Timestamp now;
            if (!isTxStartTime(server) &&
                ((abs(now.getSecs() - server->sent_time.tv_sec)) > (MAXDIFFTIMESTAMPSECS + 1))) {
                fprintf(stdout,
                        "WARN: ignore --trip-times because client didn't "
                        "provide valid "
                        "start "
                        "timestamp within %d seconds of now\n",
                        MAXDIFFTIMESTAMPSECS);
                unsetTripTime(server);
            } else {
                setTripTime(server);
            }
            setEnhanced(server);
        } else if ((flags & HEADER_VERSION1) || (flags & HEADER_VERSION2) || (flags & HEADER_EXTEND)) {
            // Mirrors apply_client_settings_tcp's key check (below). The
            // whole datagram, key included, is already in server->mBuf (see
            // test_permit_key's isUDP skip of the recvn it does for TCP), so
            // this just needs the value offset decoded from flags the same
            // way Settings_GenerateClientHdr encoded it.
            if (isPermitKey(mSettings)) {
                if (!test_permit_key(flags, server, Settings_ClientTestHdrLen(flags, mSettings))) {
                    rc = false;
                    goto DONE;
                }
            } else if (flags & HEADER_KEYCHECK) {
                // This server has no --permit-key/--permit-key-file of its
                // own, but the client presented a key anyway (e.g. a
                // professional client's own default key, talking to a
                // server that doesn't gate on one) - still decode it (so
                // server->mPermitKey reflects what was actually offered,
                // e.g. for display), but don't reject: a server with no
                // permit-key requirement should accept every client, keyed
                // or not. test_permit_key sets mKeyCheck=false since
                // nothing here could ever match (no key/file configured to
                // compare against) - force it back to true immediately
                // after, since mKeyCheck's only other consumer (ReportOutputs.c's
                // report_peer/report_peer_fail choice) means "this
                // connection failed the server's own key requirement," and
                // there was no requirement here to fail.
                test_permit_key(flags, server, Settings_ClientTestHdrLen(flags, mSettings));
                server->mKeyCheck = true;
            }
            if (flags & HEADER_VERSION1) {
                uint32_t tidthreads = ntohl(hdr->base.numThreads);
                int buflen_peer_req = ntohl(hdr->base.mBufLen);
                if (buflen_peer_req > kDefault_UDPRxBufLen) {
                    int len = snprintf(NULL, 0, "[WARN] UDP v1 header mBufLen of %d is unrealistic (max=%d), ignoring\n",
                                      buflen_peer_req, kDefault_UDPRxBufLen);
                    char *text = (char *)calloc(len + 1, sizeof(char));
                    if (text) {
                        snprintf(text, len + 1, "[WARN] UDP v1 header mBufLen of %d is unrealistic (max=%d), ignoring\n",
                                 buflen_peer_req, kDefault_UDPRxBufLen);
                        PostReport(InitStringReport(text));
                        FREE_ARRAY(text);
                    }
                    rc = false;
                    goto DONE;
                }
                uint32_t port_peer_req = (uint32_t)ntohl(hdr->base.mPort);
                if (port_peer_req > 65535) {
                    int len = snprintf(NULL, 0, "[WARN] UDP v1 header mPort of %u is invalid, ignoring\n", port_peer_req);
                    char *text = (char *)calloc(len + 1, sizeof(char));
                    if (text) {
                        snprintf(text, len + 1, "[WARN] UDP v1 header mPort of %u is invalid, ignoring\n", port_peer_req);
                        PostReport(InitStringReport(text));
                        FREE_ARRAY(text);
                    }
                    rc = false;
                    goto DONE;
                }
                if (buflen_peer_req != server->mBufLen) {
                    if (!isBuflenSet(server)) {
                        Settings_Resize_mBuf(server, buflen_peer_req);
                    } else if (buflen_peer_req > server->mBufLen) {
                        int len = snprintf(NULL, 0, "ERROR: Client write len of %d too big for server read len of %d\n",
                                          buflen_peer_req, server->mBufLen);
                        char *text = (char *)calloc(len + 1, sizeof(char));
                        if (text) {
                            snprintf(text, len + 1, "ERROR: Client write len of %d too big for server read len of %d\n",
                                     buflen_peer_req, server->mBufLen);
                            PostReport(InitStringReport(text));
                            FREE_ARRAY(text);
                        }
                        rc = false;
                        goto DONE;
                    }
                }
                if (tidthreads & HEADER_HASTRANSFERID) {
                    tidthreads &= (~HEADER_HASTRANSFERID & HEADER_TRANSFERIDMASK);
                    server->mPeerTransferID = tidthreads >> HEADER_TRANSFERIDSHIFT;
                    setSyncTransferID(server);
                } else if (!(flags & HEADER_VERSION2)) {
                    if (flags & RUN_NOW)
                        server->mMode = kTest_DualTest;
                    else
                        server->mMode = kTest_TradeOff;
                }
            }
            if (flags & HEADER_EXTEND) {
                upperflags = htons(hdr->extend.upperflags);
                lowerflags = htons(hdr->extend.lowerflags);
                server->mTOS = ntohs(hdr->extend.tos);
                server->peer_version_u = ntohl(hdr->extend.version_u);
                server->peer_version_l = ntohl(hdr->extend.version_l);
                if (flags & HEADER_UDPTESTS) {
                    // Handle stateless flags
                    if (upperflags & HEADER_ISOCH) {
                        setIsochronous(server);
                    }
                    if (upperflags & HEADER_L2ETHPIPV6) {
                        setIPV6(server);
                    } else {
                        unsetIPV6(server);
                    }
                    if (upperflags & HEADER_L2LENCHECK) {
                        setL2LengthCheck(server);
                    }
                    if (upperflags & HEADER_NOUDPFIN) {
                        setNoUDPfin(server);
                    }
                    if (upperflags & HEADER_UDPL4S) {
                        setUDPL4S(server);
                        SetSocketOptionsIPRCVTos(server);
                    }
                }
                if (upperflags & HEADER_EPOCH_START) {
                    server->txstart_epoch.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                    server->txstart_epoch.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                    Timestamp now;
                    if ((abs(now.getSecs() - server->txstart_epoch.tv_sec)) > (MAXDIFFTXSTART + 1)) {
                        fprintf(stdout,
                                "WARN: ignore --txstart-time because client "
                                "didn't provide "
                                "valid "
                                "start timestamp within %d seconds of now\n",
                                MAXDIFFTXSTART);
                        unsetTxStartTime(server);
                    } else {
                        setTxStartTime(server);
                    }
                }
                // --txdelay-time's relative-duration counterpart to
                // HEADER_EPOCH_START just above - see HEADER_EPOCH_DELAY's
                // own doc comment (payloads.h) for why a relative delay
                // exists alongside the absolute epoch. server->
                // txholdback_timer set here is what Settings_
                // GenerateClientSettings's own relay block (Settings.cpp)
                // re-applies onto the spawned reverse-writer thread after
                // that function's default unsetTxHoldback() strip.
                if (lowerflags & HEADER_EPOCH_DELAY) {
                    server->txholdback_timer.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                    server->txholdback_timer.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                    if (server->txholdback_timer.tv_sec > MAXDIFFTXDELAY) {
                        fprintf(stdout,
                                "WARN: ignore --txdelay-time because client "
                                "provided a delay exceeding %d seconds\n",
                                MAXDIFFTXDELAY);
                        unsetTxHoldback(server);
                    } else {
                        setTxHoldback(server);
                    }
                }
                if (upperflags & HEADER_TRIPTIME) {
                    server->sent_time.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                    server->sent_time.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                    Timestamp now;
                    if (!isTxStartTime(server) &&
                        ((abs(now.getSecs() - server->sent_time.tv_sec)) > (MAXDIFFTIMESTAMPSECS + 1))) {
                        fprintf(stdout,
                                "WARN: ignore --trip-times because client "
                                "didn't provide valid "
                                "start timestamp within %d seconds of now\n",
                                MAXDIFFTIMESTAMPSECS);
                        unsetTripTime(server);
                    } else {
                        setTripTime(server);
                        setEnhanced(server);
                    }
                }
                if ((upperflags & HEADER_HISTOGRAM) && isTripTime(server)) {
                    // Client (professional edition) requested UDP rx latency
                    // histograms. If the server's own command line already set
                    // --histograms (isHistogram() true, bins/ci already populated
                    // by ModalOptions_HistogramDefaults), those local settings take
                    // precedence and are left untouched. Otherwise fall back to the
                    // same defaults server-local --histograms would use (ms bins,
                    // 0-10 secs, 5/95 ci).
                    if (!isHistogram(server)) {
                        server->mHistBins = 10000;
                        server->mHistBinsize = 1;
                        server->mHistUnits = 3;
                        server->mHistci_lower = 5;
                        server->mHistci_upper = 95;
                    }
                    setHistogram(server);
                    setEnhanced(server);
                }
            }
            if (flags & HEADER_VERSION2) {
                upperflags = htons(hdr->extend.upperflags);
                if (upperflags & HEADER_FULLDUPLEX) {
                    setFullDuplex(server);
                    setServerReverse(server);
                }
                if (upperflags & HEADER_REVERSE) {
                    server->mThreadMode = kMode_Client;
                    setServerReverse(server);
                    if (server->mSumReport != NULL) {
                        server->mSumReport->info.common->ThreadMode = kMode_Client;
                        setServerReverse(server->mSumReport->info.common);
                    }
                    setNoUDPfin(server);
                    unsetReport(server);
                }
            }
        }
    }
    } // end avail block
  DONE:
    return rc;
}

#if HAVE_UDP_L4S
// Connection-setup parse for the discrete UDP-L4S bounceback transport
// (struct bounceback_udp_hdr, include/payloads.h) - mirrors
// apply_client_settings_tcp's own HEADER_BOUNCEBACK branch, but the whole
// request (header + zero-fill payload + optional permit-key suffix) is
// already sitting in server->mBuf as one datagram (server->firstreadbytes
// bytes, read by the Listener's own accept-time recv), so there's no
// TCP-style sequence of recvn() calls - just bounds checks against what's
// already buffered. See Client::WriteUdpTxBBHdr/RunBounceBackUDP
// (src/Client.cpp) for the write side.
bool Listener::apply_client_settings_udp_bounceback(thread_Settings *server, uint32_t flags) {
    bool rc = true;
    int avail = server->firstreadbytes - server->l4payloadoffset;
    struct bounceback_udp_hdr *bbhdr =
        reinterpret_cast<struct bounceback_udp_hdr *>(server->mBuf + server->l4payloadoffset);
    if (avail < (int)sizeof(struct bounceback_udp_hdr)) {
        WARN(1, "udp bounceback request too small for header, ignoring");
        rc = false;
        goto DONE;
    }
    if (!isServerModeTime(server)) {
        unsetModeTime(server);
    }
    setBounceBack(server);
    server->mBounceBackBytes = ntohl(bbhdr->bbsize);
    if ((server->mBounceBackBytes > MAXBOUNCEBACKUDPBUFLEN) ||
        (server->mBounceBackBytes < (int)sizeof(struct bounceback_udp_hdr))) {
        int len = snprintf(NULL, 0, "[WARN] UDP BounceBack bbsize of %d is unrealistic (min=%d, max=%d), ignoring\n",
                          server->mBounceBackBytes, (int)sizeof(struct bounceback_udp_hdr), MAXBOUNCEBACKUDPBUFLEN);
        char *text = (char *)calloc(len + 1, sizeof(char));
        if (text) {
            snprintf(text, len + 1, "[WARN] UDP BounceBack bbsize of %d is unrealistic (min=%d, max=%d), ignoring\n",
                     server->mBounceBackBytes, (int)sizeof(struct bounceback_udp_hdr), MAXBOUNCEBACKUDPBUFLEN);
            PostReport(InitStringReport(text));
            FREE_ARRAY(text);
        }
        rc = false;
        goto DONE;
    }
    if (avail < server->mBounceBackBytes) {
        WARN(1, "udp bounceback request shorter than its own bbsize, ignoring");
        rc = false;
        goto DONE;
    }
    if (server->mBounceBackBytes > server->mBufLen) {
        if (isBuflenSet(server)) {
            WARN(1,
                 "Buffer length (-l) too small for udp bounceback request. "
                 "Increase -l size or don't set (for auto-adjust)");
            rc = false;
            goto DONE;
        } else {
            Settings_Resize_mBuf(server, server->mBounceBackBytes);
            bbhdr = reinterpret_cast<struct bounceback_udp_hdr *>(server->mBuf + server->l4payloadoffset);
        }
    }
    server->mBounceBackHold = ntohl(bbhdr->bbhold);
    {
        uint16_t bbflags = ntohs(bbhdr->bbflags);
        if (bbflags & HEADER_BBCLOCKSYNCED) {
            setTripTime(server);
            server->sent_time.tv_sec = ntohl(bbhdr->bbclientTx_ts.sec);
            server->sent_time.tv_usec = ntohl(bbhdr->bbclientTx_ts.usec);
        }
        if (bbflags & HEADER_BBTOS) {
            server->mTOS = ntohs(bbhdr->tos);
        }
        if (bbflags & HEADER_BBREPLYSIZE) {
            server->mBounceBackReplyBytes = ntohl(bbhdr->bbreplysize);
        } else {
            server->mBounceBackReplyBytes = server->mBounceBackBytes;
        }
    }
    if ((server->mBounceBackReplyBytes > MAXBOUNCEBACKUDPBUFLEN) ||
        (server->mBounceBackReplyBytes < (int)sizeof(struct bounceback_udp_hdr))) {
        int len = snprintf(NULL, 0, "[WARN] UDP BounceBack bbreplysize of %d is unrealistic (min=%d, max=%d), ignoring\n",
                          server->mBounceBackReplyBytes, (int)sizeof(struct bounceback_udp_hdr), MAXBOUNCEBACKUDPBUFLEN);
        char *text = (char *)calloc(len + 1, sizeof(char));
        if (text) {
            snprintf(text, len + 1, "[WARN] UDP BounceBack bbreplysize of %d is unrealistic (min=%d, max=%d), ignoring\n",
                     server->mBounceBackReplyBytes, (int)sizeof(struct bounceback_udp_hdr), MAXBOUNCEBACKUDPBUFLEN);
            PostReport(InitStringReport(text));
            FREE_ARRAY(text);
        }
        rc = false;
        goto DONE;
    }
    if (server->mBounceBackReplyBytes > server->mBufLen) {
        if (isBuflenSet(server)) {
            WARN(1,
                 "Buffer length (-l) too small for udp bounceback reply. "
                 "Increase -l size or don't set (for auto-adjust)");
            rc = false;
            goto DONE;
        } else {
            Settings_Resize_mBuf(server, server->mBounceBackReplyBytes);
            bbhdr = reinterpret_cast<struct bounceback_udp_hdr *>(server->mBuf + server->l4payloadoffset);
        }
    }
    // Permit-key handshake: same one-time-at-connection-setup convention as
    // every other test type (see test_permit_key's own doc comment) - but
    // inline in this same datagram (2-byte network-order length + key
    // bytes, immediately following this request's own bbsize-counted
    // bytes), not a separate recvn() the way TCP bounceback does it, since
    // UDP already delivered the whole thing in one read.
    if (isPermitKey(mSettings) && !(flags & HEADER_KEYCHECK)) {
        rc = false;
        server->mKeyCheck = false;
        goto DONE;
    }
    if (flags & HEADER_KEYCHECK) {
        if (avail < (server->mBounceBackBytes + (int)sizeof(uint16_t))) {
            WARN(1, "udp bounceback permit-key length missing");
            rc = false;
            goto DONE;
        }
        int keyoffset = server->mBounceBackBytes + static_cast<int>(sizeof(uint16_t));
        bool keyok = test_permit_key(flags, server, keyoffset);
        if (isPermitKey(mSettings)) {
            if (!keyok) {
                rc = false;
                goto DONE;
            }
        } else {
            // No requirement here to fail against - see
            // apply_client_settings_udp's own mKeyCheck doc comment above.
            server->mKeyCheck = true;
        }
    }
    {
        Timestamp now;
        bbhdr->bbserverRx_ts.sec = htonl(now.getSecs());
        bbhdr->bbserverRx_ts.usec = htonl(now.getUsecs());
    }
  DONE:
    return rc;
}
#endif // HAVE_UDP_L4S

bool Listener::apply_client_settings_tcp(thread_Settings *server) {
    bool rc = false;
#if HAVE_TCP_STATS
    if (!isUDP(mSettings)) {
        gettcpinfo(server->mSock, &server->tcpinitstats);
    }
#endif
    int nread = recvn(server->mSock, server->mBuf, sizeof(uint32_t), 0);
    char *readptr = server->mBuf;
    if (nread == 0) {
        // peer closed the socket, with no writes e.g. a connect-only test
        WARN(1, "read tcp flags (peer close)");
        goto DONE;
    }
    if (nread < (int)sizeof(uint32_t)) {
        WARN(1, "read tcp flags (runt)");
        goto DONE;
    } else {
        rc = true;
        readptr += nread;
        struct client_tcp_testhdr *hdr = reinterpret_cast<struct client_tcp_testhdr *>(server->mBuf);
        uint32_t flags = ntohl(hdr->base.flags);
        if (!(flags & HEADER_KEYCHECK) && !(flags & HEADER_LEN_BIT) && (flags & HEADER_KEYLEN_MASK)) {
            WARN(1, "invalid header field ignored");
            goto DONE;
        }
        if (flags & HEADER_BOUNCEBACK) {
            if (!isServerModeTime(server)) {
                unsetModeTime(server);
            }
            struct bounceback_hdr *bbhdr = reinterpret_cast<struct bounceback_hdr *>(server->mBuf);
            setBounceBack(server);
            nread = recvn(server->mSock, readptr, sizeof(struct bounceback_hdr), 0);
            if (nread != sizeof(struct bounceback_hdr)) {
                WARN(1, "read bounce back header failed");
                rc = false;
                goto DONE;
            }
            readptr += nread;
            server->mBounceBackBytes = ntohl(bbhdr->bbsize);
            if (server->mBounceBackBytes > MAXBOUNCEBACKBUFLEN) {
                int len = snprintf(NULL, 0, "[WARN] BounceBack bbsize of %d is unrealistic (max=%d), ignoring\n",
                                  server->mBounceBackBytes, MAXBOUNCEBACKBUFLEN);
                char *text = (char *)calloc(len + 1, sizeof(char));
                if (text) {
                    snprintf(text, len + 1, "[WARN] BounceBack bbsize of %d is unrealistic (max=%d), ignoring\n",
                             server->mBounceBackBytes, MAXBOUNCEBACKBUFLEN);
                    PostReport(InitStringReport(text));
                    FREE_ARRAY(text);
                }
                rc = false;
                goto DONE;
            }
            if (server->mBounceBackBytes > server->mBufLen) {
                if (isBuflenSet(server)) {
                    WARN(1,
                         "Buffer length (-l) too small for bounceback request. "
                         "Increase "
                         "-l size or "
                         "don't set (for auto-adjust)");
                    rc = false;
                    goto DONE;
                } else {
                    int read_offset = readptr - server->mBuf;
                    Settings_Resize_mBuf(server, server->mBounceBackBytes);
                    readptr = server->mBuf + read_offset;
                    bbhdr = reinterpret_cast<struct bounceback_hdr *>(server->mBuf);
                }
            }
            server->mBounceBackHold = ntohl(bbhdr->bbhold);
            uint16_t bbflags = ntohs(bbhdr->bbflags);
            if (bbflags & HEADER_BBCLOCKSYNCED) {
                setTripTime(server);
                server->sent_time.tv_sec = ntohl(bbhdr->bbclientTx_ts.sec);
                server->sent_time.tv_usec = ntohl(bbhdr->bbclientTx_ts.usec);
            }
            if (bbflags & HEADER_BBTOS) {
                server->mTOS = ntohs(bbhdr->tos);
            }
#if HAVE_DECL_TCP_QUICKACK
            if (bbflags & HEADER_BBQUICKACK) {
                setTcpQuickAck(server);
            }
#endif
            if (bbflags & HEADER_BBREPLYSIZE) {
                server->mBounceBackReplyBytes = ntohl(bbhdr->bbreplysize);
            } else {
                server->mBounceBackReplyBytes = server->mBounceBackBytes;
            }
            if (server->mBounceBackReplyBytes > MAXBOUNCEBACKBUFLEN) {
                int len = snprintf(NULL, 0, "[WARN] BounceBack bbreplysize of %d is unrealistic (max=%d), ignoring\n",
                                  server->mBounceBackReplyBytes, MAXBOUNCEBACKBUFLEN);
                char *text = (char *)calloc(len + 1, sizeof(char));
                if (text) {
                    snprintf(text, len + 1, "[WARN] BounceBack bbreplysize of %d is unrealistic (max=%d), ignoring\n",
                             server->mBounceBackReplyBytes, MAXBOUNCEBACKBUFLEN);
                    PostReport(InitStringReport(text));
                    FREE_ARRAY(text);
                }
                rc = false;
                goto DONE;
            }
            if (server->mBounceBackReplyBytes > server->mBufLen) {
                if (isBuflenSet(server)) {
                    WARN(1,
                         "Buffer length (-l) too small for bounceback reply. "
                         "Increase -l "
                         "size or "
                         "don't set (for auto-adjust)");
                    rc = false;
                    goto DONE;
                } else {
                    int read_offset = readptr - server->mBuf;
                    Settings_Resize_mBuf(server, server->mBounceBackReplyBytes);
                    readptr = server->mBuf + read_offset;
                    bbhdr = reinterpret_cast<struct bounceback_hdr *>(server->mBuf);
                }
            }
            int remaining = server->mBounceBackBytes - (sizeof(struct bounceback_hdr) + sizeof(uint32_t));
            if (remaining < 0) {
                WARN(1, "bounce back bytes too small");
                rc = false;
                goto DONE;
            } else if (remaining > 0) {
                nread = recvn(server->mSock, readptr, remaining, 0);
                if (nread != remaining) {
                    WARN(1, "read bounce back payload failed");
                    rc = false;
                    goto DONE;
                }
            }
            // Permit-key handshake: bounceback used to skip this
            // entirely (it never goes through Settings_GenerateClientHdr,
            // the function every other test type relies on to embed a
            // key), so a bounceback client could reach a public server
            // without ever presenting one. The client (WriteTcpTxBBHdr/
            // RunBounceBackTCP) now sends the key as a separate suffix
            // immediately following this connection's first bounce - its
            // own bbsize-counted bytes above are already fully consumed at
            // this point, so this read doesn't disturb server->mBounceBackBytes
            // or the remaining-payload math every subsequent round trip
            // still relies on. Checked here (once, at connection setup),
            // not per bounce - same one-time convention every other test
            // type already uses.
            if (isPermitKey(mSettings) && !(flags & HEADER_KEYCHECK)) {
                // Server requires a key but this client never signaled
                // one - reject immediately rather than recvn() for a
                // length prefix that was never sent (which would just
                // hang until the socket timeout).
                rc = false;
                server->mKeyCheck = false;
                goto DONE;
            }
            if (flags & HEADER_KEYCHECK) {
                // Read (and, if this server does require a key, verify) the
                // client's presented key whenever it sent one - even when
                // this server has no --permit-key/--permit-key-file of its
                // own (e.g. a professional client's own default key,
                // talking to a server that doesn't gate on one). Skipping
                // the read entirely in that case would leave the key's
                // length+value bytes sitting unread on the wire, desyncing
                // every read after this one - so the bytes always get
                // consumed; only whether a mismatch actually rejects the
                // connection depends on isPermitKey(mSettings) below.
                int keyoffset = server->mBounceBackBytes + static_cast<int>(sizeof(uint16_t));
                if ((keyoffset + MAX_PERMITKEY_LEN) > server->mBufLen) {
                    Settings_Resize_mBuf(server, keyoffset + MAX_PERMITKEY_LEN);
                    bbhdr = reinterpret_cast<struct bounceback_hdr *>(server->mBuf);
                }
                nread = recvn(server->mSock, server->mBuf + server->mBounceBackBytes, sizeof(uint16_t), 0);
                if (nread != static_cast<int>(sizeof(uint16_t))) {
                    WARN(1, "read bounceback permit-key length failed");
                    rc = false;
                    goto DONE;
                }
                bool keyok = test_permit_key(flags, server, keyoffset);
                if (isPermitKey(mSettings)) {
                    if (!keyok) {
                        rc = false;
                        goto DONE;
                    }
                } else {
                    // No requirement here to fail against - see the
                    // UDP branch's own mKeyCheck doc comment above for why
                    // this is forced back to true rather than left at
                    // test_permit_key's own (always-false-here) result.
                    server->mKeyCheck = true;
                }
            }
            if (bbflags & HEADER_BBCCA) {
                // Bounceback's own CCA handshake - the fixed-size
                // bounceback_hdr has no room for a variable-length name,
                // so (same convention as the permit-key suffix just above)
                // the client appends a 2-byte length + name suffix after
                // its first request, immediately following the permit-key
                // suffix if that was also sent. See WriteTcpTxBBHdr/
                // RunBounceBackTCP (src/Client.cpp) for the write side.
                uint16_t ccalen_be = 0;
                nread = recvn(server->mSock, reinterpret_cast<char *>(&ccalen_be), sizeof(ccalen_be), 0);
                if (nread != static_cast<int>(sizeof(ccalen_be))) {
                    WARN(1, "read bounceback cca length failed");
                    rc = false;
                    goto DONE;
                }
                unsigned int ccalen = ntohs(ccalen_be);
                if (ccalen == 0U || ccalen > static_cast<unsigned int>(TCP_CCA_NAME_MAX - 1)) {
                    WARN(1, "invalid bounceback CCA length, ignoring");
                } else {
                    char ccabuf[TCP_CCA_NAME_MAX];
                    nread = recvn(server->mSock, ccabuf, static_cast<int>(ccalen), 0);
                    if (nread != static_cast<int>(ccalen)) {
                        WARN(1, "read bounceback cca value failed");
                        rc = false;
                        goto DONE;
                    }
#if HAVE_DECL_TCP_CONGESTION
                    ccabuf[ccalen] = '\0';
                    setCongestionControl(server);
                    setEnhanced(server);
                    server->mCongestion = new char[ccalen + 1];
                    memcpy(server->mCongestion, ccabuf, ccalen + 1);
                    int crc = setsockopt(server->mSock, IPPROTO_TCP, TCP_CONGESTION, server->mCongestion,
                                         static_cast<Socklen_t>(strlen(server->mCongestion) + 1));
                    if (crc == SOCKET_ERROR) {
                        fprintf(stderr, "Attempt to set '%s' congestion control failed: %s\n",
                                server->mCongestion, strerror(errno));
                        unsetCongestionControl(server);
                        DELETE_ARRAY(server->mCongestion);
                    }
#endif
                }
            }
            Timestamp now;
            bbhdr->bbserverRx_ts.sec = htonl(now.getSecs());
            bbhdr->bbserverRx_ts.usec = htonl(now.getUsecs());
        } else {
            uint16_t upperflags = 0;
            uint16_t lowerflags = 0;
            int readlen;
            // figure out the length of the test header
            if ((readlen = Settings_ClientTestHdrLen(flags, server)) > 0) {
                if (readlen > (server->mBufLen - nread)) {
                    WARN(1, "read tcp header too large");
                    rc = false;
                    goto DONE;
                }
                // read the test settings passed to the server by the client
                nread += recvn(server->mSock, readptr, (readlen - (int)sizeof(uint32_t)), 0);
                FAIL_errno((nread < readlen), "read tcp test info", server);
                if (isPermitKey(mSettings)) {
                    if (!test_permit_key(flags, server, readlen)) {
                        rc = false;
                        goto DONE;
                    }
                } else if (flags & HEADER_KEYCHECK) {
                    // Same "no permit-key requirement here, so accept
                    // regardless, but mKeyCheck still needs forcing back to
                    // true" reasoning as the UDP branch above - still has to
                    // run test_permit_key to consume the key's own recvn()
                    // off the wire (see that function's own isUDP check)
                    // and keep the stream in sync for whatever's read next.
                    test_permit_key(flags, server, readlen);
                    server->mKeyCheck = true;
                }
                if (!Iperf_check_thread_cap(server, MAX_THREADS_PER_CLIENT)) {
                    rc = false;
                    goto DONE;
                }
                server->firstreadbytes = nread;
                struct client_tcp_testhdr *hdr = reinterpret_cast<struct client_tcp_testhdr *>(server->mBuf);
                if (flags & HEADER_VERSION1) {
                    uint32_t tidthreads = ntohl(hdr->base.numThreads);
                    if (tidthreads & HEADER_HASTRANSFERID) {
                        tidthreads &= (~HEADER_HASTRANSFERID & HEADER_TRANSFERIDMASK);
                        server->mPeerTransferID = tidthreads >> HEADER_TRANSFERIDSHIFT;
                        setSyncTransferID(server);
                    } else if (!(flags & HEADER_VERSION2)) {
                        if (flags & RUN_NOW)
                            server->mMode = kTest_DualTest;
                        else
                            server->mMode = kTest_TradeOff;
                    }
                }
                if (flags & HEADER_EXTEND) {
                    upperflags = htons(hdr->extend.upperflags);
                    lowerflags = htons(hdr->extend.lowerflags);
                    server->mTOS = ntohs(hdr->extend.tos);
                    server->peer_version_u = ntohl(hdr->extend.version_u);
                    server->peer_version_l = ntohl(hdr->extend.version_l);
                    if (upperflags & HEADER_ISOCH) {
                        setIsochronous(server);
                    }
                    if (upperflags & HEADER_EPOCH_START) {
                        server->txstart_epoch.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                        server->txstart_epoch.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                        Timestamp now;
                        if ((abs(now.getSecs() - server->txstart_epoch.tv_sec)) > (MAXDIFFTXSTART + 1)) {
                            fprintf(stdout,
                                    "WARN: ignore --txstart-time because "
                                    "client didn't provide "
                                    "valid start timestamp within %d seconds "
                                    "of now\n",
                                    MAXDIFFTXSTART);
                            unsetTxStartTime(server);
                        } else {
                            setTxStartTime(server);
                        }
                    }
                    // See this same block's own doc comment in the UDP
                    // read path above (Listener.cpp) for the full
                    // reasoning - identical handling here for TCP.
                    if (lowerflags & HEADER_EPOCH_DELAY) {
                        server->txholdback_timer.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                        server->txholdback_timer.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                        if (server->txholdback_timer.tv_sec > MAXDIFFTXDELAY) {
                            fprintf(stdout,
                                    "WARN: ignore --txdelay-time because client "
                                    "provided a delay exceeding %d seconds\n",
                                    MAXDIFFTXDELAY);
                            unsetTxHoldback(server);
                        } else {
                            setTxHoldback(server);
                        }
                    }
                    if (upperflags & HEADER_TRIPTIME) {
                        Timestamp now;
                        server->sent_time.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
                        server->sent_time.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
                        if (!isTxStartTime(server) &&
                            ((abs(now.getSecs() - server->sent_time.tv_sec)) > (MAXDIFFTIMESTAMPSECS + 1))) {
                            fprintf(stdout,
                                    "WARN: ignore --trip-times because client "
                                    "didn't provide "
                                    "valid "
                                    "start timestamp within %d seconds of now\n",
                                    MAXDIFFTIMESTAMPSECS);
                            unsetTripTime(server);
                        } else {
                            setTripTime(server);
                            setEnhanced(server);
                        }
                    }
                    if ((upperflags & HEADER_HISTOGRAM) && isTripTime(server)) {
                        // Client (professional edition) requested a server-side
                        // frame-latency histogram. If the server's own command
                        // line already set --histograms, those local bin/ci
                        // settings take precedence and are left untouched.
                        // Otherwise fall back to the same defaults server-local
                        // --histograms would use (ms bins, 0-10 secs, 5/95 ci).
                        if (!isHistogram(server)) {
                            server->mHistBins = 10000;
                            server->mHistBinsize = 1;
                            server->mHistUnits = 3;
                            server->mHistci_lower = 5;
                            server->mHistci_upper = 95;
                        }
                        setHistogram(server);
                        setEnhanced(server);
                    }
                    if (upperflags & HEADER_PERIODICBURST) {
                        setEnhanced(server);
                        setFrameInterval(server);
                        setPeriodicBurst(server);
                        {
                            struct client_tcp_testhdr *hdr =
                                reinterpret_cast<struct client_tcp_testhdr *>(server->mBuf);
                            server->mFPS = ntohl(hdr->isoch_settings.FPSl);
                            server->mFPS += ntohl(hdr->isoch_settings.FPSu) / static_cast<double>(rMillion);
                        }
                        if (!server->mFPS) {
                            server->mFPS = 1.0;
                        }
                    }
                    if ((lowerflags & HEADER_CCA) && !isCongestionControl(server)) {
#if HAVE_DECL_TCP_CONGESTION
                        const char *const hdr_bytes = reinterpret_cast<const char *>(hdr);
                        const int cca_base_off =
                            static_cast<int>(reinterpret_cast<const char *>(&hdr->cca) - hdr_bytes);
                        const int cca_value_off = static_cast<int>(
                            reinterpret_cast<const char *>(&hdr->cca.value) - hdr_bytes);
                        if (nread < cca_base_off + static_cast<int>(sizeof(uint16_t))) {
                            WARN(1, "truncated TCP test header, ignoring CCA");
                        } else {
                            unsigned int decl = ntohs(hdr->cca.cca_length);
                            if (decl == 0U) {
                                WARN(1, "invalid CCA length, ignoring");
                            } else if (decl > static_cast<unsigned int>(TCP_CCA_NAME_MAX)) {
                                WARN(1, "CCA name too long, ignoring");
                            } else if (cca_value_off + static_cast<int>(decl) > nread) {
                                WARN(1, "CCA length exceeds received header, ignoring");
                            } else {
                                int ccalen = static_cast<int>(decl);
                                setCongestionControl(server);
                                setEnhanced(server);
                                server->mCongestion = new char[static_cast<size_t>(ccalen) + 1];
                                if (!server->mCongestion) {
                                    unsetCongestionControl(server);
                                } else {
                                    memcpy(server->mCongestion, hdr->cca.value,
                                           static_cast<size_t>(ccalen));
                                    server->mCongestion[ccalen] = '\0';
                                    Socklen_t len =
                                        static_cast<Socklen_t>(strlen(server->mCongestion) + 1);
                                    int rc = setsockopt(server->mSock, IPPROTO_TCP, TCP_CONGESTION,
                                                        server->mCongestion, len);
                                    if (rc == SOCKET_ERROR) {
                                        fprintf(stderr,
                                                "Attempt to set '%s' congestion "
                                                "control failed: %s\n",
                                                server->mCongestion, strerror(errno));
                                        unsetCongestionControl(server);
                                        DELETE_ARRAY(server->mCongestion);
                                    }
                                }
                            }
                        }
#endif
                    }
                    if (lowerflags & HEADER_BARRIER_TIME) {
                        server->barrier_time = ntohl(hdr->extend.barrier_usecs);
                    }
                    if (flags & HEADER_VERSION2) {
                        if (upperflags & HEADER_FULLDUPLEX) {
                            setFullDuplex(server);
                            setServerReverse(server);
                        }
                        if (upperflags & HEADER_REVERSE) {
                            server->mThreadMode = kMode_Client;
                            setServerReverse(server);
                            if (server->mSumReport != NULL) {
                                server->mSumReport->info.common->ThreadMode = kMode_Client;
                                setServerReverse(server->mSumReport->info.common);
                            }
                        }
                    }
#if HAVE_DECL_TCP_NOTSENT_LOWAT
                    if ((isServerReverse(server) || isFullDuplex(server)) && (upperflags & HEADER_WRITEPREFETCH)) {
                        server->mWritePrefetch = ntohl(hdr->extend.TCPWritePrefetch);
                        if (server->mWritePrefetch > 0) {
                            setWritePrefetch(server);
                        }
                    }
#endif
                    if ((isServerReverse(server) || isFullDuplex(server)) && (lowerflags & HEADER_TCPWRITETIMES)) {
                        setTcpWriteTimes(server);
                    }
#if HAVE_DECL_TCP_QUICKACK
                    if (upperflags & HEADER_TCPQUICKACK) {
                        setTcpQuickAck(server);
                    }
#endif
                    if (upperflags & HEADER_BOUNCEBACK) {
                        setBounceBack(server);
                    }
                }
            }
        }
        // Handle case that requires an ack back to the client
        // Signaled by not UDP (only supported by TCP)
        // and either 2.0.13 flags or the newer 2.0.14 flag of
        // V2PEERDETECT
        if (!isUDP(server) && !isCompat(mSettings) &&
            ((!(flags & HEADER_VERSION2) && (flags & HEADER_EXTEND)) || (flags & HEADER_V2PEERDETECT))) {
            client_test_ack(server);
        }
    }
DONE:
    return rc;
}

int Listener::client_test_ack(thread_Settings *server) {
    if (isUDP(server)) return 1;

    client_hdr_ack ack;
    int sotimer = 0;
    int size = sizeof(struct client_hdr_ack);
    ack.typelen.type = htonl(CLIENTHDRACK);

    ack.flags = 0;
    ack.reserved1 = 0;
    ack.reserved2 = 0;
    ack.version_u = htonl(IPERF_VERSION_MAJORHEX);
    ack.version_l = htonl(IPERF_VERSION_MINORHEX);
    if (isTripTime(server)) {
        ack.ts.sent_tv_sec = htonl(server->sent_time.tv_sec);
        ack.ts.sent_tv_usec = htonl(server->sent_time.tv_usec);
        ack.ts.sentrx_tv_sec = htonl(server->accept_time.tv_sec);
        ack.ts.sentrx_tv_usec = htonl(server->accept_time.tv_usec);
        Timestamp now;
        ack.ts.ack_tv_sec = htonl(now.getSecs());
        ack.ts.ack_tv_usec = htonl(now.getUsecs());
    } else {
        size -= sizeof(struct client_hdr_ack_ts);
    }
    ack.typelen.length = htonl(size);
    int rc = 1;
    // This is a version 2.0.10 or greater client
    // write back to the client so it knows the server
    // version

    // sotimer units microseconds convert
    if (server->mInterval) {
        sotimer = static_cast<int>((server->mInterval) / 4);
    } else if (isModeTime(server)) {
        sotimer = static_cast<int>((server->mAmount * 10000) / 4);
    }
    if (sotimer > HDRXACKMAX) {
        sotimer = HDRXACKMAX;
    } else if (sotimer < HDRXACKMIN) {
        sotimer = HDRXACKMIN;
    }
    SetSocketOptionsSendTimeout(server, sotimer);
#if HAVE_DECL_TCP_NODELAY
    int optflag = 1;
    // Disable Nagle to reduce latency of this intial message
    if ((rc = setsockopt(server->mSock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char *>(&optflag), sizeof(int))) <
        0) {
        WARN_errno(rc < 0, "tcpnodelay");
    }
#endif
    if ((rc = send(server->mSock, reinterpret_cast<const char *>(&ack), size, 0)) < 0) {
        WARN_errno(rc <= 0, "send_ack");
        rc = 0;
    }
#if HAVE_DECL_TCP_NODELAY
    // Re-nable Nagle
    optflag = isNoDelay(server) ? 1 : 0;
    if (!isUDP(server) && (rc = setsockopt(server->mSock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char *>(&optflag),
                                           sizeof(int))) < 0) {
        WARN_errno(rc < 0, "tcpnodelay");
    }
#endif
    return rc;
}
