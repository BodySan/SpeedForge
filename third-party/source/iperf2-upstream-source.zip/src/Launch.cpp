/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Launch.cpp
 * by Kevin Gibbs <kgibbs@nlanr.net>
 * -------------------------------------------------------------------
 * Functions to launch new server and client threads from C while
 * the server and client are in C++.
 * The launch function for reporters is in Reporter.c since it is
 * in C and does not need a special launching function.
 * ------------------------------------------------------------------- */

#include "headers.h"
#include "Thread.h"
#include "Settings.hpp"
#include "Client.hpp"
#include "Listener.hpp"
#include "Server.hpp"
#include "PerfSocket.hpp"
#include "active_hosts.h"
#include "SocketAddr.h"
#include "delay.h"

#ifndef WIN32
// Unblocks SIGUSR1/SIGUSR2 for *this thread only* - called at the very top
// of client_spawn()/server_spawn() when isWorkingLoadThread(thread) is set.
// main.cpp's main() now blocks these two signals before any thread is
// created (see its own doc comment for the full reasoning), so every
// thread inherits "blocked" by default; this is the one deliberate
// exception, scoped to exactly the thread(s) that actually check
// sWorkingLoadPaused (Client.cpp's RunTCP/RunWriteEventsTCP/RunUDPL4S,
// Server.cpp's RunTCP). Delivery of a process-wide kill()-sent signal (the
// only send path available - there's no per-thread id for the Android app
// to target even if it wanted to) always lands on some thread that
// doesn't have it blocked; keeping every other thread blocked makes the
// working-load thread(s) the only eligible candidate instead of an
// arbitrary one.
static void unblock_working_load_pause_signals(void) {
    sigset_t working_load_pause_signals;
    sigemptyset(&working_load_pause_signals);
    sigaddset(&working_load_pause_signals, SIGUSR1);
    sigaddset(&working_load_pause_signals, SIGUSR2);
    sigprocmask(SIG_UNBLOCK, &working_load_pause_signals, NULL);
}
#endif

static int fullduplex_startstop_barrier(struct BarrierMutex *barrier) {
    int rc = 0;
    assert(barrier != NULL);
    Condition_Lock(barrier->await);
    ++barrier->count;
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Fullduplex barrier incr to %d %p ", barrier->count, (void *)&barrier->await, rc);
#endif
    if (barrier->count == 2) {
        rc = 1;
        // last one wake's up everyone else'
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Fullduplex startstop broadcast on condition %p ", (void *)&barrier->await, rc);
#endif
        Condition_Broadcast(&barrier->await);
    } else {
        int timeout = barrier->timeout;
        while ((barrier->count != 2) && (timeout > 0)) {
#ifdef HAVE_THREAD_DEBUG
            thread_debug("Fullduplex startstop barrier wait  %p %d/2 (%d)", (void *)&barrier->await, barrier->count,
                         timeout);
#endif
            Condition_TimedWait(&barrier->await, 1);
            timeout--;
            if ((timeout == 0) && (barrier->count != 2)) {
                fprintf(stdout, "Barrier timeout per full duplex traffic\n");
                Condition_Unlock(barrier->await);
                return -1;
            }
        }
        barrier->count = 0;
    }
    Condition_Unlock(barrier->await);
    return rc;
}
int fullduplex_start_barrier(struct BarrierMutex *barrier) {
    int rc = fullduplex_startstop_barrier(barrier);
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Fullduplex start barrier done on condition %p rc=%d", (void *)&barrier->await, rc);
#endif
    return rc;
}
int fullduplex_stop_barrier(struct BarrierMutex *barrier) {
    int rc = fullduplex_startstop_barrier(barrier);
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Fullduplex stop barrier done on condition %p rc=%d", (void *)&barrier->await, rc);
#endif
    return rc;
}

/*
 * listener_spawn is responsible for creating a Listener class
 * and launching the listener. It is provided as a means for
 * the C thread subsystem to launch the listener C++ object.
 */
void listener_spawn(struct thread_Settings *thread) {
    Listener *theListener = NULL;
    // the Listener need to trigger a settings report
    setReport(thread);
    // start up a listener
    theListener = new Listener(thread);
    // Start listening
    theListener->Run();
    DELETE_PTR(theListener);
}

/*
 * server_spawn is responsible for creating a Server class
 * and launching the server. It is provided as a means for
 * the C thread subsystem to launch the server C++ object.
 */
void server_spawn(struct thread_Settings *thread) {
    Server *theServer = NULL;
#ifndef WIN32
    if (isWorkingLoadThread(thread)) unblock_working_load_pause_signals();
#endif
#ifdef HAVE_THREAD_DEBUG
    if (isBounceBack(thread)) {
        thread_debug("spawn server bounce-back");
    } else {
        thread_debug("spawn server settings=%p GroupSumReport=%p sock=%d", (void *)thread, (void *)thread->mSumReport,
                     thread->mSock);
    }
#endif
    // set traffic thread to realtime if needed
#if HAVE_SCHED_SETSCHEDULER
    thread_setscheduler(thread);
#endif
    // Start up the server
    theServer = new Server(thread);
    if (isTxStartTime(thread)) {
        clock_usleep_abstime(&thread->txstart_epoch);
    }
    // Run the test
    if (isUDP(thread)) {
#if HAVE_UDP_L4S
        if (isBounceBack(thread)) {
            SetSocketOptionsIPRCVTos(thread);
            theServer->RunBounceBackUDP();
        } else if (isUDPL4S(thread)) {
            SetSocketOptionsIPRCVTos(thread);
            theServer->RunUDPL4S();
        } else
#endif
        {
            theServer->RunUDP();
        }
    } else {
        if (isBounceBack(thread)) {
            theServer->RunBounceBackTCP();
        } else {
            theServer->RunTCP();
        }
    }
    DELETE_PTR(theServer);
}

static void clientside_client_basic(struct thread_Settings *thread, Client *theClient) {
    setTransferID(thread, NORMAL);
#ifdef HAVE_THREAD_DEBUG
    if (isBounceBack(thread)) {
        thread_debug("Launch: spawn client bounce-back mode, size = %d", thread->mBurstSize);
    } else {
        thread_debug("Launch: client spawn thread basic (sock=%d)", thread->mSock);
    }
#endif
    SockAddr_remoteAddr(thread);
    theClient->my_connect(false);
    if ((thread->mThreads > 1) && !isNoConnectSync(thread) && !isCompat(thread))
        // When -P > 1 then all threads finish connect before starting traffic
        theClient->BarrierClient(thread->connects_done);
    if (theClient->isConnected()) {
        Iperf_push_host(thread);
        theClient->StartSynch();
        theClient->Run();
    }
}

static void clientside_client_reverse(struct thread_Settings *thread, struct thread_Settings *reverse_client,
                                      Client *theClient) {
    setTransferID(thread, NORMAL);
    SockAddr_remoteAddr(thread);
    theClient->my_connect(false);
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Launch: client spawn thread reverse (sock=%d)", thread->mSock);
#endif
    if ((thread->mThreads > 1) && !isNoConnectSync(thread))
        // When -P > 1 then all threads finish connect before starting traffic
        theClient->BarrierClient(thread->connects_done);
    if (theClient->isConnected()) {
        FAIL((!reverse_client || !(thread->mSock > 0)),
             "Reverse test failed to start per thread settings or socket "
             "problem",
             thread);
        setTransferID(reverse_client, REVERSED);
        theClient->StartSynch();
        reverse_client->mSock = thread->mSock;  // use the same socket for both directions
        reverse_client->mThreadMode = kMode_Server;
        setReverse(reverse_client);
        setNoUDPfin(reverse_client);  // disable the fin report - no need
        reverse_client->size_local = sizeof(iperf_sockaddr);
        getsockname(reverse_client->mSock, reinterpret_cast<sockaddr *>(&reverse_client->local),
                    &reverse_client->size_local);
        Iperf_push_host(reverse_client);
        thread_start(reverse_client);
        if (theClient->myJob) FreeReport(theClient->myJob);
    }
}

static void clientside_client_fullduplex(struct thread_Settings *thread, struct thread_Settings *reverse_client,
                                         Client *theClient) {
    setTransferID(thread, NORMAL);
    SockAddr_remoteAddr(thread);
    if (!isBounceBack(thread)) {
        thread->mFullDuplexReport = InitSumReport(thread, -1, true);
    }
    Settings_Copy(thread, &reverse_client, SHALLOW_COPY);
    if (isUDP(reverse_client)) {
	Settings_Resize_mBuf(reverse_client, kDefault_UDPRxBufLen);
    }
    Iperf_push_host(thread);
    Iperf_push_host(reverse_client);
    assert(reverse_client != NULL);
    setTransferID(reverse_client, REVERSED);
    theClient->my_connect(false);
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Launch: client spawn thread fullduplex (sock=%d)", thread->mSock);
#endif
    if ((thread->mThreads > 1) && !isNoConnectSync(thread))
        // When -P > 1 then all threads finish connect before starting traffic
        theClient->BarrierClient(thread->connects_done);
    if (theClient->isConnected()) {
        thread->mFullDuplexReport->info.common->socket = thread->mSock;
        FAIL((!reverse_client || !(thread->mSock > 0)),
             "Reverse test failed to start per thread settings or socket "
             "problem",
             thread);
        reverse_client->mSock = thread->mSock;  // use the same socket for both directions
        reverse_client->mThreadMode = kMode_Server;
        setReverse(reverse_client);
        if (isModeTime(reverse_client)) {
            reverse_client->mAmount += (SLOPSECS * 100);  // add 2 sec for slop on reverse, units are 10 ms
        }
        thread_start(reverse_client);
        if (theClient->StartSynch() != -1) {
            theClient->Run();
        }
    }
}

// UDP has no independent read/write streams the way a TCP connection
// does - recv() on one shared socket just returns whichever datagram
// arrives next, with no way to tell it apart from the caller's own
// intended direction. clientside_client_fullduplex above reuses one
// socket between two concurrently-running threads (the forward
// writer's own ACK-polling recv, and the reverse reader's own data
// recv) - fine for TCP's independent byte streams, but for UDP those
// two recv() calls end up racing for the exact same incoming
// datagrams. Confirmed via a local loopback repro: ~70% apparent
// packet "loss" (impossible on loopback otherwise) and the forward
// direction's own ACK stream starving out and dying within about a
// second, while a plain (non-fullduplex) UDP L4S flow on the same
// path runs cleanly for its full duration.
//
// Fix: don't share a socket at all for UDP fullduplex - give each
// direction its own independent connection instead, exactly as if a
// technician had started two separate, unrelated iperf2 clients
// against the same host:port (one plain forward, one plain reverse).
// The forward direction (thread) runs through the exact same
// clientside_client_basic path any ordinary non-fullduplex client
// uses; the reverse direction (reverse_client) is handed off to
// client_spawn as its own fresh kMode_Client/isReverse thread, so it
// runs through the already-correct, already-independent
// clientside_client_reverse path (own connect, own header exchange,
// own socket) rather than any of this function's own shared-socket
// setup. FullDuplex itself is explicitly cleared on both copies
// first - left set, Client::Run()'s own isFullDuplex-gated setup
// (InitTrafficLoop, the fullduplex start barrier) would still expect
// the merged thread->mFullDuplexReport this path never allocates.
// The combined "[FD]"/"[SUM-...]" report lines the shared-socket path
// prints go away as a result - purely informational human-readable
// output, not something CsvLineParser (Android) or any other -e/-y C
// consumer parses; working-load up/down are already derived from each
// direction's own individual report line, same as the shared-socket
// path also provided.
static void clientside_client_fullduplex_udp(struct thread_Settings *thread, struct thread_Settings *reverse_client,
                                              Client *theClient) {
    unsetFullDuplex(thread);
    unsetFullDuplex(reverse_client);
    setReverse(reverse_client);
    reverse_client->mThreadMode = kMode_Client;
    // reverse_client is about to run its own independent my_connect()
    // (clientside_client_reverse, once client_spawn re-dispatches it
    // below) - unlike this function's shared-socket sibling above, where
    // reverse_client only ever passively reused thread's already-
    // established connection, it now sends its own header-exchange
    // packet for real. The caller's own pre-dispatch code already resized
    // mBufLen to kDefault_UDPRxBufLen (128KB - fine for a passive
    // receiver, see that resize's own call site) before either of these
    // two functions ever got called; sending that whole buffer as the
    // first packet hits EMSGSIZE ("send_hdr failed: Message too long")
    // every time. Reset to the same per-packet UDP L4S size a normal
    // working-load thread's own mBufLen gets reset to, same reasoning as
    // that reset's own doc comment (Launch.cpp, working_load_threads loop
    // above).
    reverse_client->mBufLen = isIPV6(reverse_client) ? kDefault_UDPTxBufLenV6 : kDefault_UDPTxBufLen;
    // Spawn the reverse/receive direction first (thread_start is async -
    // it returns as soon as the thread is created, not once it finishes)
    // so it starts concurrently with the forward direction below, not
    // strictly after it - clientside_client_basic's own Run() call blocks
    // for this thread's entire test duration, so starting reverse_client
    // after it returns would leave the reverse side not even beginning
    // its own connect until the forward direction had already finished.
    thread_start(reverse_client);
    // A brief stagger before the forward direction's own connect - two
    // brand new UDP flows landing on the server within microseconds of
    // each other (as thread_start's own async start otherwise invites)
    // both race Listener::udp_accept()'s handoff-then-relisten gap (see
    // FATALUDPREADERR's own doc comment, include/util.h) at once, making
    // it far likelier either one's opening packet lands in the other's
    // gap than a technician starting two ordinary, unrelated iperf2
    // clients ever would in practice. FATALUDPREADERR no longer treats a
    // stray refusal as fatal either way - this is defense in depth, not
    // the fix itself, so it stays a short, fixed delay rather than
    // anything that synchronizes on the reverse thread's own connect
    // actually completing (which would need new cross-thread state just
    // to shrink an already-tolerated race further).
    struct timeval stagger = {0, 20000};  // 20ms
    clock_usleep(&stagger);
    clientside_client_basic(thread, theClient);
}

static void serverside_client_fullduplex(struct thread_Settings *thread, Client *theClient) {
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Launch: Listener spawn client thread (fd sock=%d)", thread->mSock);
#endif
    setTransferID(thread, REVERSED);
    // This Client object reuses the listener's already-accepted socket
    // (see Client::Client's isServerReverse branch, src/Client.cpp: mySocket
    // is set straight from mSettings->mSock, mysock_init_done stays false)
    // rather than going through my_connect()/mySockInit() - so
    // SetSocketOptions() never runs on this socket any other way. Call it
    // directly here (not mySockInit(), which would open a brand new socket
    // and lose the accepted connection) so options like
    // --tcp-write-prefetch (TCP_NOTSENT_LOWAT) that the client requested
    // over the settings exchange (Listener.cpp) actually take effect on
    // the reverse-mode writer's real write socket instead of being parsed
    // and silently never applied - confirmed via inflated NotSent/write-
    // block-time reverse-mode readings that a forward-mode run with the
    // same settings didn't show.
    SetSocketOptions(thread);
    if (theClient->StartSynch() != -1) {
        theClient->Run();
    }
}

static void serverside_client_bidir(struct thread_Settings *thread, Client *theClient) {
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Launch: Listener spawn client thread (bidir sock=%d)", thread->mSock);
#endif
    setTransferID(thread, REVERSED);
    SockAddr_zeroAddress(&thread->peer);
    SockAddr_remoteAddr(thread);
    if (thread->mReportMode == kReport_CSV) {
        setNoSettReport(thread);
        setNoConnReport(thread);
    } else {
        unsetNoSettReport(thread);
        unsetNoConnReport(thread);
    }
    setReport(thread);
    theClient->my_connect(false);
    if (theClient->isConnected()) {
        Iperf_push_host(thread);
        if (theClient->StartSynch() != -1) {
            theClient->Run();
        }
    }
}

/*
 * client_spawn is responsible for creating a Client class
 * and launching the client. It is provided as a means for
 * the C thread subsystem to launch the client C++ object.
 *
 * There are a few different client startup modes
 * o) Normal
 * o) Dual (-d or -r) (legacy)
 * o) Reverse (Client side) (client acts like server)
 * o) FullDuplex (Client side) client starts server
 * o) ServerReverse (Server side) (listener starts a client)
 * o) FullDuplex (Server side) (listener starts server & client)
 *
 * Note: This runs in client thread context
 */
void client_spawn(struct thread_Settings *thread) {
    Client *theClient = NULL;

#ifndef WIN32
    if (isWorkingLoadThread(thread)) unblock_working_load_pause_signals();
#endif
    // set traffic thread to realtime if needed
#if HAVE_SCHED_SETSCHEDULER
    thread_setscheduler(thread);
#endif
    // start up the client
    setTransferID(thread, NORMAL);
    theClient = new Client(thread);
    // let the reporter thread go first in the case of -P greater than 1
    Condition_Lock(reporter_state.await);
    while (!reporter_state.ready) {
        Condition_TimedWait(&reporter_state.await, 1);
    }
    Condition_Unlock(reporter_state.await);

    if (isConnectOnly(thread)) {
        theClient->ConnectPeriodic();
    } else if (!isServerReverse(thread)) {
        // These are the client side spawning of clients
        if (!isReverse(thread) && !isFullDuplex(thread)) {
            clientside_client_basic(thread, theClient);
        } else if (isReverse(thread) && !isFullDuplex(thread)) {
            struct thread_Settings *reverse_thread = NULL;
            Settings_Copy(thread, &reverse_thread, DEEP_COPY);
            FAIL((reverse_thread == NULL), "Reverse thread alloc failed",  thread);
	    if (isUDP(reverse_thread)) {
		Settings_Resize_mBuf(reverse_thread, kDefault_UDPRxBufLen);
	    }
            clientside_client_reverse(thread, reverse_thread, theClient);
        } else if (isFullDuplex(thread)) {
            struct thread_Settings *reverse_thread = NULL;
            Settings_Copy(thread, &reverse_thread, DEEP_COPY);
            FAIL((reverse_thread == NULL), "Reverse in full-duplex thread alloc failed",  thread);
	    if (isUDP(reverse_thread)) {
		Settings_Resize_mBuf(reverse_thread, kDefault_UDPRxBufLen);
	    }
            if (isUDP(thread)) {
                // See clientside_client_fullduplex_udp's own doc comment -
                // UDP can't safely share one socket between the two
                // directions the way TCP's shared-socket path above does.
                clientside_client_fullduplex_udp(thread, reverse_thread, theClient);
            } else {
                clientside_client_fullduplex(thread, reverse_thread, theClient);
            }
        } else {
            fprintf(stdout, "Program error in client side client_spawn");
            _exit(-1);
        }
    } else {
        if (thread->mMode != kTest_Normal) {
            setCompat(thread);
            // These are the server or listener side spawning of clients
            serverside_client_bidir(thread, theClient);
        } else {
            serverside_client_fullduplex(thread, theClient);
        }
    }
    // Call the client's destructor
    DELETE_PTR(theClient);
}

/*
 * client_init handles multiple threaded connects. It creates
 * a listener object if either the dual test or tradeoff were
 * specified. It also creates settings structures for all the
 * threads and arranges them so they can be managed and started
 * via the one settings structure that was passed in.
 *
 * Note: This runs in main thread context
 */
void client_init(struct thread_Settings *clients) {
    struct thread_Settings *itr = NULL;
    struct thread_Settings *next = NULL;

    itr = clients;
    setReport(clients);
    // See if we need to start a listener as well
    Settings_GenerateListenerSettings(clients, &next);
#ifdef HAVE_THREAD
    if (next != NULL) {
        // We have threads and we need to start a listener so
        // have it ran before the client is launched
        itr->runNow = next;
        itr = next;
    }
    // For each of the needed threads create a copy of the
    // provided settings, unsetting the report flag and add
    // to the list of threads to start
    for (int i = 1; i < clients->mThreads; i++) {
        Settings_Copy(clients, &next, DEEP_COPY);
        setNoSettReport(next);
        // printf("*****port/thread = %d/%d\n", next->mPort + i, i);
        if (next) {
            if (isIncrSrcIP(clients) && (clients->mLocalhost != NULL)) {
                next->incrsrcip = i;
            }
            if (isTxStartTime(clients)) {
                // break apart -P first pkt sends by some usecs
                // this allows the listener thread to spawn a server, connect()
                // and open a new socket for subsequent threads. This issue is
                // most notable with --tx-starttime and -P > 1 use max cores & a
                // max aggregate delay to limit this so it's bounded
#define MAXCORES 10
#define MAXDELAY 20000  // 20 ms
                next->sendfirst_pacing = (i % MAXCORES) * (MAXDELAY / MAXCORES);
            }
            if (isIncrDstIP(clients)) {
                next->incrdstip = i;
                // force a setHostname
                SockAddr_zeroAddress(&next->peer);
            } else if (clients->mBindPort) {
                // Increment the source port of none of the quintuple is being
                // change or the user requests it
                if ((!isIncrDstPort(clients) && !isIncrDstIP(clients) && !isIncrSrcIP(clients)) ||
                    isIncrSrcPort(clients)) {
                    // case -B with src port and -P > 1
                    next->incrsrcport = i;
                }
            }
            if (isIncrDstPort(clients)) {
                next->mPort += i;
                SockAddr_zeroAddress(&next->peer);
            }
        }
        itr->runNow = next;
        itr = next;
    }
    if (isWorkingLoadUp(clients) || isWorkingLoadDown(clients)) {
        int working_load_threads = (clients->mWorkingLoadThreads == 0) ? 1 : clients->mWorkingLoadThreads;
        while (working_load_threads--) {
            Settings_Copy(clients, &next, DEEP_COPY);
            // No dedicated --working-load-port option - derived here
            // instead from flags already available: isUDP(clients) is the
            // main flow's own "uses the UDP L4S port" state (true for both
            // a plain --udp-l4s capacity flow and a -u --bounceback flow),
            // isWorkingLoadL4S(clients) is the working-load stream's own.
            // When they differ, shift next's port by the same +/-1 the
            // Android client itself already applies to the main flow's own
            // port when switching transport (see IperfCommandBuilder's own
            // usesL4SPort/portDelta) - the deployed server topology runs
            // TCP and UDP L4S as two separate processes on two separate
            // (adjacent) ports, not one process handling both on a shared
            // port, so a working-load stream whose own transport differs
            // from the main flow's needs the other port to reach a real
            // listener.
            if (isUDP(clients) != isWorkingLoadL4S(clients)) {
                next->mPort = static_cast<unsigned short>(clients->mPort + (isWorkingLoadL4S(clients) ? 1 : -1));
                // Settings_Copy's DEEP_COPY above also copied clients' own
                // already-resolved peer sockaddr, which has the OLD port
                // baked in - without invalidating it, the actual connect()
                // uses that stale resolved address instead of next->mPort,
                // silently ignoring the shift just made above (same
                // stale-peer hazard the -B/incrsrcport port-range code
                // above already guards against the same way).
                SockAddr_zeroAddress(&next->peer);
            }
            if (isWorkingLoadL4S(clients)) {
                // --working-load-transport udp-l4s: run this stream as its own UDP L4S
                // flow instead of TCP - forced regardless of what next
                // inherited from clients, since the main test itself may be
                // TCP (e.g. Bounceback-over-TCP with working load over L4S).
                // Uses the working-load stream's OWN, independent Prague/
                // Reno choice (isWorkingLoadL4SCcaReno, set via
                // --working-load-cca when --working-load-transport is udp-l4s - see
                // FLAG_WORKING_LOAD_L4S_CCA_RENO's own doc comment,
                // Settings.hpp) - NOT the main flow's own isUDPL4SCcaReno;
                // the two are deliberately independent so a technician can
                // e.g. run the main flow as Prague while working load runs
                // Reno, or vice versa.
                setUDP(next);
                setUDPL4S(next);
                if (isWorkingLoadL4SCcaReno(clients)) {
                    setUDPL4SCcaReno(next);
                } else {
                    unsetUDPL4SCcaReno(next);
                }
                // next inherited clients' own mBufLen as-is via the DEEP_COPY
                // above - correct for a TCP or bounceback main flow (a large
                // kDefault_TCPBufLen/BB request size, see
                // ModalOptions_BufferAndPortDefaults, Settings.cpp), but
                // wrong for this new UDP L4S flow: PragueCC's own MTU sizing
                // reads mBufLen directly (Client::RunUDPL4S's initmtu), and
                // an oversized value here causes a one-shot EMSGSIZE on the
                // very first send. Reset to the same UDP default a genuine
                // standalone --udp-l4s client would get.
                next->mBufLen = isIPV6(next) ? kDefault_UDPTxBufLenV6 : kDefault_UDPTxBufLen;
            } else if (isUDP(next)) {
                unsetUDP(next);
                unsetBWSet(next);
                next->mAppRate = 0;
            }
            // Always clear whatever --cca the working-load thread inherited
            // from the main flow via Settings_Copy's DEEP_COPY above - the
            // working-load stream has its own, independent CCA choice
            // (isLoadCCA/mLoadCCA, applied separately below if set at all),
            // never the main flow's. Previously gated on isLoadCCA(next),
            // which only cleared the inherited value when working-load had
            // its OWN cca to apply instead - meaning a main flow with its
            // own --cca set (e.g. the Android app's own cubic default) leaked
            // into the working-load socket even when neither
            // --working-load-transport nor --working-load-cca was ever
            // passed at all.
            if (isCongestionControl(next)) {
                unsetCongestionControl(next);
                DELETE_ARRAY(next->mCongestion);
            }
            if (isIsochronous(next)) {
                unsetIsochronous(next);
            }
            if (next != NULL) {
                unsetBounceBack(next);
                unsetConnectOnly(next);
                unsetPeriodicBurst(next);
                unsetTxHoldback(next);  // don't delay working load threads
                // Marks next itself as a working-load stream (distinct
                // from isWorkingLoadUp/Down above, which are the *main*
                // flow's own request) - see FLAG_WORKING_LOAD_THREAD's own
                // doc comment (Settings.hpp) for what this gates: the
                // SIGUSR1/SIGUSR2 pause/resume check in Client.cpp's
                // RunTCP/RunUDPL4S write loops, scoped to only ever affect
                // a working-load thread's own sends, never the main
                // traffic thread's (which never has this flag set).
                setWorkingLoadThread(next);
                next->mTOS = 0;         // disable any QoS on the congestion stream
#if HAVE_DECL_TCP_NOTSENT_LOWAT
                next->mWritePrefetch = SMALL_WRITE_PREFETCH;
                setWritePrefetch(next);
#endif
                if (isWorkingLoadUp(clients) && isWorkingLoadDown(clients)) {
                    setFullDuplex(next);
                } else if (isWorkingLoadDown(clients)) {
                    setReverse(next);
                }
                if (isWorkingLoadUp(clients) || isWorkingLoadDown(clients)) {
                    unsetBWSet(next);
                    setNoSettReport(next);
                }
                Iperf_push_host(clients);
                // Bump the bounceback time to include the delay time
                if (next->txholdback_timer.tv_sec || next->txholdback_timer.tv_usec) {
                    // mAmount units are 10 ms
                    next->mAmount += (next->txholdback_timer.tv_sec * 100);
                    next->mAmount += (next->txholdback_timer.tv_usec / 10000);
                }
                // --working-load-cca is a TCP_CONGESTION sockopt concept,
                // meaningless once this stream is UDP L4S (same "drop the
                // TCP-only knob" precedent as --tcp-cca under UDP
                // bounceback, Settings.cpp) - --working-load-transport udp-l4s already
                // applied this flow's own Prague/Reno choice above instead.
                if (isLoadCCA(next) && !isWorkingLoadL4S(clients)) {
                    char *tmp = new char[strlen(next->mLoadCCA) + 1];
                    if (tmp) {
                        if (next->mCongestion) DELETE_ARRAY(next->mCongestion);
                        setCongestionControl(next);
                        strcpy(tmp, next->mLoadCCA);
                        tmp[strlen(next->mLoadCCA)] = '\0';
                        next->mCongestion = tmp;
                    }
                }
                itr->runNow = next;
                itr = next;
            }
        }
        // --working-load-cca's isLoadCCA/mLoadCCA lives on the shared
        // top-level settings struct at parse time (Settings.cpp's
        // OPT_WORKING_LOAD_CCA case has no per-thread struct to target yet)
        // - every `next` copy above has already deep-copied what it needed
        // via Settings_Copy, but `clients` itself is also the MAIN flow's
        // own thread_Settings (not just a template), so leaving the flag
        // set here means the main flow's own SetSocketOptions() call
        // (PerfSocket.cpp) sees isLoadCCA too and tries to set TCP_CONGESTION
        // on the main flow's actual socket. Harmless-ish for a TCP main
        // flow (redundantly reapplies a congestion algorithm name that may
        // not even match tcpCca), but for any UDP-based main flow (UDP
        // capacity, UDP L4S, or Bounceback-over-UDP) that setsockopt fails
        // with ENOPROTOOPT, and the failure path's thread_stop() kills the
        // main thread almost immediately while other threads hang waiting
        // on it - confirmed via a live repro (Bounceback + UDP L4S +
        // --working-load-cca cubic hung indefinitely; DEBUG tracing showed
        // the main flow's own UDP socket carrying isLoadCCA=1).
        if (isLoadCCA(clients)) {
            unsetLoadCCA(clients);
            DELETE_ARRAY(clients->mLoadCCA);
        }
    }
#else
    if (next != NULL) {
        // We don't have threads and we need to start a listener so
        // have it ran after the client is finished
        itr->runNext = next;
    }
#endif
}

void listeners_init(struct thread_Settings *listener) {
    struct thread_Settings *itr = listener;
    struct thread_Settings *next = NULL;
    for (int ix = 1; ix < (listener->mPortLast - listener->mPort + 1); ix++) {
        Settings_Copy(listener, &next, DEEP_COPY);
        if (next != NULL) {
            setNoSettReport(next);
            next->mPort = listener->mPort + ix;
            next->mThreadMode = kMode_Listener;
            itr->runNow = next;
            itr = next;
        }
    }
    // --dual-transport: also listen for whichever of TCP/UDP L4S this
    // process *isn't* already the main listener for, on the adjacent port
    // (see FLAG_DUAL_TRANSPORT's own doc comment, Settings.hpp). General
    // capability, independent of --working-load - lets one server process
    // serve a main test and/or a working-load stream regardless of which
    // of the two protocols each one uses. No CCA-related settings to
    // propagate onto the auxiliary listener: Prague/Reno is purely a
    // client-side, per-connection choice relayed dynamically over that
    // connection's own wire header (see prague_cc.h), never something the
    // listener side needs to know ahead of time.
    if (isDualTransport(listener)) {
        Settings_Copy(listener, &next, DEEP_COPY);
        if (next != NULL) {
            if (isUDP(listener)) {
                // Main listener is UDP (L4S) - open a TCP listener one port down.
                unsetUDP(next);
                unsetUDPL4S(next);
                next->mPort = listener->mPort - 1;
            } else {
                // Main listener is TCP - open a UDP L4S listener one port up.
                setUDP(next);
                setUDPL4S(next);
                next->mPort = listener->mPort + 1;
            }
            next->mAppRate = 0;
            unsetBWSet(next);
            setNoSettReport(next);
            itr->runNow = next;
            itr = next;
        }
    }
}
