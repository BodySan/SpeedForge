/*---------------------------------------------------------------
 * Copyright (c) 2019 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * Suppport for packet rings between threads
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#include "headers.h"
#include "packet_ring.h"
#include "Condition.h"
#include "Thread.h"
#include "Reporter.h"

/* Old GCC (pre-4.7, e.g. arm-android) lacks __atomic_* builtins and
 * __ATOMIC_* constants.  Fall back to __sync_* (GCC 4.1+), which give
 * full sequential-consistency barriers -- stronger than acquire/release,
 * so the semantics here are correct. */
#ifndef __ATOMIC_ACQUIRE
# define __ATOMIC_ACQUIRE 0
# define __ATOMIC_RELEASE 0
# define __atomic_load_n(ptr, order)        __sync_fetch_and_add((ptr), 0)
# define __atomic_store_n(ptr, val, order)  do { __sync_synchronize(); *(ptr) = (val); } while (0)
#endif

#ifdef HAVE_THREAD_DEBUG
#include "Mutex.h"
static int totalpacketringcount = 0;
Mutex packetringdebug_mutex;
#endif

//
// Initialize a packet ring between a traffic thread and the reporter thread
// Note: enable dequeue events will have the dequeue return null on an event
// relevant to the reporter thread moving to the next ring. This is needed for
// proper summing
//
struct PacketRing *packetring_init(int count, struct Condition *awake_consumer, struct Condition *awake_producer) {
    assert(awake_consumer != NULL);
    struct PacketRing *pr = NULL;
    if ((pr = (struct PacketRing *)calloc(1, sizeof(struct PacketRing)))) {
        pr->bytes = sizeof(struct PacketRing);
        pr->data = (struct ReportStruct *)calloc(count, sizeof(struct ReportStruct));
        pr->bytes += count * sizeof(struct ReportStruct);
    }
    if (!pr || !pr->data) {
        fprintf(stderr,
                "ERROR: no memory for packet ring of size %d count, try to reduce "
                "with option "
                "--NUM_REPORT_STRUCTS\n",
                count);
        exit(1);
    }
    pr->producer = 0;
    pr->consumer = 0;
    pr->maxcount = count;
    pr->awake_producer = awake_producer;
    pr->awake_consumer = awake_consumer;
    if (!awake_producer)
        pr->mutex_enable = 0;
    else
        pr->mutex_enable = 1;
    pr->consumerdone = 0;
    pr->awaitcounter = 0;
    pr->dropcount = 0;
    pr->uplevel = HIGH;
    pr->downlevel = HIGH;
#ifdef HAVE_THREAD_DEBUG
    Mutex_Lock(&packetringdebug_mutex);
    totalpacketringcount++;
    thread_debug(
        "Init %d element packet ring=%p consumer=%p producer=%p total rings=%d "
        "enable=%d",
        count, (void *)pr, (void *)pr->awake_consumer, (void *)pr->awake_producer, totalpacketringcount,
        pr->mutex_enable);
    Mutex_Unlock(&packetringdebug_mutex);
#endif
    return (pr);
}

// Returns true if metapacket was enqueued, false if it was dropped (only
// possible when pr->mutex_enable is false and the ring is full -- see the
// comment at that branch below). packet_ring.c is a generic, decoupled
// module with no dependency on the reporting subsystem, so it never prints
// anything itself; callers that have access to the proper output path
// (InitStringReport()/InitErrorReport() + PostReport(), so output stays
// serialized through the Reporter thread instead of being written directly
// by whichever thread happens to hit this) are responsible for surfacing
// drops to the user. See ReportPacket()/EndJob() in Reporter.c.
inline bool packetring_enqueue(struct PacketRing *pr, struct ReportStruct *metapacket) {
    // The ring reserves one slot empty to disambiguate full from empty, so
    // it's full exactly when the prospective write slot is the slot the
    // consumer hasn't read yet. Compute writeindex (always wrapped to
    // [0, maxcount-1]) once: pr->producer is this (producer) thread's own
    // field and doesn't change while this thread spins below, so there's no
    // need to recompute it per iteration.
    //
    // (Historical bug: this used to check
    // "(pr->producer == pr->maxcount) && (pr->consumer == 0)" as the wrap
    // case, but pr->producer is only ever stored already-wrapped to
    // [0, maxcount-1] -- it can never equal pr->maxcount -- so that clause
    // was dead, and the remaining "(pr->producer + 1) == pr->consumer" check
    // compared an unwrapped value, missing the case where the write would
    // wrap onto consumer == 0. That let the ring silently accept one write
    // past capacity, aliasing producer back onto consumer and making a full
    // ring of unread data look empty.)
    int writeindex = ((pr->producer + 1) == pr->maxcount) ? 0 : (pr->producer + 1);
    // Single exit point: enqueued is decided in the loop below (true unless
    // the no-wait drop path runs), and everything after the loop -- the
    // write itself and the final return -- is gated on it.
    bool enqueued = true;
    // pr->consumer is written by the consumer thread; pair with its release
    // store in packetring_dequeue() via an acquire load here.
    while (writeindex == __atomic_load_n(&pr->consumer, __ATOMIC_ACQUIRE)) {
        // Signal the consumer thread to process a full queue
        if (pr->mutex_enable) {
            assert(pr->awake_consumer != NULL);
            Condition_Signal(pr->awake_consumer);
            // Wait for the consumer to create some queue space
            assert(pr->awake_producer != NULL);
            Condition_Lock((*(pr->awake_producer)));
            pr->awaitcounter++;
#ifdef HAVE_THREAD_DEBUG_PERF
            {
                struct timeval now;
                static struct timeval prev = {0, 0};
                TimeGetNow(now);
                if (!prev.tv_sec || (TimeDifference(now, prev) > 1.0)) {
                    prev = now;
                    thread_debug("Not good, traffic's packet ring %p stalled per %p", (void *)pr,
                                 (void *)&pr->awake_producer);
                }
            }
#endif
            Condition_TimedWait(pr->awake_producer, 1);
            Condition_Unlock((*(pr->awake_producer)));
        } else {
            // No producer/consumer condition variable pair was set up (e.g.
            // single_udp mode: the same thread enqueues and later drains,
            // just not strictly after every single enqueue -- see
            // ReportPacket()/reporter_process_transfer_report() in
            // Reporter.c). Spinning here would never resolve: nothing else
            // in the process can advance pr->consumer while this thread is
            // stuck in this loop, since this thread is also the only one
            // that would ever call packetring_dequeue(). Drop the newest
            // report instead of hanging forever; the caller decides whether
            // and how to tell the user (pr->dropcount lets it rate-limit).
            pr->dropcount++;
            enqueued = false;
            break;
        }
    }

    if (enqueued) {
        /* Next two lines must be maintained as is: the memcpy must complete and
         * become globally visible before the producer index publish below.
         * packetring_dequeue() polls pr->producer lock-free in the common case
         * (no mutex), so a plain assignment here would only be safe on strongly
         * ordered CPUs (e.g. x86 TSO); on a weak memory-model architecture (ARM,
         * RISC-V, POWER, ...) a concurrently polling consumer could observe the
         * new index before this memcpy's writes are visible to it. The release
         * store enforces the ordering on every architecture; do not replace it
         * with a plain assignment, and do not reorder these two lines. */
        memcpy((pr->data + writeindex), metapacket, sizeof(struct ReportStruct));
        __atomic_store_n(&pr->producer, writeindex, __ATOMIC_RELEASE);
    }
    return enqueued;
}

inline struct ReportStruct *packetring_dequeue(struct PacketRing *pr) {
    struct ReportStruct *packet = NULL;
    // pr->producer is written by the producer thread; this acquire load is
    // the pair to its release store above, and is what guarantees that once
    // we observe producer != consumer, the data at pr->data[readindex] below
    // is also visible. pr->consumer here is this (consumer) thread's own
    // field, so a plain read is fine.
    if (__atomic_load_n(&pr->producer, __ATOMIC_ACQUIRE) == pr->consumer) {
        return NULL;
    }
    int readindex;
    if ((pr->consumer + 1) == pr->maxcount)
        readindex = 0;
    else
        readindex = (pr->consumer + 1);

    packet = (pr->data + readindex);
    // See if the dequeue needs to detect an event so the reporter
    // can move to the next packet ring
    __atomic_store_n(&pr->consumer, readindex, __ATOMIC_RELEASE);
    if (pr->mutex_enable) {
        // Wake a blocked producer once a meaningful batch of slots has freed
        // up, rather than on every single dequeue (pings the producer awake
        // for one item at a time -- thrashes the condvar and bounces the
        // ring's cache lines between cores for no reason) or only when the
        // ring goes fully empty (lets an already-resumable producer sit idle
        // for up to the 1s Condition_TimedWait fallback below for nothing).
        //
        // A blocked producer's index is static (it isn't moving until
        // woken), so free space increases by exactly one per dequeue while
        // it's waiting; checking equality against the watermark therefore
        // fires exactly once per fill/drain cycle -- when free space climbs
        // up through the watermark, not on every call before or after it --
        // which is what makes this batched instead of chatty. The
        // fully-empty check is kept as a belt-and-suspenders trigger for
        // small rings where the watermark and "empty" coincide, or for any
        // signal missed due to producer/consumer racing concurrently (safe
        // either way: a missed signal here still self-heals via the 1s
        // timeout, same as before this change).
        int producer = __atomic_load_n(&pr->producer, __ATOMIC_ACQUIRE);
        int occupied = (producer >= readindex) ? (producer - readindex) : ((pr->maxcount - readindex) + producer);
        int freecount = (pr->maxcount - 1) - occupied;
        int lowat = (pr->maxcount / 2 > 0) ? (pr->maxcount / 2) : 1;
        if ((freecount == lowat) || (producer == readindex)) {
#ifdef HAVE_THREAD_DEBUG
            // thread_debug( "Consumer signal packet ring %p low-water mark %d per %p",
            // (void
            // *)pr, lowat, (void
            // *)&pr->awake_producer);
#endif
            assert(pr->awake_producer);
            Condition_Signal(pr->awake_producer);
        }
    }
    return packet;
}

void packetring_free(struct PacketRing *pr) {
    if (pr) {
        WARN_REPORT_FMT(pr->awaitcounter > 1000,
                         "WARN: Reporter thread may be too slow, await counter=%d, "
                         "consider increasing NUM_REPORT_STRUCTS\n",
                         pr->awaitcounter);
        // pr->dropcount is read and reported by the caller (Reports.c's
        // Free_iReport(), via the proper InitErrorReport()/PostReport()
        // path) before calling packetring_free(), since pr is gone after
        // this function returns.
        if (pr->data) {
#ifdef HAVE_THREAD_DEBUG
            Mutex_Lock(&packetringdebug_mutex);
            totalpacketringcount--;
            thread_debug(
                "Free packet ring=%p producer=%p (consumer=%p) awaits = %d "
                "total "
                "rings = %d",
                (void *)pr, (void *)pr->awake_producer, (void *)pr->awake_consumer, pr->awaitcounter,
                totalpacketringcount);
            Mutex_Unlock(&packetringdebug_mutex);
#endif
            free(pr->data);
        }
        free(pr);
    }
}

/*
 * This is an estimate and can be incorrect as these counters
 * done like this is not thread safe.  Use with care as there
 * is no guarantee the return value is accurate
 */
#ifdef HAVE_THREAD_DEBUG
inline int packetring_getcount(struct PacketRing *pr) {
    int depth = 0;
    if (pr->producer != pr->consumer) {
        depth = (pr->producer > pr->consumer) ? (pr->producer - pr->consumer)
                                              : ((pr->maxcount - pr->consumer) + pr->producer);
        // printf("DEBUG: Depth=%d for packet ring %p\n", depth, (void *)pr);
    }
    return depth;
}
#endif
