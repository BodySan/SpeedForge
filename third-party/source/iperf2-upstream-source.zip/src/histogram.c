/*---------------------------------------------------------------
 * Copyright (c) 2017 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * histograms.c
 * Suppport for histograms
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#include "headers.h"
#include "histogram.h"
#include "Locale.h"
#include "util.h"
#include <math.h>
#include <ctype.h>
#ifdef HAVE_THREAD_DEBUG
// needed for thread_debug
#include "Thread.h"
#endif
struct histogram *histogram_init(unsigned int bincount, unsigned int binwidth, float offset, float units,
                                 double ci_lower, double ci_upper, unsigned int id, char *name, bool Omit) {
    struct histogram *this = (struct histogram *)malloc(sizeof(struct histogram));
    if (!this) {
        fprintf(stderr, "Malloc failure in histogram init\n");
        return (NULL);
    }
    this->Omit = Omit;
    if (!bincount) bincount = 1000;
    this->mybins = (unsigned int *)malloc(sizeof(unsigned int) * bincount);
    if (!this->mybins) {
        fprintf(stderr, "Malloc failure in histogram init b\n");
        free(this);
        return (NULL);
    }
    this->myname = (char *)malloc(strlen(name) + 1);
    if (!this->myname) {
        fprintf(stderr, "Malloc failure in histogram init n\n");
        free(this->mybins);
        free(this);
        return (NULL);
    }
    this->outbuf = (char *)malloc(120 + (32 * bincount) + strlen(name));
    if (!this->outbuf) {
        fprintf(stderr, "Malloc failure in histogram init o\n");
        free(this->myname);
        free(this->mybins);
        free(this);
        return (NULL);
    }
    memset(this->mybins, 0, bincount * sizeof(unsigned int));
    strcpy(this->myname, name);
    this->id = id;
    this->bincount = bincount;
    this->binwidth = binwidth;
    this->populationcnt = 0;
    this->offset = offset;
    this->units = units;
    this->cntloweroutofbounds = 0;
    this->cntupperoutofbounds = 0;
    this->ci_lower = ci_lower;
    this->ci_upper = ci_upper;
    this->prev = NULL;
    this->maxbin = -1;
    this->fmaxbin = -1;
    this->maxts.tv_sec = 0;
    this->maxts.tv_usec = 0;
    this->fmaxts.tv_sec = 0;
    this->fmaxts.tv_usec = 0;
#ifdef HAVE_THREAD_DEBUG
    thread_debug("histo create %p", (void *)this);
#endif
    return this;
}

void histogram_delete(struct histogram *h) {
#ifdef HAVE_THREAD_DEBUG
    thread_debug("histo delete %p", (void *)h);
#endif
  if (h) {
    if (h->prev)
	histogram_delete(h->prev);
    if (h->mybins)
	free(h->mybins);
    if (h->myname)
	free(h->myname);
    if (h->outbuf)
	free(h->outbuf);
    free(h);
  }
}

// value is units seconds
int histogram_insert(struct histogram *h, float value, struct timeval *ts) {
    int bin;
    // calculate the bin, convert the value units from seconds to units of
    // interest
    bin = (int)(h->units * (value - h->offset) / h->binwidth);
    h->populationcnt++;
    if (ts && (value > h->maxval)) {
        h->maxbin = bin;
        h->maxval = value;
        h->maxts.tv_sec = ts->tv_sec;
        h->maxts.tv_usec = ts->tv_usec;
        // printf("imax=%ld.%06ld %f\n",h->maxts.tv_sec, h->maxts.tv_usec,
        // value);
        if (value > h->fmaxval) {
            h->fmaxbin = bin;
            h->fmaxval = value;
            h->fmaxts.tv_sec = ts->tv_sec;
            h->fmaxts.tv_usec = ts->tv_usec;
            // printf("fmax=%ld.%06ld %f\n",h->fmaxts.tv_sec, h->fmaxts.tv_usec,
            // value);
        }
    }
    if (bin < 0) {
	h->cntloweroutofbounds++;
	return(-1);
    } else if (bin >= (int) h->bincount) {
	h->cntupperoutofbounds++;
	return(-2);
    }
    else {
	h->mybins[bin]++;
	return(h->mybins[bin]);
    }
}

void histogram_clear(struct histogram *h) {
    memset(h->mybins, 0, (h->bincount * sizeof(unsigned int)));
    h->populationcnt = 0;
    h->cntloweroutofbounds = 0;
    h->cntupperoutofbounds = 0;
    h->maxbin = 0;
    h->maxts.tv_sec = 0;
    h->maxts.tv_usec = 0;
    if (h->prev) histogram_clear(h->prev);
    h->prev = NULL;
}

void histogram_add(struct histogram *to, struct histogram *from) {
    int ix;
    assert(to != NULL);
    assert(from != NULL);
    if (to->bincount <= from->bincount) {
        for (ix = 0; ix < to->bincount; ix++) {
            to->mybins[ix] += from->mybins[ix];
        }
        to->populationcnt += from->populationcnt;
        to->cntloweroutofbounds += from->cntloweroutofbounds;
        to->cntupperoutofbounds += from->cntupperoutofbounds;
        if (from->maxbin > to->maxbin) {
            to->maxbin = from->maxbin;
        }
        if (from->maxts.tv_sec > to->maxts.tv_sec) {
            to->maxts.tv_sec = from->maxts.tv_sec;
            to->maxts.tv_usec = from->maxts.tv_usec;
        } else if ((from->maxts.tv_sec == to->maxts.tv_sec) && (from->maxts.tv_usec > to->maxts.tv_usec)) {
            to->maxts.tv_usec = from->maxts.tv_usec;
        }
    }
}

void histogram_print(struct histogram *h, double start, double end) {
    if (h->final && h->prev) {
        histogram_clear(h->prev);
    }
    if (!h->prev) {
	h->prev = histogram_init(h->bincount, h->binwidth, h->offset, h->units, h->ci_lower, h->ci_upper, h->id, h->myname, h->Omit);
	if (!h->prev)
	  return;
    }
    int n = 0, ix, delta, lowerci, upperci, outliercnt, fence_lower, fence_upper, upper3stdev;
    int running = 0;
    int intervalpopulation, oob_u, oob_l;
    intervalpopulation = h->populationcnt - h->prev->populationcnt;
    strcpy(h->outbuf, h->myname);
    sprintf(h->outbuf, "[%3d] " IPERFTimeFrmt " sec %s%s%s bin(w=%d%s):cnt(%d)=", h->id, start, end, h->myname,
            (h->final ? "(f)" : ""), "-PDF:", h->binwidth, ((h->units == 1e3) ? "ms" : "us"), intervalpopulation);
    n = strlen(h->outbuf);
    lowerci = 0;
    upperci = 0;
    upper3stdev = 0;
    outliercnt = 0;
    fence_lower = 0;
    fence_upper = 0;
    int outside3fences = 0;
    h->prev->populationcnt = h->populationcnt;
    oob_l = h->cntloweroutofbounds - h->prev->cntloweroutofbounds;
    h->prev->cntloweroutofbounds = h->cntloweroutofbounds;
    oob_u = h->cntupperoutofbounds - h->prev->cntupperoutofbounds;
    h->prev->cntupperoutofbounds = h->cntupperoutofbounds;

    for (ix = 0; ix < h->bincount; ix++) {
        delta = h->mybins[ix] - h->prev->mybins[ix];
        if (delta > 0) {
            running += delta;
            if (!lowerci && ((float)running / intervalpopulation > h->ci_lower / 100.0)) {
                lowerci = ix + 1;
            }
            // use 10% and 90% for inner fence post, then 3 times for outlier
            if ((float)running / intervalpopulation < 0.1) {
                fence_lower = ix + 1;
            }
            if ((float)running / intervalpopulation < 0.9) {
                fence_upper = ix + 1;
            } else if (!outside3fences) {
                outside3fences = fence_upper + (3 * (fence_upper - fence_lower));
            } else if (ix > outside3fences) {
                outliercnt += delta;
            }
            if (!upperci && ((float)running / intervalpopulation > h->ci_upper / 100.0)) {
                upperci = ix + 1;
            }
            if (!upper3stdev && ((float)running / intervalpopulation > 99.7 / 100.0)) {
                upper3stdev = ix + 1;
            }
            n += sprintf(h->outbuf + n, "%d:%d,", ix + 1, delta);
            h->prev->mybins[ix] = h->mybins[ix];
        }
    }
    if (n > 0 && h->outbuf[n-1] == ',')
	h->outbuf[n-1] = '\0';
    if (!upperci)
       upperci=h->bincount;
    if (!upper3stdev)
       upper3stdev=h->bincount;
    if (h->ci_upper > 99.7)
        fprintf(stdout, "%s (%.2f/99.7/%.2f/%%=%d/%d/%d,Outliers=%d,obl/obu=%d/%d)", h->outbuf, h->ci_lower,
                h->ci_upper, lowerci, upper3stdev, upperci, outliercnt, oob_l, oob_u);
    else
        fprintf(stdout, "%s (%.2f/%.2f/99.7%%=%d/%d/%d,Outliers=%d,obl/obu=%d/%d)", h->outbuf, h->ci_lower, h->ci_upper,
                lowerci, upperci, upper3stdev, outliercnt, oob_l, oob_u);
    if (!h->final && (h->maxval > 0) && ((h->maxts.tv_sec > 0) || h->maxts.tv_usec > 0)) {
        fprintf(stdout, " (%0.3f ms/%ld.%06ld)", (h->maxval * 1e3), (long)h->maxts.tv_sec, (long)h->maxts.tv_usec);
        if (TimeDifference(h->prev->maxts, h->maxts) > 0) {
            fprintf(stdout, "(clock_err)");
        }
        h->maxbin = -1;
        h->maxval = 0;
        h->prev->maxts.tv_sec = 0;
        h->prev->maxts.tv_usec = 0;
        h->maxts.tv_sec = 0;
        h->maxts.tv_usec = 0;
    } else if (h->final && (h->fmaxval > 0) && ((h->maxts.tv_sec > 0) || h->maxts.tv_usec > 0)) {
        fprintf(stdout, " (%0.3f ms/%ld.%06ld)", (h->fmaxval * 1e3), (long)h->fmaxts.tv_sec, (long)h->fmaxts.tv_usec);
    }
    fprintf(stdout, "%s\n", (h->Omit ? report_omitted : ""));
}

// One point of a binned distribution's own empirical CDF - edge_ms is a
// populated bin's own upper edge (converted to ms so two histograms with
// different binwidth can be compared on a shared scale), cumfrac is the
// running fraction (0.0-1.0) of that distribution's total population at
// or below edge_ms. Shared by both sides of an EMD comparison (see
// histogram_emd() below) - this run's own just-built bins string and a
// baseline loaded from disk both parse into the same representation via
// parse_bins_to_cdf(), so the distance math itself doesn't need to care
// which side came from where.
struct emd_point { double edge_ms; double cumfrac; };

// Converts a histogram's own raw binwidth (a plain count, in whatever
// scale h->units selects - 1e3 for milliseconds, 1e6 for microseconds,
// see histogram_insert()'s own doc comment) into genuine microseconds:
// raw_count/units is the width in seconds, *1e6 gets microseconds. A
// no-op when units is already 1e6 (binwidth * 1e6/1e6 == binwidth), which
// is why this was never caught for BOUNCEBACK's own default histogram
// (Reports.c hardcodes mHistUnits=6/units=1e6 whenever --histograms isn't
// explicitly passed) - only a histogram actually configured for a
// different scale (e.g. SERVER's own trip-time default, mHistUnits=3, or
// an explicit --histograms=...m) was ever affected.
static double binwidth_to_us(double binwidth, double units) {
    return (units > 0.0) ? (binwidth * 1e6 / units) : binwidth;
}

// Parses a semicolon-joined "binnumber:count" bins string (the exact
// format histogram_print_csv() itself builds - see this function's own
// doc comment) into a cumulative-fraction step function. [binwidth_us]
// must already be in genuine microseconds (see binwidth_to_us above) -
// both of this function's own callers (histogram_emd_against_baseline)
// now convert before calling, so this can stay a flat /1000.0 rather
// than needing its own units parameter. [out] must have room for at
// least [out_max] points - histogram_emd_against_baseline() sizes its
// own allocations by counting ';' first (count_bin_entries()), passed
// through here as the hard cap: sscanf's "%d" also accepts a leading
// '+'/'-' as part of the number, so a string like "1:2+3:4" parses as
// *two* entries ("1:2" and "+3:4") despite having no ';' between them -
// count_bin_entries() has no way to see that coming, so [out_max] is
// enforced directly here instead, on a string that (for the baseline-file
// call site) is attacker-controlled. Returns the number of points
// written, 0 if [totalcount] is 0 (nothing to normalize by) or [binsstr]
// is empty/malformed.
static int parse_bins_to_cdf(const char *binsstr, double binwidth_us, unsigned int totalcount, struct emd_point *out,
                             int out_max) {
    if (totalcount == 0 || !binsstr || !*binsstr)
        return 0;
    int n = 0;
    unsigned int running = 0;
    const char *p = binsstr;
    while (*p && n < out_max) {
        int binnum;
        unsigned int count;
        int consumed = 0;
        if (sscanf(p, "%d:%u%n", &binnum, &count, &consumed) != 2)
            break;
        running += count;
        out[n].edge_ms = (double)binnum * binwidth_us / 1000.0;
        out[n].cumfrac = (double)running / (double)totalcount;
        n++;
        p += consumed;
        if (*p == ';')
            p++;
    }
    return n;
}

// Step-function CDF value at xMs - points[] must already be sorted
// ascending by edge_ms (guaranteed here: histogram_print_csv()'s own bin
// loop emits bins in ascending bin-number order, and a saved baseline file
// is just a prior run's own such output).
static double cdf_at(const struct emd_point *points, int n, double xMs) {
    double frac = 0.0;
    for (int i = 0; i < n; i++) {
        if (points[i].edge_ms > xMs)
            break;
        frac = points[i].cumfrac;
    }
    return frac;
}

// Earth Mover's Distance (1D Wasserstein-1) between two binned
// distributions, via the standard CDF-integral identity for 1D
// distributions: W1(P,Q) = integral over the real line of
// |F_P(x) - F_Q(x)| dx. Computed exactly (no numerical-integration error)
// as a sum of rectangle areas between consecutive points on the union of
// both distributions' own bin edges - each rectangle's height is the CDF
// gap over that segment, its width the segment's own span. [a]/[b] don't
// need equal population counts or the same binwidth (see this file's own
// baseline-comparison doc comment on histogram_emd_against_baseline) -
// both are already normalized to a 0.0-1.0 cumulative fraction by
// parse_bins_to_cdf() before this ever runs, so the comparison is of
// shape, not scale. Returns a genuine "average ms of latency shift"
// between the two distributions - not a unitless statistic like KS, which
// is part of why EMD (not KS) is the metric used for this comparison (see
// this function's own caller's doc comment).
static double histogram_emd(const struct emd_point *a, int an, const struct emd_point *b, int bn) {
    if (an == 0 || bn == 0)
        return -1.0;
    double *grid = malloc((size_t)(an + bn) * sizeof(double));
    if (!grid)
        return -1.0;
    int gn = 0, ai = 0, bi = 0;
    while (ai < an || bi < bn) {
        double nextval = (ai < an && (bi >= bn || a[ai].edge_ms <= b[bi].edge_ms)) ? a[ai++].edge_ms : b[bi++].edge_ms;
        if (gn == 0 || grid[gn - 1] != nextval)
            grid[gn++] = nextval;
    }
    double emd = 0.0;
    double prevx = 0.0;
    for (int i = 0; i < gn; i++) {
        double x = grid[i];
        if (i > 0) {
            double diff = fabs(cdf_at(a, an, prevx) - cdf_at(b, bn, prevx));
            emd += diff * (x - prevx);
        }
        prevx = x;
    }
    free(grid);
    return emd;
}

// Counts ';'-separated entries in a bins string - used to size
// parse_bins_to_cdf()'s output array before parsing it, both for this
// run's own bins string and a loaded baseline's.
static int count_bin_entries(const char *binsstr) {
    if (!binsstr || !*binsstr)
        return 0;
    int n = 1;
    for (const char *p = binsstr; *p; p++) {
        if (*p == ';')
            n++;
    }
    return n;
}

// Loads a --histogram-baseline file (h->baseline_path) - one previously-
// saved reportCSV_client_histogram_format row, the exact format this same
// function's caller (histogram_print_csv()) is about to emit for the
// *current* run - and returns this run's Earth Mover's Distance against
// it, or -1.0 if no baseline is configured (h->baseline_path is NULL) or
// the file couldn't be read/parsed (a missing/malformed baseline file
// shouldn't fail the run itself, just skip the comparison). [outbuf]/
// [cur_binwidth_us]/[intervalpopulation] are this run's own just-computed
// bins string and its width/population, from the caller's own loop -
// passed in rather than recomputed here since the caller already has
// them. [cur_binwidth_us] must already be genuine microseconds (see
// binwidth_to_us's own doc comment) - the caller converts via h->units
// before calling, since h isn't otherwise available here. The baseline
// file's own "binwidthus" field (read below, into the local
// binwidth_us) needs no such conversion: it's already genuine
// microseconds too, since a build with this fix only ever writes real
// microseconds into that field (see histogram_print_csv's own call
// site) - a baseline saved by an older, pre-fix build may still be
// wrong if it was captured from a non-microsecond-configured histogram,
// but that's a historical-data limitation no code fix here can
// retroactively repair.
static double histogram_emd_against_baseline(const char *baseline_path, const char *outbuf, double cur_binwidth_us,
                                             int intervalpopulation) {
    if (!baseline_path)
        return -1.0;
    FILE *f = fopen(baseline_path, "r");
    if (!f)
        return -1.0;
    // One CSV row, potentially long if the saved run had many populated
    // bins (each "binnumber:count;" entry is a handful of bytes) - grown
    // dynamically rather than a fixed cap, so a densely-populated baseline
    // doesn't silently truncate.
    size_t cap = 4096;
    size_t len = 0;
    char *line = malloc(cap);
    if (!line) {
        fclose(f);
        return -1.0;
    }
    int ch;
    while ((ch = fgetc(f)) != EOF && ch != '\n') {
        if (len + 1 >= cap) {
            cap *= 2;
            char *grown = realloc(line, cap);
            if (!grown) {
                free(line);
                fclose(f);
                return -1.0;
            }
            line = grown;
        }
        line[len++] = (char)ch;
    }
    line[len] = '\0';
    fclose(f);

    // Fields 9 (binwidthus) and 10 (totalcount) by position, field 19
    // (bins) as the remainder starting right after the 18th comma - same
    // field layout reportCSV_client_histogram_format itself writes (see
    // that constant's own doc comment, Locale.c), read back with sscanf/
    // strchr rather than a general CSV parser since the shape is fixed and
    // known.
    const char *p = line;
    int comma_count = 0;
    double binwidth_us = 0.0;
    unsigned int totalcount = 0;
    const char *bins_field = NULL;
    for (const char *scan = line; *scan; scan++) {
        if (*scan == ',') {
            comma_count++;
            if (comma_count == 8) {
                binwidth_us = atof(scan + 1);
            } else if (comma_count == 9) {
                totalcount = (unsigned int)strtoul(scan + 1, NULL, 10);
            } else if (comma_count == 18) {
                bins_field = scan + 1;
                break;
            }
        }
    }
    (void)p;
    if (!bins_field || totalcount == 0) {
        free(line);
        return -1.0;
    }
    // bins is itself followed by ",name,emd" in a file saved by a build
    // that already had this feature - stop at the next comma so a
    // re-saved (already-compared) baseline's own trailing fields don't
    // get parsed as bin entries. An older-format baseline (just 19 fields,
    // no trailing name/emd) has nothing after bins but the line's own end,
    // which strchr simply won't find - equally correct either way.
    const char *bins_end = strchr(bins_field, ',');
    char *bins_copy;
    if (bins_end) {
        size_t bins_len = (size_t)(bins_end - bins_field);
        bins_copy = malloc(bins_len + 1);
        if (!bins_copy) {
            free(line);
            return -1.0;
        }
        memcpy(bins_copy, bins_field, bins_len);
        bins_copy[bins_len] = '\0';
    } else {
        bins_copy = strdup(bins_field);
        if (!bins_copy) {
            free(line);
            return -1.0;
        }
    }

    int base_n_max = count_bin_entries(bins_copy);
    int cur_n_max = count_bin_entries(outbuf);
    struct emd_point *base_points = base_n_max > 0 ? malloc((size_t)base_n_max * sizeof(struct emd_point)) : NULL;
    struct emd_point *cur_points = cur_n_max > 0 ? malloc((size_t)cur_n_max * sizeof(struct emd_point)) : NULL;
    double result = -1.0;
    if (base_points && cur_points) {
        int base_n = parse_bins_to_cdf(bins_copy, binwidth_us, totalcount, base_points, base_n_max);
        int cur_n = parse_bins_to_cdf(outbuf, cur_binwidth_us, (unsigned int)intervalpopulation, cur_points, cur_n_max);
        result = histogram_emd(cur_points, cur_n, base_points, base_n);
    }
    free(base_points);
    free(cur_points);
    free(bins_copy);
    free(line);
    return result;
}

// See this function's own declaration (histogram.h) for why it exists -
// tcp_output_write_bb_csv() (ReportOutputs.c) never called histogram_print()
// at all, so -y C mode silently emitted no histogram whatsoever. Same
// bin-delta/percentile/outlier computation as histogram_print() above
// (kept in sync manually - there's no shared helper, since the two differ
// enough in what they build - text line vs CSV row - that factoring out
// just the computation loop would leave more indirection than the ~30
// duplicated lines it'd save), but builds a semicolon-joined "bin:count"
// list (commas are already the top-level CSV field separator, so bins
// can't use them internally the way the text format does) and emits one
// reportCSV_client_histogram_format row instead of a human-readable
// line. Only ever computes an EMD-against-baseline comparison (see
// histogram_emd_against_baseline() above) when h->final - a baseline
// comparison is a whole-run statistic, not something meaningful to
// recompute every interval.
void histogram_print_csv(struct histogram *h, double start, double end, const char *timestr, const char *csv_peer,
                         int transferid) {
    if (h->final && h->prev) {
        histogram_clear(h->prev);
    }
    if (!h->prev) {
       h->prev = histogram_init(h->bincount, h->binwidth, h->offset, h->units, h->ci_lower, h->ci_upper, h->id, h->myname, h->Omit);
       if (!h->prev)
         return;
    }
    int n = 0, ix, delta, lowerci, upperci, outliercnt, fence_lower, fence_upper, upper3stdev;
    int running = 0;
    int intervalpopulation, oob_u, oob_l;
    intervalpopulation = h->populationcnt - h->prev->populationcnt;
    h->outbuf[0] = '\0';
    lowerci = 0;
    upperci = 0;
    upper3stdev = 0;
    outliercnt = 0;
    fence_lower = 0;
    fence_upper = 0;
    int outside3fences = 0;
    h->prev->populationcnt = h->populationcnt;
    oob_l = h->cntloweroutofbounds - h->prev->cntloweroutofbounds;
    h->prev->cntloweroutofbounds = h->cntloweroutofbounds;
    oob_u = h->cntupperoutofbounds - h->prev->cntupperoutofbounds;
    h->prev->cntupperoutofbounds = h->cntupperoutofbounds;

    for (ix = 0; ix < h->bincount; ix++) {
        delta = h->mybins[ix] - h->prev->mybins[ix];
        if (delta > 0) {
            running += delta;
            if (!lowerci && ((float)running / intervalpopulation > h->ci_lower / 100.0)) {
                lowerci = ix + 1;
            }
            if ((float)running / intervalpopulation < 0.1) {
                fence_lower = ix + 1;
            }
            if ((float)running / intervalpopulation < 0.9) {
                fence_upper = ix + 1;
            } else if (!outside3fences) {
                outside3fences = fence_upper + (3 * (fence_upper - fence_lower));
            } else if (ix > outside3fences) {
                outliercnt += delta;
            }
            if (!upperci && ((float)running / intervalpopulation > h->ci_upper / 100.0)) {
                upperci = ix + 1;
            }
            if (!upper3stdev && ((float)running / intervalpopulation > 99.7 / 100.0)) {
                upper3stdev = ix + 1;
            }
            n += sprintf(h->outbuf + n, "%d:%d;", ix + 1, delta);
            h->prev->mybins[ix] = h->mybins[ix];
        }
    }
    if (n > 0 && h->outbuf[n-1] == ';')
       h->outbuf[n-1] = '\0';
    if (!upperci)
       upperci=h->bincount;
    if (!upper3stdev)
       upper3stdev=h->bincount;
    // Unlike histogram_print()'s text line, this CSV row has explicitly
    // named columns (cilowerbin/ciupperbin/p999bin), so there's no need for
    // that function's ci_upper > 99.7 argument-order swap - each value
    // always goes in its own named column regardless of ci_lower/ci_upper's
    // actual configured values.
    // The printed field is named "binwidthus" (reportCSV_client_histogram_
    // header) - live up to that name for real, regardless of this
    // histogram's own configured h->units, rather than the raw h->binwidth
    // count histogram_emd_against_baseline() used to receive unconverted
    // (see binwidth_to_us's own doc comment for why that was a real bug
    // for any non-microsecond-configured histogram). Rounds to the
    // nearest whole microsecond - the field's own %u format never carried
    // fractional precision anyway, and every real mHistUnits value is a
    // power of ten no finer than microseconds in practice.
    unsigned int binwidth_us = (unsigned int)llround(binwidth_to_us((double)h->binwidth, h->units));
    double emd = h->final ? histogram_emd_against_baseline(h->baseline_path, h->outbuf, (double)binwidth_us, intervalpopulation) : -1.0;
    printf(reportCSV_client_histogram_format, timestr, csv_peer, transferid, start, end, binwidth_us,
           intervalpopulation, h->ci_lower, h->ci_upper, lowerci, upperci, upper3stdev, outliercnt, oob_l, oob_u,
           h->outbuf, h->myname, emd);
    // --histogram-baseline-save name=path (CLI-only, see struct
    // histogram.baseline_save_path's own doc comment) - writes this exact
    // same row to a file, so a later run's own --histogram-baseline can
    // load it back as a reference. Same final-only scoping as the EMD
    // comparison above - capturing a baseline from a partial/per-interval
    // row wouldn't be a meaningful "this is what a full run looks like"
    // reference.
    if (h->final && h->baseline_save_path) {
        FILE *f = fopen(h->baseline_save_path, "w");
        if (f) {
            // binwidth_us, not h->binwidth - this writes the identical row
            // the stdout printf above just did (see this block's own doc
            // comment), so it needs the same already-converted-to-real-
            // microseconds value, not the raw count. Missing this was its
            // own bug on top of parse_bins_to_cdf's - confirmed via a live
            // baseline round-trip (save then compare against a 1ms-binned
            // histogram) that a saved file's own "binwidthus" field stayed
            // wrong even after fixing the stdout side, since this is a
            // separate printf call, not a shared code path.
            fprintf(f, reportCSV_client_histogram_format, timestr, csv_peer, transferid, start, end, binwidth_us,
                    intervalpopulation, h->ci_lower, h->ci_upper, lowerci, upperci, upper3stdev, outliercnt, oob_l, oob_u,
                    h->outbuf, h->myname, emd);
            fclose(f);
        } else {
            fprintf(stderr, "WARN: could not open --histogram-baseline-save path '%s' for writing\n", h->baseline_save_path);
        }
    }
}
