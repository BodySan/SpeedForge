/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Locale.c
 * by Ajay Tirumala <tirumala@ncsa.uiuc.edu>
 * & Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * Strings and other stuff that is locale specific.
 * ------------------------------------------------------------------- */

/* Format specifiers per inttypes.h
 *
 * macro	description	example
 * PRIxMAX	printf specifier for intmax_t	PRIiMAX is the equivalent of i
 (in "%i") for intmax_t values
 * PRIxN	printf specifier for intN_t	PRId16 is the equivalent of d
 (in "%d") for int16_t values
 * PRIxLEASTN	printf specifier for int_leastN_t	PRIuLEAST32 is the
 equivalent of u (in "%u") for uint32_t values
 * PRIxFASTN	printf specifier for int_fastN_t	PRIxFAST8 is the
 equivalent of x (in "%x") for uint8_t values
 * PRIxPTR	printf specifier for intptr_t	PRIuPTR is the equivalent of u
 (in "%u") for uintptr_t values
 *
 Where:
 * x is one of d, i, o,u or x (for the printf specifiers this can also be an
 uppercase X).*
 * N is 8, 16, 32, 64, or any other type width supported by the library in
 <cstdint>.
 * * The specifier assumes the type to be signed for i and d, and unsigned for
 o, u, x and X.
 */

#include "headers.h"
#include "version.h"
#include "gettcpinfo.h"

#ifdef __cplusplus
extern "C" {
#endif
/* -------------------------------------------------------------------
 * usage
 * ------------------------------------------------------------------- */

const char usage_short[] =
    "\
Usage: %s [-s|-c host] [options]\n\
Try `%s --help' for more information.\n";

const char usage_long1[] =
    "\
Usage: iperf [-s|-c host] [options]\n\
       iperf [-h|--help] [-v|--version]\n\
\n\
Client/Server:\n\
  -b, --bandwidth #[kmgKMG | pps]  bandwidth to read/send at in bits/sec or packets/sec\n\
  -e, --enhanced    use enhanced reporting giving more tcp/udp and traffic information\n\
  -f, --format    [kmgKMG]   format to report: Kbits, Mbits, KBytes, MBytes\n\
      --hide-ips           hide ip addresses and host names within outputs\n\
      --histograms         enable histograms (see client or server for more)\n\
  -i, --interval  #        seconds between periodic bandwidth reports\n\
  -l, --len       #[kmKM]    length of buffer in bytes to read or write (Defaults: TCP=128K, v4 UDP=1470, v6 UDP=1450)\n\
  -m, --print_mss          print TCP maximum segment size\n\
      --omit      #        omit n seconds of samples (TCP only)\n\
  -o, --output    <filename> output the report or error message to this specified file\n\
  -p, --port      #        client/server port to listen/send on and to connect\n\
      --permit-key         permit key to be used to verify client and server (TCP only, professional edition)\n\
      --send-delay         simulate network delay on a sending socket (units is milliseconds)\n\
      --sum-only           output sum only reports\n\
  -u, --udp                use UDP rather than TCP\n\
      --utc                use coordinated universal time (UTC) with time output\n\
  -w, --window    #[KM]    TCP window size (socket buffer size)\n"
#ifdef HAVE_SCHED_SETSCHEDULER
    "  -z, --realtime           request realtime scheduler\n"
#endif
    "  -B, --bind <host>[:<port>][%<dev>] bind to <host>, ip addr (including multicast address) and optional port and device\n\
  -C, --compatibility      for use with older versions does not sent extra msgs\n\
      --NUM_REPORT_STRUCTS increase the shared memory between the traffic threads and the reporter thread (default is 10,000 entries)\n\
  -M, --mss       #        set TCP maximum segment size using TCP_MAXSEG\n\
  -N, --nodelay            set TCP no delay, disabling Nagle's Algorithm\n\
  -S, --tos       #        set the socket's IP_TOS (byte) field\n\
  -Z, --tcp-congestion <algo>  set TCP congestion control algorithm (Linux only)\n\
      --cca <algo|prague|reno> set the congestion control algorithm (Linux only); under --udp-l4s, use 'prague' or 'reno' for the UDP L4S congestion response instead (default prague) - '--tcp-cca' is a deprecated alias for this same option\n\
\n\
Server specific:\n\
  -p, --port      #[-#]    server port(s) to listen on/connect to\n\
  -s, --server             run in server mode\n\
  -1, --singleclient       run one server at a time\n\
      --dual-transport     also listen for whichever of TCP/UDP L4S this process isn't already the main listener for, on the adjacent port (e.g. TCP on port N also gets UDP L4S on N+1, UDP L4S on port N also gets TCP on N-1)\n\
      --histograms         enable latency histograms\n\
      --jitter-histograms  enable jitter histograms\n\
      --permit-key-timeout set the timeout for a permit key in seconds (professional edition)\n\
      --permit-key-file [=<path>] file of valid permit keys, reloaded on SIGHUP without a restart (default path: /etc/iperf2/permit-keys.env) (professional edition)\n\
      --set-rand-seed #[n] set the seed for pseudo random number generator\n\
      --skip-rx-copy       set MSG_TRUNC to avoid kernel to application spaced copy of data\n\
      --tcp-rx-window-clamp set the TCP receive window clamp size in bytes\n\
      --test-exchange-timeout set the timeout on the test exchange, use 0 for no timeout\n\
      --tap-dev   #[<dev>] use TAP device to receive at L2 layer\n\
  -t, --time      #        time in seconds to listen for new connections as well as to receive traffic (default not set)\n"
#if HAVE_RECVMMSG
    "      --recvmmsg #<0-1024> use recvmmsg() API with # datagrams per call, 0 uses regular msg API (server only)\n\
      --recvmmsg-wait-all use MSG_WAITALL instead of MSG_WAITFORONE\n\
      --recvmmsg-time #   timeout in milliseconds to wait for messages in recvmmsg()\n\
      --recvlowat #[bytes] set the socket receive low-water mark\n"
#endif
    "  -B, --bind <ip>[%<dev>]  bind to multicast address and optional device\n\
  -U, --single_udp         run in single threaded UDP mode\n\
      --sum-dstip          sum traffic threads based upon destination ip address (default is src ip)\n\
  -D, --daemon             run the server as a daemon\n"
#ifdef WIN32
    "  -R, --remove             remove service in win32\n"
#endif
    "  -V, --ipv6_domain        Enable IPv6 reception by setting the domain "
    "and socket to AF_INET6 "
    "(Can receive on both IPv4 and IPv6)\n";

const char usage_long2[] =
    "\
\n\
Client specific:\n\
      --bounceback         request a bounceback test (use -l for size, defaults to 100 bytes)\n\
      --bounceback-hold    request the server to insert a delay of n milliseconds between its read and write\n\
      --bounceback-no-quickack request the server not set the TCP_QUICKACK socket option (disabling TCP ACK delays) during a bounceback test\n\
      --bounceback-period  request the client schedule a send every n milliseconds\n \
      --bounceback-reply   set the bounceback reply message size (defaults to symmetric)\n \
      --bounceback-txdelay  request the bounceback server delay n seconds between the request and the reply\n \
  -c, --client    <host>   run in client mode, connecting to <host>\n\
      --connect-only       run a connect only test\n\
      --connect-retry-timer minimum time interval in seconds between application level connect retries\n\
      --connect-retry-time time interval in seconds to attempt application level connect retries \n\
      --dscp               set the DSCP field (masking ECN bits) in TOS byte\n\
  -d, --dualtest           Do a bidirectional test simultaneously (multiple sockets)\n\
      --fq-rate #[kmgKMG]  bandwidth to socket pacing\n\
      --fq-rate-step #[kmgKMG]  step value to socket pacing\n\
      --fq-rate-step-interval #[kmgKMG]  step interval (in seconds) for socket pacing\n\
      --full-duplex        run full duplex test using same socket\n\
      --histogram-baseline <name>=<path> compare this run's final histogram named <name> (e.g. \" BB8\") against a previously-saved reference CSV row at <path>, via Earth Mover's Distance (repeatable)\n\
      --histogram-baseline-save <name>=<path> save the final histogram named <name> to <path> as a CSV row, for a later run's own --histogram-baseline (repeatable)\n\
      --histograms         enable histograms for --tcp-write-times, or for server-side latency when paired with --trip-times (UDP or TCP, professional edition only)\n\
      --ignore-shutdown    don't wait on the TCP shutdown or close (fin & finack) rather use the final write as the ending event\n\
      --incr-dstip         Increment the destination ip with parallel (-P) traffic threads\n\
      --incr-dstport       Increment the destination port with parallel (-P) traffic threads\n\
      --incr-srcip         Increment the source ip with parallel (-P) traffic threads\n\
      --incr-srcport       Increment the source port with parallel (-P) traffic threads\n\
      --ipg                set the the interpacket gap (milliseconds) for packets within an isochronous frame\n\
      --isochronous <frames-per-second>:<mean>,<stddev> send traffic in bursts (frames - emulate video traffic)\n\
      --local-only         Set don't route on socket\n\
      --near-congestion=[w] Use a weighted write delay per the sampled TCP RTT (experimental)\n\
      --no-connect-sync    No sychronization after connect when -P or parallel traffic threads\n\
      --no-udp-fin         No final server to client stats at end of UDP test\n"
#if HAVE_SENDMMSG
    "      --sendmmsg #<0-1024> use sendmmsg() API with # datagrams per call, 0 uses regular msg API (client only)\n"
#endif
    "  -n, --num       #[kmgKMG]    number of bytes to transmit (instead of -t)\n\
      --sync-transfer-id   pass the clients' transfer id(s) to the server so both will use the same id in their respective outputs\n\
  -r, --tradeoff           Do a fullduplexectional test individually\n\
      --tcp-quickack       set the socket's TCP_QUICKACK option (off by default)\n\
      --tcp-write-prefetch set the socket's TCP_NOTSENT_LOWAT value in bytes and use event based writes\n\
      --tcp-write-times    measure the socket write times at the application level\n\
  -t, --time      #        time in seconds to transmit for (default 10 secs)\n\
      --trip-times         enable end to end measurements (requires client and server clock sync)\n\
      --txdelay-time       time in seconds to hold back after connect and before first write\n\
      --txstart-time       unix epoch time to schedule first write and start traffic\n\
      --udp-l4s            run a UDP L4S flow (client only - on the server, use plain -u instead; L4S is negotiated per-connection from the client's own request)\n\
  -B, --bind [<ip> | <ip:port>] bind ip (and optional port) from which to source traffic\n\
  -F, --fileinput <name>   input the data to be transmitted from a file\n\
  -H, --ssm-host <ip>      set the SSM source, use with -B for (S,G) \n\
  -I, --stdin              input the data to be transmitted from stdin\n\
  -L, --listenport #       port to receive fullduplexectional tests back on\n\
  -P, --parallel  #        number of parallel client threads to run\n"
#ifndef WIN32
    "  -R, --reverse            reverse the test (client receives, server "
    "sends)\n"
#else
    "  -R                       Remove the windows service\n"
    "      --reverse            reverse the test (client receives, server "
    "sends)\n"
#endif
    "  -S, --tos                IP DSCP or tos settings\n\
  -T, --ttl       #        time-to-live, for multicast (default 1)\n\
      --working-load request working load(s)\n\
      --working-load-transport <tcp|udp-l4s> transport for working load (default tcp)\n\
      --working-load-cca set working load CCA (TCP algorithm name, or prague|reno\n\
                          when --working-load-transport is udp-l4s)\n\
  -V, --ipv6_domain        Set the domain to IPv6 (send packets over IPv6)\n\
  -X, --peer-detect        perform server version detection and version exchange\n\
\n\
Miscellaneous:\n\
  -x, --reportexclude [CDMSV]   exclude C(connection) D(data) M(multicast) S(settings) V(server) reports\n\
  -y, --reportstyle C      report as a Comma-Separated Values\n\
  -h, --help               print this message and quit\n\
  -v, --version            print version information and quit\n\
\n\
[kmgKMG] Indicates options that support a k,m,g,K,M or G suffix\n\
Lowercase format characters are 10^3 based and uppercase are 2^n based\n\
(e.g. 1k = 1000, 1K = 1024, 1m = 1,000,000 and 1M = 1,048,576)\n\
\n\
Accepted tos values are: af11, af12, af13, af21, af22, af23, af31, af32, af33, af41, af42, af43,\n\
cs0, cs1, cs2, cs3, cs4, cs5, cs6, cs7, ef, le, nqb, nqb2, ac_be, ac_bk, ac_vi, ac_vo, lowdelay, throughput,\n\
reliability, or a numeric value.\n\
\n\
The TCP window size option can be set by the environment variable\n\
TCP_WINDOW_SIZE. Most other options can be set by an environment variable\n\
IPERF_<long option name>, such as IPERF_BANDWIDTH.\n\
\n\
Source at <http://sourceforge.net/projects/iperf2/>\n\
Report bugs to <iperf-users@lists.sourceforge.net>\n";

// include a description of the threading in the version
#if defined(HAVE_POSIX_THREAD)
#define IPERF_THREADS "pthreads"
#elif defined(HAVE_WIN32_THREAD)
#define IPERF_THREADS "win32 threads"
#else
#define IPERF_THREADS "single threaded"
#endif

const char version[] = "iperf " IPERF_VERSION IPERF_VERSION_SUFFIX " (" IPERF_VERSION_DATE ") " IPERF_THREADS " (" IPERF_BRANCH ")" IPERF_BUILD_USER_TAG "\n";
const char branch_version[] = "iperf " IPERF_VERSION IPERF_VERSION_SUFFIX " (" IPERF_VERSION_DATE ") " IPERF_THREADS " (" IPERF_BRANCH ")" IPERF_BUILD_USER_TAG "\n";
/* -------------------------------------------------------------------
 * settings
 * ------------------------------------------------------------------- */
const char separator_line[] = "------------------------------------------------------------\n";

const char server_port[] = "Server " IPERF_SERVER_EDITION_TAG "listening on %s port %d\n";

const char client_port[] = "Client connecting to %s, %s port %d\n";

const char server_pid_port[] = "Server " IPERF_SERVER_EDITION_TAG "listening on %s port %d with pid %d\n";

const char server_pid_portrange[] = "Server " IPERF_SERVER_EDITION_TAG "listening on %s ports %d-%d with pid %d\n";

const char client_pid_port[] = "Client connecting to %s, %s port %d with pid %d (%d/%d flows/load)\n";

const char client_pid_portrange[] = "Client connecting to %s, %s ports %d-%d with pid %d (%d/%d flows/load)\n";

const char client_pid_port_dev[] =
    "Client connecting to %s, %s port %d with pid %d via %s (%d/%d "
    "flows/load)\n";

const char bind_address[] = "Binding to local address %s\n";

const char bind_address_iface[] = "Binding to local address %s and iface %s\n";

const char bind_address_iface_taptun[] = "Using virtual iface %s (AF_PACKET & SOCK_RAW)\n";

const char multicast_ttl[] = "Setting multicast TTL to %d\n";

const char join_multicast[] = "Joining multicast group  %s\n";

const char join_multicast_sg[] = "Joining multicast (S,G)=%s,%s\n";

const char join_multicast_starg_dev[] = "Joining multicast (*,G)=*,%s w/iface %s\n";

const char join_multicast_sg_dev[] = "Joining multicast (S,G)=%s,%s w/iface %s\n";

const char client_datagram_size[] = "Sending %d byte datagrams, IPG target: %.2f us\n";

const char client_datagram_size_kalman[] = "Sending %d byte datagrams, IPG target: %.2f us (kalman adjust)\n";

const char client_datagram_braket[] = "Sending lengths using markov chain: %s\n";

const char server_datagram_size[] = "Receiving %d byte datagrams\n";

const char tcp_window_size[] = "TCP window size";

const char udp_buffer_size[] = "UDP buffer size";

const char window_default[] = "(default)";

const char wait_server_threads[] = "Waiting for server threads to complete. Interrupt again to force quit.\n";

const char client_isochronous[] =
    "Isochronous: %0.2f frames/sec mean=%s/s, stddev=%s/s, "
    "Period/IPG=%0.2f/%.3f ms\n";

const char client_burstperiod[] = "Bursting: %s every %0.3f second(s)\n";

const char client_burstperiodcount[] = "Bursting: %s writes %d times every %0.3f second(s)\n";

const char client_bounceback[] =
    "Bounceback test (req/reply size =%s/%s) (server hold req=%d usecs & "
    "tcp_quickack)\n";

const char client_bbburstperiodcount[] = "Bursting request %d times every %0.2f second(s)\n";

const char client_bounceback_noqack[] = "Bounceback test (req/reply size =%s/%s) (server hold req=%d usecs)\n";

const char server_burstperiod[] =
    "Burst wait timeout set to (2 * %0.2f) seconds (use --burst-period=<n "
    "secs> to change)\n";

const char client_fq_pacing[] = "fair-queue socket pacing set to %s/s\n";

const char client_fq_pacing_step[] = "fair-queue socket pacing set to %s/s (stepping rate by %s/s)\n";

#if HAVE_SENDMMSG
const char send_mm_conf[] =
"Num. of send mmsg array: %d\n";
#endif

#if HAVE_RECVMMSG
const char recv_mm_conf[] =
"Num. of recv mmsg array: %d, wait-all:%d, wait time:%dms\n";

const char recv_mm_conf_no_timeout[] =
"Num. of recv mmsg array: %d, wait-all:%d, wait time: NULL\n";

const char recv_lowat_conf[] =
"Recvmmsg low-water mark";
#endif

/* -------------------------------------------------------------------
 * Legacy reports
 * ------------------------------------------------------------------- */

const char report_bw_header[] = "[ ID] Interval       Transfer     Bandwidth\n";

const char report_bw_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_sum_bw_format[] = "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_sumcnt_bw_format[] = "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_bw_jitter_loss_header[] =
    "[ ID] Interval       Transfer     Bandwidth        Jitter   Lost/Total "
    "Datagrams\n";

const char report_bw_jitter_loss_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%)%s\n";

const char report_sum_bw_jitter_loss_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec   %" PRIdMAX "/%" PRIdMAX " (%.*f%%)%s\n";

const char report_sumcnt_bw_jitter_loss_header[] =
    "[SUM-cnt] Interval     Transfer     Bandwidth       Lost/Total    PPS\n";

const char report_sumcnt_bw_jitter_loss_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " (%.*f%%) %8.0f pps%s\n";

/* -------------------------------------------------------------------
 * Enhanced reports (per -e)
 * ------------------------------------------------------------------- */
const char report_sumcnt_bw_header[] = "[SUM-cnt] Interval       Transfer     Bandwidth\n";

const char client_report_epoch_start_current[] =
    "[%3d] Client traffic to start in %d seconds at %s current time is %s\n";

const char server_report_epoch_start_current[] = "[%3d] Server receiving to start in %d seconds at %s\n";

const char client_write_size[] = "Write buffer size";

const char server_read_size[] = "Read buffer size";

const char report_bw_enhanced_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_sum_bw_enhanced_format[] = "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_bw_read_enhanced_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer    Bandwidth       Reads=Dist\n";

const char report_bw_read_enhanced_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

// --reverse only: RTT/bytes-in-flight relayed from the peer's own
// gettcpinfo() sample (see Client::WriteTcpTxHdr/Server::RunTCP) - the
// reader can't observe these sender-side-only stats locally otherwise.
const char report_bw_read_enhanced_reverse_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer    Bandwidth       Reads=Dist"
    "             InF(pkts)  RTT(ms)\n";

const char report_bw_read_enhanced_reverse_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d  %8" PRIdMAX "K(%" PRIdMAX ")  %.3f"
    "%s\n";

const char report_sumcnt_bw_read_enhanced_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer    Bandwidth       Reads=Dist\n";

const char report_sumcnt_bw_read_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

const char report_sumcnt_bw_read_triptime_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer    Bandwidth  InP  Reads=Dist\n";

const char report_sumcnt_bw_read_triptime_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec %s  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

const char report_bw_read_enhanced_netpwr_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer    Bandwidth    Burst Latency avg/min/max/stdev (cnt/size) inP "
    "NetPwr  Reads=Dist\n";

const char report_bw_read_enhanced_netpwr_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %.3f/%.3f/%.3f/%.3f ms (%d/%d) %s %s  %" PRIdMAX
    "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

const char report_bw_isoch_enhanced_netpwr_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer    Bandwidth    Burst Latency avg/min/max/stdev (cnt/size) "
    "NetPwr  Reads=Dist\n";

const char report_bw_isoch_enhanced_netpwr_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %.3f/%.3f/%.3f/%.3f ms (%d/%d) %s  %" PRIdMAX
    "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

const char report_sum_bw_read_enhanced_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

const char report_triptime_enhanced_format[] = "%s" IPERFTimeFrmt " trip-time (3WHS done->fin+finack) = %.4f sec%s\n";

#if HAVE_TCP_STATS
// TCP bounceback CE=cnt(%) column - only present when the kernel headers
// provide tcpi_delivered_ce/tcpi_delivered (see HAVE_TCP_BB_CE,
// gettcpinfo.h); the printf args in tcp_output_write_bb are gated the same way.
#if HAVE_TCP_BB_CE
#define BB_TCP_CE_HEADER "  CE=cnt(%)"
#define BB_TCP_CE_FORMAT "  %" PRIdMAX "(%.1f%%)"
#else
#define BB_TCP_CE_HEADER ""
#define BB_TCP_CE_FORMAT ""
#endif
#if HAVE_TCP_INFLIGHT
const char report_bw_write_enhanced_header[] = "[ ID] Interval" IPERFTimeSpace
                                               "Transfer    Bandwidth       Write/Err  Rtry     "
                                               "InF(pkts)/Cwnd(pkts)/RTT(var)        NetPwr\n";

const char report_bw_write_enhanced_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIdMAX " %8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIdMAX "K(%" PRIuLEAST32 ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us  %s%s\n";

const char report_write_enhanced_nocwnd_write_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %10" PRIdMAX "       NA/%" PRIuLEAST32
    "(%" PRIuLEAST32 ") us  %s  %.3f/%.3f/%.3f/%.3f ms (%" PRIdMAX ")%s\n";

const char report_bw_write_enhanced_fq_header[] = "[ ID] Interval" IPERFTimeSpace
                                                  "Transfer    Bandwidth       Write/Err  Rtry     "
                                                  "InF(pkts)/Cwnd(pkts)/RTT(var)  fq-rate  "
                                                  "NetPwr\n";

const char report_bw_write_enhanced_fq_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIdMAX " %8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIdMAX "K(%" PRIuLEAST32 ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us %s/sec %s%s\n";

// CE=cnt(%): TCP bounceback's own ECN CE-mark congestion signaling (see
// gettcpinfo.h's ce_marks/delivered doc comment and reportCSV_client_bb_
// bw_tcp_header's own comment, Locale.c, for the full "-1 means unavailable,
// distinct from a real 0" sentinel story) - same column label convention as
// report_client_bb_bw_udp_header's own CE=cnt(%) column.
const char report_client_bb_bw_header[] = "[ ID] Interval" IPERFTimeSpace
                                          "Transfer    Bandwidth         BB cnt=avg/min/max/stdev         Rtry  "
                                          "Cwnd(pkts)/RTT(var)/RTTmin   "
                                          "Tx/Rx bytes  RPS(avg)" BB_TCP_CE_HEADER "\n";

const char report_client_bb_bw_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms %4" PRIuLEAST32 "%4" PRIdMAX
    "K(%" PRIuLEAST32 ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ")/%" PRIdMAX " us  Tx=%s Rx=%s  RPS=%s" BB_TCP_CE_FORMAT
    "%s\n";

const char report_client_bb_bw_final_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms %4" PRIuLEAST32
    "   -(-)/-(-)/%" PRIdMAX " us   Tx=%s Rx=%s  RPS=%s" BB_TCP_CE_FORMAT "%s\n";

const char report_write_enhanced_write_header[] = "[ ID] Interval" IPERFTimeSpace
                                                  "Transfer    Bandwidth       Write/Err  Rtry    "
                                                  "InF(pkts)/Cwnd(pkts)/RTT(var)   NetPwr  "
                                                  "write-times avg/min/max/stdev (cnt)\n";

const char report_write_enhanced_write_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %8" PRIuLEAST32 "%7" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIdMAX "K(%" PRIuLEAST32 ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us      %s  %.3f/%.3f/%.3f/%.3f ms (%" PRIdMAX
    ")%s\n";

#else  // no inflight
const char report_bw_write_enhanced_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer    Bandwidth       Write/Err  Rtry     Cwnd(pkts)/RTT(var)       "
    " NetPwr\n";

const char report_bw_write_enhanced_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIuLEAST32 " %8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us  %s%s\n";

const char report_bw_write_enhanced_fq_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer    Bandwidth       Write/Err  Rtry     Cwnd(pkts)/RTT(var)  "
    "fq-rate  NetPwr\n";

const char report_bw_write_enhanced_fq_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIuLEAST32 " %8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us %s/sec %s%s\n";

// CE=cnt(%): TCP bounceback's own ECN CE-mark congestion signaling (see
// gettcpinfo.h's ce_marks/delivered doc comment and reportCSV_client_bb_
// bw_tcp_header's own comment, Locale.c, for the full "-1 means unavailable,
// distinct from a real 0" sentinel story) - same column label convention as
// report_client_bb_bw_udp_header's own CE=cnt(%) column.
const char report_client_bb_bw_header[] = "[ ID] Interval" IPERFTimeSpace
                                          "Transfer    Bandwidth         BB cnt=avg/min/max/stdev         Rtry  "
                                          "Cwnd(pkts)/RTT(var)/RTTmin   "
                                          "Tx/Rx bytes  RPS(avg)" BB_TCP_CE_HEADER "\n";

const char report_client_bb_bw_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms %4" PRIuLEAST32 " %4" PRIdMAX
    "K(%" PRIuLEAST32 ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ")/%" PRIdMAX " us  Tx=%s Rx=%s  RPS=%s" BB_TCP_CE_FORMAT
    "%s\n";

const char report_client_bb_bw_final_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms %4" PRIuLEAST32
    "   -(-)/-(-)/%" PRIdMAX " us Tx=%s Rx=%s  RPS=%s" BB_TCP_CE_FORMAT "%s\n";

const char report_write_enhanced_write_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer    Bandwidth       Write/Err  Rtry     Cwnd(pkts)/RTT(var)       "
    " NetPwr  "
    "write-times avg/min/max/stdev (cnt)\n";

const char report_write_enhanced_write_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %10" PRIuLEAST32 "%8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us  %s  %.3f/%.3f/%.3f/%.3f ms (%" PRIdMAX ")%s\n";

const char report_write_enhanced_nocwnd_write_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %10" PRIuLEAST32 "       NA/%" PRIuLEAST32
    "(%" PRIuLEAST32 ") us  %s  %.3f/%.3f/%.3f/%.3f ms (%" PRIdMAX ")%s\n";

#endif  // HAVE_TCP_INFLIGHT

const char report_sum_bw_write_enhanced_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIuLEAST32 " %s\n";

const char report_bw_write_enhanced_fq_final_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIuLEAST32 " %8dK/%u(%u) us %s%s\n";

const char report_bw_write_enhanced_nocwnd_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %10" PRIuLEAST32 "       NA/%" PRIuLEAST32
    "(%" PRIuLEAST32 ")us    %s%s\n";

const char report_write_enhanced_isoch_header[] =
    "[ ID] Interval" IPERFTimeSpace
    "Transfer     Bandwidth      Write/Err  Rtry     Cwnd(pkts)/RTT(var)     "
    "isoch:tx/miss/slip  "
    "NetPwr\n";

const char report_write_enhanced_isoch_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %8" PRIuLEAST32 " %8" PRIdMAX "K(%" PRIuLEAST32
    ")/%" PRIuLEAST32 "(%" PRIuLEAST32 ") us  %9" PRIuMAX "/%" PRIuMAX "/%" PRIuMAX "       %s%s\n";

const char report_write_enhanced_isoch_nocwnd_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %10" PRIuLEAST32 "    NA/%" PRIuLEAST32
    "(%" PRIuLEAST32 ") us  %9" PRIuMAX "/%" PRIuMAX "/%" PRIuMAX "   %s%s\n";

const char report_sumcnt_bw_write_enhanced_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer    Bandwidth       Write/Err  Rtry\n";

const char report_sumcnt_bw_write_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%10" PRIdMAX "%s\n";

#else  // no tcpstat

const char report_client_bb_bw_header[] = "[ ID] Interval" IPERFTimeSpace
                                          "Transfer    Bandwidth         BB cnt=avg/min/max/stdev  Tx/Rx bytes  "
                                          "RPS(avg)\n";

const char report_client_bb_bw_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms  Tx=%s Rx=%s  RPS=%s%s\n";

const char report_bw_write_enhanced_fq_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer    Bandwidth       Write/Err fq-rate  NetPwr\n";

const char report_bw_write_enhanced_fq_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%s/sec %s%s\n";

const char report_bw_write_enhanced_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer    Bandwidth       Write/Err\n";

const char report_bw_write_enhanced_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%s\n";

const char report_sum_bw_write_enhanced_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%s\n";

const char report_write_enhanced_isoch_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth      Write/Err  isoch:tx/miss/slip\n";

const char report_write_enhanced_isoch_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%9" PRIuMAX "/%" PRIuMAX "/%" PRIuMAX "%s\n";

const char report_write_enhanced_write_header[] = "[ ID] Interval" IPERFTimeSpace
                                                  "Transfer    Bandwidth       Write/Err  write-times "
                                                  "avg/min/max/stdev (cnt)\n";

const char report_write_enhanced_write_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "  %.3f/%.3f/%.3f/%.3f ms (%" PRIdMAX ")%s\n";

const char report_bw_write_fq_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer    Bandwidth       Write/Err  fq-rate\n";

const char report_bw_write_fq_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "    %s/sec%s\n";

const char report_sumcnt_bw_write_enhanced_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer    Bandwidth       Write/Err\n";

const char report_sumcnt_bw_write_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%s\n";

#endif  // no tcp stat

// UDP-L4S bounceback (Client::RunBounceBackUDP) - unconditional, no
// HAVE_TCP_STATS split like the TCP variants above, since UDP has no
// TCP_INFO to report either way. Modeled on the "no tcpstat" TCP variant
// just above (same Tx/Rx bytes and RPS columns), plus a CE mark count/
// percent column (stats->cntCE, reusing the same accounting the continuous
// UDP-L4S write path already does - see reporter_handle_packet_bb_client's
// own isUDP gate, src/Reporter.c).
const char report_client_bb_bw_udp_header[] = "[ ID] Interval" IPERFTimeSpace
                                              "Transfer    Bandwidth         BB cnt=avg/min/max/stdev  Tx/Rx bytes  "
                                              "RPS(avg)  CE=cnt(%)\n";

const char report_client_bb_bw_udp_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec    %" PRIdMAX "=%.3f/%.3f/%.3f/%.3f ms  Tx=%s Rx=%s  RPS=%s  %" PRIdMAX
    "(%.1f%%)%s\n";

const char report_client_bb_bw_triptime_format[] = "%s" IPERFTimeFrmt " sec  OWD (ms) Cnt=%" PRIdMAX
                                                   " TX=%.3f/%.3f/%.3f/%.3f RX=%.3f/%.3f/%.3f/%.3f "
                                                   "Asymmetry=%.3f/%.3f/%.3f/%.3f%s\n";

// Clock-offset-tolerant OWD, human-readable - see reportCSV_client_bb_owd_
// format's own doc comment (this file, CSV section) for the derivation
// (each sample minus that direction's own lifetime running minimum).
// Same avg/min/max/stdev shape as the raw OWD line above, minus an
// asymmetry column - relative-OWD asymmetry isn't a meaningful concept on
// top of an already-difference-based stat.
const char report_client_bb_owd_rel_format[] =
    "%s" IPERFTimeFrmt " sec  OWD-rel (ms) TX=%.3f/%.3f/%.3f/%.3f RX=%.3f/%.3f/%.3f/%.3f%s\n";

const char report_bw_pps_enhanced_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth   Write/Err/Timeo  PPS\n";

const char report_bw_pps_enhanced_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec   %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX "%8.0f pps %s\n";

const char report_bw_pps_enhanced_l4s_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth   Write/Err/Timeo  PPS  CE=cnt(%) Duration=avg/min/max ms (cnt) CCA\n";

const char report_bw_pps_enhanced_l4s_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec   %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX "%8.0f pps %" PRIdMAX "(%.1f%%) %.3f/%.3f/%.3f %" PRIdMAX " %s%s\n";

const char report_sumcnt_bw_pps_enhanced_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer     Bandwidth      Write/Err  PPS\n";

const char report_sumcnt_bw_pps_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %8.0f pps%s\n";

const char report_sumcnt_udp_enhanced_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer     Bandwidth      Lost/Total  PPS\n";

const char report_sumcnt_udp_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " %8.0f pps%s\n";

const char report_sumcnt_udp_triptime_header[] =
    "[SUM-cnt] Interval" IPERFTimeSpace "Transfer     Bandwidth      Lost/Total  Latency avg/min/max  Rx/inP PPS\n";

const char report_sumcnt_udp_triptime_format[] = "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX
                                                 " (%.*f%%)  %.3f/%.3f/%.3f  %" PRIdMAX "/%.0f  %8.0f pps%s\n";

const char report_bw_pps_enhanced_isoch_header[] =
    "[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth      Write/Err  PPS  isoch:tx/miss/slip\n";

const char report_bw_pps_enhanced_isoch_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX
                                                   "%8.0f pps  %3" PRIuMAX "/%" PRIuMAX "/%" PRIuMAX "%s\n";

const char report_sum_bw_pps_enhanced_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX "%8.0f pps%s\n";

const char report_bw_jitter_loss_pps_header[] =
    "[ ID] Interval       Transfer     Bandwidth        Jitter   Lost/Total "
    "Datagrams   PPS\n";

const char report_bw_jitter_loss_pps_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%) %8.0f pps%s\n";

const char report_bw_jitter_loss_enhanced_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth        Jitter   Lost/Total  \
Latency avg/min/max/stdev PPS Read/Timeo/NA NetPwr\n";

const char report_bw_jitter_loss_enhanced_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%)  %.3f/%.3f/%.3f/%.3f ms %.0f pps %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX " %s%s\n";

const char report_bw_jitter_loss_enhanced_l4s_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth        Jitter   Lost/Total  \
Latency avg/min/max/stdev PPS Read/Timeo/Trunc CE=cnt(%) CCA NetPwr\n";

const char report_bw_jitter_loss_enhanced_l4s_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%)  %.3f/%.3f/%.3f/%.3f ms %.0f pps %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX " %" PRIdMAX "(%.1f%%) %s %s%s\n";

const char report_bw_jitter_loss_enhanced_triptime_header[] = "[ ID] Interval" IPERFTimeSpace
                                                              "Transfer     Bandwidth        Jitter   Lost/Total \
 Latency avg/min/max/stdev PPS  Rx/inP  Read/Timeo/Trunc  NetPwr\n";

const char report_bw_jitter_loss_enhanced_triptime_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%) %.3f/%.3f/%.3f/%.3f ms %.0f pps %" PRIdMAX "/%s %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX " %s%s\n";

const char report_bw_jitter_loss_enhanced_triptime_l4s_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth        Jitter   Lost/Total \
 Latency avg/min/max/stdev PPS  Rx/inP  Read/Timeo/Trunc CE=cnt(%) NetPwr\n";

const char report_bw_jitter_loss_enhanced_triptime_l4s_format[] =
"%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%) %.3f/%.3f/%.3f/%.3f ms %.0f pps %" PRIdMAX "/%s %" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX "% " PRIdMAX "(%.1f%%) %s%s\n";

const char report_bw_jitter_loss_enhanced_isoch_header[] =
"[ ID] Interval" IPERFTimeSpace "Transfer     Bandwidth        Jitter   Lost/Total \
 Latency avg/min/max/stdev PPS  NetPwr  Isoch:rx/lost\n";

const char report_bw_jitter_loss_enhanced_isoch_triptime_header[] = "[ ID] Interval" IPERFTimeSpace
                                                                    "Transfer     Bandwidth        Jitter   Lost/Total \
Latency avg/min/max/stdev  PPS  Frame:rx/lost  Frame-latency avg/min/max/stdev  NetPwr\n";

const char report_bw_jitter_loss_enhanced_isoch_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX
    " (%.*f%%) %.3f/%.3f/%.3f/%.3f ms %.0f pps  %" PRIdMAX "/%" PRIdMAX " %.3f/%.3f/%.3f/%.3f ms %s%s\n";

const char report_sum_bw_jitter_loss_enhanced_format[] =
    "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%)  %.0f pps%s\n";

const char report_sumcnt_bw_jitter_loss_enhanced_header[] =
    "[SUM-cnt] Interval     Transfer     Bandwidth       Lost/Total  Latency "
    "avg/min/max  PPS\n";

const char report_sumcnt_bw_jitter_loss_enhanced_format[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %ss  %ss/sec  %" PRIdMAX "/%" PRIdMAX " (%.*f%%)  %.3f/%.3f/%.3f  %.0f pps%s\n";

const char report_bw_jitter_loss_suppress_enhanced_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%) -/-/-/- ms %.0f pps %" PRIdMAX
    "/%" PRIdMAX "/%" PRIdMAX "%s\n";

const char report_bw_jitter_loss_suppress_isoch_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX " (%.*f%%) -/-/-/- ms %.0f pps  %" PRIdMAX
    "/%" PRIdMAX " -/-/-/- ms  -%s\n";

/*
 * Frame interval reports
 */
#define IPERFFTimeFrmt "%4.4f-%4.4f"
#define IPERFFTimeSpace "  "
const char report_frame_jitter_loss_enhanced_header[] = "[ ID] Interval(f-transit)" IPERFFTimeSpace
                                                        "Transfer     Bandwidth    FrameID   Jitter   Lost/Total \
 Latency avg/min/max/stdev PPS  inP NetPwr\n";

const char report_frame_tcp_enhanced_header[] =
    "[ ID] Interval(f-transit)" IPERFFTimeSpace "Transfer     Bandwidth    FrameID\n";

const char report_burst_read_tcp_header[] = "[ ID] Burst (start-end)" IPERFFTimeSpace
                                            "Transfer     Bandwidth       XferTime  (DC%)     Reads=Dist          "
                                            "NetPwr\n";

const char report_burst_read_tcp_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms (%.0f%%)    %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d %s%s\n";

const char report_burst_read_tcp_final_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %.3f/%.3f/%.3f/%.3f ms  %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";
#if HAVE_TCP_STATS
const char report_burst_write_tcp_header[] = "[ ID] Burst (start-end)" IPERFFTimeSpace
                                             "Transfer     Bandwidth       XferTime  Write/Err  Rtry  Cwnd/RTT   "
                                             "NetPwr\n";

const char report_burst_write_tcp_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX "%10" PRIdMAX "%8dK/%u %s%s\n";

#else
const char report_burst_write_tcp_header[] =
    "[ ID] Burst (start-end)" IPERFFTimeSpace "Transfer     Bandwidth       XferTime  Write/Err\n";

const char report_burst_write_tcp_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX "%s\n";
#endif

const char report_burst_write_tcp_nocwnd_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec  %6.3f ms %" PRIdMAX "/%" PRIdMAX "%10" PRIdMAX "NA/%" PRIuLEAST32
    "(%" PRIuLEAST32 ")%s\n";

const char report_burst_write_tcp_final_format[] =
    "%s" IPERFTimeFrmt " sec  %ss  %ss/sec               %" PRIdMAX "=%d:%d:%d:%d:%d:%d:%d:%d%s\n";

/* -------------------------------------------------------------------
 * Fullduplex reports
 * ------------------------------------------------------------------- */
const char report_bw_sum_fullduplex_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_bw_sum_fullduplex_enhanced_format[] = "[FD%d] " IPERFTimeFrmt " sec  %ss  %ss/sec%s\n";

const char report_udp_fullduplex_header[] = "[ ID] Interval       Transfer     Bandwidth    Datagrams   PPS\n";

const char report_udp_fullduplex_format[] = "%s" IPERFTimeFrmt " sec  %ss  %ss/sec %" PRIdMAX "%8.0f pps%s\n";

const char report_udp_fullduplex_enhanced_format[] =
    "[FD%d] " IPERFTimeFrmt " sec  %ss  %ss/sec %" PRIdMAX "%8.0f pps%s\n";

const char report_udp_fullduplex_sum_format[] = "[SUM] " IPERFTimeFrmt " sec  %ss  %ss/sec %" PRIdMAX "%8.0f pps%s\n";

/* -------------------------------------------------------------------
 * Misc reports
 * ------------------------------------------------------------------- */
const char report_outoforder[] = "%s" IPERFTimeFrmt " sec  %" PRIdMAX " datagrams received out-of-order%s\n";

const char report_sumcnt_outoforder[] =
    "[SUM-%d] " IPERFTimeFrmt " sec  %" PRIdMAX " datagrams  received out-of-order%s\n";

const char report_quintuple_error[] = "%s" IPERFTimeFrmt " sec  %" PRIdMAX " datagrams received on wrong quintuple%s\n";

const char report_l2statistics[] = "%s" IPERFTimeFrmt
                                   " sec   L2 processing detected errors, total(length/checksum/unknown) = "
                                   "%" PRIdMAX "(%" PRIdMAX "/%" PRIdMAX "/%" PRIdMAX ")%s\n";

const char report_sum_outoforder[] = "[SUM] " IPERFTimeFrmt " sec  %" PRIdMAX " datagrams received out-of-order%s\n";

const char report_peer[] = "%slocal %s port %u connected with %s port %u%s\n";

const char report_peer_dev[] = "%slocal %s%%%s port %u connected with %s port %u%s\n";

const char report_peer_fail[] = "[drop] local %s port %u connection with %s port %u%s (permit key fail)\n";

const char report_mss_unsupported[] = "%sMSS and MTU size unknown (TCP_MAXSEG not supported)\n";

const char report_default_mss[] = "MSS size %d bytes\n";

const char report_mss[] = "MSS req size %d bytes (per TCP_MAXSEG)\n";

const char report_datagrams[] = "[%3d] Sent %" PRIdMAX " datagrams\n";

const char report_sumcnt_datagrams[] = "[SUM-%d] Sent %" PRIdMAX " datagrams\n";

const char report_sum_datagrams[] = "[SUM] Sent %" PRIdMAX " datagrams\n";

const char server_reporting[] = "[%3d] Server Report:\n";

const char reportCSV_peer[] = "%s,%u,%s,%u";

const char report_l2length_error[] = "%s" IPERFTimeFrmt " sec  %" PRIdMAX " datagrams received out-of-order\n";

const char report_client_bb_triptime_clocksync_error[] =
    "%s" IPERFTimeFrmt " sec  Clock sync error count = %" PRIdMAX "\n";

// UDP bounceback per-direction loss attribution, human-readable - see
// reportCSV_client_bb_loss_format's own doc comment above (CSV outputs,
// this file) for the request-loss/reply-loss derivation. Req=lost/sent,
// Reply=lost/serverRcvd (the denominator is how many replies the server
// actually sent, i.e. every request it received, not the client's own
// sent count).
const char report_client_bb_loss_format[] =
    "%s" IPERFTimeFrmt " sec  BB Loss  Req=%d/%u  Reply=%d/%u%s\n";

/*-------------------------------------------------------------------
 * CSV outputs
 *------------------------------------------------------------------*/
const char reportCSV_bw_format[] = "%s,%s,%d,%.1f-%.1f,%" PRIdMAX ",%" PRIdMAX "\n";

const char reportCSV_bw_tcp_read_enhanced_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,readcnt,bin0,bin1,"
    "bin2,bin3,bin4,bin5,bin6,bin7\n";

const char reportCSV_bw_tcp_read_enhanced_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%d,%d,%d,%d,%d,%d,%d,%d\n";

// --reverse only: rtt/bytes-in-flight/cwnd/retry/notsent/rttmin relayed from
// the peer's own gettcpinfo() sample - see report_bw_read_enhanced_reverse_format
// and Client::WriteTcpTxHdr's reverse_cwnd/reverse_retry/reverse_notsent/
// reverse_rtt_min (include/payloads.h). tcpminrtt is the kernel's own
// continuously-updated minimum RTT (tcpi_min_rtt) - see
// reportCSV_bw_tcp_write_enhanced_format's own comment below for what it's
// used for.
// tcpsndbuf: live, currently-autotuned send socket buffer size (SO_SNDBUF,
// KB - see iperf_tcpstats.sndbuf_bytes's own doc comment) relayed from the
// peer's own gettcpinfo() sample, same convention as tcpcwnd/tcpnotsent
// above. -1 when unavailable.
// tcpwritetimeus: mean per-write blocking time, microseconds, relayed from
// the peer's own write_mmm sample - see reportCSV_bw_tcp_write_enhanced_
// header's own comment above for what it means. -1 when --tcp-write-times
// wasn't active on the peer.
// tcpsndbuflimitedus/tcprwndlimitedus/tcpbusyus: same fields as
// reportCSV_bw_tcp_write_enhanced_format's own doc comment above, relayed
// from the peer's own gettcpinfo() sample - see Client::WriteTcpTxHdr's
// reverse_sndbuf_limited/reverse_rwnd_limited/reverse_busy_time
// (include/payloads.h). This device (the reader) computes the delta
// itself from the peer's relayed cumulative counter, same as tcpretry.
const char reportCSV_bw_tcp_read_enhanced_reverse_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,readcnt,bin0,bin1,"
    "bin2,bin3,bin4,bin5,bin6,bin7,tcprtt,tcpbytesinflight,tcppktsinflight,tcpcwnd,tcpretry,tcpnotsent,tcpminrtt,"
    "tcpsndbuf,tcpwritetimeus,tcpsndbuflimitedus,tcprwndlimitedus,tcpbusyus\n";

const char reportCSV_bw_tcp_read_enhanced_reverse_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%d,%d,%d,%d,%d,%d,%d,%d,%" PRIuLEAST32 ",%" PRIdMAX
    ",%" PRIuLEAST32 ",%" PRIdMAX ",%" PRIuLEAST32 ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX
    ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIuLEAST32 "\n";

const char reportCSV_bw_tcp_read_triptime_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,ttavg,ttmin,ttmax,"
    "ttsdev,ttcnt,ttsize,readcnt,bin0,bin1,bin2,bin3,bin4,bin5,bin6,bin7\n";

const char reportCSV_bw_tcp_read_triptime_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%.3f,%.3f,%.3f,%d,%d,%" PRIdMAX ",%d,%d,%d,%d,%d,%d,%d,%d\n";

const char reportCSV_bw_tcp_read_isochronous_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,itavg,itmin,itmax,"
    "itsdev,itcnt,itsize,readcnt,bin0,bin1,bin2,bin3,bin4,bin5,bin6,bin7\n";

// tcpminrtt (tcpi_min_rtt, Linux kernel 4.11+): the kernel's own
// continuously-updated minimum RTT for this connection, tracked at full
// per-ACK granularity - not just once per report interval like tcprtt
// itself. Lets the app compute an "excess RTT above best observed" number
// (tcprtt - tcpminrtt) directly analogous to UDP-L4S's Load Delay (srtt -
// rtt_min), without needing its own coarser app-side running-min
// approximation. -1 (0xFFFFFFFF) when the kernel doesn't expose this
// field.
// tcpsndbuf: live, currently-autotuned send socket buffer size (SO_SNDBUF,
// KB - see iperf_tcpstats.sndbuf_bytes's own doc comment), sampled locally
// alongside the rest of this writer's own gettcpinfo() sample. -1 when
// unavailable.
// tcpwritetimeus: mean per-write blocking time this interval, microseconds
// (write_mmm.current.mean, --tcp-write-times only - see
// iperf_tcpstats/ReportStruct.write_time's own doc comments) - wall-clock
// time spent inside the write()/writev() syscall itself (send-side
// backpressure/buffer-sojourn delay), an earlier and separate stage from
// tcprtt: TCP's RTT clock only starts once a byte is actually transmitted,
// so this covers how long it sat waiting to be sent at all. -1 when
// --tcp-write-times isn't active or no write was sampled yet this interval.
// tcpsndbuflimitedus/tcprwndlimitedus/tcpbusyus: this-interval delta
// (microseconds) of tcpi_sndbuf_limited/tcpi_rwnd_limited/tcpi_busy_time
// (kernel 4.9+ - see iperf_tcpstats.sndbuf_limited et al's own doc
// comment) - the kernel's own direct measurement of time spent capped by
// the local send buffer, the peer's advertised receive window, and total
// time spent with data queued to send at all, respectively. 0 when
// unavailable (same convention as the fields themselves - see
// compat/gettcpinfo.c).
// tcppaused: how many SIGUSR1-paused null events (Client.cpp's RunTCP/
// RunWriteEventsTCP, sWorkingLoadPaused - see WritePaused's own doc
// comment, packet_ring.h) this interval. Always a real 0 for any thread
// that isn't itself a paused-eligible working-load thread (only those
// ever post a WritePaused event at all, so the counter this field
// reflects never moves for anything else) - a genuine 0 here alongside
// 0 bytes/writecnt means "idle for some other reason" (backpressure, an
// intermittent network outage), while a nonzero value means "this
// interval was deliberately paused." One real trailing field, bumping
// TCP_FIELD_COUNT (Android app's CsvLineParser.kt) from 26 to 27 - kept
// clear of BOUNCEBACK_FIELD_COUNT's own value (28, not 27 - see
// reportCSV_client_bb_bw_tcp_header's own doc comment) so the two shapes
// stay distinguishable by field count alone, the same invariant that
// bounceback's own tcpbusyus field exists to preserve in the first place.
const char reportCSV_bw_tcp_write_enhanced_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,writecnt,writeerr,"
    "tcpretry,tcpcwnd,tcppcwnd,tcprtt,tcprttvar,tcppktsinflight,tcpbytesinflight,tcpnotsent,tcpminrtt,tcpsndbuf,"
    "tcpwritetimeus,tcpsndbuflimitedus,tcprwndlimitedus,tcpbusyus,tcppaused\n";

const char reportCSV_bw_tcp_write_enhanced_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIuLEAST32 ",%" PRIdMAX ",%" PRIuLEAST32
    ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX
    ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIdMAX "\n";

const char reportCSV_bw_jitter_loss_format[] =
    "%s,%s,%d,%.1f-%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX "\n";

const char reportCSV_bw_udp_read_enhanced_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,readcnt,readtimeo,readerrlen,pps\n";

const char reportCSV_bw_udp_read_enhanced_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%f\n";

// UDP L4S variant of the above - adds the same PragueCC congestion-
// experienced stats (ce, ceperc, cedurationavg/min/max/cnt) the write-side
// reportCSV_bw_udp_write_enhanced_l4s_format has. Used when the local
// client process is playing the *reader* role - i.e. --reverse - so it
// can show the same UDP L4S meters the app shows in forward mode. Unlike
// the write side (which needs the CE mark count relayed back from the
// peer over the L4S ACK channel, since a writer never sees marks that
// happen downstream), the reader sees CE marks directly off each packet's
// own ECN bits (see Server::RunUDP/reporter_handle_packet_server_udp) -
// no relay involved. Deliberately not professional-gated, matching the
// write side - client-facing diagnostics stay free regardless of edition;
// see ModalOptions_CommonBailChecks (Settings.cpp) for what's actually
// professional-only (server-side --permit-key enforcement).
// qdelayus/qbytes: PragueCC::GetQueueInfo()'s sender-side queueing-delay and
// Little's Law queue-occupancy estimate - see reportCSV_bw_udp_write_
// enhanced_l4s_format's own comment below for what they mean. rttus: the
// raw smoothed RTT (PragueCC::GetSmoothedRtt()) qdelayus is itself derived
// from. -1 only when this side hasn't yet received a packet carrying the
// writer's relayed sender_* snapshot (see client_udp_l4s_fwd's own doc
// comment, include/payloads.h, and TransferInfo.l4sStatsValid) - present
// here so the CSV column layout stays identical between the read and write
// L4S variants regardless of test direction.
const char reportCSV_bw_udp_read_enhanced_l4s_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,readcnt,readtimeo,readerrlen,pps,ce,ceperc,"
    "cedurationavg,cedurationmin,cedurationmax,cedurationcnt,qdelayus,qbytes,rttus,"
    "pktwindow,inflight,markprob,ccamode\n";

const char reportCSV_bw_udp_read_enhanced_l4s_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%f,%" PRIdMAX ",%f,%.3f,%.3f,%.3f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%s\n";

const char reportCSV_bw_udp_read_triptime_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,ttavg,ttmin,ttmax,ttsdev,ttcnt,ttsize,"
    "readcnt,readtimeo,"
    "readerrlen,pps\n";

const char reportCSV_bw_udp_read_triptime_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX
    ",%.3f,%.3f,%.3f,%.3f,%d,%d,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%f\n";

const char reportCSV_bw_udp_read_isochronous_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,ttavg,ttmin,ttmax,ttsdev,itavg,itmin,"
    "itmax,itsdev,readcnt,"
    "readtimeo,readerrlen,pps\n";

const char reportCSV_bw_udp_read_isochronous_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX
    ",%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%f\n";

const char reportCSV_bw_udp_write_enhanced_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,writecnt,writeerr,writetimeo,pps\n";

const char reportCSV_bw_udp_write_enhanced_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%f\n";

// UDP L4S variant of the above - adds the PragueCC congestion-experienced
// stats (ce, ceperc) that udp_output_write_enhanced_l4s() already prints in
// the human-readable path (report_bw_pps_enhanced_l4s_format above) but
// which the CSV path never exposed. These are genuinely available on the
// client/write side (not receive-only like jitter): the server echoes its
// observed CE mark count back to the client over the L4S ACK feedback
// channel (see src/Client.cpp's UDPAckBuf.CE_cnt / src/prague_cc.cpp).
const char reportCSV_bw_udp_write_enhanced_l4s_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,jitter,errors,"
    "datagrams,errpercent,outoforder,writecnt,writeerr,writetimeo,pps,ce,ceperc,"
    "cedurationavg,cedurationmin,cedurationmax,cedurationcnt,qdelayus,qbytes,rttus,"
    "pktwindow,inflight,markprob,ccamode\n";

// cedurationavg/min/max/cnt mirror the human-readable path's
// "Duration=avg/min/max ms (cnt)" column (report_bw_pps_enhanced_l4s_format
// above, fed by stats->CE_Duration) - the mean/min/max duration in ms of
// each congestion-experienced marking episode within the interval, and how
// many such episodes occurred. Like ce/ceperc above, this was already
// computed and printed on the human-readable path but never exposed to CSV.
//
// qdelayus/qbytes: PragueCC::GetQueueInfo()'s (src/prague_cc.cpp) sender-
// side estimate of bottleneck queueing delay (srtt minus rtt_min, in us) and
// its Little's Law (L = lambda*W) translation into bytes sitting in that
// queue (pacing_rate * qdelayus). A live snapshot updated on every packet
// (stats->l4sQueueDelayUs/l4sQueueBytes, TransferInfo), not a per-interval
// min/mean/max like CE_Duration above - same "latest known value" contract
// as tcprtt/tcpbytesinflight in the TCP CSV path, since queueing delay is a
// continuously-existing network state rather than a discrete per-interval
// event count. The app itself folds these into running min/avg/max, the
// same way it already does for TCP's rtt/bytesInFlight meters.
//
// rttus: PragueCC::GetSmoothedRtt() - the raw smoothed RTT qdelayus is
// itself derived from (srtt - rtt_min). Exposed separately per Koen De
// Schepper's review (doc/email_koen_littles_law_review.txt): srtt - rtt_min
// isn't pure single-queue delay, especially over Wi-Fi (MAC contention,
// scheduler delay, A-MPDU formation, rate adaptation all fold in too), so
// showing the raw RTT alongside the derived delay/load estimate lets a
// reader sanity-check the derived number instead of only ever seeing it
// pre-subtracted. Same live-snapshot contract as qdelayus/qbytes.
//
// pktwindow/inflight: PragueCC's own congestion window (packets) and actual
// in-flight packet count - tracked directly by the CC algorithm's packet
// send/ACK accounting (Client::RunUDPL4S), completely independent of the
// srtt-rtt_min-derived qdelayus/qbytes above. markprob: PragueCC::
// GetMarkingProbability() - the EWMA-smoothed CE-marking probability the
// algorithm itself reacts to, raw prob_tp scale (0..1<<20), distinct from
// ceperc's own raw unsmoothed per-interval ratio. Per Koen De Schepper's
// review: comparing pktwindow/inflight against qdelayus/rttus is a direct,
// RTT-independent way to tell whether elevated delay is actually queueing
// in our own window or something else (MAC contention, aggregation, etc.)
// - see doc/email_koen_littles_law_review.txt. Always -1 on the read/
// reverse-mode path, same as qdelayus/qbytes/rttus (no relay yet).
const char reportCSV_bw_udp_write_enhanced_l4s_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX ",%.3f,%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%f,%" PRIdMAX ",%f,%.3f,%.3f,%.3f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX
    ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%s\n";

// ce/ceperc: TCP bounceback's own ECN CE-mark congestion signaling - same
// field names/meaning as the UDP-L4S bounceback CSV's own ce/ceperc columns
// (reportCSV_client_bb_bw_udp_header below), but sourced from mainline
// Linux's ECN-capable TCP CCAs (e.g. --tcp-cca prague) via struct
// tcp_info's tcpi_delivered_ce/tcpi_delivered (see gettcpinfo.h's
// ce_marks/delivered doc comment) rather than UDP-L4S's own IP_TOS-relayed
// CE count. ce is this interval's CE-marked-segment delta (lifetime total
// on the final row, same "reassign the bare field" convention as
// tcpretry's own interval-vs-final split); ceperc is 100*ce/delivered-
// delta. Both are -1 when CE data isn't available - either because this
// build/kernel lacks tcpi_delivered_ce/tcpi_delivered
// (HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED_CE/_DELIVERED, compat/gettcpinfo.c)
// or because the delivered-segments delta was 0 this interval (percent
// undefined - no traffic to compute a ratio over). This is deliberately
// NOT the same as "0 CE marks observed, counters valid" (e.g. --tcp-cca
// cubic, which never CE-marks) - that case prints a real 0/0.0, only
// -1 means "can't tell you," matching this codebase's established -1
// "not available" sentinel (see e.g. tcprttmin's own doc comment above).
// tcpbusyus: kernel-tracked cumulative time (Linux tcpi_busy_time, same
// field plain TCP's own tcpbusyus column already surfaces - see
// busy_time's own doc comment, gettcpinfo.h) this connection's socket
// spent with unacknowledged data outstanding or actively sending, in
// microseconds. Added specifically to break a real ambiguity: this
// format's own field COUNT used to exactly match plain TCP's own
// forward-write CSV row (TCP_FIELD_COUNT in the Android app's
// CsvLineParser.kt) - 26 fields either way, indistinguishable by shape
// alone even though the column *meanings* are completely different
// (bbcnt/bbavg/... here vs writecnt/writeerr/... there). A bounceback
// test with --working-load=up|bidir running a plain TCP working-load
// stream alongside it produces both row shapes in the exact same stdout
// stream, and a shape-only parser (the Android app didn't have a
// connect-banner fallback available either - that's suppressed under -y
// C's own setNoConnReport(), see Settings.cpp) had no way to tell them
// apart; the working-load-up row was silently misread as a garbage
// bounceback sample every interval. One real trailing field is enough to
// make the two shapes permanently distinguishable by field count alone
// again, the same invariant every other CSV variant in this file already
// relies on.
// tcpsndbuflimitedus: kernel-tracked cumulative time (Linux
// tcpi_sndbuf_limited, same field plain TCP's own tcpsndbuflimitedus
// column already surfaces) this connection's socket spent capped by the
// local send buffer, microseconds. A second real trailing field, added
// alongside tcpbusyus specifically to keep this format's own field count
// (28) clear of TCP_FIELD_COUNT's own new value (27, tcppaused - see
// reportCSV_bw_tcp_write_enhanced_header's own doc comment) - the two
// shapes would otherwise collide again at 27 either way.
const char reportCSV_client_bb_bw_tcp_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,bbcnt,bbavg,bbmin,"
    "bbmax,bbstdev,tcpretry,tcpcwnd,tcppcwnd,tcprtt,tcprttvar,tcprttmin,txbytes,rxbytes,"
    "rps,ce,ceperc,tcpbusyus,tcpsndbuflimitedus\n";

// tcprttmin: kernel-tracked minimum RTT for this connection (Linux
// tcpi_min_rtt, iperf_tcpstats.rtt_min - see gettcpinfo.h's own doc
// comment), sampled the same way plain TCP's tcpminrtt column already is.
// Distinct from bbmin (the app-measured min request/reply latency,
// send-timestamp to reply-received-timestamp in userspace): tcprttmin is
// tracked by the kernel at full per-ACK granularity, not just once per
// report interval, so it's a tighter "best RTT observed" floor - and
// unlike bbmin, it stays meaningful even for report intervals with too
// few bounces to build a real min/max/stdev. Since bounceback is strictly
// serialized (client blocks on the reply before sending the next request,
// see RunBounceBackTCP), 1000/tcprttmin_ms is a real, principled ceiling
// on achievable RPS - useful to show alongside observed RPS to tell
// pacing-limited from path-limited runs apart. %PRIdMAX (signed), same
// specifier as plain TCP's own tcpminrtt column - -1 when
// HAVE_STRUCT_TCP_INFO_TCPI_MIN_RTT isn't available (see gettcpinfo.h).
const char reportCSV_client_bb_bw_tcp_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%.3f,%.3f,%.3f,%.3f,%" PRIuLEAST32 ",%" PRIdMAX
    ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIuLEAST32 ",%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%0.1f,%" PRIdMAX
    ",%f,%" PRIuLEAST32 ",%" PRIuLEAST32 "\n";

// UDP-L4S bounceback CSV variant (Client::RunBounceBackUDP/udp_output_write_
// bb_csv, src/ReportOutputs.c) - 20 fields vs the TCP variant's 24: no
// tcpretry/tcpcwnd/tcppcwnd/tcprtt/tcprttvar/tcprttmin columns (TCP_INFO
// doesn't exist on a UDP socket), plus ce/ceperc (same field names/format
// convention as the continuous UDP-L4S write path's own CSV columns -
// reportCSV_bw_udp_write_enhanced_l4s_header/_format above).
const char reportCSV_client_bb_bw_udp_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,bytes,"
    "speed,bbcnt,bbavg,bbmin,"
    "bbmax,bbstdev,txbytes,rxbytes,"
    "rps,ce,ceperc\n";

const char reportCSV_client_bb_bw_udp_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%" PRIdMAX ",%" PRIdMAX ",%.3f,%.3f,%.3f,%.3f,%" PRIdMAX ",%" PRIdMAX
    ",%0.1f,%" PRIdMAX ",%f\n";

// --trip-times bounceback's own per-direction one-way-delay row (TCP or
// UDP, same shape either way - unlike the main bbcnt row above, nothing
// here is transport-specific) - previously computed and printed in the
// human-readable path (report_client_bb_bw_triptime_format, this file)
// but entirely missing under -y C, same gap histogram_print_csv's own
// doc comment already called out for the plain bbrtt histogram row
// before that got fixed. A separate row (own field count, deliberately
// not 21 - see BOUNCEBACK_HISTOGRAM_FIELD_COUNT, Android's
// CsvLineParser, which disambiguates its own histogram row by field
// count alone) rather than folding these columns into the main bbcnt
// row, mirroring that same human-readable convention of a second,
// independent printf call - only emitted when --trip-times is actually
// set, same as the human-readable line.
//
// owdtocnt/owdtoavg/min/max/stdev: request-direction (client tx -> server
// rx) one-way delay, ms - stats->bbowdto. owdfroavg/min/max/stdev:
// reply-direction (server tx -> client rx), ms - stats->bbowdfro (same
// sample count as owdtocnt, one owdto+owdfro pair per bounce, not
// repeated). asymavg/min/max/stdev: per-sample owdto-owdfro asymmetry,
// ms - stats->bbasym; note this is NOT owdtoavg-owdfroavg (that would be
// the average of the difference vs the difference of the averages -
// equal in principle, but bbasym is its own independently-accumulated
// stat, not derived post-hoc, so reflects real per-sample variance
// rather than an assumption the two are perfectly correlated).
// clocksyncerrors: running count of samples where the computed OWD came
// out negative or otherwise nonsensical - the definitive sign the
// client's and server's clocks aren't actually synchronized (OWD
// requires synced clocks to mean anything at all, unlike RTT) - see
// stats->bb_clocksync_error and report_client_bb_triptime_clocksync_error's
// own human-readable warning line.
// owdtorelavg/min/max/stdev, owdfrorelavg/min/max/stdev: clock-offset-
// tolerant OWD - each raw owdto/owdfro sample minus that direction's own
// lifetime running minimum (see struct TransferInfo's own doc comment,
// Reporter.h, and reporter_handle_packet_bb_client's, Reporter.c, for the
// derivation). Useful even when clocksyncerrors is nonzero (unsynced
// clocks): a constant clock offset cancels out of this subtraction, so
// these track genuine OWD *change* over the run rather than an absolute
// value that unsynced clocks would make meaningless. Always >= 0.
const char reportCSV_client_bb_owd_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,"
    "owdtocnt,owdtoavg,owdtomin,owdtomax,owdtostdev,"
    "owdfroavg,owdfromin,owdfromax,owdfrostdev,"
    "asymavg,asymmin,asymmax,asymstdev,clocksyncerrors,"
    "owdtorelavg,owdtorelmin,owdtorelmax,owdtorelstdev,"
    "owdfrorelavg,owdfrorelmin,owdfrorelmax,owdfrorelstdev\n";

const char reportCSV_client_bb_owd_format[] =
    "%s,%s,%d,%.1f,%.1f,%" PRIdMAX ",%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%" PRIdMAX
    ",%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n";

// UDP bounceback --trip-times per-direction loss attribution CSV row -
// see struct ReportStruct's own doc comment (packet_ring.h) for what each
// running counter means. bbrequestssent/bbrepliesreceived/
// bbserverreceived are this client's latest known running totals (not a
// per-interval delta - a "gap" only ever grows over the connection's
// lifetime, same reasoning bb_clocksync_error already uses). bbreqloss =
// bbrequestssent - bbserverreceived (requests that never reached the
// server at all). bbreplyloss = bbserverreceived - bbrepliesreceived
// (requests the server received and replied to, but the reply itself
// never made it back). UDP-only - see print_bb_loss_csv's own doc comment
// (ReportOutputs.c) for why TCP bounceback doesn't get this row.
const char reportCSV_client_bb_loss_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,"
    "bbrequestssent,bbrepliesreceived,bbserverreceived,bbreqloss,bbreplyloss\n";

const char reportCSV_client_bb_loss_format[] =
    "%s,%s,%d,%.1f,%.1f,%u,%u,%u,%d,%d\n";

// See histogram_print_csv()'s own doc comment (histogram.c) for why this
// exists - the final-only histogram distribution row (bbrtt, and under
// --trip-times its OWD-TX/OWD-RX siblings too - any struct histogram, not
// bounceback-only despite the name this started under), previously
// silently missing entirely under -y C. Same time/srcaddress/srcport/
// dstaddr/dstport/transferid/istart/iend prefix as every other CSV row in
// this app for consistency, then: binwidthus/totalcount (the histogram's
// own bin width and this-interval sample count), cilowerpct/ciupperpct
// (the configured percentile bounds, e.g. 5.00/95.00), cilowerbin/
// ciupperbin/p999bin (which bin number the running population first
// crossed each threshold - convert to latency via (binnum-1)*binwidthus to
// binnum*binwidthus, see CsvLineParser's own doc comment on the Android
// side), outliers (Tukey-fence outlier count), ooblower/oobupper (samples
// that didn't fit any bin at all), bins (a field listing every populated
// bin as semicolon-joined "binnumber:count" pairs - semicolons, not
// commas, since commas are already this row's own top-level field
// separator, see histogram_print_csv()), name (this histogram's own
// myname, e.g. " BB8" - what --histogram-baseline name=path matches
// against, and what makes a saved baseline row self-identifying when
// loaded back in), and emd (this run's Earth Mover's Distance against
// --histogram-baseline's loaded reference, or -1.0 when no baseline was
// configured for this histogram - see histogram_emd_against_baseline()'s
// own doc comment).
const char reportCSV_client_histogram_header[] =
    "time,srcaddress,srcport,dstaddr,dstport,transferid,istart,iend,"
    "binwidthus,totalcount,cilowerpct,ciupperpct,cilowerbin,ciupperbin,p999bin,"
    "outliers,ooblower,oobupper,bins,name,emd\n";

const char reportCSV_client_histogram_format[] =
    "%s,%s,%d,%.1f,%.1f,%u,%d,%.2f,%.2f,%d,%d,%d,%d,%d,%d,%s,%s,%.6f\n";

/* -------------------------------------------------------------------
 * warnings
 * ------------------------------------------------------------------- */

const char warn_window_requested[] = " (WARNING: requested %s)";

const char warn_window_small[] =
    "\
WARNING: TCP window size set to %d bytes. A small window size\n\
will give poor performance. See the Iperf documentation.\n";

const char warn_delay_large[] = "WARNING: delay too large, reducing from %.1f to 1.0 seconds.\n";

const char warn_no_pathmtu[] = "WARNING: Path MTU Discovery may not be enabled.\n";

const char warn_no_ack[] = "[%3d] WARNING: did not receive ack of last datagram after %d tries.\n";

const char warn_ack_failed[] = "[%3d] WARNING: ack of last datagram failed.\n";

const char warn_fileopen_failed[] =
    "WARNING: Unable to open file stream for transfer\n\
Using default data stream. \n";

const char unable_to_change_win[] = "WARNING: Unable to change the window size\n";

const char opt_estimate[] = "Optimal Estimate\n";

#ifdef HAVE_FASTSAMPLING
const char report_interval_small[] = "WARNING: interval too small, increasing to %3.4f milliseconds.\n";
#else
const char report_interval_small[] = "WARNING: interval too small, increasing to %3.3f milliseconds.\n";
#endif
const char warn_invalid_server_option[] = "WARNING: option -%c is not valid for server mode\n";

const char warn_invalid_client_option[] = "WARNING: option -%c is not valid for client mode\n";

const char warn_invalid_compatibility_option[] = "WARNING: option -%c is not valid in compatibility mode\n";

const char warn_implied_udp[] = "WARNING: option -%c implies udp testing\n";

const char warn_implied_compatibility[] = "WARNING: option -%c has implied compatibility mode\n";

const char warn_buffer_too_small[] =
    "WARNING: %s socket buffer size (-l value) increased to %d bytes for "
    "proper operation\n";

const char warn_invalid_single_threaded[] = "WARNING: option -%c is not valid in single threaded versions\n";

const char warn_invalid_report_style[] = "WARNING: unknown reporting style \"%s\", switching to default\n";

const char warn_invalid_report[] =
    "WARNING: unknown reporting type \"%c\", ignored\n valid options are:\n\t "
    "exclude: "
    "C(connection) D(data) M(multicast) S(settings) V(server) report\n\n";

const char warn_server_old[] = "WARNING: iperf server version is likely very old\n";

const char warn_test_exchange_failed[] = "WARNING: client/server version exchange failed\n";

const char warn_len_too_small_peer_exchange[] =
    "WARNING: %s option -l value of %d is too small for peer exchange "
    "(suggested min value is %d "
    "bytes)\n";

const char warn_compat_and_peer_exchange[] =
    "WARNING: Options of '-C' '--compatibility' AND '-X' '--peerdetect' are "
    "mutually exclusive, "
    "--peerdetect ignored\n";

const char warn_start_before_now[] = "[%3d] WARNING: --txstart-time (%ld.%06ld) %s is before now %s\n";

const char error_starttime_exceeds[] =
    "ERROR: --txstart-time %ld.%06ld %s exceeds max scheduled delay of %d "
    "secs\n";

const char error_delaytime_exceeds[] =
    "ERROR: --txdelay-time of %d seconds is more than the supported delay of "
    "%d seconds\n";

const char report_omitted[] = "  (omit)";

#ifdef __cplusplus
} /* end extern "C" */
#endif
