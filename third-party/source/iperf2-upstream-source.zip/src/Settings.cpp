/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Settings.cpp
 * by Mark Gates <mgates@nlanr.net>
 * & Ajay Tirumala <tirumala@ncsa.uiuc.edu>
 * -------------------------------------------------------------------
 * Stores and parses the initial values for all the global variables.
 * -------------------------------------------------------------------
 * headers
 * uses
 *   <stdlib.h>
 *   <stdio.h>
 *   <string.h>
 *
 *   <unistd.h>
 * ------------------------------------------------------------------- */

#define HEADERS()

#include "headers.h"
#include "Settings.hpp"
#include "Locale.h"
#include "SocketAddr.h"
#include "util.h"
#include "version.h"
#include "gnu_getopt.h"
#include "sha256.h"
#include "isochronous.hpp"
#include "pdfs.h"
#include "payloads.h"
#include "PerfSocket.hpp"
#include "dscp.h"
#include "iperf_formattime.h"
#include "Extractor.h"
#include <math.h>
#include "prague_cc.h"
#include "Reporter.h"

// Cross-call state that isn't tied to a single command line option's parsing
// (set while handling one option, consumed while handling/validating another).
static int infinitetime = 0;
static int notcpbbquickack_cliset = 0;
static int l2checks = 0; // --l2checks is only meaningful once UDP-or-not is known; consumed in Settings_ModalOptions
#if HAVE_RECVMMSG || HAVE_SENDMMSG
static int recvlowat = 1; //the recv low-water mark default value
#endif /* HAVE_RECVMMSG || HAVE_SENDMMSG */

void Settings_Interpret(int option, const char *optarg, struct thread_Settings *mExtSettings);
// apply compound settings after the command line has been fully parsed
void Settings_ModalOptions(struct thread_Settings *mExtSettings);

static void generate_permit_key(struct thread_Settings *mExtSettings);

/* -------------------------------------------------------------------
 * command line options
 *
 * The option struct essentially maps a long option name (--foobar)
 * or environment variable ($FOOBAR) to its short option char (f).
 * ------------------------------------------------------------------- */
#define LONG_OPTIONS()

// val codes for long options that have no short-option equivalent.
// Each is handled by its own case in Settings_Interpret() -- no flag
// pointers and no shared "did this option fire" globals.
enum {
    OPT_BOUNCEBACK = 256,
    OPT_BOUNCEBACK_TXDELAY,
    OPT_BOUNCEBACK_HOLD,
    OPT_BOUNCEBACK_NO_QUICKACK,
    OPT_BOUNCEBACK_PERIOD,
    OPT_BOUNCEBACK_REQUEST,
    OPT_BOUNCEBACK_REPLY,
    OPT_SYNC_TRANSFER_ID,
    OPT_DSCP,
    OPT_HISTOGRAMS,
    OPT_HISTOGRAM_BASELINE,
    OPT_HISTOGRAM_BASELINE_SAVE,
    OPT_HIDE_IPS,
    OPT_JITTER_HISTOGRAMS,
    OPT_L2CHECKS,
    OPT_IGNORE_SHUTDOWN,
    OPT_INCR_DSTIP,
    OPT_INCR_SRCIP,
    OPT_INCR_DSTPORT,
    OPT_INCR_SRCPORT,
    OPT_SUM_DSTIP,
    OPT_TXSTART_TIME,
    OPT_TXDELAY_TIME,
    OPT_FQ_RATE,
    OPT_FQ_RATE_STEP,
    OPT_FQ_RATE_STEP_INTERVAL,
    OPT_TRIP_TIMES,
    OPT_NO_UDP_FIN,
    OPT_CONNECT_ONLY,
    OPT_CONNECT_RETRY_TIME,
    OPT_CONNECT_RETRY_TIMER,
    OPT_NO_CONNECT_SYNC,
    OPT_FULL_DUPLEX,
    OPT_IPG,
    OPT_ISOCHRONOUS,
    OPT_SUM_ONLY,
    OPT_LOCAL_ONLY,
    OPT_OMIT,
    OPT_NEAR_CONGESTION,
    OPT_PERMIT_KEY,
    OPT_PERMIT_KEY_TIMEOUT,
    OPT_PERMIT_KEY_FILE,
    OPT_PERMIT_KEY_HMAC,
    OPT_PERMIT_KEY_HMAC_WINDOW,
    OPT_PERMIT_KEY_VENDOR_ID,
    OPT_BURST_SIZE,
    OPT_BURST_PERIOD,
    OPT_SET_RAND_SEED,
    OPT_SKIP_RX_COPY,
    OPT_TOS_OVERRIDE,
    OPT_TCP_RX_WINDOW_CLAMP,
    OPT_TCP_QUICKACK,
    OPT_SEND_DELAY,
    OPT_TCP_WRITE_PREFETCH,
    OPT_TCP_WRITE_TIMES,
    OPT_TEST_EXCHANGE_TIMEOUT,
    OPT_TAP_DEV,
    OPT_TUN_DEV,
    OPT_UDP_L4S,
    OPT_UDP_L4S_VIDEO,
    OPT_WORKING_LOAD,
    OPT_WORKING_LOAD_CCA,
    OPT_WORKING_LOAD_TRANSPORT,
    OPT_DUAL_TRANSPORT,
    OPT_TCP_CCA,
    OPT_UTC,
    OPT_NUM_REPORT_STRUCTS,
    OPT_SENDMMSG,
    OPT_RECVMMSG,
    OPT_RECVMMSG_WAIT_ALL,
    OPT_RECVMMSG_TIME,
    OPT_RECVLOWAT,
    OPT_REVERSE_LONG, // WIN32 only: "--reverse" (short -R means --remove on WIN32)
};

const struct option long_options[] =
{
{"singleclient",     no_argument, NULL, '1'},
#if 0
{"v4",               no_argument, NULL, '4'},
{"v6",               no_argument, NULL, '6'},
#endif
{"bandwidth",  required_argument, NULL, 'b'},
{"client",     required_argument, NULL, 'c'},
{"dualtest",         no_argument, NULL, 'd'},
{"enhanced",         no_argument, NULL, 'e'},
{"format",     required_argument, NULL, 'f'},
{"help",             no_argument, NULL, 'h'},
{"interval",   required_argument, NULL, 'i'},
{"len",        required_argument, NULL, 'l'},
{"print_mss",        no_argument, NULL, 'm'},
{"num",        required_argument, NULL, 'n'},
{"output",     required_argument, NULL, 'o'},
{"port",       required_argument, NULL, 'p'},
{"tradeoff",         no_argument, NULL, 'r'},
{"server",           no_argument, NULL, 's'},
{"time",       required_argument, NULL, 't'},
{"udp",              no_argument, NULL, 'u'},
{"version",          no_argument, NULL, 'v'},
{"window",     required_argument, NULL, 'w'},
{"reportexclude", required_argument, NULL, 'x'},
{"reportstyle",required_argument, NULL, 'y'},
{"realtime",         no_argument, NULL, 'z'},

// more esoteric options
{"awdl",             no_argument, NULL, 'A'},
{"bind",       required_argument, NULL, 'B'},
{"bounceback", optional_argument, NULL, OPT_BOUNCEBACK},
{"bounceback-txdelay", required_argument, NULL, OPT_BOUNCEBACK_TXDELAY},
{"bounceback-hold", required_argument, NULL, OPT_BOUNCEBACK_HOLD},
{"bounceback-no-quickack", no_argument, NULL, OPT_BOUNCEBACK_NO_QUICKACK},
{"bounceback-period", required_argument, NULL, OPT_BOUNCEBACK_PERIOD},
{"bounceback-request", required_argument, NULL, OPT_BOUNCEBACK_REQUEST},
{"bounceback-reply", required_argument, NULL, OPT_BOUNCEBACK_REPLY},
{"compatibility",    no_argument, NULL, 'C'},
{"daemon",           no_argument, NULL, 'D'},
{"dscp", required_argument, NULL, OPT_DSCP},
{"file_input", required_argument, NULL, 'F'},
{"ssm-host", required_argument, NULL, 'H'},
{"stdin_input",      no_argument, NULL, 'I'},
{"mss",        required_argument, NULL, 'M'},
{"nodelay",          no_argument, NULL, 'N'},
{"listenport", required_argument, NULL, 'L'},
{"parallel",   required_argument, NULL, 'P'},
#ifdef WIN32
{"remove",           no_argument, NULL, 'R'},
#else
{"reverse",          no_argument, NULL, 'R'},
#endif
{"sync-transfer-id", no_argument, NULL, OPT_SYNC_TRANSFER_ID},
{"tos",        required_argument, NULL, 'S'},
{"ttl",        required_argument, NULL, 'T'},
{"single_udp",       no_argument, NULL, 'U'},
{"ipv6_domain",      no_argument, NULL, 'V'},
{"suggest_win_size", no_argument, NULL, 'W'},
{"peer-detect",      no_argument, NULL, 'X'},
{"tcp-congestion", required_argument, NULL, 'Z'},
{"histograms", optional_argument, NULL, OPT_HISTOGRAMS},
{"histogram-baseline", required_argument, NULL, OPT_HISTOGRAM_BASELINE},
{"histogram-baseline-save", required_argument, NULL, OPT_HISTOGRAM_BASELINE_SAVE},
{"hide-ips", no_argument, NULL, OPT_HIDE_IPS},
{"jitter-histograms", optional_argument, NULL, OPT_JITTER_HISTOGRAMS},
{"udp-histograms", optional_argument, NULL, OPT_HISTOGRAMS}, // keep support per 2.0.13 usage
{"l2checks", no_argument, NULL, OPT_L2CHECKS},
{"ignore-shutdown", no_argument, NULL, OPT_IGNORE_SHUTDOWN},
{"incr-dstip", no_argument, NULL, OPT_INCR_DSTIP},
{"incr-srcip", no_argument, NULL, OPT_INCR_SRCIP},
{"incr-dstport", no_argument, NULL, OPT_INCR_DSTPORT},
{"incr-srcport", no_argument, NULL, OPT_INCR_SRCPORT},
{"sum-dstip", no_argument, NULL, OPT_SUM_DSTIP},
{"txstart-time", required_argument, NULL, OPT_TXSTART_TIME},
{"txdelay-time", required_argument, NULL, OPT_TXDELAY_TIME},
{"fq-rate", required_argument, NULL, OPT_FQ_RATE},
{"fq-rate-step", required_argument, NULL, OPT_FQ_RATE_STEP},
{"fq-rate-step-interval", required_argument, NULL, OPT_FQ_RATE_STEP_INTERVAL},
{"trip-times", no_argument, NULL, OPT_TRIP_TIMES},
{"no-udp-fin", no_argument, NULL, OPT_NO_UDP_FIN},
{"connect-only", optional_argument, NULL, OPT_CONNECT_ONLY},
{"connect-retry-time", required_argument, NULL, OPT_CONNECT_RETRY_TIME},
{"connect-retry-timer", required_argument, NULL, OPT_CONNECT_RETRY_TIMER},
{"no-connect-sync", no_argument, NULL, OPT_NO_CONNECT_SYNC},
{"full-duplex", no_argument, NULL, OPT_FULL_DUPLEX},
{"ipg", required_argument, NULL, OPT_IPG},
{"isochronous", optional_argument, NULL, OPT_ISOCHRONOUS},
{"sum-only", no_argument, NULL, OPT_SUM_ONLY},
{"local-only", optional_argument, NULL, OPT_LOCAL_ONLY},
{"omit", required_argument, NULL, OPT_OMIT},
{"near-congestion", optional_argument, NULL, OPT_NEAR_CONGESTION},
{"permit-key", optional_argument, NULL, OPT_PERMIT_KEY},
{"permit-key-timeout", required_argument, NULL, OPT_PERMIT_KEY_TIMEOUT},
{"permit-key-file", optional_argument, NULL, OPT_PERMIT_KEY_FILE},
{"permit-key-hmac", no_argument, NULL, OPT_PERMIT_KEY_HMAC},
{"permit-key-hmac-window", required_argument, NULL, OPT_PERMIT_KEY_HMAC_WINDOW},
{"permit-key-vendor-id", required_argument, NULL, OPT_PERMIT_KEY_VENDOR_ID},
{"burst-size", required_argument, NULL, OPT_BURST_SIZE},
{"burst-period", required_argument, NULL, OPT_BURST_PERIOD},
{"set-rand-seed", required_argument, NULL, OPT_SET_RAND_SEED},
{"skip-rx-copy", no_argument, NULL, OPT_SKIP_RX_COPY},
{"tos-override", required_argument, NULL, OPT_TOS_OVERRIDE},
{"tcp-rx-window-clamp", required_argument, NULL, OPT_TCP_RX_WINDOW_CLAMP},
{"tcp-quickack", no_argument, NULL, OPT_TCP_QUICKACK},
{"send-delay", required_argument, NULL, OPT_SEND_DELAY},
{"tcp-write-prefetch", required_argument, NULL, OPT_TCP_WRITE_PREFETCH}, // see doc/DESIGN_NOTES
{"tcp-write-times", no_argument, NULL, OPT_TCP_WRITE_TIMES},
{"test-exchange-timeout", required_argument, NULL, OPT_TEST_EXCHANGE_TIMEOUT},
{"tap-dev", optional_argument, NULL, OPT_TAP_DEV},
{"tun-dev", optional_argument, NULL, OPT_TUN_DEV},
{"udp-l4s", no_argument, NULL, OPT_UDP_L4S},
{"udp-l4s-video", optional_argument, NULL, OPT_UDP_L4S_VIDEO},
{"working-load", optional_argument, NULL, OPT_WORKING_LOAD},
{"working-load-cca", required_argument, NULL, OPT_WORKING_LOAD_CCA},
{"working-load-transport", required_argument, NULL, OPT_WORKING_LOAD_TRANSPORT},
{"dual-transport", no_argument, NULL, OPT_DUAL_TRANSPORT},
{"cca", required_argument, NULL, OPT_TCP_CCA},
{"tcp-cca", required_argument, NULL, OPT_TCP_CCA},  // deprecated alias for --cca (kept for anyone already using it - --cca is now the documented name since this option doubles as the UDP-L4S CCA selector under --udp-l4s too)
{"utc", no_argument, NULL, OPT_UTC},
{"NUM_REPORT_STRUCTS", required_argument, NULL, OPT_NUM_REPORT_STRUCTS},
#if HAVE_RECVMMSG || HAVE_SENDMMSG
{"sendmmsg", required_argument, NULL, OPT_SENDMMSG},
{"recvmmsg", required_argument, NULL, OPT_RECVMMSG},
{"recvmmsg-wait-all", no_argument, NULL, OPT_RECVMMSG_WAIT_ALL},
{"recvmmsg-time", required_argument, NULL, OPT_RECVMMSG_TIME},
{"recvlowat", required_argument, NULL, OPT_RECVLOWAT},
#endif /* HAVE_RECVMMSG || HAVE_SENDMMSG */
#ifdef WIN32
{"reverse", no_argument, NULL, OPT_REVERSE_LONG},
#endif
{0, 0, 0, 0}
};

#define ENV_OPTIONS()

const struct option env_options[] =
{
{"IPERF_IPV6_DOMAIN",      no_argument, NULL, 'V'},
{"IPERF_SINGLECLIENT",     no_argument, NULL, '1'},
{"IPERF_BANDWIDTH",  required_argument, NULL, 'b'},
{"IPERF_CLIENT",     required_argument, NULL, 'c'},
{"IPERF_DUALTEST",         no_argument, NULL, 'd'},
{"IPERF_ENHANCEDREPORTS",  no_argument, NULL, 'e'},
{"IPERF_FORMAT",     required_argument, NULL, 'f'},
// skip help
{"IPERF_INTERVAL",   required_argument, NULL, 'i'},
{"IPERF_LEN",        required_argument, NULL, 'l'},
{"IPERF_PRINT_MSS",        no_argument, NULL, 'm'},
{"IPERF_NUM",        required_argument, NULL, 'n'},
{"IPERF_PORT",       required_argument, NULL, 'p'},
{"IPERF_TRADEOFF",         no_argument, NULL, 'r'},
{"IPERF_SERVER",           no_argument, NULL, 's'},
{"IPERF_TIME",       required_argument, NULL, 't'},
{"IPERF_UDP",              no_argument, NULL, 'u'},
// skip version
{"TCP_WINDOW_SIZE",  required_argument, NULL, 'w'},
{"IPERF_REPORTEXCLUDE", required_argument, NULL, 'x'},
{"IPERF_REPORTSTYLE",required_argument, NULL, 'y'},

// more esoteric options
{"IPERF_BIND",       required_argument, NULL, 'B'},
{"IPERF_COMPAT",           no_argument, NULL, 'C'},
{"IPERF_DAEMON",           no_argument, NULL, 'D'},
{"IPERF_FILE_INPUT", required_argument, NULL, 'F'},
{"IPERF_STDIN_INPUT",      no_argument, NULL, 'I'},
{"IPERF_MSS",        required_argument, NULL, 'M'},
{"IPERF_NODELAY",          no_argument, NULL, 'N'},
{"IPERF_LISTENPORT", required_argument, NULL, 'L'},
{"IPERF_PARALLEL",   required_argument, NULL, 'P'},
{"IPERF_TOS",        required_argument, NULL, 'S'},
{"IPERF_TTL",        required_argument, NULL, 'T'},
{"IPERF_SINGLE_UDP",       no_argument, NULL, 'U'},
{"IPERF_SUGGEST_WIN_SIZE", required_argument, NULL, 'W'},
{"IPERF_PEER_DETECT", no_argument, NULL, 'X'},
{"IPERF_CONGESTION_CONTROL",  required_argument, NULL, 'Z'},
{0, 0, 0, 0}
};

#define SHORT_OPTIONS()

const char short_options[] = "146b:c:def:hi:l:mn:o:p:rst:uvw:x:y:zAB:CDF:H:IL:M:NP:RS:T:UVWXZ:";

/* -------------------------------------------------------------------
 * defaults
 * ------------------------------------------------------------------- */
#define DEFAULTS()

const long kDefault_UDPRate = 1024 * 1024; // -u  if set, 1 Mbit/sec
const int kDefault_TCPBufLen = 128 * 1024; // TCP default read/write size
const int kDefault_BBTCPReqLen = 100; // default bounce-back size in bytes

/* -------------------------------------------------------------------
 * Initialize all settings to defaults.
 * ------------------------------------------------------------------- */
void Settings_Initialize (struct thread_Settings *main) {
    // Everything defaults to zero or NULL with
    // this memset. Only need to set non-zero values
    // below.
    memset(main, 0, sizeof(struct thread_Settings));
    // Settings_Copy() initializes awake_me for every copy, but the client
    // traffic thread runs on this original object, not a copy. A zeroed
    // pthread cond/mutex only happens to be valid on glibc (it equals
    // the static initializer); on winpthreads a zeroed cond makes every
    // Condition_TimedWait return EINVAL immediately, so the traffic
    // thread spins holding awake_me's mutex and the reporter can never
    // take it to set consumerdone - the process never exits.
    Condition_Initialize(&main->awake_me);
    main->mSock = INVALID_SOCKET;
    main->mReportMode = kReport_Default;
    // option, defaults
    main->flags         = FLAG_MODETIME | FLAG_STDOUT; // Default time and stdout
    main->flags_extend  = 0x0;           // Default all extend flags to off
    main->flags_extend2 = 0x0;           // Default all extend flags to off
    main->flags_extend3 = 0x0;           // Default all extend flags to off
    //main->mAppRate      = 0;           // -b,  offered (or rate limited) load (both UDP and TCP)
    main->mAppRateUnits = kRate_BW;
    //main->mHost         = NULL;        // -c,  none, required for client
    main->mMode         = kTest_Normal;  // -d,  mMode == kTest_DualTest
    main->mFormat       = 'a';           // -f,  adaptive bits
    // skip help                         // -h,
    //main->mBufLenSet  = false;         // -l,
    main->mBufLen       = kDefault_TCPBufLen; // -l,  Default to TCP read/write size
    //main->mInterval     = 0;           // -i,  ie. no periodic bw reports
    //main->mPrintMSS   = false;         // -m,  don't print MSS
    // mAmount is time also              // -n,  N/A
    //main->mOutputFileName = NULL;      // -o,  filename
    main->mPort         = 5001;          // -p,  ttcp port
    main->mBindPort     = 0;             // -B,  default port for bind
    // mMode    = kTest_Normal;          // -r,  mMode == kTest_TradeOff
    main->mThreadMode   = kMode_Unknown; // -s,  or -c, none
    main->mAmount       = 1000;          // -t,  10 seconds, units is 10 ms
    main->mOmitAmount   = 100;           // --omit,  1 seconds, units is 10 ms
    main->mIntervalMode = kInterval_None;// -i   none, time, packets, or bursts
    // skip version                      // -v,
    //main->mTCPWin       = 0;           // -w,  ie. don't set window

    // more esoteric options
    //main->mLocalhost    = NULL;        // -B,  none
    //main->mCompat     = false;         // -C,  run in Compatibility mode
    //main->mDaemon     = false;         // -D,  run as a daemon
    //main->mFileInput  = false;         // -F,
    //main->mFileName     = NULL;        // -F,  filename
    //main->mStdin      = false;         // -I,  default not stdin
    //main->mListenPort   = 0;           // -L,  listen port
    //main->mMSS          = 0;           // -M,  ie. don't set MSS
    //main->mNodelay    = false;         // -N,  don't set nodelay
    //main->mThreads      = 0;           // -P,
    //main->mRemoveService = false;      // -R,
    //main->mTOS          = 0;           // -S,  ie. don't set type of service
    main->mTTL          = -1;            // -T,  link-local TTL
    //main->mDomain     = kMode_IPv4;    // -V,
    //main->mSuggestWin = false;         // -W,  Suggest the window size.
    main->mListenerTimeout = -1;         //
    main->mKeyCheck = true;
    main->mPermitKeyHmacWindowSecs = DEFAULT_PERMITKEY_HMAC_WINDOW;
#if defined(HAVE_DECL_SO_DONTROUTE) && defined(HAVE_DEFAULT_DONTROUTE_ON)
    setDontRoute(main);
#endif
    main->mFPS = 1;
#if HAVE_RECVMMSG || HAVE_SENDMMSG
    main->mmnum = 1;
    main->wait_mode = WaitForOne;
    main->wait_nsec = -1;
    main->recvlowat = &recvlowat; //default value
#endif /* HAVE_RECVMMSG || HAVE_SENDMMSG */
} // end Settings

static char *dupstr (const char *src) {
    if (!src)
	return NULL;
    char *dst = new char[strlen(src) + 1];
    strcpy(dst, src);
    return dst;
}

// Deep-copies a whole histogram_baseline list (used for both
// mHistogramBaselines and mHistogramBaselineSaves) - a shallow pointer
// copy would leave both thread_Settings sharing (and eventually
// double-freeing) the same nodes. Returns NULL if [from] is NULL (an
// empty list copies to an empty list).
static struct histogram_baseline *copy_histogram_baseline_list (struct histogram_baseline *from) {
    struct histogram_baseline *head = NULL;
    struct histogram_baseline **totail = &head;
    for (struct histogram_baseline *node = from; node; node = node->next) {
	struct histogram_baseline *copy = static_cast<struct histogram_baseline *>(calloc(1, sizeof(struct histogram_baseline)));
	copy->name = dupstr(node->name);
	copy->path = dupstr(node->path);
	copy->next = NULL;
	*totail = copy;
	totail = &copy->next;
    }
    return head;
}

void Settings_Copy (struct thread_Settings *from, struct thread_Settings **into, int copyall) {
    *into = new struct thread_Settings;
    memset(*into, 0, sizeof(struct thread_Settings));
    memcpy(*into, from, sizeof(struct thread_Settings));
    (*into)->mSumReport = NULL;
    (*into)->mTransferIDStr = NULL;

#ifdef HAVE_THREAD_DEBUG
    thread_debug("Copy thread settings (malloc) from/to=%p/%p report/sum/fullduplex %p/%p/%p", \
		 (void *)from, (void *)*into, (void *)(*into)->reporthdr, (void *)(*into)->mSumReport, (void *)(*into)->mFullDuplexReport);
#endif
    // Some settings don't need to be copied and will confuse things. Don't copy them unless copyall is set
    if (copyall) {
	// Don't allocate memory for these if this is a reverse client
	if (from->mHost != NULL) {
	    (*into)->mHost = dupstr(from->mHost);
	}
	if (from->mOutputFileName != NULL) {
	    (*into)->mOutputFileName = dupstr(from->mOutputFileName);
	}
	if (from->mLocalhost != NULL) {
	    (*into)->mLocalhost = dupstr(from->mLocalhost);
	}
	if (from->mFileName != NULL) {
	    (*into)->mFileName = dupstr(from->mFileName);
	}
	if (from->mHistogramStr != NULL) {
	    (*into)->mHistogramStr = dupstr(from->mHistogramStr);
	}
	// Deep-copy each whole linked list (not just the head pointer) - a
	// shallow pointer copy would leave both thread_Settings sharing (and
	// eventually double-freeing) the same nodes.
	(*into)->mHistogramBaselines = copy_histogram_baseline_list(from->mHistogramBaselines);
	(*into)->mHistogramBaselineSaves = copy_histogram_baseline_list(from->mHistogramBaselineSaves);
	if (from->mSSMMulticastStr != NULL) {
	    (*into)->mSSMMulticastStr = dupstr(from->mSSMMulticastStr);
	}
	if (from->mIfrname != NULL) {
	    (*into)->mIfrname = static_cast<char *>(calloc(strlen(from->mIfrname) + 1, sizeof(char)));
	    strcpy((*into)->mIfrname, from->mIfrname);
	}
	if (from->mIfrnametx != NULL) {
	    (*into)->mIfrnametx = static_cast<char *>(calloc(strlen(from->mIfrnametx) + 1, sizeof(char)));
	    strcpy((*into)->mIfrnametx, from->mIfrnametx);
	}
	if (from->mIsochronousStr != NULL) {
	    (*into)->mIsochronousStr = dupstr(from->mIsochronousStr);
	}
	if (from->mHideHost != NULL) {
	    (*into)->mHideHost = dupstr(from->mHideHost);
	}
	if (from->mCongestion != NULL) {
	    (*into)->mCongestion = dupstr(from->mCongestion);
	}
	if (from->mLoadCCA != NULL) {
	    (*into)->mLoadCCA = dupstr(from->mLoadCCA);
	}
	if (from->mBraKetGraph != NULL) {
	    (*into)->mBraKetGraph = dupstr(from->mBraKetGraph);
	}
    } else {
	(*into)->mHost = NULL;
	(*into)->mOutputFileName = NULL;
	(*into)->mLocalhost = NULL;
	(*into)->mFileName = NULL;
	(*into)->mHistogramStr = NULL;
	(*into)->mHistogramBaselines = NULL;
	(*into)->mHistogramBaselineSaves = NULL;
	(*into)->mSSMMulticastStr = NULL;
	(*into)->mIfrname = NULL;
	(*into)->mIfrnametx = NULL;
	(*into)->mIsochronousStr = NULL;
	(*into)->mCongestion = NULL;
	// apply the server side congestion setting to reverse clients
	if (from->mIsochronousStr != NULL) {
	    (*into)->mIsochronousStr = dupstr(from->mIsochronousStr);
	}
    }

    (*into)->txstart_epoch = from->txstart_epoch;
    (*into)->mSumReport = from->mSumReport;
    (*into)->mFullDuplexReport = from->mFullDuplexReport;

    // Zero out certain entries
    (*into)->mTID = thread_zeroid();
    (*into)->runNext = NULL;
    (*into)->runNow = NULL;
#if defined(HAVE_LINUX_FILTER_H) && defined(HAVE_AF_PACKET)
    (*into)->mSockDrop = INVALID_SOCKET;
#endif
    int mbuflen = (from->mBufLen > MINMBUFALLOCSIZE) ? from->mBufLen : MINMBUFALLOCSIZE; // defined in payloads.h
#if (((HAVE_TUNTAP_TUN) || (HAVE_TUNTAP_TAP)) && (AF_PACKET))
    mbuflen += TAPBYTESSLOP;
#endif
#if HAVE_RECVMMSG
    if(isRcvMMsgs(from)) {
        mbuflen = mbuflen * from->mmnum;
    }
#endif
    (*into)->mBuf = new char[mbuflen];
    memset((*into)->mBuf, 0, mbuflen);

#ifdef HAVE_THREAD_DEBUG
    thread_debug("Copy Settings: MBUF malloc %d bytes (%p)", mbuflen, (void *) (*into)->mBuf);
#endif
    Condition_Initialize(&(*into)->awake_me);
    // default copied settings to no reporter reporting
    unsetReport((*into));
}

const char *Settings_FindHistogramBaseline (struct histogram_baseline *list, const char *name) {
    for (struct histogram_baseline *node = list; node; node = node->next) {
	if (!strcmp(node->name, name))
	    return node->path;
    }
    return NULL;
}

void Settings_Resize_mBuf (struct thread_Settings *mSettings, int newsize) {
    if (newsize > 0) {
	if (newsize > mSettings->mBufLen) {
	    char *tmp = new char[newsize];
	    pattern(tmp, newsize);
	    memcpy(tmp, mSettings->mBuf, mSettings->mBufLen);
	    DELETE_ARRAY(mSettings->mBuf);
	    mSettings->mBuf = tmp;
	}
	mSettings->mBufLen = newsize;
    }
}

/* -------------------------------------------------------------------
 * Delete memory: Now properly cleans up all allocated resources
 * ------------------------------------------------------------------- */

void Settings_Destroy (struct thread_Settings *mSettings) {
#if HAVE_THREAD_DEBUG
    thread_debug("Free thread settings=%p", mSettings);
#endif
    if (mSettings->tuntapdev)
	close(mSettings->tuntapdev);

    // FIX 1: Close Extractor file if it was opened
    Extractor_Destroy(mSettings);

    // FIX 2: Free report header if it exists
    if (mSettings->reporthdr) {
        FreeReport(mSettings->reporthdr);
        mSettings->reporthdr = NULL;
    }

    Condition_Destroy(&mSettings->awake_me);
    DELETE_ARRAY(mSettings->mHost);
    DELETE_ARRAY(mSettings->mHideHost);
    DELETE_ARRAY(mSettings->mLocalhost);
    DELETE_ARRAY(mSettings->mFileName);
    DELETE_ARRAY(mSettings->mOutputFileName);
    DELETE_ARRAY(mSettings->mHistogramStr);
    DELETE_ARRAY(mSettings->mSSMMulticastStr);
    DELETE_ARRAY(mSettings->mCongestion);
    DELETE_ARRAY(mSettings->mLoadCCA);
    DELETE_ARRAY(mSettings->mBraKetGraph);
    FREE_ARRAY(mSettings->mIfrname);
    FREE_ARRAY(mSettings->mIfrnametx);
    FREE_ARRAY(mSettings->mTransferIDStr);
    DELETE_ARRAY(mSettings->mIsochronousStr);
    DELETE_ARRAY(mSettings->mBuf);
    DELETE_PTR(mSettings);
} // end ~Settings

/* -------------------------------------------------------------------
 * Parses settings from user's environment variables.
 * ------------------------------------------------------------------- */
void Settings_ParseEnvironment (struct thread_Settings *mSettings) {
    char *theVariable;

    int i = 0;
    while (env_options[i].name != NULL) {
        theVariable = getenv(env_options[i].name);
        if (theVariable != NULL) {
            Settings_Interpret(env_options[i].val, theVariable, mSettings);
        }
        i++;
    }
} // end ParseEnvironment

/* -------------------------------------------------------------------
 * Parse settings from app's command line.
 * ------------------------------------------------------------------- */

void Settings_ParseCommandLine (int argc, char **argv, struct thread_Settings *mSettings) {
    int option;
    gnu_opterr = 1; // Fail on an unrecognized command line option
    while ((option =
             gnu_getopt_long(argc, argv, short_options,
                              long_options, NULL)) != EOF) {
        Settings_Interpret(option, gnu_optarg, mSettings);
    }

    for (int i = gnu_optind; i < argc; i++) {
        fprintf(stderr, "%s: ignoring extra argument -- %s\n", argv[0], argv[i]);
    }
    // Determine the modal or compound settings now that the full command line has been parsed
    Settings_ModalOptions(mSettings);

} // end ParseCommandLine

// Shared name=path parsing for --histogram-baseline/--histogram-baseline-save
// (see struct histogram_baseline's own doc comment, histogram.h) - prepends
// a new node onto *listhead on success, warns and leaves the list untouched
// on a malformed argument (missing '=', empty name, or empty path).
static void parse_histogram_baseline_arg(const char *optarg, const char *flagname, struct histogram_baseline **listhead) {
    const char *eq = strchr(optarg, '=');
    if (!eq || eq == optarg || !eq[1]) {
	fprintf(stderr, "WARN: --%s requires name=path (got '%s'), ignoring\n", flagname, optarg);
	return;
    }
    struct histogram_baseline *node = static_cast<struct histogram_baseline *>(calloc(1, sizeof(struct histogram_baseline)));
    size_t namelen = static_cast<size_t>(eq - optarg);
    node->name = new char[namelen + 1];
    memcpy(node->name, optarg, namelen);
    node->name[namelen] = '\0';
    node->path = dupstr(eq + 1);
    node->next = *listhead;
    *listhead = node;
}

/* -------------------------------------------------------------------
 * Interpret individual options, either from the command line
 * or from environment variables.
 * ------------------------------------------------------------------- */

void Settings_Interpret (int option, const char *optarg, struct thread_Settings *mExtSettings) {
    char *results;
    switch (option) {
    case '1': // Single Client
	setSingleClient(mExtSettings);
	break;

    case '4': // v4 only
	setIPV4(mExtSettings);
	break;

    case '6': // v6 only
	setIPV6(mExtSettings);
	break;

    case 'b': // offered load
    {
	char *tmp= new char [strlen(optarg) + 1];
	strcpy(tmp, optarg);
	// scan for PPS units, just look for 'p' as that's good enough
	if ((((results = strtok(tmp, "p")) != NULL) && strcmp(results,optarg) != 0) \
	    || (((results = strtok(tmp, "P")) != NULL)  && strcmp(results,optarg) != 0)) {
	    mExtSettings->mAppRateUnits = kRate_PPS;
	    mExtSettings->mAppRate = byte_atoi(results);
	} else {
	    mExtSettings->mAppRateUnits = kRate_BW;
	    mExtSettings->mAppRate = byte_atoi(optarg);
	    if (((results = strtok(tmp, ",")) != NULL) && strcmp(results,optarg) != 0) {
		setVaryLoad(mExtSettings);
		mExtSettings->mVariance = byte_atoi(optarg);
	    }
	}
	delete [] tmp;
	setBWSet(mExtSettings);
	break;
    }
    case 'c': // client mode w/ server host to connect to
	mExtSettings->mHost = dupstr(optarg);

	if (mExtSettings->mThreadMode == kMode_Unknown) {
	    mExtSettings->mThreadMode = kMode_Client;
	}
	break;

    case 'd': // Dual-test Mode
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, warn_invalid_server_option, option);
	    break;
	}
	if (isCompat(mExtSettings)) {
	    fprintf(stderr, warn_invalid_compatibility_option, option);
	}
#ifdef HAVE_THREAD
	mExtSettings->mMode = kTest_DualTest;
#else
	fprintf(stderr, warn_invalid_single_threaded, option);
	mExtSettings->mMode = kTest_TradeOff;
#endif
	break;
    case 'e': // Use enhanced reports
	setEnhanced(mExtSettings);
	break;
    case 'f': // format to print in
	mExtSettings->mFormat = (*optarg);
	break;

    case 'h': // print help and exit
	fprintf(stdout, "%s", usage_long1);
	fprintf(stdout, "%s", usage_long2);
	exit(0);
	break;

    case 'i': // specify interval between periodic bw reports
    {
	char framechar;
	char *tmp= new char [strlen(optarg) + 1];
	strcpy(tmp, optarg);
	// scan for frames as units
	if ((sscanf(optarg,"%c", &framechar)) && ((framechar == 'f') || (framechar == 'F'))) {
	    mExtSettings->mIntervalMode = kInterval_Frames;
	    setEnhanced(mExtSettings);
	    setFrameInterval(mExtSettings);
	} else {
	    char *end;
	    strcpy(tmp, optarg);
	    double itime = strtof(optarg, &end);
	    if (*end != '\0') {
		fprintf (stderr, "Invalid value of '%s' for -i interval\n", optarg);
		exit(1);
	    }
	    if (itime > (UINT_MAX / 1e6)) {
		fprintf (stderr, "Too large value of '%s' for -i interval, max is %f\n", optarg, (UINT_MAX / 1e6));
		exit(1);
	    }
	    mExtSettings->mInterval = static_cast<unsigned int>(ceil(itime * 1e6));
	    mExtSettings->mIntervalMode = kInterval_Time;
	    if (mExtSettings->mInterval < SMALLEST_INTERVAL) {
		mExtSettings->mInterval = SMALLEST_INTERVAL;
		fprintf (stderr, report_interval_small, (double) mExtSettings->mInterval / 1e3);
	    }
	}
	delete [] tmp;
    }
    break;

    case 'l': // length of each buffer
	if (isdigit(optarg[0])) {
	    mExtSettings->mBufLen = byte_atoi(optarg);
	    setBuflenSet(mExtSettings);
	} else if (optarg[0] == '<') {
	    mExtSettings->mBraKetGraph = dupstr(optarg);
	    mExtSettings->mBufLen = -1;
	} else {
	    fprintf(stderr, "Invalid value for -l or --len '%s'\n", optarg);
	    exit(1);
	}
	break;

    case 'm': // print TCP MSS
#if HAVE_DECL_TCP_MAXSEG
	setPrintMSS(mExtSettings);
#endif
	break;

    case 'n': // bytes of data
	// amount mode (instead of time mode)
	unsetModeTime(mExtSettings);
	mExtSettings->mAmount = byte_atoi(optarg);
	if (!(mExtSettings->mAmount > 0)) {
	    fprintf (stderr, "Invalid value for -n amount of '%s'\n", optarg);
	    exit(1);
	}
	break;

    case 'o' : // output the report and other messages into the file
	unsetSTDOUT(mExtSettings);
	mExtSettings->mOutputFileName = dupstr(optarg);
	break;

    case 'p': // server port
    {
	char *tmp= new char [strlen(optarg) + 1];
	strcpy(tmp, optarg);
	if ((results = strtok(tmp, "-")) != NULL) {
	    mExtSettings->mPort = atoi(results);
	    if (strcmp(results,optarg)) {
		mExtSettings->mPortLast = atoi(strtok(NULL, "-"));
		setIncrDstPort(mExtSettings);
	    }
	}
	delete [] tmp;
	break;
    }
    case 'r': // test mode tradeoff
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, warn_invalid_server_option, option);
	    break;
	}
	if (isCompat(mExtSettings)) {
	    fprintf(stderr, warn_invalid_compatibility_option, option);
	}
	mExtSettings->mMode = kTest_TradeOff;
	break;

    case 's': // server mode
	if (mExtSettings->mThreadMode != kMode_Unknown) {
	    fprintf(stderr, warn_invalid_client_option, option);
	    break;
	}

	mExtSettings->mThreadMode = kMode_Listener;
	break;

    case 't': // seconds to run the client, server, listener
	if (!optarg) {
	  fprintf(stderr, "ERROR: option -t requires value\n");
	  exit(1);
	}
	{
	  double val;
#if HAVE_STRTOD
	  char *end;
	  errno = 0;
	  val = strtod(optarg, &end);
	  if (errno || (*end != '\0')) {
	    fprintf(stderr, "ERROR: -t value of '%s' not recognized\n", optarg);
	    exit(1);
	  }
#else
	  val = atof(optarg);
#endif
	  if (val > 0.0)
	    mExtSettings->mAmount = static_cast<size_t>(val * 100.0);
	  else
	    infinitetime = 1;
	  // time mode (instead of amount mode), units is 10 ms
	  setModeTime(mExtSettings);
	  setServerModeTime(mExtSettings);
	}
	break;
    case 'u': // UDP instead of TCP
	setUDP(mExtSettings);
	break;

    case 'v': // print version and exit
	if (strlen(IPERF_BRANCH))
	    fprintf(stdout, "%s", branch_version);
	else
	    fprintf(stdout, "%s", version);
	exit(0);
	break;

    case 'w': // TCP window size (socket buffer size)
	mExtSettings->mTCPWin = byte_atoi(optarg);
	if (mExtSettings->mTCPWin < 2048) {
	    fprintf(stderr, warn_window_small, mExtSettings->mTCPWin);
	}
	break;

    case 'x': // Limit Reports
	while (*optarg != '\0') {
	    switch (*optarg) {
	    case 's':
	    case 'S':
		setNoSettReport(mExtSettings);
		break;
	    case 'c':
	    case 'C':
		setNoConnReport(mExtSettings);
		break;
	    case 'd':
	    case 'D':
		setNoDataReport(mExtSettings);
		break;
	    case 'v':
	    case 'V':
		setNoServReport(mExtSettings);
		break;
	    case 'm':
	    case 'M':
		setNoMultReport(mExtSettings);
		break;
	    default:
		fprintf(stderr, warn_invalid_report, *optarg);
	    }
	    optarg++;
	}
	break;
#if HAVE_SCHED_SETSCHEDULER
    case 'z': // Use realtime scheduling
	setRealtime(mExtSettings);
	break;
#endif

    case 'y': // Reporting Style
	switch (*optarg) {
	case 'c':
	case 'C':
	    mExtSettings->mReportMode = kReport_CSV;
	    setNoSettReport(mExtSettings);
	    setNoConnReport(mExtSettings);
	    break;
	default:
	    fprintf(stderr, warn_invalid_report_style, optarg);
	}
	break;

	// more esoteric options

    case 'B': // specify bind address
	if (mExtSettings->mLocalhost == NULL) {
	    mExtSettings->mLocalhost = dupstr(optarg);
	}
	break;

    case 'C': // Run in Compatibility Mode, i.e. no intial nor final header messaging
	setCompat(mExtSettings);
	if (mExtSettings->mMode != kTest_Normal) {
	    fprintf(stderr, warn_invalid_compatibility_option,
		    (mExtSettings->mMode == kTest_DualTest ?
		     'd' : 'r'));
	    mExtSettings->mMode = kTest_Normal;
	}
	break;

    case 'D': // Run as a daemon
	setDaemon(mExtSettings);
	break;

    case 'F' : // Get the input for the data stream from a file
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, warn_invalid_server_option, option);
	    break;
	}

	setFileInput(mExtSettings);
	mExtSettings->mFileName = dupstr(optarg);
	break;

    case 'H' : // Get the SSM host (or Source per the S,G)
	if (mExtSettings->mThreadMode == kMode_Client) {
	    fprintf(stderr, warn_invalid_client_option, option);
	    break;
	}
	mExtSettings->mSSMMulticastStr = dupstr(optarg);
	setSSMMulticast(mExtSettings);
	break;

    case 'I' : // Set the stdin as the input source
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, warn_invalid_server_option, option);
	    break;
	}

	setFileInput(mExtSettings);
	setSTDIN(mExtSettings);
	mExtSettings->mFileName = dupstr("<stdin>");
	break;

    case 'L': // Listen Port (bidirectional testing client-side)
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, warn_invalid_server_option, option);
	    break;
	}
	mExtSettings->mListenPort = atoi(optarg);
	break;

    case 'M': // specify TCP MSS (maximum segment size)
#if HAVE_DECL_TCP_MAXSEG
	mExtSettings->mMSS = byte_atoi(optarg);
	setTCPMSS(mExtSettings);
	setPrintMSS(mExtSettings);
#endif
	break;

    case 'N': // specify TCP nodelay option (disable Jacobson's Algorithm)
	setNoDelay(mExtSettings);
	break;

    case 'P': // number of client threads
#ifdef HAVE_THREAD
	mExtSettings->mThreads = atoi(optarg);
#else
	if (mExtSettings->mThreadMode != kMode_Server) {
	    fprintf(stderr, warn_invalid_single_threaded, option);
	} else {
	    mExtSettings->mThreads = atoi(optarg);
	}
#endif
	break;
#ifdef WIN32
    case 'R':
	setRemoveService(mExtSettings);
	break;
#else
    case 'R':
	setReverse(mExtSettings);
	break;
#endif
    case 'S': // IP type-of-service
	// TODO use a function that understands base-2
	// the zero base here allows the user to specify
	// "0x#" hex, "0#" octal, and "#" decimal numbers
	mExtSettings->mTOS = parse_ipqos(optarg);
	if (mExtSettings->mTOS == -1) {
	    fprintf(stderr, "WARN: Invalid --tos value of %s ignored\n", optarg);
	    mExtSettings->mTOS = 0;
	} else {
	    setSetTOS(mExtSettings);
	}
	break;

    case 'T': // time-to-live for both unicast and multicast
	mExtSettings->mTTL = atoi(optarg);
	break;

    case 'U': // single threaded UDP server
	setUDP(mExtSettings);
	setSingleUDP(mExtSettings);
	setSingleClient(mExtSettings);
	break;

    case 'V': // IPv6 Domain
#if HAVE_IPV6
	setIPV6(mExtSettings);
#else
	fprintf(stderr, "The --ipv6_domain (-V) option is not enabled in this build.\n");
	exit(1);
#endif
	break;

    case 'W' :
	setSuggestWin(mExtSettings);
	fprintf(stderr, "The -W option is not available in this release\n");
	break;

    case 'X' :
	setPeerVerDetect(mExtSettings);
	break;

    case 'Z':
#if HAVE_DECL_TCP_CONGESTION
	if (isCongestionControl(mExtSettings)) {
	    fprintf(stderr, "Option --tcp-congestion or -Z ignored because --cca set\n");
	} else {
	    setCongestionControl(mExtSettings);
	    mExtSettings->mCongestion = dupstr(optarg);
	}
#else
	fprintf(stderr, "The -Z option is not available on this operating system\n");
#endif
	break;

    case OPT_INCR_DSTIP:
	setIncrDstIP(mExtSettings);
	break;

    case OPT_INCR_DSTPORT:
	setIncrDstPort(mExtSettings);
	break;

    case OPT_INCR_SRCIP:
	setIncrSrcIP(mExtSettings);
	break;

    case OPT_INCR_SRCPORT:
	setIncrSrcPort(mExtSettings);
	break;

    case OPT_IGNORE_SHUTDOWN:
	setIgnoreShutdown(mExtSettings);
	break;

    case OPT_L2CHECKS:
	// Whether this applies depends on -u/--udp, which may not be parsed yet
	// (command line options are position independent); deferred to Settings_ModalOptions.
	l2checks = 1;
	break;

    case OPT_SUM_DSTIP:
	setSumServerDstIP(mExtSettings);
	break;

    case OPT_SYNC_TRANSFER_ID:
	setSyncTransferID(mExtSettings);
	break;

    case OPT_TXSTART_TIME:
    {
	long seconds;
	long usecs;
	setTxStartTime(mExtSettings);
	setEnhanced(mExtSettings);
	int match = sscanf(optarg,"%ld.%6ld", &seconds, &usecs);
	mExtSettings->txstart_epoch.tv_usec = 0;
	switch (match) {
	case 2:
	    mExtSettings->txstart_epoch.tv_usec = usecs;
	case 1:
	    mExtSettings->txstart_epoch.tv_sec = seconds;
	    break;
	default:
	    unsetTxStartTime(mExtSettings);
	    fprintf(stderr, "WARNING: invalid --txstart-time format\n");
	}
	break;
    }
    case OPT_NO_CONNECT_SYNC:
#ifdef HAVE_THREAD
	setNoConnectSync(mExtSettings);
#else
	fprintf(stderr, "WARNING: --no-connect-sync requires thread support and not supported\n");
#endif
	break;

    case OPT_TXDELAY_TIME:
    {
	char *end;
	Timestamp holdbackdelay;
	double delay = strtof(optarg, &end);
	if (*end != '\0') {
	    fprintf (stderr, "Invalid value of '%s' for --txdelay-time time\n", optarg);
	} else {
	    holdbackdelay.set(delay);
	    mExtSettings->txholdback_timer.tv_sec = holdbackdelay.getSecs();
	    mExtSettings->txholdback_timer.tv_usec = (holdbackdelay.getUsecs());
	    setTxHoldback(mExtSettings);
	}
	break;
    }
    case OPT_TRIP_TIMES:
	setTripTime(mExtSettings);
	setEnhanced(mExtSettings);
	break;

    case OPT_NO_UDP_FIN:
	setNoUDPfin(mExtSettings);
	break;

    case OPT_CONNECT_ONLY:
	setConnectOnly(mExtSettings);
	unsetNoConnReport(mExtSettings);
	if (optarg) {
	    mExtSettings->connectonly_count = atoi(optarg);
	} else {
	    mExtSettings->connectonly_count = -1;
	}
	break;

    case OPT_CONNECT_RETRY_TIMER:
    {
	char *end;
	double period = strtof(optarg, &end);
	if ((*end != '\0') || (period < 0 ))  {
	    fprintf (stderr, "Invalid value of '%s' for --connect-retry-timer\n", optarg);
	    exit(1);
	}
	if (period > (UINT_MAX / 1e6)) {
	    fprintf (stderr, "Too large value of '%s' for --connect-retry-timer, max is %f\n", optarg, (UINT_MAX / 1e6));
	    exit(1);
	}
	mExtSettings->connect_retry_timer = static_cast<unsigned int>(ceil(period * 1e6));
	if (mExtSettings->connect_retry_timer == 0) {
	    mExtSettings->connect_retry_timer = 10000;
	}
	break;
    }
    case OPT_CONNECT_RETRY_TIME:
    {
	char *end;
	double timer = strtof(optarg, &end);
	if (*end != '\0') {
	    fprintf (stderr, "Invalid value of '%s' for --connect-retry-time\n", optarg);
	    exit(1);
	}
	if (timer > (UINT_MAX / 1e6)) {
	    fprintf (stderr, "Too large value of '%s' for --connect-retry-time, max is %f\n", optarg, (UINT_MAX / 1e6));
	    exit(1);
	}
	mExtSettings->connect_retry_time = timer;
	break;
    }
    case OPT_SUM_ONLY:
	setSumOnly(mExtSettings);
	break;

    case OPT_LOCAL_ONLY:
#if HAVE_DECL_SO_DONTROUTE
	setDontRoute(mExtSettings);
	if (optarg) {
	    if (atoi(optarg))
		setDontRoute(mExtSettings);
	    else
		unsetDontRoute(mExtSettings);
	}
#else
	fprintf(stderr, "WARNING: The --local-only option is not supported on this platform\n");
#endif
	break;

    case OPT_NEAR_CONGESTION:
	setNearCongest(mExtSettings);
	if (optarg && (atof(optarg) >=  0.0)) {
	    mExtSettings->rtt_nearcongest_weight_factor = atof(optarg);
	} else {
	    mExtSettings->rtt_nearcongest_weight_factor = NEARCONGEST_DEFAULT;
	}
	break;

    case OPT_OMIT:
    {
	double val;
#if HAVE_STRTOD
	char *end;
	errno = 0;
	val = strtod(optarg, &end);
	if (errno || (*end != '\0')) {
	    fprintf(stderr, "ERROR: --omit value of '%s' not recognized\n", optarg);
	    exit(1);
	}
#else
	val = atof(optarg);
#endif
	if (val > 0.0) {
	    if (val > (UINT_MAX / 1e6)) {
		fprintf (stderr, "Too large value of '%s' for --omit, max is %f\n", optarg, (UINT_MAX / 1e6));
		exit(1);
	    }
	    if (val < (1e-6)) {
		fprintf (stderr, "Too small value of '%s' for --omit, min is 0.000001\n", optarg);
		exit(1);
	    }
	    setOmit(mExtSettings);
	    mExtSettings->mOmitAmount = static_cast<unsigned int> (val * 1000000); // units usecs
	} else {
	    mExtSettings->mOmitAmount = 0;
	}
	break;
    }
    case OPT_PERMIT_KEY:
	if (optarg) {
	    strncpy(mExtSettings->mPermitKey, optarg, MAX_PERMITKEY_LEN);
	    mExtSettings->mPermitKey[MAX_PERMITKEY_LEN-1] = '\0';
	} else {
	    mExtSettings->mPermitKey[0] = '\0';
	}
	setPermitKey(mExtSettings);
	break;

    case OPT_PERMIT_KEY_TIMEOUT:
	if (atof(optarg) > mExtSettings->mListenerTimeout)
	    mExtSettings->mListenerTimeout = static_cast<size_t>(atof(optarg));
	break;

    // Server-side list of valid keys, reloadable without a restart via
    // SIGHUP (see Listener.cpp's load_permit_key_file()). File format is
    // systemd EnvironmentFile=-compatible (NAME=VALUE lines, '#' comments,
    // blank lines ignored) so a file already used for a systemd unit's
    // EnvironmentFile= (e.g. holding PERMIT_KEY=<value>) can be pointed at
    // directly - any line whose NAME contains "PERMIT_KEY" contributes its
    // VALUE as one valid key, so adding more lines (PERMIT_KEY_PREV=...,
    // a second PERMIT_KEY=..., etc.) extends the accepted list without
    // changing what systemd itself does with the file. No value given
    // (bare --permit-key-file, same optional-argument convention as
    // --permit-key) defaults to DEFAULT_PERMITKEYFILE_PATH.
    case OPT_PERMIT_KEY_FILE:
	mExtSettings->mPermitKeyFile = dupstr(optarg ? optarg : DEFAULT_PERMITKEYFILE_PATH);
	setPermitKey(mExtSettings);
	break;

    // Client-side opt-in: --permit-key's value becomes an HMAC-SHA256 key
    // (see build_permit_key_wire_value(), HMAC1 wire format) instead of a
    // raw bearer secret. Validated (requires a non-empty --permit-key,
    // client-only) in ModalOptions_ClientBailChecks below - not here, same
    // as every other combination-dependent flag in this parser.
    case OPT_PERMIT_KEY_HMAC:
	setPermitKeyHmac(mExtSettings);
	break;

    // Server-side: max abs(now - client's presented HMAC1 timestamp)
    // tolerated before Listener::test_permit_key() rejects an otherwise-
    // valid HMAC outright. Meaningless standalone (WARN+ignore on the
    // client, validated below) - this only affects HMAC1-format
    // verification, which the server does unconditionally whenever a
    // presented key parses as one, regardless of --permit-key-hmac (a
    // purely client-side flag).
    case OPT_PERMIT_KEY_HMAC_WINDOW:
	mExtSettings->mPermitKeyHmacWindowSecs = atoi(optarg);
	break;

    // Server-side, soft/non-cryptographic signal only - see
    // Listener::test_permit_key()'s HMAC1 branch and
    // reporter_output_listener_settings() (ReportOutputs.c), both of
    // which just check this starts with "fi-wi". Rejected on the client
    // below (ModalOptions_ClientBailChecks), same as --permit-key-file.
    case OPT_PERMIT_KEY_VENDOR_ID:
	mExtSettings->mPermitKeyVendorId = dupstr(optarg);
	break;

    case OPT_TEST_EXCHANGE_TIMEOUT:
	if (atof(optarg) > mExtSettings->mListenerTimeout)
	    mExtSettings->mListenerTimeout = static_cast<size_t>(atof(optarg));
	break;

    case OPT_HISTOGRAM_BASELINE:
	// name=path, repeatable - name (e.g. " BB8", matching struct
	// histogram.myname exactly) is what a run with multiple simultaneous
	// histograms (bbrtt, jitter, write, frame-latency, latency, and
	// BOUNCEBACK's own OWD-TX/OWD-RX pair under --trip-times) needs to
	// tell them apart - see struct histogram_baseline's own doc comment
	// (histogram.h). path is a previously-saved histogram CSV row (the
	// exact same format histogram_print_csv() itself emits) - loaded at
	// the end of this run and compared against via Earth Mover's
	// Distance (histogram_emd_against_baseline(), src/histogram.c) once
	// Settings_FindHistogramBaseline() resolves it by name onto that
	// histogram's own baseline_path. A saved reference this way is
	// calibrated to whatever run the user chose to save (real
	// path/device conditions), not a generic theoretical distribution.
	parse_histogram_baseline_arg(optarg, "histogram-baseline", &mExtSettings->mHistogramBaselines);
	break;

    case OPT_HISTOGRAM_BASELINE_SAVE:
	// name=path, repeatable - the save-side counterpart to
	// --histogram-baseline above (same name=path shape, same per-name
	// resolution onto struct histogram.baseline_save_path). A
	// standalone CLI capability for capturing a golden reference
	// directly (e.g. a scripted calibration run) - deliberately never
	// set by the Android app itself, which only ever saves a golden
	// reference as a user-driven action *after* a run has already
	// completed and rendered its results (see
	// IperfViewModel.saveGoldenHistogram()), not something requested
	// up front via a launch argument the way this flag is.
	parse_histogram_baseline_arg(optarg, "histogram-baseline-save", &mExtSettings->mHistogramBaselineSaves);
	break;

    case OPT_HISTOGRAMS:
	setHistogram(mExtSettings);
	setEnhanced(mExtSettings);
	if (optarg) {
	    mExtSettings->mHistogramStr = dupstr(optarg);
	} else {
	    mExtSettings->mHistogramStr = NULL;
	}
	break;

    case OPT_JITTER_HISTOGRAMS:
	setJitterHistogram(mExtSettings);
	setEnhanced(mExtSettings);
	if (optarg) {
	    mExtSettings->jitter_binwidth = atoi(optarg);
	} else {
	    mExtSettings->jitter_binwidth = JITTER_BINWIDTH; // units are usecs
	}
	break;

    case OPT_REVERSE_LONG: // WIN32 only
	setReverse(mExtSettings);
	break;

    case OPT_FULL_DUPLEX:
	setFullDuplex(mExtSettings);
	break;

    case OPT_TOS_OVERRIDE:
	if ((mExtSettings->mRTOS = parse_ipqos(optarg)) == -1) {
	    fprintf(stderr, "Invalid --tos-overide value of %s\n", optarg);
	} else {
	    setOverrideTOS(mExtSettings);
	}
	break;

    case OPT_DSCP:
	// dscp needs to shifted by 2 and the ECN bits masked off to map to a TOS byte
	mExtSettings->mTOS = (atoi(optarg) << DSCP_SHIFT) & DSCP_BITMASK; //2 & 0xFC
	break;

    case OPT_FQ_RATE:
#if (HAVE_DECL_SO_MAX_PACING_RATE)
	setFQPacing(mExtSettings);
	mExtSettings->mFQPacingRate = static_cast<uintmax_t>(bitorbyte_atoi(optarg) / 8);
#else
	fprintf(stderr, "WARNING: The --fq-rate option is not supported\n");
#endif
	break;

#if (HAVE_DECL_SO_MAX_PACING_RATE)
    case OPT_FQ_RATE_STEP:
	setFQPacingStep(mExtSettings);
	mExtSettings->mFQPacingRateStep = static_cast<uintmax_t>(bitorbyte_atoi(optarg) / 8);
	setEnhanced(mExtSettings);
	break;

    case OPT_FQ_RATE_STEP_INTERVAL:
    {
	double val;
#if HAVE_STRTOD
	char *end;
	errno = 0;
	val = strtod(optarg, &end);
	if (errno || (*end != '\0')) {
	    fprintf(stderr, "ERROR: --fq-rate-step-interval value of '%s' not recognized\n", optarg);
	    exit(1);
	}
#else
	val = atof(optarg);
#endif
	if (val > 0.0) {
	    mExtSettings->mFQPacingRateStepInterval = val;
	    setFQPacingStepInterval(mExtSettings);
	    setEnhanced(mExtSettings);
	}
	break;
    }
#endif
#if HAVE_RECVMMSG || HAVE_SENDMMSG
    case OPT_SENDMMSG:
	setSndMMsgs(mExtSettings);
	if (optarg) {
	    mExtSettings->mmnum = byte_atoi(optarg);
	    if (mExtSettings->mmnum > 1024) {
		fprintf(stderr, "WARN: --sendmmsg value %d exceeds max of 1024, clamping\n", mExtSettings->mmnum);
		mExtSettings->mmnum = 1024;
	    } else if (mExtSettings->mmnum <= 0) {
		fprintf(stderr, "WARN: --sendmmsg value %d is <= 0, using regular msg API instead\n", mExtSettings->mmnum);
		unsetSndMMsgs(mExtSettings);
	    }
	}
	break;

    case OPT_RECVMMSG:
	setRcvMMsgs(mExtSettings);
	if (optarg) {
	    mExtSettings->mmnum = byte_atoi(optarg);
	    if (mExtSettings->mmnum > 1024) {
		fprintf(stderr, "WARN: --recvmmsg value %d exceeds max of 1024, clamping\n", mExtSettings->mmnum);
		mExtSettings->mmnum = 1024;
	    } else if (mExtSettings->mmnum <= 0) {
		fprintf(stderr, "WARN: --recvmmsg value %d is <= 0, using regular msg API instead\n", mExtSettings->mmnum);
		unsetRcvMMsgs(mExtSettings);
	    }
	}
	break;

    case OPT_RECVMMSG_WAIT_ALL:
	setRcvMMsgsWaitAll(mExtSettings);
	mExtSettings->wait_mode = WaitAll;
	break;

    case OPT_RECVMMSG_TIME:
	setRcvMMsgsTime(mExtSettings);
	if (optarg)
	    mExtSettings->wait_nsec = byte_atoi(optarg) * 1000000; // input unit is ms
	else
	    mExtSettings->wait_nsec = 1000000;
	break;

    case OPT_RECVLOWAT:
	setRcvLowat(mExtSettings);
	if (optarg) {
	    recvlowat = byte_atoi(optarg);
	    if (recvlowat <= 0)
		mExtSettings->recvlowat = &mExtSettings->mBufLen;
	} else {
	    mExtSettings->recvlowat = &mExtSettings->mBufLen;
	}
	break;
#endif /* HAVE_RECVMMSG || HAVE_SENDMMSG */

    case OPT_ISOCHRONOUS:
	setEnhanced(mExtSettings);
	setIsochronous(mExtSettings);
	// The following are default values which
	// may be overwritten during modal parsing
	mExtSettings->mFPS = 60.0;
	mExtSettings->mMean = 20000000.0;
	mExtSettings->mVariance = 0.0;
	mExtSettings->mBurstIPG = 5e-6;
	if (optarg) {
	    mExtSettings->mIsochronousStr = dupstr(optarg);
	}
	break;

    case OPT_IPG:
    {
	setIPG(mExtSettings);
	char *end;
	mExtSettings->mBurstIPG = strtof(optarg,&end);
	if (*end != '\0') {
	    fprintf (stderr, "ERROR: Invalid value of '%s' for --ipg\n", optarg);
	    exit(1);
	}
	mExtSettings->mBurstIPG = mExtSettings->mBurstIPG * 1e6; // convert to microseconds
	break;
    }
    case OPT_TCP_RX_WINDOW_CLAMP:
#if HAVE_DECL_TCP_WINDOW_CLAMP
	mExtSettings->mClampSize = byte_atoi(optarg);
	setRxClamp(mExtSettings);
#else
	fprintf(stderr, "--tcp-rx-window-clamp not supported on this platform\n");
#endif
	break;

    case OPT_TCP_WRITE_TIMES:
	setTcpWriteTimes(mExtSettings);
	setEnhanced(mExtSettings);
	break;

    case OPT_BOUNCEBACK_NO_QUICKACK:
	notcpbbquickack_cliset = 1;
	break;

    case OPT_TCP_QUICKACK:
#if HAVE_DECL_TCP_QUICKACK
	setTcpQuickAck(mExtSettings);
#endif
	break;

    case OPT_SEND_DELAY:
#if HAVE_DECL_TCP_TX_DELAY || HAVE_DECL_SO_TXTIME
    {
	char *end;
	mExtSettings->mSendDelay = strtof(optarg,&end);
	if (*end != '\0') {
	    fprintf (stderr, "ERROR: Invalid value of '%s' for --send-delay\n", optarg);
	    exit(1);
	}
	if (mExtSettings->mSendDelay >= 0.001) { // smallest value is one us, units are ms
#ifdef TCP_TX_DELAY
	    setSendDelay(mExtSettings);
	    setEnhanced(mExtSettings);
#endif
	} else {
	    fprintf(stderr, "The --send-delay smallest unti is one microsecond \n");
	}
    }
#else
	fprintf(stderr, "The --send-delay option is not available on this operating system\n");
#endif
	break;

    case OPT_UTC:
	setUTC(mExtSettings);
	break;

    case OPT_WORKING_LOAD_CCA:
#if HAVE_DECL_TCP_CONGESTION
	setLoadCCA(mExtSettings);
	mExtSettings->mLoadCCA = dupstr(optarg);
	setEnhanced(mExtSettings);
#else
	fprintf(stderr, "The --working-load-cca option is not available on this operating system\n");
#endif
	break;

    case OPT_TCP_CCA:
#if HAVE_DECL_TCP_CONGESTION
	if (isCongestionControl(mExtSettings)) {
	    fprintf(stderr, "Option --cca ignored because --tcp-congestion or -Z set\n");
	} else {
	    setCongestionControl(mExtSettings);
	    mExtSettings->mCongestion = dupstr(optarg);
	}
#else
	fprintf(stderr, "The --cca option is not available on this operating system\n");
#endif
	break;

    case OPT_WORKING_LOAD:
#ifdef HAVE_THREAD
	setWorkingLoadUp(mExtSettings);
	setWorkingLoadDown(mExtSettings);
	setEnhanced(mExtSettings);
	if (optarg) {
	    char *tmp= new char [strlen(optarg) + 1];
	    if (tmp) {
		strcpy(tmp, optarg);
		if ((results = strtok(tmp, ",")) != NULL) {
		    if (strcasecmp(results, "up") == 0) {
			unsetWorkingLoadDown(mExtSettings);
		    } else if (strcasecmp(results, "down") == 0) {
			unsetWorkingLoadUp(mExtSettings);
		    } else if (strcasecmp(results, "bidir") == 0) {
			setWorkingLoadUp(mExtSettings);
			setWorkingLoadDown(mExtSettings);
		    } else {
			fprintf(stderr, "Unrecoginized value of %s for --working-load, use 'up', 'down' or 'bidir'\n", results);
		    }
		    if ((results = strtok(NULL, ",")) != NULL) {
			mExtSettings->mWorkingLoadThreads = atoi(results);
		    }
		    delete [] tmp;
		}
	    }
	}
#else
	fprintf(stderr, "bounceback-congest option requires a platform that supports threads\n");
#endif
	break;

    case OPT_BOUNCEBACK_TXDELAY:
    {
	char *end;
	Timestamp holdbackdelay;
	double delay = strtof(optarg, &end);
	if (*end != '\0') {
	    fprintf (stderr, "Invalid value of '%s' for --bounceback-txdelay time\n", optarg);
	} else {
	    holdbackdelay.set(delay);
	    mExtSettings->txholdback_timer.tv_sec = holdbackdelay.getSecs();
	    mExtSettings->txholdback_timer.tv_usec = (holdbackdelay.getUsecs());
	    setTxHoldback(mExtSettings);
	}
	break;
    }
    case OPT_TCP_WRITE_PREFETCH:
#if HAVE_DECL_TCP_NOTSENT_LOWAT
	mExtSettings->mWritePrefetch = byte_atoi(optarg);
	setWritePrefetch(mExtSettings);
	setEnhanced(mExtSettings);
#else
	fprintf(stderr, "--tcp-write-prefetch not supported on this platform\n");
#endif
	break;

    case OPT_BURST_PERIOD:
	setPeriodicBurst(mExtSettings);
	if (optarg && (atof(optarg) > 1e-5)) { // limit to 10 usecs
	    mExtSettings->mFPS = 1.0/atof(optarg);
	} else {
	    if (atof(optarg) != 0)
		fprintf(stderr, "WARN: burst-period too small, must be greater than 10 usecs\n");
	    unsetPeriodicBurst(mExtSettings);
	}
	break;

    case OPT_BURST_SIZE:
	setBurstSize(mExtSettings);
	if (optarg) {
	    mExtSettings->mBurstSize = byte_atoi(optarg);
	}
	break;

    case OPT_NUM_REPORT_STRUCTS:
	mExtSettings->numreportstructs = byte_atoi(optarg);
	break;

    case OPT_TAP_DEV:
#if HAVE_TUNTAP_TAP
	if (optarg) {
	    mExtSettings->mIfrname = static_cast<char *>(calloc(strlen(optarg) + 1, sizeof(char)));
	    strcpy(mExtSettings->mIfrname, optarg);
	}
	setTapDev(mExtSettings);
	setEnhanced(mExtSettings);
	setL2LengthCheck(mExtSettings);
#else
	fprintf(stderr, "ERROR: tap devices not supported\n");
	exit(1);
#endif
	break;

    case OPT_TUN_DEV:
	fprintf(stderr, "ERROR: tun devices not yet supported\n");
	exit(1);
#if HAVE_TUNTAP_TUN
	if (optarg) {
	    mExtSettings->mIfrname = static_cast<char *>(calloc(strlen(optarg) + 1, sizeof(char)));
	    strcpy(mExtSettings->mIfrname, optarg);
	}
	setTunDev(mExtSettings);
	setEnhanced(mExtSettings);
#endif
	break;

    case OPT_HIDE_IPS:
	setHideIPs(mExtSettings);
	break;

    case OPT_BOUNCEBACK:
	setBounceBack(mExtSettings);
	setNoDelay(mExtSettings);
	setEnhanced(mExtSettings);
	if (optarg) {
	    mExtSettings->mBounceBackBurst = atoi(optarg);
	    if (mExtSettings->mBounceBackBurst <= 0) {
		fprintf(stderr, "WARN: invalid bounceback value, setting it to 10\n");
		mExtSettings->mBounceBackBurst = 10;
	    }
	} else {
	    mExtSettings->mBounceBackBurst = -1;
	}
	break;

    case OPT_BOUNCEBACK_HOLD:
	if (optarg)
	    //cli units is ms, working units is us
	    mExtSettings->mBounceBackHold = int(atof(optarg) * 1e3);
	else
	    mExtSettings->mBounceBackHold = 0;
	break;

    case OPT_BOUNCEBACK_PERIOD:
	setPeriodicBurst(mExtSettings);
	if (optarg) {
	    float value = atof(optarg);
	    if (value  > 1e-5) { // limit to 10 usecs
		mExtSettings->mFPS = 1.0/atof(optarg);
	    } else {
		mExtSettings->mFPS = -1;
	    }
	}
	break;

    case OPT_BOUNCEBACK_REQUEST:
	if (optarg)
	    mExtSettings->mBounceBackBytes = byte_atoi(optarg);
	else
	    mExtSettings->mBounceBackBytes = 0;
	break;

    case OPT_BOUNCEBACK_REPLY:
	if (optarg)
	    mExtSettings->mBounceBackReplyBytes = byte_atoi(optarg);
	else
	    mExtSettings->mBounceBackReplyBytes = 0;
	break;

    case OPT_SET_RAND_SEED:
	setRandSeed(mExtSettings);
	mExtSettings->rand_seed = atoi(optarg);
	break;

    case OPT_SKIP_RX_COPY:
#if HAVE_DECL_MSG_TRUNC
	setSkipRxCopy(mExtSettings);
	setEnhanced(mExtSettings);
#endif
	break;

    case OPT_UDP_L4S:
#if !HAVE_UDP_L4S
	fprintf (stderr, "WARN: UDP L4S --udp-l4s not supported\n");
#else
	setUDP(mExtSettings);
	setUDPL4S(mExtSettings);
	setEnhanced(mExtSettings);
#endif
	break;

    case OPT_UDP_L4S_VIDEO:
#if !HAVE_UDP_L4S || 1
	fprintf (stderr, "WARN: UDP L4S --udp-l4s-video not supported\n");
#else
	setUDP(mExtSettings);
	setUDPL4S(mExtSettings);
	setUDPL4SVideo(mExtSettings);
#endif
	break;

    case OPT_WORKING_LOAD_TRANSPORT:
#ifdef HAVE_THREAD
	if (strcasecmp(optarg, "tcp") == 0) {
	    unsetWorkingLoadL4S(mExtSettings);  // explicit tcp, same as the (unset) default
	} else if (strcasecmp(optarg, "udp-l4s") == 0) {
	    setWorkingLoadL4S(mExtSettings);
	} else {
	    fprintf(stderr, "Unrecognized value of %s for --working-load-transport, use 'tcp' or 'udp-l4s'\n", optarg);
	}
	setEnhanced(mExtSettings);
#else
	fprintf(stderr, "--working-load-transport option requires a platform that supports threads\n");
#endif
	break;

    case OPT_DUAL_TRANSPORT:
#ifdef HAVE_THREAD
	setDualTransport(mExtSettings);
	// Assume -e (enhanced reporting) - the whole point of --dual-transport
	// is a technician watching two listener threads (this one plus the
	// auxiliary one on the adjacent port, see listeners_init/Launch.cpp)
	// come up, and the enhanced settings banner is what distinguishes
	// them clearly (port + pid + "(v6)" tagging per listener, see
	// reporter_output_listener_settings) instead of the plain banner's
	// bare port number alone.
	setEnhanced(mExtSettings);
#else
	fprintf(stderr, "--dual-transport option requires a platform that supports threads\n");
#endif
	break;

    default: // ignore unknown
	break;
    }
} // end Interpret


// See this function's own declaration/doc-comment in Settings.hpp for the
// overall design. --permit-key's original exposure (Listener::
// test_permit_key(), plain strncmp against a static shared secret sent in
// the clear) let anyone who captured one connection replay those exact
// bytes indefinitely (or for the life of --permit-key-timeout). HMAC mode
// doesn't need a new round trip (there is no server-hello before the
// client's first send on any path, TCP/UDP/bounceback alike, so a literal
// nonce challenge-response would require inventing one and would break
// every existing client) - instead the client authenticates a timestamp
// it already knows, bounding replay to whatever window the server
// configures (--permit-key-hmac-window) instead of leaving it unbounded.
// The wire slot itself (struct permitKey, payloads.h) is unchanged; only
// the string placed in it differs, self-describing via the "HMAC1:"
// prefix so a server can support both legacy and HMAC-mode clients at
// once with no separate mode flag of its own (Listener::test_permit_key()
// branches purely on this prefix).
void build_permit_key_wire_value(char *out, size_t outsize, const char *key, bool hmacMode) {
    if (!hmacMode) {
        strncpy(out, key, outsize - 1);
        out[outsize - 1] = '\0';
        return;
    }
    uint32_t ts = static_cast<uint32_t>(time(NULL));
    unsigned char ts_be[4] = {
        static_cast<unsigned char>(ts >> 24), static_cast<unsigned char>(ts >> 16),
        static_cast<unsigned char>(ts >> 8), static_cast<unsigned char>(ts),
    };
    unsigned char mac[SHA256_DIGEST_LENGTH];
    hmac_sha256(reinterpret_cast<const unsigned char *>(key), strlen(key), ts_be, sizeof(ts_be), mac);

    char machex[2 * SHA256_DIGEST_LENGTH + 1];
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        snprintf(machex + (i * 2), 3, "%02x", mac[i]);
    }
    snprintf(out, outsize, "HMAC1:%08x:%s", ts, machex);
}

static void generate_permit_key (struct thread_Settings *mExtSettings) {
    Timestamp now;
    mExtSettings->mPermitKeyTime.tv_sec = now.getSecs();
    mExtSettings->mPermitKeyTime.tv_usec = now.getUsecs();
    int usecs = mExtSettings->mPermitKeyTime.tv_usec;
    int timestrlength = snprintf(NULL, 0, "%ld.%06d-", static_cast<long>(mExtSettings->mPermitKeyTime.tv_sec), usecs);
    snprintf(mExtSettings->mPermitKey, (timestrlength+1), "%ld.%06d-", static_cast<long>(mExtSettings->mPermitKeyTime.tv_sec), usecs);
    srand(static_cast<unsigned int>(time(NULL)));
    int index;
    char characters[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for(index = timestrlength; index < (DEFAULT_PERMITKEY_LEN + timestrlength); index++) {
        int len = snprintf(mExtSettings->mPermitKey + index, sizeof(char) + 1, "%c", \
			   characters[rand() % (static_cast<int>(sizeof(characters)) - 1)]);
        FAIL_errno ((len < 0), "permit-key gen", mExtSettings);
    }
    mExtSettings->mPermitKey[DEFAULT_PERMITKEY_LEN + timestrlength] = '\0';
    if (strlen(mExtSettings->mPermitKey) > MAX_PERMITKEY_LEN) {
	fprintf(stderr, "ERROR: permit key too long\n");
	exit(1);
    }
}

static void strip_v6_brackets (char *v6addr) {
    char * results;
    if (v6addr && (*v6addr ==  '[') && ((results = strtok(v6addr, "]")) != NULL)) {
	int len = strlen(v6addr);
	for (int jx = 0; jx < len; jx++) {
	    v6addr[jx]= v6addr[jx + 1];
	}
    }
}

static char * isv6_bracketed_port (char *v6addr) {
    char *results = NULL;
    if (v6addr && (*v6addr ==  '[') && ((results = strtok(v6addr, "]")) != NULL)) {
	results = strtok(NULL, ":");
	strip_v6_brackets(v6addr);
	return results;
    }
    return NULL;
}
static char * isv4_port (char *v4addr) {
    char *results = NULL;
    if (((results = strtok(v4addr, ":")) != NULL) && ((results = strtok(NULL, ":")) != NULL)) {
	return results;
    }
    return NULL;
}


//  The commmand line options are position independent and hence some settings become "modal"
//  i.e. two passes are required to get all the final settings correct.
//  For example, -V indicates use IPv6 and -u indicates use UDP, and the default socket
//  read/write (UDP payload) size is different for ipv4 and ipv6.
//  So in the Settings_Interpret pass there is no guarantee to know all three of (-u and -V and not -l)
//  while parsing them individually.
//
//  Since Settings_Interpret() will set all the *individual* options and flags
//  then the below code (per the example UDP, v4 or v6, and not -l) can set final
//  values, e.g. a correct default mBufLen. Other examples that need this are multicast
//  socket or not,-B local bind port parsing, and when to use the default UDP offered load
//
//  Also apply the bail out or exit conditions if the user requested mutually exclusive
//  or incompatabile options
//
//  Settings_ModalOptions() is organized as a sequence of focused passes below,
//  run in order, each handling one concern.

// Pass: default read/write (-l) size for v4/v6, UDP/TCP, and the -p port range
static void ModalOptions_BufferAndPortDefaults (struct thread_Settings *mExtSettings) {
    if (!isBuflenSet(mExtSettings)) {
	if (isUDP(mExtSettings)) {
	    if (mExtSettings->mThreadMode == kMode_Client) {
		if (isIPV6(mExtSettings)) {
		    mExtSettings->mBufLen = kDefault_UDPTxBufLenV6;
		} else {
		    mExtSettings->mBufLen = kDefault_UDPTxBufLen;
		}
	    } else {
		mExtSettings->mBufLen = kDefault_UDPRxBufLen;
	    }
	} else {
	    if (isBounceBack(mExtSettings))
	        mExtSettings->mBufLen = kDefault_TCPBufLen;
	    else
	        mExtSettings->mBufLen = kDefault_TCPBufLen;
	}
    }
    if (!mExtSettings->mPortLast)
	mExtSettings->mPortLast = mExtSettings->mPort;

    if (isTripTime(mExtSettings) && (isReverse(mExtSettings) || \
				     isFullDuplex(mExtSettings) || \
				     (mExtSettings->mMode != kTest_Normal))) {
	setEnhanced(mExtSettings);
    }
}

// Pass (client only): infinite-time mode and the default UDP offered load/burst sizing
static void ModalOptions_ClientLoadDefaults (struct thread_Settings *mExtSettings) {
    if (mExtSettings->mThreadMode != kMode_Client)
	return;
    if (isModeTime(mExtSettings) && infinitetime) {
	unsetModeTime(mExtSettings);
	setModeInfinite(mExtSettings);
	fprintf(stderr, "WARNING: client will send traffic forever or until an external signal (e.g. SIGINT or SIGTERM) occurs to stop it\n");
    }
    // Handle default UDP offered load (TCP will be max, i.e. no read() or write() rate limiting).
    // Excludes BounceBack: it's a discrete request/reply probe, not a continuous rate/burst-paced
    // UDP stream, and has its own dedicated sizing (--bounceback-request/--bounceback-reply). Without
    // this guard, UDP bounceback (-u --bounceback) inherits FLAG_PERIODICBURST from
    // --bounceback-period's own option handler (OPT_BOUNCEBACK_PERIOD above - correct for TCP
    // bounceback's inter-request pacing, but this function also treats isPeriodicBurst as "wants a
    // UDP burst-size default"), which sets FLAG_BURSTSIZE below - Client::Run() checks isBurstSize()
    // before isBounceBack(), so that misroutes UDP bounceback into RunUDPBurst() and crashes (no
    // isochronous/FrameCounter setup was ever done for it).
    if (isUDP(mExtSettings) && !isBounceBack(mExtSettings)) {
	if (!isBWSet(mExtSettings)) {
	    if ((static_cast<int> (mExtSettings->mBurstSize) == 0) && !isPeriodicBurst(mExtSettings)) {
		mExtSettings->mAppRate = (isUDPL4S(mExtSettings) ? PRAGUE_MAXRATE : kDefault_UDPRate);
	    } else if ((static_cast<int> (mExtSettings->mBurstSize) == 0) && isPeriodicBurst(mExtSettings)) {
		mExtSettings->mBurstSize = byte_atoi("1M"); //default to 1 Mbyte
		setBurstSize(mExtSettings);
	    } else if ((static_cast<int> (mExtSettings->mBurstSize) != 0) && !isPeriodicBurst(mExtSettings)) {
		mExtSettings->mFPS = 1.0;
		setPeriodicBurst(mExtSettings);
	    }
	} else {
	    if ((mExtSettings->mAppRateUnits == kRate_PPS) && \
		((static_cast<int> (mExtSettings->mBurstSize) != 0) || isPeriodicBurst(mExtSettings))) {
		mExtSettings->mAppRateUnits = kRate_BW;
		mExtSettings->mAppRate = mExtSettings->mAppRate * mExtSettings->mBufLen * 8;
	    }
	    if ((static_cast<int> (mExtSettings->mBurstSize) == 0) && isPeriodicBurst(mExtSettings)) {
		mExtSettings->mBurstSize = static_cast <uint32_t> ((mExtSettings->mAppRate / 8) / mExtSettings->mFPS);
		setBurstSize(mExtSettings);
	    } else if ((static_cast<int> (mExtSettings->mBurstSize) != 0) && !isPeriodicBurst(mExtSettings)) {
		mExtSettings->mFPS = (static_cast<double>(mExtSettings->mAppRate / 8) /static_cast<double>(mExtSettings->mBurstSize));
		setPeriodicBurst(mExtSettings);
	    }
	}
//	    printf("**** fps = %f %f %f\n", mExtSettings->mFPS, static_cast<double> (mExtSettings->mAppRate), static_cast<double> (mExtSettings->mBurstSize));
    } else if (isBWSet(mExtSettings) && (mExtSettings->mAppRate <= 0)) {
	unsetBWSet(mExtSettings);
    }
}

static void ModalOptions_HideIPs (struct thread_Settings *mExtSettings) {
    if (isHideIPs(mExtSettings)) {
        mExtSettings->mHideHost = dupstr("(**hidden**)");
    }
}

// Pass: bail-out checks that apply regardless of client/server mode.
// Returns true if a fatal incompatible option combination was found.
static bool ModalOptions_CommonBailChecks (struct thread_Settings *mExtSettings) {
    bool bail = false;
    // compat mode doesn't support these test settings
    int compat_nosupport = (isReverse(mExtSettings) | isFullDuplex(mExtSettings) | isTripTime(mExtSettings) | isVaryLoad(mExtSettings) \
			    | isHistogram(mExtSettings) |  isIsochronous(mExtSettings) \
			    | isEnhanced(mExtSettings) | (mExtSettings->mMode != kTest_Normal));
    if (isCompat(mExtSettings) && compat_nosupport) {
	fprintf(stderr, "ERROR: compatibility mode not supported with the requested with options\n");
	bail = true;
    }
    if (isPermitKey(mExtSettings)) {
#if !HAVE_PROFESSIONAL
	// --permit-key/--permit-key-timeout/--permit-key-file all set this
	// same flag (see setPermitKey() call sites) - one check here covers
	// every entry point. Only the *server* side is restricted in
	// community edition: enforcing/gating access is the paid capability
	// (a community server silently accepting every connection despite
	// the operator believing it's key-gated would be a real security
	// regression, not just a missing nice-to-have - hence a hard ERROR
	// here rather than the WARN-and-fall-back pattern used for other
	// professional-only options). A community *client* sending a key
	// it was simply handed is harmless and shouldn't be blocked - the
	// whole point is letting a free client reach someone else's paid,
	// key-gated server, so only bail when this is the server side.
	if (mExtSettings->mThreadMode != kMode_Client) {
	    fprintf(stderr, "ERROR: --permit-key requires the professional edition\n");
	    bail = true;
	    if (isUDP(mExtSettings)) {
		fprintf(stderr, "ERROR: Option of --permit-key not supported with UDP in the community edition\n");
	    }
	}
#endif
	if (mExtSettings->mPermitKey[0] != '\0') {
	    int keylen = strnlen(mExtSettings->mPermitKey, MAX_PERMITKEY_LEN + 1);
	    if (keylen < MIN_PERMITKEY_LEN) {
		fprintf(stderr, "ERROR: value for --permit-key must have at least %d characters\n", MIN_PERMITKEY_LEN);
		bail = true;
	    } else if (keylen > MAX_PERMITKEY_LEN) {
		fprintf(stderr, "ERROR: value for --permit-key can't be more than %d characters \n", MAX_PERMITKEY_LEN);
		bail = true;
	    }
	}
    }
#if !HAVE_IPV6
    if (isIPV6(mExtSettings)) {
	fprintf(stderr, "ERROR: ipv6 not supported\n");
	bail = true;
    }
#endif
    if (isIPV4(mExtSettings) && isIPV6(mExtSettings)) {
	fprintf(stderr, "WARN: both ipv4 and ipv6 set\n");
	unsetIPV6(mExtSettings);
	unsetIPV4(mExtSettings);
    }
    return bail;
}

// Pass (client only): client-side validation and defaulting. Returns true to bail.
static bool ModalOptions_ClientBailChecks (struct thread_Settings *mExtSettings) {
    bool bail = false;
    {
	if (isRemoveService(mExtSettings)) {
	    // -R on the client is overloaded and is the
	    // short option for --reverse, fix it now
	    setReverse(mExtSettings);
	    unsetRemoveService(mExtSettings);
	}
	if (isIncrSrcIP(mExtSettings) && (mExtSettings->mLocalhost==NULL)) {
	    fprintf(stderr, "ERROR: option of --incr-srcip requires -B bind option to be set\n");
	    bail = true;
	}
	if (isSumServerDstIP(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --sum-dstip not supported on the client\n");
	}
	if (isOverrideTOS(mExtSettings)) {
	    unsetOverrideTOS(mExtSettings);
	    fprintf(stderr, "WARN: option of --tos-override not supported on the client\n");
	}
	if (isRxClamp(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --tcp-rx-window-clamp not supported on the client\n");
	    unsetRxClamp(mExtSettings);
	}
	if (isJitterHistogram(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --jitter-histogram not supported on the client\n");
	    unsetJitterHistogram(mExtSettings);
	}
	if (isDualTransport(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --dual-transport not supported on the client\n");
	    unsetDualTransport(mExtSettings);
	}
	if (isUDP(mExtSettings) && isHistogram(mExtSettings) && !isTripTime(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --histograms for UDP requires --trip-times on the client\n");
	    unsetHistogram(mExtSettings);
	}
#if !HAVE_PROFESSIONAL
	if (isHistogram(mExtSettings) && isTripTime(mExtSettings)) {
	    if (isUDP(mExtSettings)) {
		fprintf(stderr, "WARN: option of --histograms for UDP requires the professional edition\n");
		unsetHistogram(mExtSettings);
	    } else {
		fprintf(stderr, "WARN: option of --histograms with --trip-times to also build a server-side "
				"latency histogram requires the professional edition\n");
		// not unset here: --tcp-write-times/--tcp-write-prefetch client-local
		// histograms remain available in the community edition
	    }
	}
#endif
	// else (professional, isHistogram && isTripTime): left set, signaled to
	// the peer over the wire so it builds a server-side latency histogram
	// (UDP rx latency, or TCP frame-latency)
	if (isPeriodicBurst(mExtSettings)) {
	    setEnhanced(mExtSettings);
	    setFrameInterval(mExtSettings);
	}
        if (mExtSettings->mTTL > MAXTTL) {
	    fprintf(stderr, "ERROR: option of -ttl (-T) must be less than %d\n", MAXTTL);
	    bail = true;
	}
	if (isPermitKey(mExtSettings) && (mExtSettings->mPermitKey[0] == '\0') && !mExtSettings->mPermitKeyFile) {
	    fprintf(stderr, "ERROR: option of --permit-key requires a value on the client\n");
	    bail = true;
	}
	if (mExtSettings->mPermitKeyFile) {
	    fprintf(stderr, "ERROR: option of --permit-key-file is not supported on the client\n");
	    bail = true;
	}
	if (isPermitKeyHmac(mExtSettings) && (mExtSettings->mPermitKey[0] == '\0')) {
	    fprintf(stderr, "WARN: option of --permit-key-hmac requires --permit-key with a value, ignoring\n");
	    unsetPermitKeyHmac(mExtSettings);
	}
	if (mExtSettings->mPermitKeyVendorId) {
	    fprintf(stderr, "WARN: option of --permit-key-vendor-id is not applicable on the client, ignoring\n");
	    mExtSettings->mPermitKeyVendorId = NULL;
	}
#if (HAVE_DECL_SO_MAX_PACING_RATE)
	if (isFQPacingStep(mExtSettings)) {
	    if (!isFQPacing(mExtSettings)) {
		setFQPacing(mExtSettings);
		mExtSettings->mFQPacingRate = mExtSettings->mFQPacingRateStep;
	    }
	    if (!isFQPacingStepInterval(mExtSettings)) {
		mExtSettings->mFQPacingRateStepInterval = 1.0;
	    }
	}
#endif
	if (!isUDP(mExtSettings) && isTxHoldback(mExtSettings) && isTxStartTime(mExtSettings)) {
	    fprintf(stderr,"ERROR: options of --txstart-time and --txdelay-time are mutually exclusive\n");
	    bail = true;
	} else if (isTxStartTime(mExtSettings) || isTxHoldback(mExtSettings)) {
	    Timestamp now;
	    if (isTxStartTime(mExtSettings)) {
		if (mExtSettings->txstart_epoch.tv_sec < 0) {
		    fprintf(stderr, "ERROR: --txstart-time must be a positive value\n");
		    unsetTxStartTime(mExtSettings);
		    bail = true;
		} else if ((mExtSettings->txstart_epoch.tv_sec - now.getSecs()) > MAXDIFFTXSTART) {
		    char timestr[120];
		    struct timeval t;
		    t.tv_sec = now.getSecs();
		    t.tv_usec = now.getUsecs();
		    iperf_formattime(timestr, sizeof(timestr), t, (isEnhanced(mExtSettings) ? Milliseconds : Seconds), isUTC(mExtSettings), YearThruSecTZ);
		    printf(error_starttime_exceeds, mExtSettings->txstart_epoch.tv_sec, mExtSettings->txstart_epoch.tv_usec, \
			  timestr, MAXDIFFTXSTART);
		    bail = true;
		}
	    } else if (mExtSettings->txholdback_timer.tv_sec > MAXDIFFTXDELAY) {
		printf(error_delaytime_exceeds, mExtSettings->txholdback_timer.tv_sec, MAXDIFFTXDELAY);
		bail = true;
	    }
	}
	if (isTripTime(mExtSettings)) {
	    int minsize = static_cast<int> (isUDP(mExtSettings) ? (sizeof(struct UDP_datagram)) : (sizeof(struct TCP_burst_payload)));
	    if (mExtSettings->mBufLen < minsize) {
	        fprintf(stderr, "ERROR: payload (-l) size of %d too small for --trip-times, must be %d or greater\n", \
			mExtSettings->mBufLen, minsize);
		bail = true;
	    }
	}
	if (isBounceBack(mExtSettings)) {
	    if (static_cast<int> (mExtSettings->mBurstSize) > 0) {
		fprintf(stderr, "WARN: options of --burst-size for bounce-back ignored, use -l sets size\n");
	    }
	    if (mExtSettings->mBounceBackBytes <= 0) {
		if (isBuflenSet(mExtSettings)) {
		    // Backward compatibility with older versions
		    mExtSettings->mBounceBackBytes = mExtSettings->mBufLen;
		} else {
		    mExtSettings->mBounceBackBytes = kDefault_BBTCPReqLen;
		}
	    } else if (mExtSettings->mBounceBackBytes > mExtSettings->mBufLen) {
		if (isBuflenSet(mExtSettings)) {
		    mExtSettings->mBounceBackBytes = mExtSettings->mBufLen;
		    fprintf(stderr, "WARN: bounceback request will use -l length and not --bounceback-request value\n");
		} else {
		    mExtSettings->mBufLen = mExtSettings->mBounceBackBytes;
		}
	    }
	    if (mExtSettings->mBounceBackReplyBytes <= 0) {
		mExtSettings->mBounceBackReplyBytes = mExtSettings->mBounceBackBytes;
	    } else if (mExtSettings->mBounceBackReplyBytes > mExtSettings->mBufLen) {
		if (isBuflenSet(mExtSettings)) {
		    mExtSettings->mBounceBackReplyBytes = mExtSettings->mBufLen;
		    fprintf(stderr, "WARN: bounceback reply will use -l length and not --bounceback-reply value\n");
		} else {
		    mExtSettings->mBufLen = mExtSettings->mBounceBackReplyBytes;
		}
	    }
	    mExtSettings->mBurstSize = mExtSettings->mBufLen;
#if HAVE_DECL_TCP_QUICKACK
	    // TCP_QUICKACK is a TCP-only socket option - guard against -u UDP
	    // bounceback (see the HAVE_UDP_L4S isBounceBack+isUDP handling
	    // below) so this default-setting block doesn't wrongly turn on
	    // isTcpQuickAck for a UDP run, which would otherwise hit the
	    // mismatched WARN/unset path further down (isUDP() section).
	    if (!isUDP(mExtSettings)) {
		if (notcpbbquickack_cliset && isTcpQuickAck(mExtSettings)) {
		    fprintf(stderr, "ERROR: --tcp-quickack and --bounceback-no-quickack are mutually exclusive\n");
		    bail = true;
		}
		// be wary of double negatives here
		if (!notcpbbquickack_cliset) {
		    setTcpQuickAck(mExtSettings);
		}
	    }
#endif
	    // default bounceback period to 1 second
	    if (!isPeriodicBurst(mExtSettings)) {
		mExtSettings->mFPS = 1.0;
		setPeriodicBurst(mExtSettings);
		if (mExtSettings->mIntervalMode == kInterval_None) {
		    mExtSettings->mIntervalMode = kInterval_Time;
		    mExtSettings->mInterval = 1000000; // units is us
		}
	    } else if (mExtSettings->mFPS <= 1e-5) {
		unsetPeriodicBurst(mExtSettings);
	    }
	    if (isPeriodicBurst(mExtSettings) && (mExtSettings->mBounceBackBurst == -1))  {
		mExtSettings->mBounceBackBurst = 10;
	    }
	}
#if HAVE_DECL_TCP_NOTSENT_LOWAT
	if (!isUDP(mExtSettings) && isWritePrefetch(mExtSettings) &&
	    (isTcpWriteTimes(mExtSettings) || isTripTime(mExtSettings))) {
	    if (mExtSettings->mWritePrefetch <= 0) {
		unsetWritePrefetch(mExtSettings);
	    }
	}
#endif
	if (isPeriodicBurst(mExtSettings)) {
	    if (isIsochronous(mExtSettings)) {
		fprintf(stderr, "ERROR: options of --burst-period and --isochronous cannot be applied together\n");
		bail = true;
	    } else if (isNearCongest(mExtSettings)) {
		fprintf(stderr, "ERROR: options of --burst-period and --near-congestion cannot be applied together\n");
		bail = true;
	    }
	    if (static_cast<int> (mExtSettings->mBurstSize) < mExtSettings->mBufLen) {
		fprintf(stderr, "ERROR: option of --burst-size %d must be equal or larger to write length (-l) %d\n", mExtSettings->mBurstSize, mExtSettings->mBufLen);
		bail = true;
	    }
	}
	if ((mExtSettings->connect_retry_time > 0) && !mExtSettings->connect_retry_timer) {
	    fprintf(stderr, "WARN: companion option of --connect-retry-timer not set - setting to default value of one second\n");
	    mExtSettings->connect_retry_timer = 1000000; // 1 sec in units usecs
	}
	if ((mExtSettings->connect_retry_timer > 0) && (mExtSettings->connect_retry_time <= 0)) {
	    fprintf(stderr, "WARN: companion option of --connect-retry-time not set - setting to default value of ten seconds\n");
	    mExtSettings->connect_retry_time = 10;
	}
	if (isUDP(mExtSettings)) {
	    if (isPeerVerDetect(mExtSettings)) {
		fprintf(stderr, "ERROR: option of -X or --peer-detect not supported with -u UDP\n");
		bail = true;
	    }
	    if (isConnectOnly(mExtSettings)) {
		fprintf(stderr, "ERROR: option of --connect-only not supported with -u UDP\n");
		bail = true;
	    }
	    if (isBounceBack(mExtSettings)) {
#if HAVE_UDP_L4S
		// UDP bounceback rides the UDP-L4S transport (vanilla ECT(1)/CE
		// marking, see struct bounceback_udp_hdr) rather than being
		// rejected outright - but --tcp-cca is a TCP-only concept
		// (there's no TCP_CONGESTION socket option on a UDP socket), so
		// warn and drop it instead of silently ignoring it.
		if (isCongestionControl(mExtSettings)) {
		    fprintf(stderr, "WARN: option of --cca not supported with -u UDP bounceback, ignoring\n");
		    unsetCongestionControl(mExtSettings);
		    // Also clear the string itself, not just the flag - otherwise
		    // the settings-report banner (ReportOutputs.c's isEnhanced()-
		    // gated CCA print, which doesn't re-check isCongestionControl())
		    // would still echo the now-ignored name back as if it had
		    // actually been applied.
		    DELETE_ARRAY(mExtSettings->mCongestion);
		}
		// UDP bounceback's own per-request HEADER_BBSTOP flag
		// (Client::WriteUdpTxBBHdr/RunBounceBackUDP) is its explicit
		// end-of-test signal - skip the generic continuous-UDP-stream
		// negative-packetID fin handshake (FinishTrafficActions/
		// AwaitServerFinPacket) entirely, since Server::RunBounceBackUDP
		// never answers it (same as the TCP bounceback server never
		// engages TCP's own analogous mechanism).
		setNoUDPfin(mExtSettings);
#else
		fprintf(stderr, "ERROR: option of -X or --bounceback not supported with -u UDP\n");
		bail = true;
#endif
	    }
	    if (isNearCongest(mExtSettings)) {
		fprintf(stderr, "ERROR: option of --near-congestion not supported with -u UDP\n");
		bail = true;
	    }
#if HAVE_UDP_L4S
	    // --tcp-cca doubles as the UDP-L4S CCA selector once --udp-l4s is
	    // set - there's no reason to bind the CCA choice to a transport-
	    // specific flag name when --udp-l4s already tracks the transport
	    // independently, so its value ("prague"/"reno") is reinterpreted
	    // here (order-independent, post-parse, since --udp-l4s may appear
	    // after --tcp-cca on the command line) instead of being applied as
	    // a TCP_CONGESTION sockopt name. isCongestionControl/mCongestion
	    // are explicitly cleared afterward - not just left set with a
	    // "prague"/"reno" string - since both feed several TCP-specific
	    // paths that would otherwise misinterpret it: the wire relay to
	    // the server (HEADER_CCA, a few hundred lines down), the
	    // settings-report banner, and Reports.c's connected_cca field.
	    // Same "clear the string, not just the flag" precedent already
	    // used a few lines up for UDP bounceback's own --tcp-cca rejection.
	    if (isUDPL4S(mExtSettings) && isCongestionControl(mExtSettings) && mExtSettings->mCongestion) {
		if (strcasecmp(mExtSettings->mCongestion, "reno") == 0) {
		    setUDPL4SCcaReno(mExtSettings);
		} else if (strcasecmp(mExtSettings->mCongestion, "prague") == 0) {
		    unsetUDPL4SCcaReno(mExtSettings);  // explicit prague, same as the (unset) default
		} else {
		    fprintf(stderr, "Unrecognized value of %s for --cca under --udp-l4s, use 'prague' or 'reno'\n",
			    mExtSettings->mCongestion);
		}
		unsetCongestionControl(mExtSettings);
		DELETE_ARRAY(mExtSettings->mCongestion);
	    }
	    // Same dual interpretation for --working-load-cca under
	    // --working-load-transport udp-l4s - the working-load stream's own,
	    // independent Prague/Reno choice (see FLAG_WORKING_LOAD_L4S_CCA_
	    // RENO's own doc comment, Settings.hpp), not the main flow's.
	    if (isWorkingLoadL4S(mExtSettings) && isLoadCCA(mExtSettings) && mExtSettings->mLoadCCA) {
		if (strcasecmp(mExtSettings->mLoadCCA, "reno") == 0) {
		    setWorkingLoadL4SCcaReno(mExtSettings);
		} else if (strcasecmp(mExtSettings->mLoadCCA, "prague") == 0) {
		    unsetWorkingLoadL4SCcaReno(mExtSettings);
		} else {
		    fprintf(stderr, "Unrecognized value of %s for --working-load-cca when --working-load-transport is udp-l4s, use 'prague' or 'reno'\n",
			    mExtSettings->mLoadCCA);
		}
		unsetLoadCCA(mExtSettings);
		DELETE_ARRAY(mExtSettings->mLoadCCA);
	    }
#endif
	    if (isIPG(mExtSettings) && isBWSet(mExtSettings)) {
		fprintf(stderr, "ERROR: options of --b and --ipg cannot be applied together\n");
		bail = true;
	    }
	    if (mExtSettings->mBurstIPG < 0.0) {
		fprintf(stderr, "ERROR: option --ipg must be a positive value\n");
		bail = true;
	    }
	    if (mExtSettings->connect_retry_timer > 0) {
		fprintf(stderr, "ERROR: option --connect-retries not supported with -u UDP\n");
		bail = true;
	    }
	    if (isWritePrefetch(mExtSettings)) {
		fprintf(stderr, "WARN: setting of option --tcp-write-prefetch is not supported with -u UDP\n");
		unsetWritePrefetch(mExtSettings);
	    }
	    if (isTcpQuickAck(mExtSettings)) {
		fprintf(stderr, "WARN: setting of option --tcp-quickack is not supported with -u UDP\n");
		unsetWritePrefetch(mExtSettings);
	    }
	    {
		double delay_target;
		if (isIPG(mExtSettings)) {
		    delay_target = ((mExtSettings->mBurstIPG > 0) ?  mExtSettings->mBurstIPG * 1e9 : 0);  // convert from seconds to nanoseconds
		} else {
		    // compute delay target in units of nanoseconds
		    if (mExtSettings->mAppRateUnits == kRate_BW) {
			// compute delay for bandwidth restriction, constrained to [0,max] seconds
			delay_target = ((mExtSettings->mAppRate > 0) ? ((mExtSettings->mBufLen * 8e9) / mExtSettings->mAppRate) : 0);
		    } else {
			delay_target = ((mExtSettings->mAppRate > 0) ? (1e9 / mExtSettings->mAppRate) : 0);
		    }
		}
		if (delay_target < 0  ||
		    delay_target > MAXIPGSECS * 1e9) {
		    fprintf(stderr, "ERROR: IPG delay target of %.1f secs too large (max value is %d secs)\n", (delay_target / 1e9), MAXIPGSECS);
		    bail = true;
		}
	    }
	    if (isTripTime(mExtSettings)) {
		if (mExtSettings->mBufLen < MINTRIPTIMEPAYLOAD) {
		    if (isReverse(mExtSettings) || isFullDuplex(mExtSettings) || (mExtSettings->mMode != kTest_Normal)) {
			fprintf(stderr, "ERROR: payload (-l) size of %d too small for --trip-times, must be %d or greater\n", mExtSettings->mBufLen, MINTRIPTIMEPAYLOAD);
			bail = true;
		    } else {
			setSmallTripTime(mExtSettings);
		    }
		}
	    }
	} else {
	    if ((mExtSettings->mAppRate > 0) && isNearCongest(mExtSettings)) {
		fprintf(stderr, "ERROR: option of --near-congestion and -b rate limited are mutually exclusive\n");
		bail = true;
	    }
	    if (isBWSet(mExtSettings) && !(mExtSettings->mAppRateUnits == kRate_PPS) \
		&& ((mExtSettings->mAppRate / 8) < static_cast<uintmax_t>(mExtSettings->mBufLen))) {
		fprintf(stderr, "ERROR: option -b and -l of %d are incompatible, consider setting -l to %d or lower\n", \
			mExtSettings->mBufLen, static_cast<int>(mExtSettings->mAppRate / 8));
		bail = true;
	    }
	    if (isIPG(mExtSettings)) {
		fprintf(stderr, "ERROR: option --ipg requires -u UDP\n");
		bail = true;
	    }
	    if (isNoUDPfin(mExtSettings)) {
		fprintf(stderr, "ERROR: option --no-udp-fin requires -u UDP\n");
		bail = true;
	    }
	    if (isTxHoldback(mExtSettings) && isConnectOnly(mExtSettings)) {
		fprintf(stderr,"ERROR: Fail because --txdelay-time and --connect-only cannot be applied together\n");
		bail = true;			;
	    }
	    if (mExtSettings->mAppRateUnits == kRate_PPS) {
		fprintf(stderr, "ERROR: units of pps not supported with TCP\n");
		bail = true;
	    }
	    if (!isUDP(mExtSettings) && isUDPL4S(mExtSettings) && (mExtSettings->mThreadMode == kMode_Client)) {
		fprintf(stderr, "ERROR: UDP L4S not supported with TCP\n");
		bail = true;
	    }
	    if (isJitterHistogram(mExtSettings)) {
		fprintf(stderr, "ERROR: option of --jitter-histogram not supported with TCP\n");
		bail = true;
	    }
	}
	if (!isReverse(mExtSettings) && !isFullDuplex(mExtSettings) && isHistogram(mExtSettings)){
	    setTcpWriteTimes(mExtSettings);
	    mExtSettings->mHistBins = 100000; // 10 seconds wide
	    mExtSettings->mHistBinsize = 100; // 100 usec bins
	    mExtSettings->mHistUnits = 6;  // usecs 10 pow(x)
	    mExtSettings->mHistci_lower = 5;
	    mExtSettings->mHistci_upper = 95;
	}
	{
	    int one_only = 0;
	    if (isFullDuplex(mExtSettings))
		one_only++;
	    if (isReverse(mExtSettings))
		one_only++;
	    if (mExtSettings->mMode != kTest_Normal)
		one_only++;
	    if (one_only > 1) {
		fprintf(stderr, "ERROR: options of --full-duplex, --reverse, -d and -r are mutually exclusive\n");
		bail = true;
	    }
	}
	if (isBWSet(mExtSettings) && isIsochronous(mExtSettings)) {
	    fprintf(stderr, "ERROR: options of --b and --isochronous cannot be applied together\n");
	    bail = true;
	}
    }
    return bail;
}

// Pass (server only): server-side validation/warnings for client-only options. Returns true to bail.
static bool ModalOptions_ServerBailChecks (struct thread_Settings *mExtSettings) {
    bool bail = false;
    {
	if (mExtSettings->mPortLast && (!(mExtSettings->mPortLast >= mExtSettings->mPort))) {
            fprintf(stderr, "ERROR: invalid port range of %d-%d\n",mExtSettings->mPort, mExtSettings->mPortLast);
	    bail = true;
	}
	if (isPermitKey(mExtSettings)) {
	    // Only auto-generate a random inline key when nothing else was
	    // configured to gate connections - a --permit-key-file-only
	    // server is intentionally relying solely on that file's list, and
	    // an extra unrequested random key would just be surprising noise.
	    if ((mExtSettings->mPermitKey[0] == '\0') && !mExtSettings->mPermitKeyFile) {
		generate_permit_key(mExtSettings);
	    }
	    if (mExtSettings->mListenerTimeout < 0) {
		mExtSettings->mListenerTimeout = DEFAULT_PERMITKEY_LIFE;
	    }
	}
	if (isPermitKeyHmac(mExtSettings)) {
	    // --permit-key-hmac is purely a client-side opt-in (it controls
	    // what the client sends). The server verifies HMAC1-format
	    // values unconditionally whenever one is presented, regardless
	    // of this flag - see Listener::test_permit_key().
	    fprintf(stderr, "WARN: option of --permit-key-hmac is not applicable on the server\n");
	    unsetPermitKeyHmac(mExtSettings);
	}
	// isWorkingLoadL4S deliberately isn't rejected alongside the other
	// working-load sub-options below - unlike thread count/direction
	// imbalance (pure client-side tuning the server doesn't need to
	// know), the server genuinely needs this flag ahead of time to
	// pre-bind a UDP listening socket for the working-load stream
	// (listeners_init, Launch.cpp) - sockets must be bound before any
	// packet can arrive, there's no TCP-style dynamic accept() for UDP.
	// Same reasoning as why plain -u itself isn't rejected here either,
	// even though --udp-l4s specifically is (a few lines below) - the
	// server only needs to know "bind UDP", the L4S/Prague/Reno
	// specifics are negotiated per-connection off that connection's own
	// wire handshake, not the listener's own static settings.
	if ((mExtSettings->mWorkingLoadThreads > 0) || (!isWorkingLoadUp(mExtSettings) && isWorkingLoadDown(mExtSettings)) \
	    || (isWorkingLoadUp(mExtSettings) && !isWorkingLoadDown(mExtSettings))) {
	    fprintf(stderr, "ERROR: setting of --working-load options is not supported on the server, just use --working-load\n");
	    bail = true;
	}
        if (isBounceBack(mExtSettings)) {
            fprintf(stderr, "ERROR: setting of option --bounce-back is not supported on the server\n");
	    bail = true;
	}
        if (isTripTime(mExtSettings)) {
            fprintf(stderr, "WARN: setting of option --trip-times is not supported on the server\n");
	}
        if (isWritePrefetch(mExtSettings)) {
            fprintf(stderr, "WARN: setting of option --tcp-write-prefetch is not supported on the server\n");
	    unsetWritePrefetch(mExtSettings);
	}
        if (isIncrSrcIP(mExtSettings)) {
            fprintf(stderr, "WARN: setting of option --incr-srcip is not supported on the server\n");
	}
	if (isVaryLoad(mExtSettings)) {
	    fprintf(stderr, "WARN: option of variance per -b is not supported on the server\n");
	}
	if (isTxStartTime(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --txstart-time is not supported on the server\n");
	}
	if (isTxHoldback(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --txdelay-time is not supported on the server\n");
	}
	if (isIPG(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --ipg is not supported on the server\n");
	}
	if (isIsochronous(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --isochronous is not supported on the server\n");
	}
	if (isFullDuplex(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --full-duplex is not supported on the server\n");
	}
	if (isReverse(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --reverse is not supported on the server\n");
	}
	if (isIncrDstIP(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --incr-dstip is not supported on the server\n");
	}
	if (isIgnoreShutdown(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --ignore-shutdown is not supported on the server\n");
	}
	if (isFQPacing(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --fq-rate is not supported on the server\n");
	}
	if (isNoUDPfin(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --no-udp-fin is not supported on the server\n");
	}
	if (isPeerVerDetect(mExtSettings)) {
	    fprintf(stderr, "WARN: option of -X or --peer-detect not supported on the server\n");
	}
	if (mExtSettings->connect_retry_timer > 0) {
	    fprintf(stderr, "WARN: option --connect-retries not supported on the server\n");
	}
	if (isNearCongest(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --near-congestion not supported on the server\n");
	}
	if (isSyncTransferID(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --sync-transfer-id is not supported on the server\n");
	}
	if (isPeriodicBurst(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --burst-period can only be set on the client\n");
	}
	if (mExtSettings->mBurstSize != 0) {
	    fprintf(stderr, "WARN: option of --burst-size not supported on the server\n");
	}
#if HAVE_UDP_L4S
	// --udp-l4s is rejected on the server, not silently accepted as a
	// convenience alias for -u: L4S negotiation is entirely per-connection,
	// dynamic, off the *client's* own header (apply_client_settings_udp,
	// Listener.cpp) - the listener's own isUDPL4S flag is never read for
	// dispatch, only cosmetic startup-banner tagging. A -u server already
	// accepts L4S *and* plain UDP clients equally (whichever a given
	// connection's own header asks for); if --udp-l4s were silently
	// accepted here, a technician could easily read that as "this server
	// only serves L4S flows now, non-L4S UDP clients won't connect" -
	// which is wrong. Rejecting it outright, with a message that says so
	// explicitly, heads that misconception off instead of leaving it to
	// only be discovered by trial and error.
	if (isUDPL4S(mExtSettings)) {
	    fprintf(stderr, "WARN: option of --udp-l4s not supported on the server, use plain -u instead - "
			     "a -u server already serves both L4S and non-L4S UDP clients "
			     "(negotiated per-connection from each client's own request), ignoring\n");
	    unsetUDPL4S(mExtSettings);
	    setUDP(mExtSettings);  // still bind a UDP socket, same as -u would
	}
	// No separate isUDPL4SCcaReno/isWorkingLoadL4SCcaReno check here -
	// --cca/--working-load-cca's prague/reno reinterpretation only runs in
	// ModalOptions_ClientBailChecks (see that function's own comment),
	// gated on mThreadMode == kMode_Client, so neither flag can ever
	// actually be set on a server in the first place.
#endif
	if (isUDP(mExtSettings)) {
	    if (isRxClamp(mExtSettings)) {
		fprintf(stderr, "WARN: option of --tcp-rx-window-clamp not supported using -u UDP \n");
		unsetRxClamp(mExtSettings);
	    }
	    if (isSkipRxCopy(mExtSettings)) {
		fprintf(stderr, "WARN: Option of --skip-rx-copy not supported with -u UDP\n");
		unsetSkipRxCopy(mExtSettings);
	    }
	}
    }
    return bail;
}

// Pass: bail-out checks that apply regardless of client/server mode, run after the
// per-mode passes above. Returns true to bail.
static bool ModalOptions_FinalBailChecks (struct thread_Settings *mExtSettings) {
    bool bail = false;
    if (isUDP(mExtSettings) && isOmit(mExtSettings)) {
	fprintf(stderr, "ERROR: option of --omit not supported with -u UDP\n");
	bail = true;
    }
    if (!isUDP(mExtSettings) && mExtSettings->mBraKetGraph) {
	fprintf(stderr, "ERROR: length markov chains only supported with -u UDP\n");
	bail = true;
    }
    return bail;
}

// Pass: histogram bin/CI defaults, either built-in or parsed from the --histograms argument
static void ModalOptions_HistogramDefaults (struct thread_Settings *mExtSettings) {
    char *results;
    if (isHistogram(mExtSettings)) {
	if (!mExtSettings->mHistogramStr) {
	    if (mExtSettings->mThreadMode == kMode_Server) {
		// set default rx histogram settings, milliseconds bins between 0 and 10 secs
		mExtSettings->mHistBins = 10000;
		mExtSettings->mHistBinsize = 1;
		mExtSettings->mHistUnits = 3;
		mExtSettings->mHistci_lower = 5;
		mExtSettings->mHistci_upper = 95;
	    } else {
		// set default tx histogram settings, microseconds with 100 us bins
		mExtSettings->mHistBins = 100000;
		mExtSettings->mHistBinsize = 100;
		mExtSettings->mHistUnits = 6;
		mExtSettings->mHistci_lower = 5;
		mExtSettings->mHistci_upper = 95;
	    }
	} else {
	    // check for optional arguments to change histogram settings
	    if (((results = strtok(mExtSettings->mHistogramStr, ",")) != NULL) && !strcmp(results,mExtSettings->mHistogramStr)) {
		// scan for unit specifier
		char *tmp = new char [strlen(results) + 1];
		strcpy(tmp, results);
		if ((strtok(tmp, "u") != NULL) && strcmp(results,tmp) != 0) {
		    mExtSettings->mHistUnits = 6;  // units is microseconds
		} else {
		    strcpy(tmp, results);
		    if ((strtok(tmp, "m") != NULL) && strcmp(results,tmp) != 0) {
			mExtSettings->mHistUnits = 3;  // units is milliseconds
		    }
		}
		mExtSettings->mHistBinsize = atoi(tmp);
		delete [] tmp;
		mExtSettings->mHistci_lower = 5;
		mExtSettings->mHistci_upper = 95;
		if ((results = strtok(results+strlen(results)+1, ",")) != NULL) {
		    mExtSettings->mHistBins = byte_atoi(results);
		    if ((results = strtok(NULL, ",")) != NULL) {
			mExtSettings->mHistci_lower = atof(results);
			if ((results = strtok(NULL, ",")) != NULL) {
			    mExtSettings->mHistci_upper = atof(results);
			}
		    }
		} else {
		  mExtSettings->mHistBins = 100000;
		}
	    }
	}
    }
}

// Pass: UDP-only deferred L2 length-check request (--l2checks, see comment at its
// declaration), no-fin-on-fullduplex, and TCP burst-size reconciliation with -l
static void ModalOptions_L2AndBurstSize (struct thread_Settings *mExtSettings) {
    // Consume the deferred --l2checks request exactly once per parse, regardless of
    // which branch below runs, so it can't survive (e.g. TCP, or server mode) into a
    // later Settings_ParseCommandLine() call in the same process.
    int requested_l2checks = l2checks;
    l2checks = 0;

    if (isUDP(mExtSettings)) {
	if (isFullDuplex(mExtSettings)) {
	    setNoUDPfin(mExtSettings);
	}
	if (mExtSettings->mThreadMode == kMode_Client) {
	    // L2 settings
	    if (requested_l2checks) {
#if defined(HAVE_LINUX_FILTER_H) && defined(HAVE_AF_PACKET)
		// Request server to do length checks
		setL2LengthCheck(mExtSettings);
#else
		fprintf(stderr, "WARNING: option --l2checks not supported on this platform\n");
#endif
	    }
	}
    } else {
	if (mExtSettings->mBurstSize && (static_cast<int>(mExtSettings->mBurstSize) < mExtSettings->mBufLen)) {
	    fprintf(stderr, "WARN: Setting --burst-size to %d because value given is smaller than -l value\n", \
		    mExtSettings->mBufLen);
	    mExtSettings->mBurstSize = mExtSettings->mBufLen;
	} else if (isTripTime(mExtSettings) && !(mExtSettings->mBurstSize > 0)) {
	    mExtSettings->mBurstSize = mExtSettings->mBufLen;
	}
    }
}

// Pass (client only): parse the --isochronous <fps>:<mean>,<variance> argument string
static void ModalOptions_IsochronousString (struct thread_Settings *mExtSettings) {
    char *results;
    if (isIsochronous(mExtSettings) && mExtSettings->mIsochronousStr) {
	// parse client isochronous field,
	// format is --isochronous <int>:<float>,<float> and supports
	// human suffixes, e.g. --isochronous 60:100m,5m
	// which is frames per second, mean and variance
	if (mExtSettings->mThreadMode == kMode_Client) {
	    if (((results = strtok(mExtSettings->mIsochronousStr, ":")) != NULL) && !strcmp(results,mExtSettings->mIsochronousStr)) {
		mExtSettings->mFPS = atof(results);
		if ((results = strtok(NULL, ",")) != NULL) {
		    mExtSettings->mMean = bitorbyte_atof(results);
		    if (mExtSettings->mMean == 0.0) {
		        fprintf(stderr, "ERROR: Invalid --isochronous mean value, must be greater than zero\n");
		        exit(1);
		    }
		    if (!isUDP(mExtSettings)) {
		        if (mExtSettings->mMean < 0) {
			    fprintf(stderr, "ERROR: Invalid --isochronous units of 'p' with TCP must be bytes\n");
			    exit(1);
			}
		    } else { // UDP
		        if (mExtSettings->mMean < 0) {
			    mExtSettings->mMean *= -8 * mExtSettings->mBufLen * mExtSettings->mFPS;
			}
		    }
		    if ((results = strtok(NULL, ",")) != NULL) {
		        mExtSettings->mVariance = bitorbyte_atof(results);
		    }
		} else {
		    mExtSettings->mMean = 20000000.0;
		    mExtSettings->mVariance = 0.0;
		}
	    } else {
		fprintf(stderr, "WARNING: Invalid --isochronous value, format is <fps>:<mean>,<variance> (e.g. 60:18M,1m)\n");
	    }
	}
    }
}

// Pass: parse -B addresses (bind device suffix, port, multicast group/SSM source)
static void ModalOptions_BindAddress (struct thread_Settings *mExtSettings) {
    char *results;
    // Check for further mLocalhost (-B) and <dev> requests
    // full addresses look like 192.168.1.1:6001%eth0 or [2001:e30:1401:2:d46e:b891:3082:b939]:6001%eth0
    // Parse -B addresses
    if (mExtSettings->mLocalhost) {
	if (((results = strtok(mExtSettings->mLocalhost, "%")) != NULL) && ((results = strtok(NULL, "%")) != NULL)) {
	    mExtSettings->mIfrname = static_cast<char *>(calloc(strlen(results) + 1, sizeof(char)));
	    strcpy(mExtSettings->mIfrname, results);
	    if (mExtSettings->mThreadMode == kMode_Client) {
	        fprintf(stderr, "WARNING: Client cannot set bind device %s via -B consider using -c\n", mExtSettings->mIfrname);
		free(mExtSettings->mIfrname);
		mExtSettings->mIfrname = NULL;
	    }
	}
	if (isIPV6(mExtSettings)) {
	    results = isv6_bracketed_port(mExtSettings->mLocalhost);
	} else {
	    results = isv4_port(mExtSettings->mLocalhost);
	}
	if (results) {
	    if (mExtSettings->mThreadMode == kMode_Client) {
		mExtSettings->mBindPort = atoi(results);
	    } else {
		fprintf(stderr, "WARNING: port %s ignored - set receive port on server via -p or -L\n", results);
	    }
	}
	// Do multicast address checking and processing
	SockAddr_setHostname(mExtSettings->mLocalhost, &mExtSettings->multicast_group, \
			     &mExtSettings->size_multicast_group, (isIPV6(mExtSettings) ? 1 : 0));
	if (SockAddr_isMulticast(&mExtSettings->multicast_group)) {
	    if (mExtSettings->mThreadMode == kMode_Client) {
		fprintf(stderr, "WARNING: Client src addr (per -B) must be ip unicast\n");
		exit(1);
	    } else {
		setMulticast(mExtSettings);
		if (isSSMMulticast(mExtSettings)) {
		    SockAddr_setHostname(mExtSettings->mSSMMulticastStr, &mExtSettings->multicast_group_source, \
					 &mExtSettings->size_multicast_group, (isIPV6(mExtSettings) ? 1 : 0));
		    if (SockAddr_isMulticast(&mExtSettings->multicast_group_source)) {
			fprintf(stderr, "WARNING: SSM host src address (-H or --ssm-host) must be ip unicast\n");
			exit(1);
		    }
		}
	    }
	} else {
	    SockAddr_zeroAddress(&mExtSettings->multicast_group); // Zero out multicast sockaddr
	}
    }
}

// Pass (client only): parse -c host addresses for multicast, link-local and bind-to-device,
// and reconcile -P thread count with a -p port range
static void ModalOptions_ClientHostAddress (struct thread_Settings *mExtSettings) {
    char *results;
    if (mExtSettings->mThreadMode == kMode_Client) {
	if (mExtSettings->mPortLast > mExtSettings->mPort) {
	    int prcnt = ((mExtSettings->mPortLast - mExtSettings->mPort) + 1);
	    int threads_needed = (prcnt > mExtSettings->mThreads) ? prcnt : mExtSettings->mThreads;
	    if (mExtSettings->mThreads < prcnt) {
		if (mExtSettings->mThreads)
		    fprintf(stderr, "WARNING: port-range and -P mismatch (adjusting -P to %d)\n", threads_needed);
		mExtSettings->mThreads = threads_needed;
	    } else if ((mExtSettings->mThreads > 1) && (threads_needed > prcnt)) {
		fprintf(stderr, "WARNING: port-range and -P mismatch (adjusting port-range to %d-%d)\n", \
			mExtSettings->mPort, mExtSettings->mPort + threads_needed);
	    }
	}
	if (!mExtSettings->mThreads)
	    mExtSettings->mThreads = 1;

        mExtSettings->mIfrnametx = NULL;  // default off SO_BINDTODEVICE
        if (((results = strtok(mExtSettings->mHost, "%")) != NULL) && ((results = strtok(NULL, "%")) != NULL)) {
            size_t len = strlen(results) + 1;
            mExtSettings->mIfrnametx = static_cast<char *>(calloc(len, sizeof(char)));
            strncpy(mExtSettings->mIfrnametx, results, len);
        }
        if (isIPV6(mExtSettings)) strip_v6_brackets(mExtSettings->mHost);
        // get the socket address settings from the host, needed for link-local
        // and multicast tests
        SockAddr_zeroAddress(&mExtSettings->peer);
        SockAddr_remoteAddr(mExtSettings);
        // capture multicast-ness now: link-local scope (below) re-zeroes peer
        // to force a fresh getaddrinfo() resolution at connect() time, which
        // would otherwise make the isMulticast check below see an empty addr
        bool isMcastHost = SockAddr_isMulticast(&mExtSettings->peer);
        if (isIPV6(mExtSettings) && SockAddr_isLinkScope(&mExtSettings->peer)) {
            // link-local scope (unicast fe80:: or multicast ffx2::) doesn't use
            // SO_BINDTODEVICE but includes it in the host string so stitch
            // things back together and null the bind to name; glibc's
            // getaddrinfo() resolves the %<iface> zone id into sin6_scope_id
            // when the connect() path re-resolves it below
            if (mExtSettings->mIfrnametx) {
                strcat(mExtSettings->mHost, "%");
                strcat(mExtSettings->mHost, mExtSettings->mIfrnametx);
                free(mExtSettings->mIfrnametx);
                mExtSettings->mIfrnametx = NULL;
            } else {
                fprintf(stderr,
                        "WARNING: usage of ipv6 link-local requires a device "
                        "specifier, e.g. "
                        "%s%%eth0\n",
                        mExtSettings->mHost);
            }
            SockAddr_zeroAddress(&mExtSettings->peer);  // for link-local, force getaddrinfo() in
                                                        // the connect
        }
        if (isMcastHost) {
            bool bail = false;
            if (isFullDuplex(mExtSettings) || isReverse(mExtSettings) || (mExtSettings->mMode != kTest_Normal)) {
                fprintf(stderr,
                        "ERROR: options of --full-duplex, --reverse, -d and -r not "
                        "supported with "
                        "multicast addresses\n");
                bail = true;
            } else if (isSyncTransferID(mExtSettings)) {
                fprintf(stderr,
                        "ERROR: option of --sync-transfer-id incompatibile with "
                        "multicast\n");
                bail = true;
            }
            if (bail)
                exit(1);
            else
                setMulticast(mExtSettings);
        }
    }
}

// Pass: final small fixups that depend on the fully-resolved settings above
static void ModalOptions_FinalCleanup (struct thread_Settings *mExtSettings) {
    if (isIncrSrcPort(mExtSettings) && !mExtSettings->mBindPort) {
	fprintf(stderr, "WARN: option of --incr-srcport requires -B bind option w/port to be set\n");
	unsetIncrSrcPort(mExtSettings);
    }
    // mIntervalMode == kInterval_Time (1) can never also be <= 0 - the
    // original second clause tested mIntervalMode again instead of the
    // interval value itself, making this whole block dead code (a static
    // analyzer's "apparently unreachable condition" flag). The evident
    // intent is right here: -i 0 in time-interval mode should fall back
    // to no interval reporting, same as never passing -i at all.
    if ((mExtSettings->mIntervalMode == kInterval_Time) && (mExtSettings->mInterval == 0)) {
	mExtSettings->mIntervalMode = kInterval_None;
	mExtSettings->mInterval = 0;
    }
}

void Settings_ModalOptions (struct thread_Settings *mExtSettings) {
    ModalOptions_BufferAndPortDefaults(mExtSettings);
    ModalOptions_ClientLoadDefaults(mExtSettings);
    ModalOptions_HideIPs(mExtSettings);

    bool bail = ModalOptions_CommonBailChecks(mExtSettings);
    if (mExtSettings->mThreadMode == kMode_Client) {
	bail |= ModalOptions_ClientBailChecks(mExtSettings);
    } else {
	bail |= ModalOptions_ServerBailChecks(mExtSettings);
    }
    bail |= ModalOptions_FinalBailChecks(mExtSettings);
    if (bail)
	exit(1);

    ModalOptions_HistogramDefaults(mExtSettings);
    ModalOptions_L2AndBurstSize(mExtSettings);
    ModalOptions_IsochronousString(mExtSettings);
    ModalOptions_BindAddress(mExtSettings);
    ModalOptions_ClientHostAddress(mExtSettings);
    ModalOptions_FinalCleanup(mExtSettings);
}

void Settings_GetUpperCaseArg (const char *inarg, char *outarg) {
    int len = strlen(inarg);
    strcpy(outarg,inarg);

    if ((len > 0) && (inarg[len-1] >='a')
         && (inarg[len-1] <= 'z'))
        outarg[len-1]= outarg[len-1]+'A'-'a';
}

void Settings_GetLowerCaseArg (const char *inarg, char *outarg) {
    int len = strlen(inarg);
    strcpy(outarg,inarg);

    if ((len > 0) && (inarg[len-1] >='A')
         && (inarg[len-1] <= 'Z'))
        outarg[len-1]= outarg[len-1]-'A'+'a';
}

/*
 * Settings_GenerateListenerSettings
 * Called to generate the settings to be passed to the Listener
 * instance that will handle dual testings from the client side
 * this should only return an instance if it was called on
 * the struct thread_settings instance generated from the command line
 * for client side execution
 */
#define DUALTIMER_MS 300
void Settings_GenerateListenerSettings (struct thread_Settings *client, struct thread_Settings **listener) {
    if ((client->mMode == kTest_DualTest) || (client->mMode == kTest_TradeOff)) {
	Settings_Copy(client, listener, SHALLOW_COPY);
        unsetDaemon((*listener));
        setCompat((*listener));
        if (client->mListenPort != 0) {
            (*listener)->mPort   = client->mListenPort;
        } else {
            (*listener)->mPort   = client->mPort;
        }
	if (client->mMode == kTest_TradeOff) {
	    (*listener)->mAmount   = client->mAmount + DUALTIMER_MS;
	} else if (client->mMode == kTest_DualTest) {
	    (*listener)->mAmount   = client->mAmount + (SLOPSECS * 100);
	}
	if ((client->mMode != kTest_Normal) && ((*listener)->mAmount  < DUALTIMER_MS)) {
	    (*listener)->mAmount   = DUALTIMER_MS;
	}
        (*listener)->mFileName   = NULL;
        (*listener)->mHost       = NULL;
        (*listener)->mLocalhost  = NULL;
        (*listener)->mOutputFileName = NULL;
        (*listener)->mMode       = kTest_Normal;
        (*listener)->mThreadMode = kMode_Listener;
        if (client->mHost != NULL) {
            (*listener)->mHost = dupstr(client->mHost);
        }
        if (client->mLocalhost != NULL) {
            (*listener)->mLocalhost = dupstr(client->mLocalhost);
        }
	if (client->mBufLen <= 0) {
	    if (isUDP((*listener))) {
		(*listener)->mBufLen = kDefault_UDPRxBufLen;
	    } else {
		(*listener)->mBufLen = kDefault_TCPBufLen;
	    }
	} else {
	    (*listener)->mBufLen = client->mBufLen;
	}
	setReport((*listener));
    } else {
        *listener = NULL;
    }
}

void Settings_ReadClientSettingsIsoch (struct thread_Settings **client, struct client_hdrext_isoch_settings *hdr) {
    (*client)->mFPS = ntohl(hdr->FPSl);
    (*client)->mFPS += ntohl(hdr->FPSu) / static_cast<double>(rMillion);
    (*client)->mMean = ntohl(hdr->Meanl);
    (*client)->mMean += ntohl(hdr->Meanu) / static_cast<double>(rMillion);
    (*client)->mVariance = ntohl(hdr->Variancel);
    (*client)->mVariance += ntohl(hdr->Varianceu) / static_cast<double>(rMillion);
    (*client)->mBurstIPG = ntohl(hdr->BurstIPGl);
    (*client)->mBurstIPG += ntohl(hdr->BurstIPGu) / static_cast<double>(rMillion);
}

void Settings_ReadClientSettingsBurst (struct thread_Settings **client, struct client_hdrext_isoch_settings *hdr) {
    (*client)->mFPS = ntohl(hdr->FPSl);
    (*client)->mFPS += ntohl(hdr->FPSu) / static_cast<double>(rMillion);
}

void Settings_ReadClientSettingsV1 (struct thread_Settings **client, struct client_hdr_v1 *hdr) {
    (*client)->mTID = thread_zeroid();
    (*client)->mPort = static_cast<unsigned short>(ntohl(hdr->mPort));
    (*client)->mThreads = 1;
    struct thread_Settings *tmpSettings  = *client;
    if (hdr->mBufLen != 0) {
	// See MAXCLIENTMBUFLEN's own doc comment (headers.h) for why this
	// wire value can't be trusted at face value the way a real
	// client's own -l request could be, and why an unvalidated large
	// value here used to crash (confirmed via a tester's own gdb
	// backtrace + core file). Reject rather than clamp - silently
	// truncating a clearly-bogus value to some "safe" number would
	// still run the rest of the test with settings the client never
	// actually requested, same reasoning as the sibling bounceback
	// bbsize checks (Listener.cpp) this mirrors.
	int32_t wire_buflen = static_cast<int32_t>(ntohl(hdr->mBufLen));
	if ((wire_buflen <= 0) || (wire_buflen > MAXCLIENTMBUFLEN)) {
	    WARN_REPORT_FMT(1, "WARN: ignoring implausible client buffer length %d (max=%d)\n",
			     wire_buflen, MAXCLIENTMBUFLEN);
	} else {
	    (*client)->mBufLen = wire_buflen;
	    setBuflenSet(tmpSettings);
	    // Make the actual allocation match what was just claimed - this
	    // was the missing half of the original bug: mBufLen alone
	    // controlling pattern()/read()/write() calls against a buffer
	    // that was never resized to match it.
	    Settings_Resize_mBuf(tmpSettings, wire_buflen);
	}
    } else {
#ifdef DEFAULT_PAYLOAD_LEN_PER_MTU_DISCOVERY
	checksock_max_udp_payload(tmpSettings);
#endif
    }
    (*client)->mAmount = ntohl(hdr->mAmount);
    if (((*client)->mAmount & 0x80000000) > 0) {
	setModeTime((*client));
#ifndef WIN32
	(*client)->mAmount |= 0xFFFFFFFF00000000LL;
#else
	(*client)->mAmount |= 0xFFFFFFFF00000000;
#endif
	(*client)->mAmount = -(*client)->mAmount;
    } else {
	unsetModeTime((*client));
    }
}

/*
 * Settings_GenerateClientSettings
 *
 * Called by the Listener to generate the settings to be used by clients
 * per things like dual tests. Set client pointer to null if a client isn't needed
 *
 * Note: mBuf should already be filled out per the Listener's apply_client_settings
 */
// In reverse/full-duplex/dual-test modes, the server sends data back per a
// duration taken from the connecting client's own requested -t (below,
// Settings_ReadClientSettingsV1() sets reversed_thread->mAmount straight
// from the client's header). Without a cap, that request alone controls how
// long the server sends for. If the server itself was started with its own
// -t, clamp the reversed direction's duration to whichever is shorter, so a
// client can't force the server to send longer than the server allows.
static void Settings_ClampReverseDuration(struct thread_Settings *reversed_thread, bool server_had_mode_time,
                                          uintmax_t server_own_amount) {
    if (server_had_mode_time && isModeTime(reversed_thread) && (reversed_thread->mAmount > server_own_amount)) {
        reversed_thread->mAmount = server_own_amount;
    }
}

void Settings_GenerateClientSettings (struct thread_Settings *server, struct thread_Settings **client, void *mBuf) {
    assert(server != NULL);
    assert(mBuf != NULL);
    // Capture before any of the branches below potentially overwrite
    // server->mAmount (isServerReverse(server) aliases reversed_thread to
    // server itself, so this must be read before Settings_ReadClientSettingsV1
    // runs, not after).
    const bool server_had_mode_time = isServerModeTime(server);
    const uintmax_t server_own_amount = server->mAmount;
    uint32_t flags = isUDP(server) ? ntohl(*(uint32_t *)((char *)mBuf + sizeof(struct UDP_datagram))) : ntohl(*(uint32_t *)mBuf);
    uint16_t upperflags = 0;
    thread_Settings *reversed_thread = NULL;
    *client = NULL;
    bool v1test = (flags & HEADER_VERSION1) && !(flags & HEADER_VERSION2);
#ifdef HAVE_THREAD_DEBUG
    if (v1test)
	thread_debug("header set for a version 1 test");
#endif
    if (isFullDuplex(server) || isServerReverse(server))
	setTransferID(server, REVERSED);
    if (isFullDuplex(server) || v1test) {
	Settings_Copy(server, client, SHALLOW_COPY);
	reversed_thread = *client;
	if (isFullDuplex(server) && !(flags & HEADER_VERSION1)) {
	    setFullDuplex(reversed_thread);
	} else {
	    unsetFullDuplex(reversed_thread);
	}
    } else if (isServerReverse(server)) {
	reversed_thread = server;
    } else {
	assert(0);
	return;
    }
    reversed_thread->mThreadMode = kMode_Client;
    if (isUDP(reversed_thread)) {
	int new_size = 0; // test for a reverse tx that needs a smaller mBufLen
	if (isIPV6(reversed_thread) && (kDefault_UDPTxBufLenV6 < reversed_thread->mBufLen)) {
	    new_size = kDefault_UDPTxBufLenV6;
	} else if (!isIPV6(reversed_thread) && (kDefault_UDPTxBufLen < reversed_thread->mBufLen)) {
	    new_size = kDefault_UDPTxBufLen;
	}
	if (new_size) {
	    Settings_Resize_mBuf(reversed_thread,new_size);
	}
    }
    if (isUDP(server)) { // UDP test information passed in every packet per being stateless
	struct client_udp_testhdr *hdr = static_cast<struct client_udp_testhdr *>(mBuf);
	Settings_ReadClientSettingsV1(&reversed_thread, &hdr->base);
	Settings_ClampReverseDuration(reversed_thread, server_had_mode_time, server_own_amount);
	if (isFullDuplex(server) || v1test) {
	    server->mAmount = reversed_thread->mAmount + (SLOPSECS * 100);
	}
	if (v1test) {
	    setServerReverse(reversed_thread);
	    if (flags & RUN_NOW) {
		reversed_thread->mMode = kTest_DualTest;
	    } else {
		reversed_thread->mMode = kTest_TradeOff;
	    }
	}
	if (flags & HEADER_EXTEND) {
	    reversed_thread->mAppRate = ntohl(hdr->extend.lRate);
#ifdef HAVE_INT64_T
	    reversed_thread->mAppRate |= (static_cast<uint64_t>(ntohl(hdr->extend.uRate) >> 8) << 32);
#endif
	    upperflags = ntohs(hdr->extend.upperflags);
	    // UDP's own self-contained relay of --txdelay-time - reads
	    // hdr->extend.lowerflags/hdr->start_fq directly from this same
	    // mBuf, same convention every other flag in this block already
	    // uses, rather than depending on server->txholdback_timer having
	    // already been populated by an earlier, separate parse of a
	    // datagram this function has no guarantee is the same one (UDP's
	    // "info passed in every packet" design, this block's own leading
	    // comment) - see HEADER_EPOCH_DELAY's own doc comment (payloads.h).
	    if (ntohs(hdr->extend.lowerflags) & HEADER_EPOCH_DELAY) {
		reversed_thread->txholdback_timer.tv_sec = ntohl(hdr->start_fq.start_tv_sec);
		reversed_thread->txholdback_timer.tv_usec = ntohl(hdr->start_fq.start_tv_usec);
		if (reversed_thread->txholdback_timer.tv_sec > MAXDIFFTXDELAY) {
		    fprintf(stdout,
			    "WARN: ignore --txdelay-time because client "
			    "provided a delay exceeding %d seconds\n",
			    MAXDIFFTXDELAY);
		    unsetTxHoldback(reversed_thread);
		} else {
		    setTxHoldback(reversed_thread);
		}
	    }
	    if (upperflags & HEADER_NOUDPFIN) {
		setNoUDPfin(reversed_thread);
	    }
	    if ((upperflags & HEADER_UNITS_PPS) == HEADER_UNITS_PPS) {
		reversed_thread->mAppRateUnits = kRate_PPS;
	    } else {
		reversed_thread->mAppRateUnits = kRate_BW;
	    }
	    reversed_thread->mTOS = ntohs(hdr->extend.tos);
	    if (isIsochronous(server)) {
		Settings_ReadClientSettingsIsoch(&reversed_thread, &hdr->isoch_settings);
	    }
	    if (upperflags & HEADER_FQRATESET) {
		setFQPacing(reversed_thread);
		reversed_thread->mFQPacingRate = ntohl(hdr->start_fq.fqratel);
#ifdef HAVE_INT64_T
		reversed_thread->mFQPacingRate |= (static_cast<uint64_t>(ntohl(hdr->start_fq.fqrateu)) << 32);
#endif
	    }
	    upperflags = ntohs(hdr->extend.upperflags);
	    if ((upperflags & HEADER_UDPL4S) == HEADER_UDPL4S) {
		setUDPL4S(reversed_thread);
		if (reversed_thread->mAppRate == 0) {
		    reversed_thread->mAppRate = PRAGUE_MAXRATE;
		}
		// Carries --cca's prague/reno choice (under --udp-l4s) to a
		// listener-spawned reverse Client thread (-R) - see
		// UDP_L4S_CCA_WIRE_RENO's own doc
		// comment in payloads.h for why this rides in reserved rather
		// than a new header bit.
		if (ntohs(hdr->extend.reserved) == UDP_L4S_CCA_WIRE_RENO) {
		    setUDPL4SCcaReno(reversed_thread);
		}
	    }
	}
    } else { //tcp first payload
	struct client_tcp_testhdr *hdr = static_cast<struct client_tcp_testhdr *>(mBuf);
	Settings_ReadClientSettingsV1(&reversed_thread, &hdr->base);
	Settings_ClampReverseDuration(reversed_thread, server_had_mode_time, server_own_amount);

	if (isFullDuplex(server) || v1test) {
	    server->mAmount = reversed_thread->mAmount + (SLOPSECS * 100);
	}
	if (v1test) {
	    setServerReverse(reversed_thread);
	    if (flags & RUN_NOW) {
		reversed_thread->mMode = kTest_DualTest;
	    } else {
		reversed_thread->mMode = kTest_TradeOff;
	    }
	}
	if (flags & HEADER_EXTEND) {
	    reversed_thread->mAppRate = ntohl(hdr->extend.lRate);
#ifdef HAVE_INT64_T
	    reversed_thread->mAppRate |= (static_cast<uint64_t>(ntohl(hdr->extend.uRate) >> 8) << 32);
#endif
	    upperflags = ntohs(hdr->extend.upperflags);
	    reversed_thread->mTOS = ntohs(hdr->extend.tos);

	    if (isIsochronous(server)) {
		Settings_ReadClientSettingsIsoch(&reversed_thread, &hdr->isoch_settings);
	    } else if (isPeriodicBurst(server)) {
		Settings_ReadClientSettingsBurst(&reversed_thread, &hdr->isoch_settings);
	    }
	    if (upperflags & HEADER_FQRATESET) {
		setFQPacing(reversed_thread);
		reversed_thread->mFQPacingRate = ntohl(hdr->start_fq.fqratel);
#ifdef HAVE_INT64_T
		reversed_thread->mFQPacingRate |= (static_cast<uint64_t>(ntohl(hdr->start_fq.fqrateu)) << 32);
#endif
	    }
	}
    }
    // Strip any --txdelay-time reversed_thread might otherwise carry
    // (never a legitimate source of a value the SERVER should honor on
    // its own, absent an actual client relay) - then restore it if the
    // UDP/TCP parsing above (this function's own HEADER_EPOCH_DELAY
    // handling, or Listener.cpp's earlier relay read for the isServerReverse
    // case where reversed_thread IS server) actually populated it.
    // Snapshotting reversed_thread's OWN state right before the
    // unconditional strip - rather than separately re-checking server's -
    // is what makes this correct regardless of whether reversed_thread is
    // server itself (isServerReverse - checking server here would see the
    // very value this same strip line just cleared, since they're the
    // same object) or a distinct SHALLOW_COPY (isFullDuplex). See
    // HEADER_EPOCH_DELAY's own doc comment (payloads.h) for the full
    // reasoning.
    bool relayed_holdback = isTxHoldback(reversed_thread);
    struct timeval relayed_holdback_timer = reversed_thread->txholdback_timer;
    unsetTxHoldback(reversed_thread);
    if (relayed_holdback) {
        reversed_thread->txholdback_timer = relayed_holdback_timer;
        setTxHoldback(reversed_thread);
    }
    setNoSettReport(reversed_thread);
    setNoConnectSync(reversed_thread);
    // for legacy -d and -r need so set the reversed threads mHost
    if (v1test) {
	reversed_thread->mHost = new char[REPORT_ADDRLEN];
	if ((reinterpret_cast<sockaddr*>(&server->peer))->sa_family == AF_INET) {
	    inet_ntop(AF_INET, &(reinterpret_cast<sockaddr_in*>(&server->peer))->sin_addr,
		      reversed_thread->mHost, REPORT_ADDRLEN);
	}
#if HAVE_IPV6
	else {
	    inet_ntop(AF_INET6, &(reinterpret_cast<sockaddr_in6*>(&server->peer))->sin6_addr,
		      reversed_thread->mHost, REPORT_ADDRLEN);
	}
#endif
    } else {
	reversed_thread->mMode = kTest_Normal;
#if HAVE_DECL_SO_MAX_PACING_RATE
	if (isFQPacing(reversed_thread)) {
	    int rc = setsockopt(reversed_thread->mSock, SOL_SOCKET, SO_MAX_PACING_RATE, \
				&reversed_thread->mFQPacingRate, sizeof(reversed_thread->mFQPacingRate));
	    WARN_errno(rc == SOCKET_ERROR, "setsockopt SO_MAX_PACING_RATE");
  #ifdef HAVE_THREAD_DEBUG
    #ifdef HAVE_INT64_T
	    thread_debug("Set socket %d pacing rate to %ld byte/sec", reversed_thread->mSock, reversed_thread->mFQPacingRate);
    #else
	    thread_debug("Set socket %d pacing rate to %d byte/sec", reversed_thread->mSock, reversed_thread->mFQPacingRate);
    #endif
  #endif
	}
#endif // MAX_PACING_RATE
    }
}

int Settings_GenerateClientHdrV1 (struct thread_Settings *client, struct client_hdr_v1 *hdr, uint32_t *flags) {
    if (isBuflenSet(client)) {
	hdr->mBufLen = htonl(client->mBufLen);
    } else {
	hdr->mBufLen = 0;
    }
    if (client->mListenPort != 0) {
	hdr->mPort  = htonl(client->mListenPort);
    } else {
	hdr->mPort  = htonl(client->mPort);
    }
    if (isSyncTransferID(client)) {
	if (client->mTransferID & (HEADER_HASTRANSFERID | HEADER_TRANSFERIDMASK)) {
	    fprintf(stderr, "WARN: num threads too large for --sync-transfer-id\n");
	} else {
	    uint32_t tidthreads = (HEADER_HASTRANSFERID | ((client->mTransferID << HEADER_TRANSFERIDSHIFT) & HEADER_TRANSFERIDMASK) | client->mThreads);
	    hdr->numThreads = htonl(tidthreads);
	}
    } else {
	hdr->numThreads = htonl(client->mThreads);
    }
    if (isModeTime(client)) {
	hdr->mAmount = htonl(-(long)client->mAmount);
    } else {
	hdr->mAmount = htonl((long)client->mAmount);
	hdr->mAmount &= htonl(0x7FFFFFFF);
    }
    if (!isCompat(client) && (client->mMode != kTest_Normal)) {
	*flags |= HEADER_VERSION1;
	if (client->mMode == kTest_DualTest)
	    *flags |= RUN_NOW;
    }
    return (sizeof(struct client_hdr_v1));
}

/*
 * Settings_GenerateClientHdr
 *
 * Called to generate the client header to be passed to the listener/server
 *
 * This will handle:
 * o) dual testings from the listener/server side
 * o) advanced udp test settings
 *
 * Returns size of header in bytes
 */
int Settings_GenerateClientHdr (struct thread_Settings *client, void *testhdr, struct timeval startTime) {
    uint16_t len = 0;
    uint16_t upperflags = 0;
    uint16_t lowerflags = 0;
    uint32_t flags = 0;

    // Check the corner case of small packets and trip times
    if (isUDP(client) && isSmallTripTime(client)) {
        int buflen = (client->mBufLen < (int) sizeof(struct client_udpsmall_testhdr)) ? client->mBufLen \
	             : sizeof(struct client_udpsmall_testhdr);
	struct client_udpsmall_testhdr *hdr = static_cast<struct client_udpsmall_testhdr *>(testhdr);
	memset(hdr, 0, buflen);
	hdr->flags = htons(HEADER16_SMALL_TRIPTIMES);
	if (isTxStartTime(client) && !TimeZero(startTime)) {
	    hdr->start_tv_sec = htonl(startTime.tv_sec);
	}
#ifdef HAVE_THREAD_DEBUG
	thread_debug("UDP small trip times flags = %X", ntohs(hdr->flags));
#endif
	return buflen;
    }
    // flags common to both TCP and UDP
    if (isReverse(client) && !isCompat(client)) {
	upperflags |= HEADER_REVERSE;
	if (isTxStartTime(client) && !TimeZero(startTime)) {
	    upperflags |= HEADER_EPOCH_START;
	} else if (isTxHoldback(client) && !TimeZero(startTime)) {
	    lowerflags |= HEADER_EPOCH_DELAY;
	}
    }
    if (isFullDuplex(client) && !isCompat(client)) {
	upperflags |= HEADER_FULLDUPLEX;
	if (isTxStartTime(client) && !TimeZero(startTime)) {
	    upperflags |= HEADER_EPOCH_START;
	} else if (isTxHoldback(client) && !TimeZero(startTime)) {
	    lowerflags |= HEADER_EPOCH_DELAY;
	}
    }
    if (isTxStartTime(client) && isTripTime(client) && !TimeZero(startTime)) {
	upperflags |= HEADER_EPOCH_START;
    }

    // Now setup UDP and TCP specific passed settings from client to server
    if (isUDP(client)) { // UDP test information passed in every packet per being stateless
	struct client_udp_testhdr *hdr = static_cast<struct client_udp_testhdr *>(testhdr);
        int buflen = (client->mBufLen < (int) sizeof(struct client_udp_testhdr)) ? client->mBufLen \
	             : sizeof(struct client_udp_testhdr);
	memset(hdr, 0, buflen);
	flags |= HEADER_SEQNO64B; // use 64 bit by default
	flags |= HEADER_EXTEND;
	hdr->extend.version_u = htonl(IPERF_VERSION_MAJORHEX);
	hdr->extend.version_l = htonl(IPERF_VERSION_MINORHEX);
	hdr->extend.tos = htons(client->mTOS & 0xFF);
	// Valid iff HEADER_UDPL4S ends up set in upperflags below - see
	// UDP_L4S_CCA_WIRE_RENO's own doc comment in payloads.h.
	hdr->extend.reserved = htons(isUDPL4SCcaReno(client) ? UDP_L4S_CCA_WIRE_RENO : UDP_L4S_CCA_WIRE_PRAGUE);
	if (isBWSet(client) && (client->mAppRate > 0)) {
	    uint64_t bw = 0;
	    if ((client->mAppRateUnits == kRate_PPS) && (isFullDuplex(client) || isReverse(client) || (client->mMode != kTest_Normal))) {
		bw = client->mAppRate * 8 * client->mBufLen;
	    } else {
		bw = client->mAppRate;
	    }
	    hdr->extend.lRate = htonl((uint32_t)(bw));
#ifdef HAVE_INT64_T
	    hdr->extend.uRate = htonl(((uint32_t)(bw >> 32)) << 8);
#endif
	} else {
	    hdr->extend.lRate = (isUDPL4S(client) ? 0 : htonl(kDefault_UDPRate));
	    hdr->extend.uRate = 0x0;
	}
	len += sizeof(struct client_hdrext);
	len += Settings_GenerateClientHdrV1(client, &hdr->base, &flags);
	/*
	 * set the default offset where underlying "inline" subsystems can write into the udp payload
	 */
	if (isL2LengthCheck(client)) {
	    flags |= HEADER_UDPTESTS;
	    if (isL2LengthCheck(client)) {
		upperflags |= HEADER_L2LENCHECK;
		if (isIPV6(client))
		    upperflags |= HEADER_L2ETHPIPV6;
	    }
	}
	if (isIsochronous(client)) {
	    flags |= (HEADER_UDPTESTS | HEADER_EXTEND) ;
	    upperflags |= HEADER_ISOCH;
	    if (isFullDuplex(client) || isReverse(client)) {
		upperflags |= HEADER_ISOCH_SETTINGS;
		hdr->isoch_settings.FPSl = htonl((long)(client->mFPS));
		hdr->isoch_settings.FPSu = htonl((long)((client->mFPS - (long)(client->mFPS)) * rMillion));
		hdr->isoch_settings.Meanl = htonl((long)(client->mMean));
		hdr->isoch_settings.Meanu = htonl((long)(((client->mMean) - (long)(client->mMean)) * rMillion));
		hdr->isoch_settings.Variancel = htonl((long)(client->mVariance));
		hdr->isoch_settings.Varianceu = htonl((long)((client->mVariance - (long)(client->mVariance)) * rMillion));
		hdr->isoch_settings.BurstIPGl = htonl((long)(client->mBurstIPG));
		hdr->isoch_settings.BurstIPGu = htonl((long)((client->mBurstIPG - (long)(client->mBurstIPG)) * rMillion));
		len += sizeof(struct client_hdrext_isoch_settings);
	    }
	}
	if (isUDPL4S(client)) {
	    flags |= (HEADER_UDPTESTS | HEADER_EXTEND);
	    upperflags |= HEADER_UDPL4S;
	}
	if (isReverse(client) || isFullDuplex(client)) {
	    flags |= (HEADER_UDPTESTS | HEADER_VERSION2);
	}
	if (isNoUDPfin(client)) {
	    flags |= (HEADER_UDPTESTS | HEADER_EXTEND);
	    upperflags |= HEADER_NOUDPFIN;
	}
	if (isTripTime(client) || isFQPacing(client) || isTxStartTime(client) || isTxHoldback(client)) {
	    flags |= HEADER_UDPTESTS;
	    if (isTripTime(client) || isTxStartTime(client) || isTxHoldback(client)) {
		hdr->start_fq.start_tv_sec = htonl(startTime.tv_sec);
		hdr->start_fq.start_tv_usec = htonl(startTime.tv_usec);
		if (isTripTime(client))
		    upperflags |= HEADER_TRIPTIME;
	    }
	    if (isFQPacing(client)) {
		upperflags |= HEADER_FQRATESET;
		hdr->start_fq.fqratel = htonl((uint32_t) client->mFQPacingRate);
#ifdef HAVE_INT64_T
		hdr->start_fq.fqrateu = htonl((uint32_t) (client->mFQPacingRate >> 32));
#endif
	    }
	}
#if HAVE_PROFESSIONAL
	if (isHistogram(client) && isTripTime(client)) {
	    flags |= HEADER_UDPTESTS;
	    upperflags |= HEADER_HISTOGRAM;
	}
#endif
	// Write flags to header so the listener can determine the tests requested
	hdr->extend.upperflags = htons(upperflags);
	hdr->extend.lowerflags = htons(lowerflags);

	// isoch payload is an enclave field between v 0.13 and v0.14
	// so figure out if it's there now - UDP only
	// will be filled in by the client write
	if (isTripTime(client) || isFQPacing(client) || isIsochronous(client))
	    len += sizeof (struct isoch_payload);

	if (len > 0) {
	    len += sizeof(struct UDP_datagram);
	    // Mirrors the TCP permit-key embed below - no separate
	    // HAVE_PROFESSIONAL guard needed at this call site.
	    // isPermitKey(client) can legitimately be true here on a
	    // community-edition client: ModalOptions_CommonBailChecks only
	    // restricts the *server* side (enforcing/requiring a key is the
	    // paid capability), a community client sending a key it was
	    // simply handed is always allowed. struct client_udp_testhdr's
	    // permitkey field is unconditional (see payloads.h) precisely so
	    // this write is well-formed and wire-compatible regardless of
	    // which edition built this client.
	    int keylen = 0;
	    if (isPermitKey(client) && (client->mPermitKey[0] != '\0')) {
		char wirekey[MAX_PERMITKEY_LEN + 1];
		build_permit_key_wire_value(wirekey, sizeof(wirekey), client->mPermitKey, isPermitKeyHmac(client));
		keylen = static_cast<int>(strnlen(wirekey, MAX_PERMITKEY_LEN));
		flags |= HEADER_KEYCHECK;
		struct permitKey *thiskey = reinterpret_cast<struct permitKey *>(static_cast<char *>(testhdr) + len);
		thiskey->length = htons((uint16_t)keylen);
		memcpy(thiskey->value, wirekey, keylen);
		len += sizeof(thiskey->length);
	    }
	    flags |= ((len << 1) & HEADER_KEYLEN_MASK) | HEADER_LEN_BIT;
	    len += keylen;
	}
	if (isBuflenSet(client) && isReverse(client)) {
	    flags |= HEADER_VERSION1;
	}
	hdr->base.flags = htonl(flags);
#ifdef HAVE_THREAD_DEBUG
	thread_debug("UDPflags = %X", ntohl(hdr->base.flags));
#endif
    } else { // TCP first write with test information
	struct client_tcp_testhdr *hdr = static_cast<struct client_tcp_testhdr *>(testhdr);
#ifdef HAVE_THREAD_DEBUG
	thread_debug("Client header init size %d (%p)", sizeof(struct client_tcp_testhdr), (void *) hdr);
#endif
	if (isBounceBack(client)) {
	    flags = HEADER_BOUNCEBACK;
	    len = sizeof(struct bounceback_hdr);
	} else {
	    int buflen = (client->mBufLen < (int) sizeof(struct client_tcp_testhdr)) ? client->mBufLen \
	                 : sizeof(struct client_tcp_testhdr);
	    memset(hdr, 0, buflen);
	    flags |= HEADER_EXTEND;
	    hdr->extend.version_u = htonl(IPERF_VERSION_MAJORHEX);
	    hdr->extend.version_l = htonl(IPERF_VERSION_MINORHEX);
	    hdr->extend.tos = htons(client->mTOS & 0xFF);
	    if (isBWSet(client)) {
		hdr->extend.lRate = htonl((uint32_t)(client->mAppRate));
#ifdef HAVE_INT64_T
		hdr->extend.uRate = htonl(((uint32_t)(client->mAppRate >> 32)) << 8);
#endif
	    }
	    len += sizeof(struct client_hdrext);
	    len += Settings_GenerateClientHdrV1(client, &hdr->base, &flags);
	    if (isPeerVerDetect(client)) {
		flags |= (HEADER_V2PEERDETECT | HEADER_VERSION2);
	    }
	    if (isTripTime(client) || isFQPacing(client) || isIsochronous(client) || isTxStartTime(client) || isTxHoldback(client) || isLoadCCA(client) || isCongestionControl(client)) {
		hdr->start_fq.start_tv_sec = htonl(startTime.tv_sec);
		hdr->start_fq.start_tv_usec = htonl(startTime.tv_usec);
		hdr->start_fq.fqratel = htonl((uint32_t) client->mFQPacingRate);
#ifdef HAVE_INT64_T
		hdr->start_fq.fqrateu = htonl((uint32_t) (client->mFQPacingRate >> 32));
#endif
		len += sizeof(struct client_hdrext_starttime_fq);
		// Set flags on
		if (isTripTime(client)) {
		    upperflags |= HEADER_TRIPTIME;
		}
		if (isFQPacing(client)) {
		    upperflags |= HEADER_FQRATESET;
		}
#if HAVE_PROFESSIONAL
		if (isHistogram(client) && isTripTime(client)) {
		    upperflags |= HEADER_HISTOGRAM;
		}
#endif
	    }
#if HAVE_DECL_TCP_NOTSENT_LOWAT
	    if (isWritePrefetch(client) && (isReverse(client) || isFullDuplex(client))) {
		upperflags  |= HEADER_WRITEPREFETCH;
		hdr->extend.TCPWritePrefetch = htonl((long)client->mWritePrefetch);
	    }
#endif
	    if (client->barrier_time) {
		lowerflags |= HEADER_BARRIER_TIME;
		hdr->extend.barrier_usecs = htonl((long)client->barrier_time);
	    }
	    if (isTcpWriteTimes(client) && (isReverse(client) || isFullDuplex(client))) {
		lowerflags |= HEADER_TCPWRITETIMES;
	    }
#if HAVE_DECL_TCP_QUICKACK
	    if (isTcpQuickAck(client) && (!isReverse(client) || isFullDuplex(client))) {
		upperflags  |= HEADER_TCPQUICKACK;
	    }
#endif
	    if (isIsochronous(client) || isPeriodicBurst(client)) {
		if (isPeriodicBurst(client)) {
		    upperflags |= HEADER_PERIODICBURST;  // overload the isoch settings
		} else {
		    upperflags |= HEADER_ISOCH;
		}
		if (isFullDuplex(client) || isReverse(client) || isPeriodicBurst(client)) {
		    hdr->isoch_settings.FPSl = htonl((long)client->mFPS);
		    hdr->isoch_settings.FPSu = htonl((long)((client->mFPS - (long)(client->mFPS)) * rMillion));
		    hdr->isoch_settings.Variancel = htonl((long)(client->mVariance));
		    hdr->isoch_settings.Varianceu = htonl((long)((client->mVariance - (long)(client->mVariance)) * rMillion));
		    if (!isPeriodicBurst(client)) {
			hdr->isoch_settings.Meanl = htonl((long)(client->mMean));
			hdr->isoch_settings.Meanu = htonl((long)(((client->mMean) - (long)(client->mMean)) * rMillion));
			hdr->isoch_settings.BurstIPGl = htonl((long)client->mBurstIPG);
			hdr->isoch_settings.BurstIPGu = htonl(((long)(client->mBurstIPG) - (long)client->mBurstIPG * rMillion));
		    } else {
			hdr->isoch_settings.Meanl = htonl((long)(client->mBurstSize));
		    }
		    len += sizeof(struct client_hdrext_isoch_settings);
		}
	    } else if (isLoadCCA(client) || isCongestionControl(client)) {
		// just jump the enclave hdr
		len += sizeof(struct client_hdrext_isoch_settings);
	    }
	    if (isLoadCCA(client) && (isWorkingLoadUp(client) || isWorkingLoadDown(client))) {
		uint16_t lenfield = 0;
		if (client->mLoadCCA != NULL) {
		    lenfield = static_cast<uint16_t>(strnlen(client->mLoadCCA, TCP_CCA_NAME_MAX));
		    if (client->mLoadCCA[lenfield] != '\0') {
			fprintf(stderr, "WARN: --working-load-cca value '%s' exceeds %d chars, truncating\n", \
				client->mLoadCCA, TCP_CCA_NAME_MAX);
		    }
		}
		if (lenfield > 0) {
		    hdr->cca.cca_length = htons(lenfield);
		    lowerflags |= HEADER_CCA;
		    memcpy(hdr->cca.value, client->mLoadCCA, lenfield);
		    len += sizeof(uint16_t) + lenfield;
		}
	    } else if (isCongestionControl(client)) {
		uint16_t lenfield = 0;
		if (client->mCongestion != NULL) {
		    lenfield = static_cast<uint16_t>(strnlen(client->mCongestion, TCP_CCA_NAME_MAX));
		    if (client->mCongestion[lenfield] != '\0') {
			fprintf(stderr, "WARN: --cca/--tcp-congestion value '%s' exceeds %d chars, truncating\n", \
				client->mCongestion, TCP_CCA_NAME_MAX);
		    }
		}
		if (lenfield > 0) {
		    hdr->cca.cca_length = htons(lenfield);
		    lowerflags |= HEADER_CCA;
		    memcpy(hdr->cca.value, client->mCongestion, lenfield);
		    len += sizeof(uint16_t) + lenfield;
		}
	    }
	    if (isReverse(client) || isFullDuplex(client)) {
		flags |= HEADER_VERSION2;
	    }
	    hdr->extend.upperflags = htons(upperflags);
	    hdr->extend.lowerflags = htons(lowerflags);
	    if (len > 0) {
		flags |= HEADER_LEN_BIT;
		int keylen = 0;
		if (!isServerReverse(client) && isPermitKey(client) && (client->mPermitKey[0] != '\0')) {
		    char wirekey[MAX_PERMITKEY_LEN + 1];
		    build_permit_key_wire_value(wirekey, sizeof(wirekey), client->mPermitKey, isPermitKeyHmac(client));
		    keylen = static_cast<int>(strnlen(wirekey, MAX_PERMITKEY_LEN));
		    flags |= HEADER_KEYCHECK;
		    struct permitKey *thiskey = reinterpret_cast<struct permitKey *>(static_cast<char *>(testhdr) + len);
		    thiskey->length = htons((uint16_t)keylen);
		    memcpy(thiskey->value, wirekey, keylen);
		    len += sizeof(thiskey->length);
		}
		flags |= ((len << 1) & HEADER_KEYLEN_MASK); // this is the key value offset passed to the server
		len += keylen;
	    }
	}
	hdr->base.flags = htonl(flags);
    }
    return (len);
}

int Settings_ClientTestHdrLen (uint32_t flags, struct thread_Settings *inSettings) {
    int peeklen = 0;
    if ((flags & HEADER_VERSION1) || (flags & HEADER_VERSION2) || (flags & HEADER_EXTEND) || isPermitKey(inSettings)) {
	if (flags & HEADER_LEN_BIT) {
	    // Decode with the same width mask Settings_GenerateClientHdr() used to
	    // encode (HEADER_KEYLEN_MASK, 16 bits) -- HEADER_LEN_MASK is only 8 bits
	    // and would silently wrap a value above 255 into a small bogus one that
	    // passes the MAX_HEADER_LEN check below instead of being rejected by it.
	    peeklen = static_cast<int>((flags & HEADER_KEYLEN_MASK) >> 1);
	    if (peeklen > MAX_HEADER_LEN) {
		fprintf(stderr, "WARN: header of %d length too large\n", peeklen);
		peeklen = -1;
	    }
	} else {
	    if (flags & (HEADER_VERSION1 | HEADER_EXTEND)) {
		peeklen = sizeof(struct client_hdr_v1);
	    }
	    if (flags & (HEADER_VERSION2 | HEADER_EXTEND)) {
		peeklen += sizeof(struct client_hdrext);
	    }
	}
    }
    return peeklen;
}
