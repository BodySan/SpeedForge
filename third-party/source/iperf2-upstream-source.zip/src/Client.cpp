/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Client.cpp
 * by Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * A client thread initiates a connect to the server and handles
 * sending and receiving data, then closes the socket.
 * ------------------------------------------------------------------- */
#include <ctime>
#include <cmath>
#include "headers.h"
#include "Client.hpp"
#include "Thread.h"
#include "SocketAddr.h"
#include "PerfSocket.hpp"
#include "Extractor.h"
#include "delay.h"
#include "util.h"
#include "Locale.h"
#include "isochronous.hpp"
#include "pdfs.h"
#include "version.h"
#include "payloads.h"
#include "active_hosts.h"
#include "gettcpinfo.h"

// const double kSecs_to_usecs = 1e6;
const double kSecs_to_nsecs = 1e9;
const int kBytes_to_Bits = 8;

#define VARYLOAD_PERIOD 0.1  // recompute the variable load every n seconds
#define TCPDELAYDEFAULTQUANTUM 4000  // units usecs

Client::Client(thread_Settings *inSettings) {
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Client constructor with thread %p sum=%p (flags=%x)", (void *)inSettings,
                 (void *)inSettings->mSumReport, inSettings->flags);
#endif
    mSettings = inSettings;
    myJob = NULL;
    myReport = NULL;
    framecounter = NULL;
    one_report = false;
    udp_payload_minimum = 1;
    apply_first_udppkt_delay = false;
    markov_graph_len = NULL;
    memset(&scratchpad, 0, sizeof(struct ReportStruct));
    reportstruct = &scratchpad;
    reportstruct->packetID = 1;
    mySocket = isServerReverse(mSettings) ? mSettings->mSock : INVALID_SOCKET;
    connected = isServerReverse(mSettings);
    if (isCompat(mSettings) && isPeerVerDetect(mSettings)) {
        fprintf(stderr, "%s", warn_compat_and_peer_exchange);
        unsetPeerVerDetect(mSettings);
    }

    pattern(mSettings->mBuf, mSettings->mBufLen);
    if (isSetRandSeed(mSettings)) {
        srand(mSettings->rand_seed);
    }
    if (isIsochronous(mSettings)) {
        FAIL_errno(!(mSettings->mFPS > 0.0), "Invalid value for frames per second in the isochronous settings\n",
                   mSettings);
    }
    if (isFileInput(mSettings)) {
        if (!isSTDIN(mSettings))
            Extractor_Initialize(mSettings->mFileName, mSettings->mBufLen, mSettings);
        else
            Extractor_InitializeFile(stdin, mSettings->mBufLen, mSettings);

        if (!Extractor_canRead(mSettings)) {
            unsetFileInput(mSettings);
        }
    }
    if (isUDPL4S(mSettings)) {
        mSettings->mTOS = (mSettings->mTOS & 0xFC);
    }
    peerclose = false;
    mysock_init_done = false;
    // isServerReverse (TCP only): the server's reverse-mode writer thread
    // also frames its writes with TCP_burst_payload, purely to carry its
    // own gettcpinfo() bytes-in-flight/rtt back to the reader in the
    // struct's otherwise-unused reserved fields (see WriteTcpTxHdr) - same
    // "framed writes without wanting isochronous pacing" precedent as the
    // isTripTime term just below.
    isburst = (isIsochronous(mSettings) || isPeriodicBurst(mSettings) || (isTripTime(mSettings) && !isUDP(mSettings)) ||
               (isServerReverse(mSettings) && !isUDP(mSettings)));
}  // end Client

/* -------------------------------------------------------------------
 * Destructor
 * ------------------------------------------------------------------- */
Client::~Client() {
#if HAVE_THREAD_DEBUG
    thread_debug("Client destructor sock=%d report=%p server-reverse=%s fullduplex=%s", mySocket,
                 (void *)mSettings->reporthdr, (isServerReverse(mSettings) ? "true" : "false"),
                 (isFullDuplex(mSettings) ? "true" : "false"));
#endif
    DELETE_PTR(framecounter);
}  // end ~Client

/* -------------------------------------------------------------------
 * Setup a socket connected to a server.
 * If inLocalhost is not null, bind to that address, specifying
 * which outgoing interface to use.
 * ------------------------------------------------------------------- */
void Client::mySockInit(void) {
    // create an internet socket
    int type = (isUDP(mSettings) ? SOCK_DGRAM : SOCK_STREAM);
    int domain = SockAddr_getAFdomain(&mSettings->peer);

    mySocket = socket(domain, type, 0);
    WARN_errno(mySocket == INVALID_SOCKET, "socket");
    // Socket is carried both by the object and the thread
    mSettings->mSock = mySocket;
    SetSocketOptions(mSettings);
    SockAddr_localAddr(mSettings);
    SockAddr_remoteAddr(mSettings);
    // do this bind to device after IP addr name lookups per above
    SetSocketBindToDeviceIfNeeded(mSettings);
    if (mSettings->mLocalhost != NULL) {  // bind src ip if needed
        // bind socket to local address
        int rc = bind(mSettings->mSock, (struct sockaddr *)(&mSettings->local),
                      SockAddr_get_sizeof_sockaddr(&mSettings->local));
        WARN_errno(rc == SOCKET_ERROR, "bind");
    }
    if (isSettingsReport(mSettings)) {
        struct ReportHeader *tmp = InitSettingsReport(mSettings);
        assert(tmp != NULL);
        PostReport(tmp);
        if (isConnectOnly(mSettings)) {
            setNoSettReport(mSettings);
        }
    }
    mysock_init_done = true;
}

/* -------------------------------------------------------------------
 * Setup a socket connected to a server.
 * If inLocalhost is not null, bind to that address, specifying
 * which outgoing interface to use.
 * ------------------------------------------------------------------- */
bool Client::my_connect(bool close_on_fail) {
    int rc;
    if (!mysock_init_done) {
        mySockInit();
    }
    // connect socket
    connected = false;
    int connect_errno = 0;
    mSettings->tcpinitstats.connecttime = -1;
    if (!isUDP(mSettings)) {
        Timestamp end_connect_retry;
        end_connect_retry.add(mSettings->connect_retry_time);
        do {
            connect_start.setnow();
            rc = connect(mySocket, reinterpret_cast<sockaddr *>(&mSettings->peer),
                         SockAddr_get_sizeof_sockaddr(&mSettings->peer));
            connect_done.setnow();
            if (rc == SOCKET_ERROR) {
                struct timeval cdone;
                cdone.tv_sec = connect_done.getSecs();
                cdone.tv_usec = connect_done.getUsecs();
                connect_errno = post_connection_error(mSettings, cdone);
                bool need_open = false;
                if (close_on_fail || FATALTCPCONNECTERR(errno)) {  // MAC OS kicks out invalid argument
                                                                   // at times, not sure why
                    close(mySocket);
                    mySockInit();
                    delay_loop(10000);  // delay the minimum of 10ms
                    need_open = true;
                }
                if (!need_open && connect_done.before(end_connect_retry)) {
                    int delay = mSettings->connect_retry_timer - (connect_done.subUsec(connect_start));
                    delay_loop((delay < 10000) ? 10000 : delay);  // minimum of 10ms
                }
            } else {
                mSettings->tcpinitstats.connecttime = 1e3 * connect_done.subSec(connect_start);
                connected = true;
                break;
            }
        } while (connect_done.before(end_connect_retry));
        if (!connected && (mSettings->connect_retry_time > 0)) {
            struct timeval t;
            t.tv_sec = end_connect_retry.getSecs();
            t.tv_usec = end_connect_retry.getUsecs();
            post_connect_timer_expired(mSettings, t);
            return false;  // timer expired such that connect no longer retries
        }
    } else {
        rc = connect(mySocket, reinterpret_cast<sockaddr *>(&mSettings->peer),
                     SockAddr_get_sizeof_sockaddr(&mSettings->peer));
        mSettings->tcpinitstats.connecttime = 0.0;  // UDP doesn't have a 3WHS
        WARN_errno((rc == SOCKET_ERROR), "udp connect");
        // Reverse UDP tests reverse tests need to do test exchange
        if (isReverse(mSettings) && isUDP(mSettings)) {
            reportstruct->packetLen = 0;
            fd_set set;
            struct timeval timeout;
            // Same RTT-aware retry pattern as the TCP connect retry above
            // (this function's !isUDP branch) instead of a fixed 0-10ms
            // cadence - that assumed sub-millisecond LAN RTT and, over a
            // real WAN path (100s of ms RTT), fired a burst of ~100
            // duplicate exchange packets before a single real reply could
            // possibly arrive. Verified against a live public server
            // (~250ms RTT) that the old cadence doesn't actually break
            // connectivity there (the burst goes through fine with a
            // valid permit key) - this is a correctness/hygiene fix for
            // any WAN path stricter than that one, not a fix for a
            // specific reported failure. Falls back to the same 1s/10s
            // defaults the TCP path uses when --connect-retry-timer/
            // --connect-retry-time aren't set, but applies them
            // unconditionally here rather than requiring the user to pass
            // either flag (Settings.cpp's own default substitution only
            // fires when exactly one of the two was explicitly given).
            unsigned int retry_timer_usecs = (mSettings->connect_retry_timer > 0) ? mSettings->connect_retry_timer : 1000000;
            double retry_time_secs = (mSettings->connect_retry_time > 0) ? mSettings->connect_retry_time : 10;
            Timestamp end_exchange_retry;
            end_exchange_retry.add(retry_time_secs);
            Timestamp exchange_done;
            do {
                FD_ZERO(&set);
                FD_SET(mySocket, &set);
                timeout.tv_sec = retry_timer_usecs / 1000000;
                timeout.tv_usec = retry_timer_usecs % 1000000;
                reportstruct->packetLen = SendFirstPayload();
                int selrc = select(mySocket + 1, &set, NULL, NULL, &timeout);
                exchange_done.setnow();
                if (selrc != 0) {
                    break;
                }
            } while (exchange_done.before(end_exchange_retry));
        }

        if (rc != SOCKET_ERROR) connected = true;
    }
    if (connected) {
#if HAVE_TCP_STATS
        assert(reportstruct);
        if (!isUDP(mSettings)) {
            gettcpinfo(mySocket, &mSettings->tcpinitstats);
            if (mSettings->tcpinitstats.isValid) {
                reportstruct->tcpstats = mSettings->tcpinitstats;
            }
        }
#endif
        // Set the send timeout for the very first write which has the test
        // exchange
        getsockname(mySocket, reinterpret_cast<sockaddr *>(&mSettings->local), &mSettings->size_local);
        getpeername(mySocket, reinterpret_cast<sockaddr *>(&mSettings->peer), &mSettings->size_peer);
        SockAddr_Ifrname(mSettings);
#ifdef DEFAULT_PAYLOAD_LEN_PER_MTU_DISCOVERY
        if (isUDP(mSettings) && !isBuflenSet(mSettings)) {
            checksock_max_udp_payload(mSettings);
        }
#endif
        if (isUDP(mSettings) && !isIsochronous(mSettings) && !isIPG(mSettings)) {
            mSettings->mBurstIPG = get_delay_target() / 1e3;  // this is being set for the settings report only
        }
    } else {
        if (mySocket != INVALID_SOCKET) {
            int rc = close(mySocket);
            WARN_errno(rc == SOCKET_ERROR, "client connect close");
            mySocket = INVALID_SOCKET;
        }
    }
    // Post the connect report unless peer version exchange is set
    if (isConnectionReport(mSettings) && !isSumOnly(mSettings)) {
        if (connected) {
            struct ReportHeader *reporthdr = InitConnectionReport(mSettings);
            struct ConnectionInfo *cr = static_cast<struct ConnectionInfo *>(reporthdr->this_report);
            cr->connect_timestamp.tv_sec = connect_start.getSecs();
            cr->connect_timestamp.tv_usec = connect_start.getUsecs();
            assert(reporthdr);
            PostReport(reporthdr);
        } else if (!connect_errno) {
            PostReport(InitConnectionReport(mSettings));
        }
    }
    return connected;
}  // end Connect

bool Client::isConnected() const {
#ifdef HAVE_THREAD_DEBUG
    // thread_debug("Client is connected %d", connected);
#endif
    return connected;
}

void Client::TxDelay() {
    if (isTxHoldback(mSettings)) {
        clock_usleep(&mSettings->txholdback_timer);
    }
}

inline void Client::myReportPacket(void) {
    ReportPacket(myReport, reportstruct);
    reportstruct->packetLen = 0;
}

inline void Client::myReportPacket(struct ReportStruct *reportptr) { ReportPacket(myReport, reportptr); }

#if HAVE_TCP_STATS
inline void Client::mygetTcpInfo(void) {
    reportstruct->tcpstats.isValid = false;
    if (isEnhanced(mSettings) && !isUDP(mSettings) && reportstruct->tcpstats.needTcpInfoSample) {
        gettcpinfo(mySocket, &reportstruct->tcpstats);
        reportstruct->tcpstats.needTcpInfoSample = false;
    }
}
inline int Client::myWrite(int inSock, const void *inBuf, int inLen) {
    mygetTcpInfo();
    return write(inSock, inBuf, inLen);
}
inline int Client::myWriten(int inSock, const void *inBuf, int inLen, int *count) {
    mygetTcpInfo();
    return writen(inSock, inBuf, inLen, count);
}
#else
inline int Client::myWrite(int inSock, const void *inBuf, int inLen) { return write(inSock, inBuf, inLen); }
inline int Client::myWriten(int inSock, const void *inBuf, int inLen, int *count) {
    return writen(inSock, inBuf, inLen, count);
}
#endif

// There are multiple startup synchronizations, this code
// handles them all. The caller decides to apply them
// either before connect() or after connect() and before writes()
int Client::StartSynch() {
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Client start sync enterred");
#endif
    bool delay_test_exchange = (isFullDuplex(mSettings) && isUDP(mSettings));
    if (isTxStartTime(mSettings) && delay_test_exchange) {
        clock_usleep_abstime(&mSettings->txstart_epoch);
    }
    myJob = InitIndividualReport(mSettings);
    myReport = static_cast<struct ReporterData *>(myJob->this_report);
    myReport->info.common->socket = mySocket;
    myReport->info.isEnableTcpInfo = false;  // default here, set in init traffic actions
    markov_graph_len = myReport->info.markov_graph_len;
    if (!isReverse(mSettings) && (mSettings->mReportMode == kReport_CSV)) {
        format_ips_port_string(&myReport->info, 0);
    }

    // Perform delays, usually between connect() and data xfer though before
    // connect Two delays are supported: o First is an absolute start time per
    // unix epoch format o Second is a holdback, a relative amount of seconds
    // between the connect and data xfers check for an epoch based start time
    reportstruct->packetLen = 0;
    if (!isServerReverse(mSettings) && !isCompat(mSettings)) {
        if (!isBounceBack(mSettings) && !(isReverse(mSettings) && isUDP(mSettings))) {
            reportstruct->packetLen = SendFirstPayload();
        }
        if (isTxStartTime(mSettings) && !delay_test_exchange) {
            clock_usleep_abstime(&mSettings->txstart_epoch);
        } else if (isTxHoldback(mSettings)) {
            TxDelay();
        }
        // Server side client
    } else if (isTripTime(mSettings) || isPeriodicBurst(mSettings)) {
        reportstruct->packetLen = SendFirstPayload();
    }
    // Listener-spawned reverse sender (UDP/TCP): isServerReverse skips the block
    // above, so it never slept until --txstart-time; traffic started immediately.
    if (isServerReverse(mSettings) && isTxStartTime(mSettings) && !delay_test_exchange) {
        clock_usleep_abstime(&mSettings->txstart_epoch);
    } else if (isServerReverse(mSettings) && isTxHoldback(mSettings) && !delay_test_exchange) {
        // --txdelay-time's own relay counterpart to the absolute-epoch
        // sleep just above - see HEADER_EPOCH_DELAY's own doc comment
        // (payloads.h). A plain relative sleep, same as TxDelay() does for
        // the client's own local --txdelay-time - mSettings->
        // txholdback_timer was populated from the wire relay
        // (Settings_GenerateClientSettings, Settings.cpp), not from any
        // local CLI parsing on this server-spawned thread.
        clock_usleep(&mSettings->txholdback_timer);
    }
    if (isIsochronous(mSettings) || isPeriodicBurst(mSettings) || isBounceBack(mSettings)) {
        Timestamp tmp;
        if (isTxStartTime(mSettings)) {
            tmp.set(mSettings->txstart_epoch.tv_sec, mSettings->txstart_epoch.tv_usec);
        }
        if (mSettings->mFPS > 0) {
            framecounter = new Isochronous::FrameCounter(mSettings->mFPS, tmp);
            // set the mbuf valid for burst period ahead of time. The same value
            // will be set for all burst writes
            if (!isUDP(mSettings) && framecounter) {
                struct TCP_burst_payload *mBuf_burst = reinterpret_cast<struct TCP_burst_payload *>(mSettings->mBuf);
                mBuf_burst->burst_period_us = htonl(framecounter->period_us());
            }
        }
    }
    int setfullduplexflag = 0;
    if (isFullDuplex(mSettings) && !isServerReverse(mSettings)) {
        assert(mSettings->mFullDuplexReport != NULL);
        if ((setfullduplexflag = fullduplex_start_barrier(&mSettings->mFullDuplexReport->fullduplex_barrier)) < 0)
            return -1;
    }
    SetReportStartTime();
#if HAVE_TCP_STATS
    if (!isUDP(mSettings)) {
        // Near congestion and periodic need sampling on every report packet.
        // Bounceback also sets PeriodicBurst (its request cadence) but wants
        // the per-interval sample below - with a zero nextTCPSampleTime
        // ReportPacket never requests one, leaving its Cwnd/RTT/CE columns
        // empty.
        if ((isNearCongest(mSettings) || isPeriodicBurst(mSettings)) && !isBounceBack(mSettings)) {
            myReport->info.isEnableTcpInfo = true;
            myReport->info.ts.nextTCPSampleTime.tv_sec = 0;
            myReport->info.ts.nextTCPSampleTime.tv_usec = 0;
        } else if (isEnhanced(mSettings) || isBounceBack(mSettings)) {
            myReport->info.isEnableTcpInfo = true;
            myReport->info.ts.nextTCPSampleTime = myReport->info.ts.nextTime;
            // Bounceback's requests land on the interval ticks, so a sample
            // armed at nextTime is taken in the following interval - arm it
            // at start so the first interval gets its own sample too.
            if (isBounceBack(mSettings) && !TimeZero(myReport->info.ts.nextTime)) {
                myReport->info.ts.nextTCPSampleTime = myReport->info.ts.startTime;
            }
        }
    }
#endif

    if (reportstruct->packetLen > 0) {
        reportstruct->err_readwrite = WriteSuccess;
        reportstruct->packetTime = myReport->info.ts.startTime;
        reportstruct->sentTime = reportstruct->packetTime;
        reportstruct->prevSentTime = reportstruct->packetTime;
        reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
        if (isModeAmount(mSettings)) {
            mSettings->mAmount -= reportstruct->packetLen;
        }
        reportstruct->writecnt = 1;
        myReportPacket();
        myReport->info.ts.prevpacketTime = reportstruct->packetTime;
        reportstruct->packetID++;
    }
    if (setfullduplexflag) {
        SetFullDuplexReportStartTime();
    }
    // Full duplex sockets need to be syncronized
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Client start sync exited");
#endif
    return 0;
}

inline void Client::SetFullDuplexReportStartTime() {
    assert(myReport->FullDuplexReport != NULL);
    struct TransferInfo *fullduplexstats = &myReport->FullDuplexReport->info;
    assert(fullduplexstats != NULL);
    if (TimeZero(fullduplexstats->ts.startTime)) {
        fullduplexstats->ts.startTime = myReport->info.ts.startTime;
        if (isModeTime(mSettings)) {
            fullduplexstats->ts.nextTime = myReport->info.ts.nextTime;
        }
    }
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Client fullduplex report start=%ld.%06ld next=%ld.%06ld", fullduplexstats->ts.startTime.tv_sec,
                 fullduplexstats->ts.startTime.tv_usec, fullduplexstats->ts.nextTime.tv_sec,
                 fullduplexstats->ts.nextTime.tv_usec);
#endif
}
inline void Client::SetReportStartTime() {
    assert(myReport != NULL);
    now.setnow();
    if (isUDP(mSettings) && (mSettings->sendfirst_pacing > 0)) {
        now.add(static_cast<unsigned int>(mSettings->sendfirst_pacing));
    }
    myReport->info.ts.startTime.tv_sec = now.getSecs();
    myReport->info.ts.startTime.tv_usec = now.getUsecs();
    myReport->info.ts.prevpacketTime = myReport->info.ts.startTime;
    if (isOmit(mSettings) && (mSettings->mOmitAmount > 0)) {
        myReport->info.ts.omitTime = myReport->info.ts.startTime;
        TimeAddIntUsec(myReport->info.ts.omitTime, mSettings->mOmitAmount);
#if 0
	printf("**** start %ld.%ld omit %ld.%ld\n", myReport->info.ts.startTime.tv_sec, myReport->info.ts.startTime.tv_usec, myReport->info.ts.omitTime.tv_sec, myReport->info.ts.omitTime.tv_usec);
#endif
    }
    if (!TimeZero(myReport->info.ts.intervalTime)) {
        myReport->info.ts.nextTime = myReport->info.ts.startTime;
        TimeAdd(myReport->info.ts.nextTime, myReport->info.ts.intervalTime);
    }
    if (myReport->GroupSumReport) {
        struct TransferInfo *sumstats = &myReport->GroupSumReport->info;
        assert(sumstats != NULL);
        Mutex_Lock(&myReport->GroupSumReport->reference.lock);
        if (TimeZero(sumstats->ts.startTime)) {
            sumstats->ts.startTime = myReport->info.ts.startTime;
            if (mSettings->mIntervalMode == kInterval_Time) {
                sumstats->ts.nextTime = myReport->info.ts.nextTime;
            }
#ifdef HAVE_THREAD_DEBUG
            thread_debug("Client group sum report start=%ld.%06ld next=%ld.%06ld", sumstats->ts.startTime.tv_sec,
                         sumstats->ts.startTime.tv_usec, sumstats->ts.nextTime.tv_sec, sumstats->ts.nextTime.tv_usec);
#endif
            if (isOmit(mSettings) && (mSettings->mOmitAmount > 0)) {
                sumstats->ts.omitTime = myReport->info.ts.omitTime;
#if 0
		printf("**** start %ld.%ld omit %ld.%ld\n", sumstats->ts.startTime.tv_sec, sumstats->ts.startTime.tv_usec, sumstats->ts.omitTime.tv_sec, sumstats->ts.omitTime.tv_usec);
#endif
            }
        }
        Mutex_Unlock(&myReport->GroupSumReport->reference.lock);
    }
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Client(%d) report start/ipg=%ld.%06ld next=%ld.%06ld", mSettings->mSock,
                 myReport->info.ts.startTime.tv_sec, myReport->info.ts.startTime.tv_usec,
                 myReport->info.ts.nextTime.tv_sec, myReport->info.ts.nextTime.tv_usec);
#endif
}

void Client::ConnectPeriodic() {
    Timestamp end;
    Timestamp next;
    unsigned int amount_usec = 1000000;
    if (isModeTime(mSettings)) {
        amount_usec = (mSettings->mAmount * 10000);
        end.add(amount_usec);  // add in micro seconds
    }
    setNoConnectSync(mSettings);
    int num_connects = -1;
    if (!(mSettings->mInterval > 0)) {
        if (mSettings->connectonly_count < 0) {
            num_connects = 10;
        } else if (mSettings->connectonly_count > 0) {
            num_connects = mSettings->connectonly_count;
        }
    }

    do {
        if (my_connect(false)) {
            int rc = close(mySocket);
            WARN_errno(rc == SOCKET_ERROR, "client close");
            mySocket = INVALID_SOCKET;
            mysock_init_done = false;
        }
        if (mSettings->mInterval > 0) {
            now.setnow();
            do {
                next.add(mSettings->mInterval);
            } while (next.before(now));
            if (next.before(end)) {
                struct timeval tmp;
                tmp.tv_sec = next.getSecs();
                tmp.tv_usec = next.getUsecs();
                clock_usleep_abstime(&tmp);
            }
        } else if (isModeTime(mSettings)) {
            next.setnow();
            num_connects = 1;
            //	    printf("***** set now %ld.%ld %ld.%ld\n", next.getSecs(),
            // next.getUsecs(), end.getSecs(), end.getUsecs());
        }
    } while (num_connects-- && !sInterupted && next.before(end));
}
/* -------------------------------------------------------------------
 * Common traffic loop intializations
 * ------------------------------------------------------------------- */
void Client::InitTrafficLoop() {
    //  Enable socket write timeouts for responsive reporting
    //  Do this after the connection establishment
    //  and after Client::InitiateServer as during these
    //  default socket timeouts are preferred.
    int sosndtimer = 0;
    // sosndtimer units microseconds
    // mInterval units are microseconds, mAmount units is 10 ms
    // SetSocketOptionsSendTimeout takes microseconds
    // Set the timeout value to 1/2 the interval (per -i) or 1/2 the -t value
    if (isPeriodicBurst(mSettings) && (mSettings->mFPS > 0.0)) {
        sosndtimer = static_cast<int>(round(250000.0 / mSettings->mFPS));
    } else if ((mSettings->mInterval > 0) && (mSettings->mIntervalMode == kInterval_Time)) {
        sosndtimer = static_cast<int>(round(((mSettings->mThreads > 1) ? 0.25 : 0.5) * mSettings->mInterval));
    } else {
        sosndtimer = static_cast<int>(mSettings->mAmount * 5e3);
    }
    // set to 1 second for wraps or too large
    if ((sosndtimer < 0) || (sosndtimer > 1000000)) {
        sosndtimer = 1000000;
    }
    if (sosndtimer < 1000) {
        sosndtimer = 1000;  // lower bound of 1 ms
    }
    mSettings->sosndtimer = sosndtimer;
    SetSocketOptionsSendTimeout(mSettings, sosndtimer);
    // set the lower bounds delay based of the socket timeout timer
    // units needs to be in nanoseconds
    delay_lower_bounds = static_cast<double>(sosndtimer) * -1e3;

    if (isIsochronous(mSettings)) myReport->info.matchframeID = 1;

    // set the total bytes sent to zero
    totLen = 0;
    if (isModeTime(mSettings)) {
        mEndTime.setnow();
        mEndTime.add(mSettings->mAmount / 100.0);
        // now.setnow(); fprintf(stderr, "DEBUG: end time set to %ld.%06ld now
        // is %ld.%06ld\n", mEndTime.getSecs(), mEndTime.getUsecs(),
        // now.getSecs(), now.getUsecs());
    }
    readAt = mSettings->mBuf;
    lastPacketTime.set(myReport->info.ts.startTime.tv_sec, myReport->info.ts.startTime.tv_usec);
    reportstruct->err_readwrite = WriteSuccess;
    reportstruct->emptyreport = false;
    reportstruct->packetLen = 0;
    // Finally, post this thread's "job report" which the reporter thread
    // will continuously process as long as there are packets flowing
    // right now the ring is empty
    if (!isReverse(mSettings) && !isSingleUDP(mSettings) && isDataReport(mSettings)) {
        assert(myJob != NULL);
        assert(myReport != NULL);
        PostReport(myJob);
    }
    one_report =
        (!isUDP(mSettings) && !isEnhanced(mSettings) && (mSettings->mIntervalMode != kInterval_Time) &&
         !isIsochronous(mSettings) && !isPeriodicBurst(mSettings) && !isTripTime(mSettings) && !isReverse(mSettings));
}

/* -------------------------------------------------------------------
 * Run the appropriate send loop between
 *
 * 1) TCP without rate limiting
 * 2) TCP with rate limiting
 * 3) UDP
 * 4) UDP isochronous w/vbr
 *
 * ------------------------------------------------------------------- */
void Client::Run() {
    // Initialize the report struct scratch pad
    // Peform common traffic setup
    InitTrafficLoop();

    /*
     * UDP
     */
    if (isUDP(mSettings)) {
        if (isFileInput(mSettings)) {
            // Due to the UDP timestamps etc, included
            // reduce the read size by an amount
            // equal to the header size
            Extractor_reduceReadSize(sizeof(struct UDP_datagram), mSettings);
            readAt += sizeof(struct UDP_datagram);
        }
        // Launch the approprate UDP traffic loop
        if (isIsochronous(mSettings)) {
            RunUDPIsochronous();
        } else if (isBurstSize(mSettings)) {
            RunUDPBurst();
#if HAVE_UDP_L4S
        } else if (isBounceBack(mSettings)) {
            // Discrete stop-and-wait bounceback over the UDP-L4S transport -
            // checked before the continuous UDP-L4S dispatch below so it
            // takes this dedicated request/reply path instead of the
            // PragueCC-paced streaming loop.
            RunBounceBackUDP();
        } else if (isUDPL4S(mSettings)) {
            RunUDPL4S();
#endif
#if HAVE_SENDMMSG
        } else if (isSndMMsgs(mSettings)) {
            RunUDPBurstMMSG();
#endif
        } else {
            RunUDP();
        }
    } else {
        // Launch the approprate TCP traffic loop
        if (isBounceBack(mSettings)) {
            RunBounceBackTCP();
        } else if (mSettings->mAppRate > 0) {
            RunRateLimitedTCP();
        } else if (isNearCongest(mSettings)) {
            RunNearCongestionTCP();
#if HAVE_DECL_TCP_NOTSENT_LOWAT
        } else if (isWritePrefetch(mSettings) && !isIsochronous(mSettings) && !isPeriodicBurst(mSettings)) {
            RunWriteEventsTCP();
#endif
        } else {
            RunTCP();
        }
    }
}

/*
 * TCP send loop
 */
void Client::RunTCP() {
    int burst_remaining = 0;
    uint32_t burst_id = 1;
    int writelen = mSettings->mBufLen;

    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    reportstruct->write_time = 0;
#if (HAVE_DECL_SO_MAX_PACING_RATE)
    if (isFQPacingStep(mSettings)) {
        PacingStepTime = now;
        PacingStepTime.add(mSettings->mFQPacingRateStepInterval);
    }
#endif
    while (InProgress()) {
#ifndef WIN32
        // SIGUSR1/SIGUSR2-driven pause - only ever checked for a spawned
        // working-load thread (isWorkingLoadThread), never the main
        // traffic thread, which doesn't have that flag set and so never
        // reaches this branch. Keeps iterating (so InProgress()'s own
        // -t deadline/interrupt check still fires normally) without
        // reaching any write - "continue the loop, skip the writes," not
        // a blocking pause that would ignore the test's own end.
        // PostNullEvent(..., paused=true) - not a bare packetTime refresh
        // - both keeps InProgress()'s own isModeTime check fed a fresh
        // timestamp AND, critically, feeds the Reporter thread's own
        // interval-boundary-crossing logic a well-formed empty report
        // every spin. Skipping that entirely (an earlier version of this
        // branch did) left the Reporter free-running its own periodic
        // interval flush against a ReportStruct this loop never touched
        // for potentially many seconds - confirmed via a real repro to
        // print a corrupted row (epoch-zero timestamp, fields shifted)
        // once an interval boundary was crossed with no real packet event
        // in between. err_readwrite=WritePaused (not WriteNoAccount, what
        // an ordinary idle interval already uses) also makes a
        // deliberately paused interval distinguishable in the CSV output
        // from a genuine backpressure stall or intermittent network
        // outage - both would otherwise show an identical zero-byte
        // interval with no way to tell them apart after the fact.
        if (isWorkingLoadThread(mSettings) && sWorkingLoadPaused) {
            PostNullEvent(false, false, true);
            struct timeval pause_poll = {0, 100000};  // 100ms - avoid busy-spinning while paused
            clock_usleep(&pause_poll);
            continue;
        }
#endif
        reportstruct->writecnt = 0;
        reportstruct->scheduled = false;
        if (isModeAmount(mSettings)) {
            writelen = ((mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                         : mSettings->mBufLen);
        }
        if (isburst && !(burst_remaining > 0)) {
            if (isIsochronous(mSettings)) {
                assert(mSettings->mMean);
                burst_remaining =
                    static_cast<int>(lognormal(mSettings->mMean, mSettings->mVariance)) / (mSettings->mFPS * 8);
            } else if (isBurstSize(mSettings)) {
                assert(mSettings->mBurstSize);
                burst_remaining = mSettings->mBurstSize;
            } else {
                burst_remaining = mSettings->mBufLen;
            }
            // check for TCP minimum payload
            if (burst_remaining < static_cast<int>(sizeof(struct TCP_burst_payload)))
                burst_remaining = static_cast<int>(sizeof(struct TCP_burst_payload));
            // apply scheduling if needed
            if (framecounter) {
                burst_id = framecounter->wait_tick(&reportstruct->sched_err, true);
                reportstruct->scheduled = true;
                if (isPeriodicBurst(mSettings)) {
                    // low duty cycle traffic needs special event handling
                    now.setnow();
                    myReport->info.ts.prevsendTime = reportstruct->packetTime;
                    reportstruct->packetTime.tv_sec = now.getSecs();
                    reportstruct->packetTime.tv_usec = now.getUsecs();
                    if (!InProgress()) {
                        reportstruct->packetLen = 0;
                        reportstruct->emptyreport = true;
                        // wait may have crossed the termination boundry
                        break;
                    } else {
                        // time interval crossings may have occurred during the
                        // wait post a null event to cause the report to flush
                        // the packet ring
                        PostNullEvent(false, false);
                    }
                }
                if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) continue;
            }
            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            WriteTcpTxHdr(reportstruct, burst_remaining, burst_id++);
            reportstruct->sentTime = reportstruct->packetTime;
            myReport->info.ts.prevsendTime = reportstruct->packetTime;
            writelen = (mSettings->mBufLen > burst_remaining) ? burst_remaining : mSettings->mBufLen;
            // perform write, full header must succeed
            if (isTcpWriteTimes(mSettings)) {
                write_start.setnow();
            }
            reportstruct->packetLen = myWriten(mySocket, mSettings->mBuf, writelen, &reportstruct->writecnt);
            FAIL_errno(reportstruct->packetLen < (intmax_t)sizeof(struct TCP_burst_payload), "burst written",
                       mSettings);
            if (isTcpWriteTimes(mSettings)) {
                now.setnow();
                reportstruct->write_time = now.subUsec(write_start);
            }
#if HAVE_TCP_STATS
            // Sampled unconditionally right after this write completes -
            // same "tied directly to the write, not to interval-report
            // boundaries" model trip-times already uses for its own
            // send timestamp above, not the needTcpInfoSample/
            // isEnableTcpInfo machinery the write-enhanced *display*
            // report uses for its own on-screen sampling cadence.
            if (isServerReverse(mSettings) && !isUDP(mSettings)) {
                gettcpinfo(mySocket, &reportstruct->tcpstats);
            }
#endif
        } else {
            // printf("pl=%ld\n",reportstruct->packetLen);
            // perform write
            if (isburst) writelen = (mSettings->mBufLen > burst_remaining) ? burst_remaining : mSettings->mBufLen;
            if (isTcpWriteTimes(mSettings)) {
                write_start.setnow();
            }
            if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) continue;
            reportstruct->packetLen = myWrite(mySocket, mSettings->mBuf, writelen);
            now.setnow();
            reportstruct->writecnt++;
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            if (isTcpWriteTimes(mSettings)) {
                reportstruct->write_time = now.subUsec(write_start);
            }
            reportstruct->sentTime = reportstruct->packetTime;
        }
        if (reportstruct->packetLen <= 0) {
            if (reportstruct->packetLen == 0) {
                reportstruct->err_readwrite = WriteErrFatal;
                peerclose = true;
            } else if (NONFATALTCPWRITERR(errno)) {
                reportstruct->err_readwrite = WriteErrAccount;
            } else if (FATALTCPWRITERR(errno)) {
                reportstruct->err_readwrite = WriteErrFatal;
                now.setnow();
                WARN_REPORT(1, "tcp write");
                break;
            } else {
                reportstruct->err_readwrite = WriteNoAccount;
            }
            reportstruct->packetLen = 0;
            reportstruct->emptyreport = true;
        } else {
            reportstruct->emptyreport = false;
            totLen += reportstruct->packetLen;
            reportstruct->err_readwrite = WriteSuccess;
            if (isburst) {
                burst_remaining -= reportstruct->packetLen;
                if (burst_remaining > 0) {
                    reportstruct->transit_ready = false;
                } else {
                    reportstruct->transit_ready = true;
                    reportstruct->prevSentTime = myReport->info.ts.prevsendTime;
                }
            }
        }
        if (isModeAmount(mSettings) && !reportstruct->emptyreport) {
            /* mAmount may be unsigned, so don't let it underflow! */
            if (mSettings->mAmount >= static_cast<unsigned long>(reportstruct->packetLen)) {
                mSettings->mAmount -= static_cast<unsigned long>(reportstruct->packetLen);
            } else {
                mSettings->mAmount = 0;
            }
        }
        if (!one_report) {
#if (HAVE_DECL_SO_MAX_PACING_RATE)
            if (isFQPacing(mSettings)) {
                socklen_t len = sizeof(reportstruct->FQPacingRate);
                getsockopt(mSettings->mSock, SOL_SOCKET, SO_MAX_PACING_RATE, &reportstruct->FQPacingRate, &len);
                mSettings->mFQPacingRateCurrent = reportstruct->FQPacingRate;
            }
#endif
            myReportPacket();
#if (HAVE_DECL_SO_MAX_PACING_RATE)
            if (isFQPacing(mSettings) && isFQPacingStep(mSettings) && PacingStepTime.before(now)) {
                mSettings->mFQPacingRateCurrent += mSettings->mFQPacingRateStep;
                setsockopt(mSettings->mSock, SOL_SOCKET, SO_MAX_PACING_RATE, &mSettings->mFQPacingRateCurrent,
                           sizeof(mSettings->mFQPacingRateCurrent));
                PacingStepTime.add(mSettings->mFQPacingRateStepInterval);
            }
#endif
        }
    }
    FinishTrafficActions();
}

/*
 * TCP send loop
 */
void Client::RunNearCongestionTCP() {
    int burst_remaining = 0;
    int burst_id = 1;
    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    while (InProgress()) {
        reportstruct->writecnt = 0;
        if (isModeAmount(mSettings)) {
            reportstruct->packetLen =
                ((mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                  : mSettings->mBufLen);
        } else {
            reportstruct->packetLen = mSettings->mBufLen;
        }
        if (!burst_remaining) {
            burst_remaining = mSettings->mBufLen;
            // mAmount check
            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            WriteTcpTxHdr(reportstruct, burst_remaining, burst_id++);
            reportstruct->sentTime = reportstruct->packetTime;
            myReport->info.ts.prevsendTime = reportstruct->packetTime;
            // perform write
            int writelen = (mSettings->mBufLen > burst_remaining) ? burst_remaining : mSettings->mBufLen;
            reportstruct->packetLen = myWrite(mySocket, mSettings->mBuf, writelen);
            reportstruct->writecnt++;
            assert(reportstruct->packetLen >= (intmax_t)sizeof(struct TCP_burst_payload));
            goto ReportNow;
        }
        if (reportstruct->packetLen > burst_remaining) {
            reportstruct->packetLen = burst_remaining;
        }
        // printf("pl=%ld\n",reportstruct->packetLen);
        // perform write
        reportstruct->packetLen = myWrite(mySocket, mSettings->mBuf, reportstruct->packetLen);
        now.setnow();
        reportstruct->writecnt++;
        reportstruct->packetTime.tv_sec = now.getSecs();
        reportstruct->packetTime.tv_usec = now.getUsecs();
        reportstruct->sentTime = reportstruct->packetTime;
    ReportNow:
        reportstruct->transit_ready = false;
        if (reportstruct->packetLen < 0) {
            if (NONFATALTCPWRITERR(errno)) {
                reportstruct->err_readwrite = WriteErrAccount;
            } else if (FATALTCPWRITERR(errno)) {
                reportstruct->err_readwrite = WriteErrFatal;
                WARN_REPORT_errno(1, "tcp write");
                break;
            } else {
                reportstruct->err_readwrite = WriteNoAccount;
            }
            reportstruct->packetLen = 0;
            reportstruct->emptyreport = true;
        } else {
            reportstruct->emptyreport = false;
            totLen += reportstruct->packetLen;
            reportstruct->err_readwrite = WriteSuccess;
            burst_remaining -= reportstruct->packetLen;
            if (burst_remaining <= 0) {
                reportstruct->transit_ready = true;
            }
        }
        if (isModeAmount(mSettings) && !reportstruct->emptyreport) {
            /* mAmount may be unsigned, so don't let it underflow! */
            if (mSettings->mAmount >= static_cast<unsigned long>(reportstruct->packetLen)) {
                mSettings->mAmount -= static_cast<unsigned long>(reportstruct->packetLen);
            } else {
                mSettings->mAmount = 0;
            }
        }
        // apply placing after write burst completes
        if (reportstruct->transit_ready) {
            myReportPacket();  // this will set the tcpstats in the report
                               // struct
            // pacing timer is weighted by the RTT (set to 1 when RTT is not
            // supported)
            int pacing_timer = 0;
#if HAVE_TCP_STATS
            pacing_timer = static_cast<int>(
                std::ceil(static_cast<double>(reportstruct->tcpstats.rtt) * mSettings->rtt_nearcongest_weight_factor));
#else
            pacing_timer = static_cast<int>(100 * mSettings->rtt_nearcongest_weight_factor);
#endif
            if (pacing_timer) delay_loop(pacing_timer);
        }
    }
    FinishTrafficActions();
}

/*
 * A version of the transmit loop that supports TCP rate limiting using a token
 * bucket
 */
void Client::RunRateLimitedTCP() {
    double tokens = 0;
    Timestamp time1, time2;
    int write_remaining = 0;
    int burst_id = 1;

    long var_rate = mSettings->mAppRate;
    int fatalwrite_err = 0;

    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    while (InProgress() && !fatalwrite_err) {
        reportstruct->writecnt = 0;
        // Add tokens per the loop time
        time2.setnow();
        if (isVaryLoad(mSettings)) {
            static Timestamp time3;
            if (time2.subSec(time3) >= VARYLOAD_PERIOD) {
                var_rate = lognormal(mSettings->mAppRate, mSettings->mVariance);
                time3 = time2;
                if (var_rate < 0) var_rate = 0;
            }
        }
        tokens += time2.subSec(time1) * (var_rate / 8.0);
        time1 = time2;
        if (tokens >= 0.0) {
            if (isModeAmount(mSettings)) {
                reportstruct->packetLen =
                    ((mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                      : mSettings->mBufLen);
            } else {
                reportstruct->packetLen = mSettings->mBufLen;
            }
            // perform write
            int len = 0;
            int len2 = 0;

            if (isburst && !(write_remaining > 0)) {
                if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) continue;
                write_remaining = mSettings->mBufLen;
                // check for TCP minimum payload
                if (write_remaining < static_cast<int>(sizeof(struct TCP_burst_payload)))
                    write_remaining = static_cast<int>(sizeof(struct TCP_burst_payload));
                now.setnow();
                reportstruct->packetTime.tv_sec = now.getSecs();
                reportstruct->packetTime.tv_usec = now.getUsecs();
                reportstruct->sentTime = reportstruct->packetTime;
                WriteTcpTxHdr(reportstruct, write_remaining, burst_id++);
                // perform write
                // perform write, full header must succeed
                if (isTcpWriteTimes(mSettings)) {
                    write_start.setnow();
                }
                len = myWriten(mySocket, mSettings->mBuf, write_remaining, &reportstruct->writecnt);
                WARN_REPORT((len < static_cast<int>(sizeof(struct TCP_burst_payload))), "burst hdr write");
                if (isTcpWriteTimes(mSettings)) {
                    now.setnow();
                    reportstruct->write_time = now.subUsec(write_start);
                }
                if (len < 0) {
                    len = 0;
                    if (NONFATALTCPWRITERR(errno)) {
                        reportstruct->err_readwrite = WriteErrAccount;
                    } else if (FATALTCPWRITERR(errno)) {
                        reportstruct->err_readwrite = WriteErrFatal;
                        WARN_REPORT_errno(1, "write");
                        fatalwrite_err = 1;
                        break;
                    } else {
                        reportstruct->err_readwrite = WriteNoAccount;
                    }
                } else {
                    write_remaining -= len;
                }
                // thread_debug("***write burst header %d id=%d", burst_size,
                // (burst_id
                // - 1));
            } else {
                write_remaining = mSettings->mBufLen;
            }
            if (write_remaining > 0) {
                if (isTcpWriteTimes(mSettings)) {
                    write_start.setnow();
                }
                if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) continue;
                len2 = myWrite(mySocket, mSettings->mBuf, write_remaining);
                if (isTcpWriteTimes(mSettings)) {
                    now.setnow();
                    reportstruct->write_time = now.subUsec(write_start);
                }
                reportstruct->writecnt++;
            }
            if (len2 < 0) {
                len2 = 0;
                if (NONFATALTCPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrAccount;
                } else if (FATALTCPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "write");
                    fatalwrite_err = 1;
                    break;
                } else {
                    reportstruct->err_readwrite = WriteNoAccount;
                }
            } else {
                // Consume tokens per the transmit
                tokens -= (len + len2);
                totLen += (len + len2);
                reportstruct->err_readwrite = WriteSuccess;
            }
            time2.setnow();
            reportstruct->packetLen = len + len2;
            reportstruct->packetTime.tv_sec = time2.getSecs();
            reportstruct->packetTime.tv_usec = time2.getUsecs();
            reportstruct->sentTime = reportstruct->packetTime;
            if (isModeAmount(mSettings)) {
                /* mAmount may be unsigned, so don't let it underflow! */
                if (mSettings->mAmount >= static_cast<unsigned long>(reportstruct->packetLen)) {
                    mSettings->mAmount -= static_cast<unsigned long>(reportstruct->packetLen);
                } else {
                    mSettings->mAmount = 0;
                }
            }
            if (!one_report) {
                myReportPacket();
            }
        } else {
            // Use a 4 usec delay to fill tokens
            delay_loop(4);
            if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) {
                continue;
            }
        }
    }
    FinishTrafficActions();
}

inline bool Client::AwaitSelectWrite(void) {
#if HAVE_DECL_TCP_NOTSENT_LOWAT
    do {
        int rc;
        struct timeval timeout;
        fd_set writeset;
        FD_ZERO(&writeset);
        FD_SET(mySocket, &writeset);
        if (isModeTime(mSettings)) {
            Timestamp write_event_timeout(0, 0);
            if (mSettings->mInterval && (mSettings->mIntervalMode == kInterval_Time)) {
                write_event_timeout.add((double)mSettings->mInterval / ((mSettings->mThreads > 1) ? 4e6 : 2e6));
            } else {
                write_event_timeout.add((double)mSettings->mAmount / 4e2);
            }
            timeout.tv_sec = write_event_timeout.getSecs();
            timeout.tv_usec = write_event_timeout.getUsecs();
        } else {
            timeout.tv_sec = 1;  // longest is 1 seconds
            timeout.tv_usec = 0;
        }

        if ((rc = select(mySocket + 1, NULL, &writeset, NULL, &timeout)) <= 0) {
            WARN_REPORT_errno((rc < 0), "select");
            if (rc <= 0) PostNullEvent(false, true);
#if HAVE_SUMMING_DEBUG
            if (rc == 0) {
                WARN_REPORT(1, "Timeout: write select");
            }
#endif
        } else {
            return true;
        }
    } while (InProgress());
    return false;
#else
    return true;
#endif
}

#if HAVE_DECL_TCP_NOTSENT_LOWAT
void Client::RunWriteEventsTCP() {
    int burst_id = 0;
    int writelen = mSettings->mBufLen;
    Timestamp write_end;

    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    // Reset once, before the loop starts - not every iteration (see below) -
    // matching RunTCP()'s own one-time reset ahead of its own while loop.
    reportstruct->write_time = 0;
#if (HAVE_DECL_SO_MAX_PACING_RATE)
    if (isFQPacingStep(mSettings)) {
        PacingStepTime = now;
        PacingStepTime.add(mSettings->mFQPacingRateStepInterval);
    }
#endif
    while (InProgress()) {
#ifndef WIN32
        // SIGUSR1/SIGUSR2-driven pause - see RunTCP's own copy of this
        // check for the full doc comment. This is the separate write-
        // prefetch (TCP_NOTSENT_LOWAT) event-driven write loop
        // client_init's working-load spawn unconditionally opts every
        // working-load thread into (Launch.cpp's own setWritePrefetch(next)
        // under HAVE_DECL_TCP_NOTSENT_LOWAT) - RunTCP's own copy of this
        // check only ever fires for a working-load thread on a platform
        // without that declaration, so both need it.
        if (isWorkingLoadThread(mSettings) && sWorkingLoadPaused) {
            PostNullEvent(false, false, true);
            struct timeval pause_poll = {0, 100000};  // 100ms - avoid busy-spinning while paused
            clock_usleep(&pause_poll);
            continue;
        }
#endif
#if HAVE_DECL_TCP_TX_DELAY
        //	apply_txdelay_func();
#endif
        if (isModeAmount(mSettings)) {
            writelen = ((mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                         : mSettings->mBufLen);
        }
        now.setnow();
        // Deliberately NOT reset to 0 here every iteration (unlike writecnt
        // below) - WriteTcpTxHdr(), called further down before this write
        // has even happened, relays reportstruct->write_time as-is for the
        // server's reverse-mode writer (see that function's own doc
        // comment) - resetting it here first made every relayed sample 0
        // (never a real measured value), so the reader's write_mmm never
        // accumulated any and always showed -1. Carrying the previous
        // write's real value forward until this write's own measurement
        // overwrites it below is the same one-sample-lagged convention
        // already used for tcpstats/cwnd/rtt's own relay.
        reportstruct->writecnt = 0;
        if (isTcpWriteTimes(mSettings)) {
            write_start = now;
        }
        if (isWritePrefetch(mSettings) && !AwaitSelectWrite()) continue;
        if (!reportstruct->emptyreport) {
            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            WriteTcpTxHdr(reportstruct, writelen, ++burst_id);
            reportstruct->sentTime = reportstruct->packetTime;
            reportstruct->packetLen = myWriten(mySocket, mSettings->mBuf, writelen, &reportstruct->writecnt);
            if (reportstruct->packetLen <= 0) {
                WARN_REPORT_errno((reportstruct->packetLen < 0), "event writen()");
                if (reportstruct->packetLen == 0) {
                    peerclose = true;
                }
                reportstruct->packetLen = 0;
                reportstruct->emptyreport = true;
            } else if (isTcpWriteTimes(mSettings)) {
                write_end.setnow();
                reportstruct->write_time = write_end.subUsec(write_start);
            }
#if HAVE_TCP_STATS
            // See the identical block in RunTCP()'s burst branch - this is
            // the write-prefetch (TCP_NOTSENT_LOWAT) event-driven write
            // loop, a completely separate code path from RunTCP(), so it
            // needs its own copy of the same unconditional post-write
            // sample for WriteTcpTxHdr to relay to the reader.
            if (isServerReverse(mSettings) && !isUDP(mSettings)) {
                gettcpinfo(mySocket, &reportstruct->tcpstats);
            }
#endif
        }
        if (isModeAmount(mSettings) && !reportstruct->emptyreport) {
            /* mAmount may be unsigned, so don't let it underflow! */
            if (mSettings->mAmount >= static_cast<unsigned long>(reportstruct->packetLen)) {
                mSettings->mAmount -= static_cast<unsigned long>(reportstruct->packetLen);
            } else {
                mSettings->mAmount = 0;
            }
        }
        if (!one_report) {
#if (HAVE_DECL_SO_MAX_PACING_RATE)
            if (isFQPacing(mSettings)) {
                socklen_t len = sizeof(reportstruct->FQPacingRate);
                getsockopt(mSettings->mSock, SOL_SOCKET, SO_MAX_PACING_RATE, &reportstruct->FQPacingRate, &len);
                mSettings->mFQPacingRateCurrent = reportstruct->FQPacingRate;
            }
#endif
            myReportPacket();
#if (HAVE_DECL_SO_MAX_PACING_RATE)
            if (isFQPacing(mSettings) && isFQPacingStep(mSettings) && PacingStepTime.before(now)) {
                mSettings->mFQPacingRateCurrent += mSettings->mFQPacingRateStep;
                setsockopt(mSettings->mSock, SOL_SOCKET, SO_MAX_PACING_RATE, &mSettings->mFQPacingRateCurrent,
                           sizeof(mSettings->mFQPacingRateCurrent));
                PacingStepTime.add(mSettings->mFQPacingRateStepInterval);
            }
#endif
        }
    }
    FinishTrafficActions();
}
#endif
void Client::RunBounceBackTCP() {
    int burst_id = 0;
    // Tracks whether the one-time permit-key handshake has already gone
    // out on this connection - burst_id alone can't tell us that. burst_id
    // is the *scheduling tick* (which 1-second window we're in), reused
    // unchanged across every inner-loop send within that same tick (see
    // the "(burst_id == 1)" checks below), so a tick whose burst count
    // (--bounceback-burst, default >1) sends more than one request would
    // otherwise resend the key on every one of them, not just the very
    // first request of the whole connection - corrupting the stream by
    // inserting extra bytes into what the server expects to be a plain
    // bbsize-counted bounce, compounding with each spurious resend until
    // the connection desyncs and resets a few intervals in.
    bool permitKeySent = false;
    // Same one-shot-per-connection reasoning as permitKeySent above -
    // --tcp-cca is a connection-level setting, not a per-request one, so
    // the CCA suffix (see WriteTcpTxBBHdr/HEADER_BBCCA) only needs to go
    // out once, on the very first request.
    bool ccaSent = false;
    int writelen = mSettings->mBounceBackBytes;
    memset(mSettings->mBuf, 0x5A, sizeof(struct bounceback_hdr));
    if (mSettings->mInterval && (mSettings->mIntervalMode == kInterval_Time)) {
        int sotimer = static_cast<int>(round(mSettings->mInterval / 2.0));
        SetSocketOptionsReceiveTimeout(mSettings, sotimer);
        SetSocketOptionsSendTimeout(mSettings, sotimer);
    } else if (isModeTime(mSettings)) {
        int sotimer = static_cast<int>(round(mSettings->mAmount * 10000) / 2);
        SetSocketOptionsReceiveTimeout(mSettings, sotimer);
        SetSocketOptionsSendTimeout(mSettings, sotimer);
    }
    if (isModeTime(mSettings)) {
        uintmax_t end_usecs = (mSettings->mAmount * 10000);
        if (int err = set_itimer(end_usecs)) {
            FAIL_errno(err != 0, "setitimer", mSettings);
        }
    }
    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    while (InProgress()) {
        int n;
        long remaining;
        reportstruct->writecnt = 0;
        bool isFirst;
        if (framecounter) {
            burst_id = framecounter->wait_tick(&reportstruct->sched_err, false);
            PostNullEvent(true, false);  // now is set in this call
            reportstruct->sentTime.tv_sec = now.getSecs();
            reportstruct->sentTime.tv_usec = now.getUsecs();
            isFirst = true;
        } else {
            burst_id++;
            isFirst = false;
        }
        int bb_burst = (mSettings->mBounceBackBurst > 0) ? mSettings->mBounceBackBurst : 1;
        while ((bb_burst > 0) && InProgress() &&
               (!framecounter || (framecounter->get(&remaining)) == (unsigned int)burst_id)) {
            bb_burst--;
            if (isFirst) {
                isFirst = false;
            } else {
                now.setnow();
                reportstruct->sentTime.tv_sec = now.getSecs();
                reportstruct->sentTime.tv_usec = now.getUsecs();
            }
            const bool sendKeyThisWrite = !permitKeySent && isPermitKey(mSettings) && (mSettings->mPermitKey[0] != '\0');
            const bool sendCcaThisWrite = !ccaSent && isCongestionControl(mSettings);
            WriteTcpTxBBHdr(reportstruct, burst_id, 0, sendKeyThisWrite, sendCcaThisWrite);
            int write_offset = 0;
            reportstruct->writecnt = 0;
            reportstruct->writeLen = 0;
            reportstruct->recvLen = 0;
        RETRY_WRITE:
            n = myWriten(mySocket, (mSettings->mBuf + write_offset), (writelen - write_offset),
                         &reportstruct->writecnt);
            if (n < 0) {
                if (FATALTCPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "tcp bounceback write fatal error");
                    peerclose = true;
                    break;
                } else if (InProgress()) {
                    PostNullEvent(false, false);
                    goto RETRY_WRITE;
                }
            }
            write_offset += n;
            if ((write_offset < writelen) && InProgress()) {
                WARN_REPORT_errno(1, "tcp bounceback writen incomplete");
                PostNullEvent(false, false);
                goto RETRY_WRITE;
            }
            if (write_offset == writelen) {
                reportstruct->emptyreport = false;
                totLen += writelen;
                reportstruct->err_readwrite = WriteSuccess;
#if HAVE_DECL_TCP_QUICKACK
                if (isTcpQuickAck(mSettings)) {
                    int opt = 1;
                    Socklen_t len = sizeof(opt);
                    int rc = setsockopt(mySocket, IPPROTO_TCP, TCP_QUICKACK, reinterpret_cast<char *>(&opt), len);
                    WARN_REPORT_errno(rc == SOCKET_ERROR, "setsockopt TCP_QUICKACK");
                }
#endif
                reportstruct->writeLen = writelen;
                if (sendKeyThisWrite) {
                    // One-time permit-key handshake, sent as a separate
                    // write immediately following the first bounce's own
                    // bbsize-counted bytes - deliberately NOT part of
                    // writelen/bbsize itself, so server->mBounceBackBytes
                    // and the remaining-payload math Listener.cpp/Server.cpp
                    // use for every OTHER bounce round trip stay unaffected.
                    // Same permitKey wire format every other test type uses
                    // (Settings_GenerateClientHdr): a 2-byte network-order
                    // length prefix followed by the raw key bytes. See
                    // WriteTcpTxBBHdr's HEADER_KEYCHECK flag (just written,
                    // above) and Listener.cpp's matching read. Gated on
                    // sendKeyThisWrite (computed once, above) rather than
                    // re-deriving "is this the first request" from burst_id
                    // here too - see permitKeySent's own doc comment for why
                    // that would resend the key on every request in a
                    // multi-request burst instead of just the first ever.
                    char wirekey[MAX_PERMITKEY_LEN + 1];
                    build_permit_key_wire_value(wirekey, sizeof(wirekey), mSettings->mPermitKey, isPermitKeyHmac(mSettings));
                    uint16_t keylen = static_cast<uint16_t>(strnlen(wirekey, MAX_PERMITKEY_LEN));
                    char keybuf[sizeof(uint16_t) + MAX_PERMITKEY_LEN];
                    uint16_t keylen_be = htons(keylen);
                    memcpy(keybuf, &keylen_be, sizeof(keylen_be));
                    memcpy(keybuf + sizeof(keylen_be), wirekey, keylen);
                    int keybytes = static_cast<int>(sizeof(keylen_be)) + keylen;
                    int keywritecnt = 0;
                    int kn = myWriten(mySocket, keybuf, keybytes, &keywritecnt);
                    if (kn != keybytes) {
                        WARN_REPORT_errno(1, "tcp bounceback permit-key write");
                        peerclose = true;
                        break;
                    }
                    permitKeySent = true;
                }
                if (sendCcaThisWrite) {
                    // Same external-suffix convention as the permit-key
                    // write just above (and gated the same way, via
                    // sendCcaThisWrite/ccaSent - see that variable's own
                    // doc comment) - a 2-byte network-order length prefix
                    // followed by the raw CCA name bytes, read by
                    // Listener.cpp's matching HEADER_BBCCA branch.
                    uint16_t ccalen = static_cast<uint16_t>(strnlen(mSettings->mCongestion, TCP_CCA_NAME_MAX - 1));
                    char ccabuf[sizeof(uint16_t) + TCP_CCA_NAME_MAX];
                    uint16_t ccalen_be = htons(ccalen);
                    memcpy(ccabuf, &ccalen_be, sizeof(ccalen_be));
                    memcpy(ccabuf + sizeof(ccalen_be), mSettings->mCongestion, ccalen);
                    int ccabytes = static_cast<int>(sizeof(ccalen_be)) + ccalen;
                    int ccawritecnt = 0;
                    int ccan = myWriten(mySocket, ccabuf, ccabytes, &ccawritecnt);
                    if (ccan != ccabytes) {
                        WARN_REPORT_errno(1, "tcp bounceback cca write");
                        peerclose = true;
                        break;
                    }
                    ccaSent = true;
                }
                int read_offset = 0;
            RETRY_READ:
                n = recvn(mySocket, (mSettings->mBuf + read_offset), (mSettings->mBounceBackReplyBytes - read_offset),
                          0);
                if (n > 0) {
                    read_offset += n;
                    if (read_offset == mSettings->mBounceBackReplyBytes) {
                        struct bounceback_hdr *bbhdr = reinterpret_cast<struct bounceback_hdr *>(mSettings->mBuf);
                        now.setnow();
                        reportstruct->sentTimeRX.tv_sec = ntohl(bbhdr->bbserverRx_ts.sec);
                        reportstruct->sentTimeRX.tv_usec = ntohl(bbhdr->bbserverRx_ts.usec);
                        reportstruct->sentTimeTX.tv_sec = ntohl(bbhdr->bbserverTx_ts.sec);
                        reportstruct->sentTimeTX.tv_usec = ntohl(bbhdr->bbserverTx_ts.usec);
                        reportstruct->packetTime.tv_sec = now.getSecs();
                        reportstruct->packetTime.tv_usec = now.getUsecs();
                        reportstruct->recvLen = mSettings->mBounceBackReplyBytes;
                        reportstruct->packetLen = reportstruct->writeLen + reportstruct->recvLen;
                        reportstruct->emptyreport = false;
                        reportstruct->packetID = burst_id;
                        myReportPacket();
                    } else if (InProgress()) {
                        PostNullEvent(false, false);
                        goto RETRY_READ;
                    } else {
                        break;
                    }
                } else if (n == 0) {
                    peerclose = true;
                    break;
                } else {
                    if (FATALTCPREADERR(errno)) {
                        FAIL_errno(1, "fatal bounceback read", mSettings);
                        peerclose = true;
                        break;
                    } else {
                        WARN_REPORT_errno(1, "timeout: bounceback read");
                        PostNullEvent(false, false);
                        if (InProgress()) goto RETRY_READ;
                    }
                }
            }
        }
    }
    if (!peerclose) WriteTcpTxBBHdr(reportstruct, 0x0, 1, false, false);  // Signal end of BB test
    FinishTrafficActions();
}

#if HAVE_UDP_L4S
// Discrete stop-and-wait UDP-L4S bounceback - same RPS measurement as
// RunBounceBackTCP above, but the request/reply round trip is one
// ECT(1)-marked UDP datagram each way (writemsg_delay_tos()) instead of a
// TCP byte stream, so it can be A/B compared directly against TCP
// bounceback. See struct bounceback_udp_hdr's own doc comment
// (include/payloads.h) for the wire-format deltas from TCP bounceback.
inline int Client::ReadUdpBBReplyWithRxTos(u_char &rxtos) {
    int n;
    rxtos = 0;
#if (HAVE_DECL_SO_TIMESTAMP) && (HAVE_DECL_MSG_CTRUNC)
    struct iovec iov[1];
    struct msghdr message;
    char ctrl[CMSG_SPACE(sizeof(u_char))];
    iov[0].iov_base = mSettings->mBuf;
    iov[0].iov_len = mSettings->mBufLen;
    memset(&message, 0, sizeof(message));
    memset(ctrl, 0, sizeof(ctrl));
    message.msg_iov = iov;
    message.msg_iovlen = 1;
    message.msg_control = ctrl;
    message.msg_controllen = sizeof(ctrl);
    n = recvmsg(mySocket, &message, 0);
    if ((n > 0) && !(message.msg_flags & MSG_CTRUNC)) {
        for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(&message); cmsg != NULL; cmsg = CMSG_NXTHDR(&message, cmsg)) {
            if (cmsg->cmsg_level == IPPROTO_IP && cmsg->cmsg_type == IP_TOS &&
                cmsg->cmsg_len == CMSG_LEN(sizeof(u_char))) {
                memcpy(&rxtos, CMSG_DATA(cmsg), sizeof(u_char));
            }
        }
    }
#else
    // Platform can't retrieve the reply's IP_TOS via cmsg - the round trip
    // itself still works fine, only CE-mark accounting stays at zero (same
    // "no relay yet" fallback the continuous UDP-L4S path uses elsewhere).
    n = recv(mySocket, mSettings->mBuf, mSettings->mBufLen, 0);
#endif
    return n;
}

void Client::RunBounceBackUDP() {
    uint32_t burst_id = 0;
    // Same one-shot-per-connection reasoning as RunBounceBackTCP's own
    // permitKeySent - see that variable's doc comment. No CCA-suffix
    // equivalent here: --tcp-cca is a TCP-only concept, not applicable to
    // the UDP-L4S bounceback transport (Settings.cpp WARNs and unsets it).
    bool permitKeySent = false;
    // One-shot guards, not counters - each logged (PostReport, Reporter
    // thread) the first time observed, never again this connection. See
    // HEADER_BBREQ_BLEACHED's own doc comment (payloads.h) for the
    // reasoning on why these exist at all and why they're not CSV/counted
    // stats.
    bool ceEverLogged = false;
    bool replyBleachLogged = false;
    bool reqBleachLogged = false;
    bool replyConfirmedLogged = false;
    bool reqConfirmedLogged = false;
    // Same one-shot reasoning as the flags above for the immediate
    // detection message (see the RETRY_READ bbid check below) - a
    // stale-reply discard is an expected, routine consequence of loss/
    // reordering under real congestion, not a rare anomaly, so logging
    // every occurrence would spam the output for little added value once
    // the condition itself is known to be happening at all. Unlike the
    // pure bools above, this one doubles as a real running count (every
    // discard increments it, not just the first) so the end-of-run
    // summary below can report a total, not just "it happened".
    uint32_t staleReplyCount = 0;
    int writelen = mSettings->mBounceBackBytes;
    // Per-direction loss attribution running totals - see struct
    // ReportStruct's own doc comment (packet_ring.h) for the full
    // reasoning and PostNullEvent's own doc comment for how these reach
    // the reporter thread even on a run that ends on a string of losses.
    uint32_t bbRequestsSent = 0;
    uint32_t bbRepliesReceived = 0;
    uint32_t bbServerReceivedCount = 0;
    memset(mSettings->mBuf, 0x5A, sizeof(struct bounceback_udp_hdr));
    SetSocketOptionsIPRCVTos(mSettings);
    if (mSettings->mInterval && (mSettings->mIntervalMode == kInterval_Time)) {
        int sotimer = static_cast<int>(round(mSettings->mInterval / 2.0));
        SetSocketOptionsReceiveTimeout(mSettings, sotimer);
        SetSocketOptionsSendTimeout(mSettings, sotimer);
    } else if (isModeTime(mSettings)) {
        int sotimer = static_cast<int>(round(mSettings->mAmount * 10000) / 2);
        SetSocketOptionsReceiveTimeout(mSettings, sotimer);
        SetSocketOptionsSendTimeout(mSettings, sotimer);
    }
    if (isModeTime(mSettings)) {
        uintmax_t end_usecs = (mSettings->mAmount * 10000);
        if (int err = set_itimer(end_usecs)) {
            FAIL_errno(err != 0, "setitimer", mSettings);
        }
    }
    now.setnow();
    reportstruct->packetTime.tv_sec = now.getSecs();
    reportstruct->packetTime.tv_usec = now.getUsecs();
    while (InProgress()) {
        long remaining;
        reportstruct->writecnt = 0;
        bool isFirst;
        if (framecounter) {
            burst_id = framecounter->wait_tick(&reportstruct->sched_err, false);
            PostNullEvent(true, false);  // now is set in this call
            reportstruct->sentTime.tv_sec = now.getSecs();
            reportstruct->sentTime.tv_usec = now.getUsecs();
            isFirst = true;
        } else {
            burst_id++;
            isFirst = false;
        }
        int bb_burst = (mSettings->mBounceBackBurst > 0) ? mSettings->mBounceBackBurst : 1;
        while ((bb_burst > 0) && InProgress() &&
               (!framecounter || (framecounter->get(&remaining)) == (unsigned int)burst_id)) {
            bb_burst--;
            if (isFirst) {
                isFirst = false;
            } else {
                now.setnow();
                reportstruct->sentTime.tv_sec = now.getSecs();
                reportstruct->sentTime.tv_usec = now.getUsecs();
            }
            const bool sendKeyThisWrite = !permitKeySent && isPermitKey(mSettings) && (mSettings->mPermitKey[0] != '\0');
            WriteUdpTxBBHdr(reportstruct, burst_id, 0, sendKeyThisWrite);
            int sendlen = writelen;
            if (sendKeyThisWrite) {
                // Unlike TCP bounceback's separate suffix write, the whole
                // request (header + payload + key) is one datagram - append
                // the same 2-byte network-order length + key bytes suffix
                // right after this request's own bbsize-counted bytes, only
                // on the connection's first request (see permitKeySent).
                char wirekey[MAX_PERMITKEY_LEN + 1];
                build_permit_key_wire_value(wirekey, sizeof(wirekey), mSettings->mPermitKey, isPermitKeyHmac(mSettings));
                uint16_t keylen = static_cast<uint16_t>(strnlen(wirekey, MAX_PERMITKEY_LEN));
                int keybytes = static_cast<int>(sizeof(uint16_t)) + keylen;
                if ((writelen + keybytes) <= mSettings->mBufLen) {
                    uint16_t keylen_be = htons(keylen);
                    memcpy(mSettings->mBuf + writelen, &keylen_be, sizeof(keylen_be));
                    memcpy(mSettings->mBuf + writelen + sizeof(keylen_be), wirekey, keylen);
                    sendlen += keybytes;
                    permitKeySent = true;
                } else {
                    WARN_REPORT(1, "udp bounceback permit-key too large for buffer, not sent");
                    permitKeySent = true;  // don't keep retrying every request
                }
            }
            reportstruct->writecnt = 0;
            reportstruct->writeLen = 0;
            reportstruct->recvLen = 0;
            // ECT(1) only under --udp-l4s, same conditional as RunUDPL4S's
            // own write path above - plain -u/--udp (no --udp-l4s) leaves
            // the wire unmarked, so a congested L4S-capable queue has only
            // drop, not CE-marking, as a signal for this run. Lets the two
            // be A/B compared against the same path (loss/tail latency
            // with marking off vs. ce/ceperc absorbing congestion with it
            // on) rather than L4S marking being an unconditional part of
            // Bounceback-over-UDP.
            u_char tos = isUDPL4S(mSettings) ? ((mSettings->mTOS & 0xFC) | ecn_l4s_id) : mSettings->mTOS;
            int n = writemsg_delay_tos(mySocket, mSettings->mBuf, sendlen, 0, tos);
            if (n <= 0) {
                if (n == 0) {
                    reportstruct->err_readwrite = WriteTimeo;
                    WARN_REPORT(1, "timeout: udp bounceback write");
                } else if (FATALUDPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "udp bounceback write fatal error");
                    peerclose = true;
                    break;
                } else {
                    reportstruct->err_readwrite = WriteErrAccount;
                    WARN_REPORT_errno(1, "udp bounceback write");
                }
                PostNullEvent(false, false);
                continue;
            }
            reportstruct->emptyreport = false;
            totLen += writelen;
            reportstruct->err_readwrite = WriteSuccess;
            reportstruct->writeLen = writelen;
            reportstruct->writecnt = 1;
            bbRequestsSent++;
            reportstruct->bbRequestsSent = bbRequestsSent;
            reportstruct->bbRepliesReceived = bbRepliesReceived;
            reportstruct->bbServerReceivedCount = bbServerReceivedCount;
            // Read the reply, capturing its CE mark via IP_TOS cmsg directly
            // - vanilla L4S: this stop-and-wait client is both writer and
            // reader of the same round trip, so it can read the CE mark on
            // the reply itself, no server-side relay/extension needed
            // (unlike the continuous UDP-L4S stream's writer role, which
            // never reads its own traffic and needs the peer to echo CE
            // counts back in the ACK payload - see Client::RunUDPL4S).
            u_char rxtos;
        RETRY_READ:
            n = ReadUdpBBReplyWithRxTos(rxtos);
            if (n == static_cast<int>(mSettings->mBounceBackReplyBytes)) {
                struct bounceback_udp_hdr *bbhdr = reinterpret_cast<struct bounceback_udp_hdr *>(mSettings->mBuf);
                // Discard a reply that doesn't answer *this* request. A UDP
                // reply can arrive late enough to miss its own read's
                // timeout (the genuine-timeout branch below already gives
                // up on a request's reply rather than stalling, per its own
                // doc comment) and still land in the kernel receive queue
                // afterward. Without this check, the *next* request's own
                // read call picks up that stale datagram instead of waiting
                // for its actual reply, pairing a just-sent sentTime with a
                // reply that was already in flight before this request even
                // existed - the computed "RTT" then measures however long
                // the stale packet had left to arrive, not a real round
                // trip, which can be arbitrarily (and implausibly) small.
                // Confirmed via a real repro: a raw log showing sub-100us
                // bbmin alongside frequent read timeouts, RPS reported in
                // the hundreds against a real WAN path. Same discard-and
                // retry pattern as the wrong-size branch below (bounded by
                // InProgress() and each retry's own read timeout) rather
                // than accepting it under the wrong burst_id - draining
                // every stale reply already queued either finds the one
                // that actually answers this request or correctly times
                // out, instead of silently mis-pairing.
                if (ntohl(bbhdr->bbid) != burst_id) {
                    // WARN_REPORT, not WARN() - see that macro's own doc
                    // comment (util.h) for why a direct fprintf has no
                    // place in this loop. Only the first occurrence gets
                    // an immediate message - every occurrence (including
                    // the first) still counts toward the end-of-run total
                    // printed once at teardown below.
                    WARN_REPORT(!staleReplyCount, "udp bounceback reply id mismatch, discarding stale reply");
                    staleReplyCount++;
                    PostNullEvent(false, false);
                    if (InProgress()) goto RETRY_READ;
                } else {
                now.setnow();
                reportstruct->sentTimeRX.tv_sec = ntohl(bbhdr->bbserverRx_ts.sec);
                reportstruct->sentTimeRX.tv_usec = ntohl(bbhdr->bbserverRx_ts.usec);
                reportstruct->sentTimeTX.tv_sec = ntohl(bbhdr->bbserverTx_ts.sec);
                reportstruct->sentTimeTX.tv_usec = ntohl(bbhdr->bbserverTx_ts.usec);
                reportstruct->packetTime.tv_sec = now.getSecs();
                reportstruct->packetTime.tv_usec = now.getUsecs();
                reportstruct->recvLen = mSettings->mBounceBackReplyBytes;
                reportstruct->packetLen = reportstruct->writeLen + reportstruct->recvLen;
                reportstruct->emptyreport = false;
                reportstruct->packetID = burst_id;
                reportstruct->ce_count = (((rxtos & 0x03) == ecn_ce) ? 1 : 0);
                // Five one-shot, un-counted signals (see this function's own
                // local ceEverLogged/replyBleachLogged/reqBleachLogged/
                // replyConfirmedLogged/reqConfirmedLogged doc comment above,
                // and HEADER_BBREQ_BLEACHED/HEADER_BBREQ_CONFIRMED's,
                // payloads.h) - each posted at most once per connection via
                // the Reporter thread, never a raw stat. CE confirms the
                // path's queue is genuinely applying L4S marks (no negative
                // counterpart - absence doesn't confirm anything, see that
                // flag's own doc comment, IperfViewModel.kt). Each direction
                // gets exactly one of confirmed-intact or bleached logged,
                // never both - a direction with no clean read yet logs
                // neither, which the app renders as "no icon" rather than
                // conflating it with either affirmative or negative.
                if (isUDPL4S(mSettings) && (reportstruct->ce_count > 0) && !ceEverLogged) {
                    ceEverLogged = true;
                    int len = snprintf(NULL, 0, "%sL4S CE marking confirmed - this path's queue is applying congestion marks\n",
                                       mSettings->mTransferIDStr);
                    char *text = (char *)calloc(len + 1, sizeof(char));
                    if (text) {
                        snprintf(text, len, "%sL4S CE marking confirmed - this path's queue is applying congestion marks\n",
                                 mSettings->mTransferIDStr);
                        PostReport(InitStringReport(text));
                        FREE_ARRAY(text);
                    }
                }
                if (isUDPL4S(mSettings)) {
                    if (((rxtos & 0x03) == ecn_not_ect) && !replyBleachLogged) {
                        replyBleachLogged = true;
                        int len = snprintf(NULL, 0, "%sL4S reply-direction ECN bleaching detected (server marked ECT(1), arrived Not-ECT)\n",
                                           mSettings->mTransferIDStr);
                        char *text = (char *)calloc(len + 1, sizeof(char));
                        if (text) {
                            snprintf(text, len, "%sL4S reply-direction ECN bleaching detected (server marked ECT(1), arrived Not-ECT)\n",
                                     mSettings->mTransferIDStr);
                            PostReport(InitStringReport(text));
                            FREE_ARRAY(text);
                        }
                    } else if (((rxtos & 0x03) != ecn_not_ect) && !replyConfirmedLogged) {
                        replyConfirmedLogged = true;
                        int len = snprintf(NULL, 0, "%sL4S reply-direction ECN confirmed intact (server marked ECT(1), arrived unmolested)\n",
                                           mSettings->mTransferIDStr);
                        char *text = (char *)calloc(len + 1, sizeof(char));
                        if (text) {
                            snprintf(text, len, "%sL4S reply-direction ECN confirmed intact (server marked ECT(1), arrived unmolested)\n",
                                     mSettings->mTransferIDStr);
                            PostReport(InitStringReport(text));
                            FREE_ARRAY(text);
                        }
                    }
                    uint16_t replyBbflags = ntohs(bbhdr->bbflags);
                    if (((replyBbflags & HEADER_BBREQ_BLEACHED) != 0) && !reqBleachLogged) {
                        reqBleachLogged = true;
                        int len = snprintf(NULL, 0, "%sL4S request-direction ECN bleaching detected (server received your request as Not-ECT)\n",
                                           mSettings->mTransferIDStr);
                        char *text = (char *)calloc(len + 1, sizeof(char));
                        if (text) {
                            snprintf(text, len, "%sL4S request-direction ECN bleaching detected (server received your request as Not-ECT)\n",
                                     mSettings->mTransferIDStr);
                            PostReport(InitStringReport(text));
                            FREE_ARRAY(text);
                        }
                    } else if (((replyBbflags & HEADER_BBREQ_CONFIRMED) != 0) && !reqConfirmedLogged) {
                        reqConfirmedLogged = true;
                        int len = snprintf(NULL, 0, "%sL4S request-direction ECN confirmed intact (server received your request unmolested)\n",
                                           mSettings->mTransferIDStr);
                        char *text = (char *)calloc(len + 1, sizeof(char));
                        if (text) {
                            snprintf(text, len, "%sL4S request-direction ECN confirmed intact (server received your request unmolested)\n",
                                     mSettings->mTransferIDStr);
                            PostReport(InitStringReport(text));
                            FREE_ARRAY(text);
                        }
                    }
                }
                bbRepliesReceived++;
                bbServerReceivedCount = ntohl(bbhdr->bbRequestsRx);
                reportstruct->bbRequestsSent = bbRequestsSent;
                reportstruct->bbRepliesReceived = bbRepliesReceived;
                reportstruct->bbServerReceivedCount = bbServerReceivedCount;
                myReportPacket();
                }
            } else if (n < 0) {
                if (FATALUDPREADERR(errno)) {
                    FAIL_errno(1, "fatal udp bounceback read", mSettings);
                    peerclose = true;
                } else if (errno == EINTR) {
                    // A blocking read interrupted mid-wait by a signal -
                    // almost always this thread's own one-shot end-of-test
                    // SIGALRM (set_itimer() above) landing right as the
                    // last reply was still in flight, not a real read
                    // failure - the read timeout socket option would
                    // surface as EAGAIN/EWOULDBLOCK below instead, so
                    // nothing was actually lost or slow here. Retry
                    // silently (or fall through to the loop's own exit via
                    // InProgress() going false) rather than warning.
                    PostNullEvent(false, false);
                    if (InProgress()) goto RETRY_READ;
                } else {
                    // Genuine read timeout (EAGAIN/EWOULDBLOCK) - this
                    // specific request's reply never showed up. Bounded
                    // give-up: no retransmission, no re-poll of the same
                    // read. Post the loss event (carrying the latest known
                    // bbRequestsSent/bbRepliesReceived/bbServerReceivedCount
                    // on reportstruct, set at write-time and last-reply-time
                    // above) and fall through to the outer loop's next
                    // request, so one lost datagram costs one round trip's
                    // worth of time instead of stalling the rest of the run.
                    WARN_REPORT_errno(1, "timeout: udp bounceback read");
                    PostNullEvent(false, false);
                }
            } else {
                // zero-length or short/mis-sized datagram - not a valid
                // reply (e.g. a stray late packet), retry the read
                WARN_REPORT(1, "udp bounceback read wrong size, retrying");
                PostNullEvent(false, false);
                if (InProgress()) goto RETRY_READ;
            }
        }
    }
    // One final summary line covering the whole run, in addition to the
    // single one-shot detection message already fired above (see
    // staleReplyCount's own doc comment) - lets a human (or the Android
    // app, which tails this same merged stdout/stderr stream - see
    // IperfProcessRunner's redirectErrorStream(true) - for the stable
    // "stale replies discarded this run" substring to drive its own
    // warning badge) see a real total rather than just "it happened at
    // least once". WARN_REPORT_FMT (util.h), not a hand-rolled snprintf/
    // calloc/PostReport block, since this message needs to interpolate
    // the count.
    WARN_REPORT_FMT(staleReplyCount > 0, "%sudp bounceback: %u stale replies discarded this run\n",
                     mSettings->mTransferIDStr, staleReplyCount);
    if (!peerclose) WriteUdpTxBBHdr(reportstruct, 0x0, 1, false);  // Signal end of BB test
    // Same isUDPL4S(mSettings) conditional as the main request loop above -
    // this final close packet is a separate write site and was missed on
    // the first pass, letting one marked packet slip out at the very end
    // of an otherwise-unmarked run (caught via a live tcpdump capture).
    u_char final_tos = isUDPL4S(mSettings) ? ((mSettings->mTOS & 0xFC) | ecn_l4s_id) : mSettings->mTOS;
    int n = writemsg_delay_tos(mySocket, mSettings->mBuf, writelen, 0, final_tos);
    WARN_REPORT_errno(n <= 0, "udp bounceback final write");
    FinishTrafficActions();
}
#endif // HAVE_UDP_L4S

/*
 * UDP send loop
 */
double Client::get_delay_target() {
    double delay_target;
    if (isIPG(mSettings)) {
        delay_target = mSettings->mBurstIPG * 1000;  // convert from microseconds to nanoseconds
    } else {
        // compute delay target in units of nanoseconds
        if (mSettings->mAppRateUnits == kRate_BW) {
            // compute delay for bandwidth restriction, constrained to [0,1]
            // seconds
            delay_target = ((mSettings->mAppRate > 0)
                                ? (mSettings->mBufLen * ((kSecs_to_nsecs * kBytes_to_Bits) / mSettings->mAppRate))
                                : 0);
        } else {
            delay_target = (mSettings->mAppRate > 0) ? (1e9 / mSettings->mAppRate) : 0;
        }
    }
    return delay_target;
}

#if HAVE_SENDMMSG
void Client::RunUDPBurstMMSG(void) {
    int currMsg=0;
    int msg_len;
    struct iovec *iov;
    struct mmsghdr *mmsg;
    char*  mBuf;
    struct UDP_datagram* mBuf_UDP = NULL;
    int vlen;
    double delay_target = get_delay_target();
    double delay = 0;
    double adjust = 0;
    int i=0;

    delay_target *= mSettings->mmnum;

    double variance = mSettings->mVariance;

    // Size of one message
    if (!isModeTime(mSettings)) {
        msg_len = (mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount : mSettings->mBufLen;
    } else {
        msg_len = mSettings->mBufLen;
    }
    //msg_len = mSettings->mBufLen;
    // Number of messages in one burst
    vlen = mSettings->mmnum;

    // Allocate temporary mBuf with enough space for all messages in a burst
    mBuf = (char*) malloc( vlen * msg_len);
    if (mBuf == NULL) {
        FAIL_errno(errno, "Out of memory", mSettings);
    }

    for(i=0;i<vlen;i++)
        memcpy(mBuf + i*msg_len, mSettings->mBuf, mSettings->mBufLen);

    // Allocate temporary mBuf with enough space for all messages in a burst
    iov = (struct iovec *) calloc(vlen, sizeof(struct iovec));
    if (iov == NULL) {
        free(mBuf);
        FAIL_errno(errno, "Out of memory", mSettings);
    }

    // Allocate buffer for multi message header array
    mmsg = (struct mmsghdr *) calloc(vlen, sizeof(struct mmsghdr));
    if (mmsg == NULL) {
        free(iov);
        free(mBuf);
        FAIL_errno(errno, "Out of memory", mSettings);
    }

    while (InProgress()) {
        // Test case: drop 17 packets and send 2 out-of-order:
        // sequence 51, 52, 70, 53, 54, 71, 72
        //switch(datagramID) {
        //  case 53: datagramID = 70; break;
        //  case 71: datagramID = 53; break;
        //  case 55: datagramID = 71; break;
        //  default: break;
        //}

        for (int m = 0; m < vlen; m++) {

            iov[m].iov_base = mBuf + (m * msg_len);
            iov[m].iov_len  = msg_len;

            mmsg[m].msg_hdr.msg_name = NULL;
            mmsg[m].msg_hdr.msg_namelen = 0;
            mmsg[m].msg_hdr.msg_iov = &iov[m];
            mmsg[m].msg_hdr.msg_iovlen = 1;
            mmsg[m].msg_hdr.msg_control = NULL;
            mmsg[m].msg_hdr.msg_controllen = 0;

            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            reportstruct->sentTime = reportstruct->packetTime;
            if (isVaryLoad(mSettings) && mSettings->mAppRateUnits == kRate_BW) {
                static Timestamp time3;
                if (now.subSec(time3) >= VARYLOAD_PERIOD) {
                    long var_rate = lognormal(mSettings->mAppRate,variance);
                    if (var_rate < 0)
                        var_rate = 0;
                    delay_target = (mSettings->mBufLen * ((kSecs_to_nsecs * kBytes_to_Bits) / var_rate));

                    time3 = now;
                }
            }
            // store datagram ID into buffer
            mBuf_UDP = reinterpret_cast<struct UDP_datagram*>(mBuf + (m*msg_len));
            WritePacketID(reportstruct->packetID++, mBuf_UDP);
            mBuf_UDP->tv_sec  = htonl(reportstruct->packetTime.tv_sec);
            mBuf_UDP->tv_usec = htonl(reportstruct->packetTime.tv_usec);
        }

        // Adjustment for the running delay
        // o measure how long the last loop iteration took
        // o calculate the delay adjust
        //   - If write succeeded, adjust = target IPG - the loop time
        //   - If write failed, adjust = the loop time
        // o then adjust the overall running delay
        // Note: adjust units are nanoseconds,
        //       packet timestamps are microseconds
        adjust = delay_target + (1000.0 * lastPacketTime.subUsec(reportstruct->packetTime));

        lastPacketTime.set(reportstruct->packetTime.tv_sec, reportstruct->packetTime.tv_usec);
        // Since linux nanosleep/busyloop can exceed delay
        // there are two possible equilibriums
        //  1)  Try to perserve inter packet gap
        //  2)  Try to perserve requested transmit rate
        // The latter seems preferred, hence use a running delay
        // that spans the life of the thread and constantly adjust.
        // A negative delay means the iperf app is behind.
        delay += adjust;
        // Don't let delay grow unbounded
        if (delay < delay_lower_bounds) {
            delay = delay_target;
        }

        reportstruct->err_readwrite = WriteSuccess;
        reportstruct->emptyreport = false;
        int msgSent=0;

        do {
            // perform write
            currMsg = sendmmsg(mSettings->mSock, &mmsg[msgSent], vlen - msgSent, 0);

            if (currMsg < 0) {
                reportstruct->packetID -= (vlen - currMsg);

                if(errno == ECONNREFUSED) {
                    WARN_REPORT_errno(1, "sendmmsg - connection refused");
                    goto err;
                }
                if (FATALUDPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "write");
                    goto err;
                } else {
                    reportstruct->err_readwrite = WriteErrAccount;
                    currMsg = 0;
                }
                reportstruct->emptyreport = 1;
            }
            // report packets
            for (int m = msgSent; m < msgSent + currMsg; m++) {
                reportstruct->packetLen = static_cast<unsigned long>(msg_len);
                reportstruct->writecnt = (m == 0) ? 1 : 0;
                reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
                myReportPacket();
                myReport->info.ts.prevpacketTime = reportstruct->packetTime;
            }

            msgSent += currMsg;
        } while( msgSent < vlen );
#if 1
        // Insert delay here only if the running delay is greater than 100 usec,
        // otherwise don't delay and immediately continue with the next tx.
        if (delay >= 1000) {
            // Convert from nanoseconds to microseconds
            // and invoke the microsecond delay
            delay_loop(static_cast<unsigned long>(delay / 1000));
        }
#endif
    }

err:
    FinishTrafficActions();

    free(mmsg);
    free(iov);
    free(mBuf);
}
#endif /* HAVE_SENDMMSG */

void Client::RunUDP() {
    struct UDP_datagram *mBuf_UDP = reinterpret_cast<struct UDP_datagram *>(mSettings->mBuf);
    int currLen;

    double delay_target = get_delay_target();
    double delay = 0;
    double adjust = 0;

    // Set this to > 0 so first loop iteration will delay the IPG
    currLen = 1;
    double variance = mSettings->mVariance;
    if (apply_first_udppkt_delay && (delay_target > 100000)) {
        // the case when a UDP first packet went out in SendFirstPayload
        delay_loop(static_cast<unsigned long>(delay_target / 1000));
        lastPacketTime.setnow();
    }

    while (InProgress()) {
        // Test case: drop 17 packets and send 2 out-of-order:
        // sequence 51, 52, 70, 53, 54, 71, 72
        // switch(datagramID) {
        //  case 53: datagramID = 70; break;
        //  case 71: datagramID = 53; break;
        //  case 55: datagramID = 71; break;
        //  default: break;
        //}
        now.setnow();
        reportstruct->writecnt = 1;
        reportstruct->packetTime.tv_sec = now.getSecs();
        reportstruct->packetTime.tv_usec = now.getUsecs();
        reportstruct->sentTime = reportstruct->packetTime;
        if (isVaryLoad(mSettings) && mSettings->mAppRateUnits == kRate_BW) {
            static Timestamp time3;
            if (now.subSec(time3) >= VARYLOAD_PERIOD) {
                long var_rate = lognormal(mSettings->mAppRate, variance);
                if (var_rate < 0) var_rate = 0;
                delay_target = (mSettings->mBufLen * ((kSecs_to_nsecs * kBytes_to_Bits) / var_rate));
                time3 = now;
            }
        }
        // store datagram ID into buffer
        WritePacketID(reportstruct->packetID, mBuf_UDP);
        mBuf_UDP->tv_sec = htonl(reportstruct->packetTime.tv_sec);
        mBuf_UDP->tv_usec = htonl(reportstruct->packetTime.tv_usec);

        if (delay_target > 0) {
            // Adjustment for the running delay
            // o measure how long the last loop iteration took
            // o calculate the delay adjust
            //   - If write succeeded, adjust = target IPG - the loop time
            //   - If write failed, adjust = the loop time
            // o then adjust the overall running delay
            // Note: adjust units are nanoseconds,
            //       packet timestamps are microseconds
            if (currLen > 0)
                adjust = delay_target + (1000.0 * lastPacketTime.subUsec(reportstruct->packetTime));
            else
                adjust = 1000.0 * lastPacketTime.subUsec(reportstruct->packetTime);

            lastPacketTime.set(reportstruct->packetTime.tv_sec, reportstruct->packetTime.tv_usec);
            // Since linux nanosleep/busyloop can exceed delay
            // there are two possible equilibriums
            //  1)  Try to perserve inter packet gap
            //  2)  Try to perserve requested transmit rate
            // The latter seems preferred, hence use a running delay
            // that spans the life of the thread and constantly adjust.
            // A negative delay means the iperf app is behind.
            delay += adjust;
            // Don't let delay grow unbounded
            if (delay < delay_lower_bounds) {
                delay = delay_target;
            }
        }
        reportstruct->err_readwrite = WriteSuccess;
        reportstruct->emptyreport = false;
        // perform write
        if (isModeAmount(mSettings)) {
            currLen = write(mySocket, mSettings->mBuf,
                            (mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                             : mSettings->mBufLen);
        } else {
            int markov_len = (markov_graph_len ? markov_graph_next(markov_graph_len) : mSettings->mBufLen);
            currLen = write(mySocket, mSettings->mBuf, markov_len);
        }
        if (currLen <= 0) {
            reportstruct->emptyreport = true;
            if (currLen == 0) {
                reportstruct->err_readwrite = WriteTimeo;
            } else {
                if (FATALUDPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "write");
                    currLen = 0;
                    break;
                } else {
                    // WARN_errno(1, "write n");
                    currLen = 0;
                    reportstruct->err_readwrite = WriteErrAccount;
                }
            }
        }
        if (isModeAmount(mSettings)) {
            /* mAmount may be unsigned, so don't let it underflow! */
            if (mSettings->mAmount >= static_cast<unsigned long>(currLen)) {
                mSettings->mAmount -= static_cast<unsigned long>(currLen);
            } else {
                mSettings->mAmount = 0;
            }
        }

        // report packets
        reportstruct->packetLen = static_cast<unsigned long>(currLen);
        reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
        myReportPacket();
        if (!reportstruct->emptyreport) {
            reportstruct->packetID++;
            myReport->info.ts.prevpacketTime = reportstruct->packetTime;
            // Insert delay here only if the running delay is greater than 100
            // usec, otherwise don't delay and immediately continue with the
            // next tx.
            if (delay >= 100000) {
                // Convert from nanoseconds to microseconds
                // and invoke the microsecond delay
                delay_loop(static_cast<unsigned long>(delay / 1000));
            }
        }
    }
    FinishTrafficActions();
}

/*
 * UDP isochronous send loop
 */
void Client::RunUDPIsochronous() {
    struct UDP_datagram *mBuf_UDP = reinterpret_cast<struct UDP_datagram *>(mSettings->mBuf);
    // skip over the UDP datagram (seq no, timestamp) to reach the isoch fields
    struct client_udp_testhdr *udp_payload = reinterpret_cast<client_udp_testhdr *>(mSettings->mBuf);

    // returns units nanoseconds, zero if --ipg not set
    double delay_target = get_delay_target();

    double delay = 0;
    double adjust = 0;
    int currLen = 1;
    int frameid = 0;
    Timestamp t1;

    // make sure the packet can carry the isoch payload
    if (!framecounter) {
        framecounter = new Isochronous::FrameCounter(mSettings->mFPS);
    }
    udp_payload->isoch.burstperiod = htonl(framecounter->period_us());

    int initdone = 0;
    int fatalwrite_err = 0;
    while (InProgress() && !fatalwrite_err) {
        int bytecnt = static_cast<int>(lognormal(mSettings->mMean, mSettings->mVariance)) / (mSettings->mFPS * 8);
        if (bytecnt < udp_payload_minimum) bytecnt = udp_payload_minimum;
        delay = 0;

        // printf("bits=%d\n", (int) (mSettings->mFPS * bytecnt * 8));
        udp_payload->isoch.burstsize = htonl(bytecnt);
        udp_payload->isoch.prevframeid = htonl(frameid);
        reportstruct->burstsize = bytecnt;
        frameid = framecounter->wait_tick(&reportstruct->sched_err, true);
        reportstruct->scheduled = true;
        udp_payload->isoch.frameid = htonl(frameid);
        lastPacketTime.setnow();
        if (!initdone) {
            initdone = 1;
            udp_payload->isoch.start_tv_sec = htonl(lastPacketTime.getSecs());
            udp_payload->isoch.start_tv_usec = htonl(lastPacketTime.getUsecs());
        }
        while ((bytecnt > 0) && InProgress() && !fatalwrite_err) {
            t1.setnow();
            reportstruct->packetTime.tv_sec = t1.getSecs();
            reportstruct->packetTime.tv_usec = t1.getUsecs();
            reportstruct->sentTime = reportstruct->packetTime;
            mBuf_UDP->tv_sec = htonl(reportstruct->packetTime.tv_sec);
            mBuf_UDP->tv_usec = htonl(reportstruct->packetTime.tv_usec);
            WritePacketID(reportstruct->packetID, mBuf_UDP);

            // Adjustment for the running delay
            // o measure how long the last loop iteration took
            // o calculate the delay adjust
            //   - If write succeeded, adjust = target IPG - the loop time
            //   - If write failed, adjust = the loop time
            // o then adjust the overall running delay
            // Note: adjust units are nanoseconds,
            //       packet timestamps are microseconds
            if (currLen > 0)
                adjust = delay_target + (1000.0 * lastPacketTime.subUsec(reportstruct->packetTime));
            else
                adjust = 1000.0 * lastPacketTime.subUsec(reportstruct->packetTime);

            lastPacketTime.set(reportstruct->packetTime.tv_sec, reportstruct->packetTime.tv_usec);
            // Since linux nanosleep/busyloop can exceed delay
            // there are two possible equilibriums
            //  1)  Try to perserve inter packet gap
            //  2)  Try to perserve requested transmit rate
            // The latter seems preferred, hence use a running delay
            // that spans the life of the thread and constantly adjust.
            // A negative delay means the iperf app is behind.
            delay += adjust;
            // Don't let delay grow unbounded
            // if (delay < delay_lower_bounds) {
            //	  delay = delay_target;
            // }

            reportstruct->err_readwrite = WriteSuccess;
            reportstruct->emptyreport = false;
            reportstruct->writecnt = 1;

            // perform write
            if (isModeAmount(mSettings) && (mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen))) {
                udp_payload->isoch.remaining = htonl(mSettings->mAmount);
                reportstruct->remaining = mSettings->mAmount;
                currLen = write(mySocket, mSettings->mBuf, mSettings->mAmount);
            } else {
                udp_payload->isoch.remaining = htonl(bytecnt);
                reportstruct->remaining = bytecnt;
                currLen =
                    write(mySocket, mSettings->mBuf, (bytecnt < mSettings->mBufLen) ? bytecnt : mSettings->mBufLen);
            }
            if (currLen < 0) {
                reportstruct->packetID--;
                reportstruct->emptyreport = true;
                if (FATALUDPWRITERR(errno)) {
                    reportstruct->err_readwrite = WriteErrFatal;
                    WARN_REPORT_errno(1, "write");
                    fatalwrite_err = 1;
                    currLen = 0;
                } else {
                    currLen = 0;
                    reportstruct->err_readwrite = WriteErrAccount;
                }
            } else {
                bytecnt -= currLen;
                if (!bytecnt)
                    reportstruct->transit_ready = true;
                else
                    reportstruct->transit_ready = false;
                // adjust bytecnt so last packet of burst is greater or equal to
                // min packet
                if ((bytecnt > 0) && (bytecnt < udp_payload_minimum)) {
                    bytecnt = udp_payload_minimum;
                    udp_payload->isoch.burstsize = htonl(bytecnt);
                    reportstruct->burstsize = bytecnt;
                }
            }
            if (isModeAmount(mSettings)) {
                /* mAmount may be unsigned, so don't let it underflow! */
                if (mSettings->mAmount >= static_cast<unsigned long>(currLen)) {
                    mSettings->mAmount -= static_cast<unsigned long>(currLen);
                } else {
                    mSettings->mAmount = 0;
                }
            }
            // report packets

            reportstruct->frameID = frameid;
            reportstruct->packetLen = static_cast<unsigned long>(currLen);
            reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
            myReportPacket();
            reportstruct->scheduled = false;  // reset to false after the report
            reportstruct->packetID++;
            myReport->info.ts.prevpacketTime = reportstruct->packetTime;
            // Insert delay here only if the running delay is greater than 1
            // usec, otherwise don't delay and immediately continue with the
            // next tx.
            if (delay >= 1000) {
                // Convert from nanoseconds to microseconds
                // and invoke the microsecond delay
                delay_loop(static_cast<unsigned long>(delay / 1000));
            }
        }
    }
    FinishTrafficActions();
}
// end RunUDPIsoch

void Client::RunUDPBurst() {
    struct UDP_datagram *mBuf_UDP = reinterpret_cast<struct UDP_datagram *>(mSettings->mBuf);
    int currLen;
    int remaining;
    if (mSettings->mFPS > 0) {
        framecounter = new Isochronous::FrameCounter(mSettings->mFPS);
    }
    while (InProgress()) {
        remaining = mSettings->mBurstSize;
        framecounter->wait_tick(&reportstruct->sched_err, true);
        do {
            now.setnow();
            reportstruct->writecnt = 1;
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            reportstruct->sentTime = reportstruct->packetTime;
            // store datagram ID into buffer
            WritePacketID(reportstruct->packetID, mBuf_UDP);
            mBuf_UDP->tv_sec = htonl(reportstruct->packetTime.tv_sec);
            mBuf_UDP->tv_usec = htonl(reportstruct->packetTime.tv_usec);

            reportstruct->err_readwrite = WriteSuccess;
            reportstruct->emptyreport = false;
            // perform write
            if (isModeAmount(mSettings)) {
                currLen = write(mySocket, mSettings->mBuf,
                                (mSettings->mAmount < static_cast<unsigned>(mSettings->mBufLen)) ? mSettings->mAmount
                                                                                                 : mSettings->mBufLen);
            } else {
                currLen =
                    write(mySocket, mSettings->mBuf,
                          ((remaining > mSettings->mBufLen) ? mSettings->mBufLen
                                                            : (remaining < static_cast<int>(sizeof(struct UDP_datagram))
                                                                   ? static_cast<int>(sizeof(struct UDP_datagram))
                                                                   : remaining)));
            }
            if (isIPG(mSettings)) {
                Timestamp t2;
                double delay = mSettings->mBurstIPG - (1e-6 * t2.subSec(now));
                if (delay) delay_loop(static_cast<unsigned long>(delay));
            }
            if (currLen <= 0) {
                reportstruct->emptyreport = true;
                if (currLen == 0) {
                    reportstruct->err_readwrite = WriteTimeo;
                } else {
                    if (FATALUDPWRITERR(errno)) {
                        reportstruct->err_readwrite = WriteErrFatal;
                        WARN_REPORT_errno(1, "write");
                        currLen = 0;
                        break;
                    } else {
                        // WARN_errno(1, "write n");
                        currLen = 0;
                        reportstruct->err_readwrite = WriteErrAccount;
                    }
                }
            }
            if (isModeAmount(mSettings)) {
                /* mAmount may be unsigned, so don't let it underflow! */
                if (mSettings->mAmount >= static_cast<unsigned long>(currLen)) {
                    mSettings->mAmount -= static_cast<unsigned long>(currLen);
                } else {
                    mSettings->mAmount = 0;
                }
            }

            // report packets
            reportstruct->packetLen = static_cast<unsigned long>(currLen);
            reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
            remaining -= reportstruct->packetLen;
            myReportPacket();
            if (!reportstruct->emptyreport) {
                reportstruct->packetID++;
                myReport->info.ts.prevpacketTime = reportstruct->packetTime;
            }
        } while (remaining > 0);
    }
    FinishTrafficActions();
}

#if HAVE_UDP_L4S
int Client::ack_poll(time_tp ack_timeout) {
    int rc = -1;
    if (ack_timeout > 0) {
        bool read_ready = false;
        bool read_done = false;
        struct timeval t_initial, t_final;
        struct timeval t_now;
        TimeGetNow(t_initial);
        t_final = t_initial;
        TimeAddIntUsec(t_final, static_cast<int>(ack_timeout));
        if (ack_timeout > 1000) {  // one millisecond
            struct timeval timeout;
            fd_set set;
            timeout.tv_sec = static_cast<long>(ack_timeout / 1000000);
            timeout.tv_usec = static_cast<long>(ack_timeout % 1000000);
            FD_ZERO(&set);
            FD_SET(mySocket, &set);
            if (select(mySocket + 1, &set, NULL, NULL, &timeout) > 0) {
                read_ready = true;
            }
        }
        while (!read_ready && !read_done) {
            TimeGetNow(t_now);
            double delta_usecs;
            if ((delta_usecs = TimeDifference(t_final, t_now)) > 0.0) {
                rc = recv(mySocket, reinterpret_cast<char *>(&UDPAckBuf), sizeof(struct udp_l4s_ack), MSG_DONTWAIT);
                if (rc > 0) {
                    read_done = true;
                }
            } else {
                break;
            }
        }
        if (read_ready && !read_done) {
            rc = recv(mySocket, reinterpret_cast<char *>(&UDPAckBuf), sizeof(struct udp_l4s_ack), 0);
        }
#if 0
	TimeGetNow(t_now);
	printf("Ack slop %f n:%ld.%ld f:%ld.%ld i:%ld.%ld to:%d (%d)\n", TimeDifference(t_now, t_final), t_now.tv_sec, t_now.tv_usec, t_final.tv_sec, t_final.tv_usec, t_initial.tv_sec, t_initial.tv_usec, ack_timeout, read_ready);
#endif
    }
    return rc;
}

// UDP-L4S writer's own "has the peer gone away" liveness heuristic (see
// the ack-timeout branch in RunUDPL4S below) - previously a flat 1s
// regardless of path RTT, which real congestion (the exact condition
// CE-marking is signaling) can trip on a fully healthy connection: RTT
// rises and loss becomes more likely at the same time, compounding right
// when a flat threshold is tightest. Confirmed via a real report against
// a genuinely lossy/CE-marked path (Sebastian Moeller, 2026-08-11): a
// --working-load=down UDP-L4S stream was ending at ~4s into a 30s test.
// Scaled by the pacer's own smoothed RTT instead, clamped to a sane
// range - MIN preserves today's original 1s behavior on an already-
// healthy low-RTT path, MAX bounds worst-case dead-peer-detection
// latency so a pathological RTT spike can't silently stall detection for
// an unreasonable fraction of a short test. RTT_MULTIPLIER is the same
// order of magnitude as TCP's own RTO-style multiplier.
static const time_tp L4S_PEERCLOSE_MIN_TIMEOUT_US = 1000000;  // 1s
static const time_tp L4S_PEERCLOSE_MAX_TIMEOUT_US = 5000000;  // 5s
static const time_tp L4S_PEERCLOSE_RTT_MULTIPLIER = 8;
// Consecutive confirming polls required before actually declaring
// peerclose, not just one - cheap insurance against a single noisy
// sample (a poll landing right as the clock crosses the threshold, or a
// one-off spurious empty poll) killing an otherwise-healthy connection.
// Paired with L4S_ACK_POLL_INTERVAL_US below being shorter than the
// timeout itself, so debounce actually gets multiple independent
// samples within the timeout window instead of one big blocking wait.
static const int L4S_PEERCLOSE_DEBOUNCE_COUNT = 3;
static const time_tp L4S_ACK_POLL_INTERVAL_US = 200000;  // 200ms

void Client::RunUDPL4S() {
    int currLen;
    peerclose = false;
    struct client_udp_l4s_fwd *mBuf_UDP = reinterpret_cast<struct client_udp_l4s_fwd *>(mSettings->mBuf);
    size_tp initmtu;
    rate_tp maxrate = PRAGUE_MAXRATE;
    if (mSettings->mAppRateUnits == kRate_BW && mSettings->mAppRate &&
        mSettings->mAppRate * kBytes_to_Bits <= PRAGUE_MAXRATE) {
        if (mSettings->mAppRate <= PRAGUE_MINRATE * kBytes_to_Bits)
            maxrate = PRAGUE_MINRATE;
        else
            maxrate = mSettings->mAppRate / kBytes_to_Bits;
    }
    initmtu = ((size_tp)mSettings->mBufLen > PRAGUE_MINMTU) ? mSettings->mBufLen : PRAGUE_MINMTU;
    PragueCC l4s_pacer(initmtu, 0, 0, PRAGUE_INITRATE, PRAGUE_INITWIN, PRAGUE_MINRATE, maxrate,
                       (isUDPL4SCcaReno(mSettings) ? l4s_cca_reno : l4s_cca_prague));
    time_tp nextSend = l4s_pacer.Now();
    time_tp last_acktime = 0;
    count_tp seqnr = 1;
    count_tp inflight = 0;
    // One-shot, un-counted signals - same Reporter-thread-safe pattern as
    // RunBounceBackUDP's own reqBleachLogged/reqConfirmedLogged (see that
    // function's own doc comment). Capacity's own UDP L4S stream is a
    // single continuous flow (not a discrete per-request/reply exchange
    // like Bounceback), so there's only ever one direction's worth of
    // marking-integrity to report here, not two - see l4s_err's own
    // per-ACK read below for what actually flips these. m_error_L4S
    // (prague_cc.h) latches permanently once set (never cleared short of
    // reconstructing the pacer), so once a bleach fires, every later ACK
    // keeps echoing the same error - these one-shot local bools mirror
    // that: at most one of the two ever fires for the life of this run.
    bool l4sConfirmedLogged = false;
    bool l4sBleachLogged = false;
    // See L4S_PEERCLOSE_DEBOUNCE_COUNT's own doc comment - counts
    // consecutive ack-timeout polls since the last real ACK, reset to 0
    // the moment a real ACK arrives.
    int consecutive_timeout_polls = 0;
    rate_tp pacing_rate;
    count_tp packet_window;
    count_tp packet_burst;
    size_tp packet_size;
    time_tp compRecv = 0;
    l4s_pacer.GetCCInfo(pacing_rate, packet_window, packet_burst, packet_size);
    // --working-load=down's own wire-relayed pause state (L4S_PAUSE, see
    // its own doc comment payloads.h) - this instance is the *writer* for
    // that direction, a thread the server spawns with no relayed
    // flags_extend3 at all (isWorkingLoadThread(mSettings) is always false
    // here - see FLAG_WORKING_LOAD_THREAD's own doc comment, Settings.hpp),
    // so unlike the client-writer case below it has no local
    // sWorkingLoadPaused to read; this is the only signal it has. Updated
    // from whichever ACK was most recently received (see the ack-parse
    // block below) - level-triggered, not edge-triggered like SIGUSR1/
    // SIGUSR2 themselves (see L4S_PAUSE's own doc comment for why that's
    // the right choice here), so it naturally reflects "paused" for
    // exactly as long as the reader keeps saying so, self-healing against
    // an occasional dropped ACK.
    bool wire_paused = false;

    while (InProgress()) {
#ifndef WIN32
        // SIGUSR1/SIGUSR2-driven pause - see RunTCP's own copy of this
        // check for the full doc comment (only ever checked for a
        // working-load thread, "continue the loop, skip the writes," and
        // why packetTime needs refreshing here). ack_poll() still runs
        // with a small fixed timeout (not derived from nextSend/pacing_
        // rate, which never advance while paused) so any ACKs still in
        // flight from just before the pause get drained rather than
        // queuing up, but its result is deliberately discarded here, not
        // fed to l4s_pacer - there's nothing newly in flight worth
        // updating window/rate estimates for while deliberately not
        // sending. Skipping straight past the inner send loop, the pacer
        // math, and the "no ACK for 1s" peerclose check below altogether
        // is what keeps a multi-second pause from tripping that check -
        // none of that logic needs to run at all while genuinely paused.
        if (isWorkingLoadThread(mSettings) && sWorkingLoadPaused) {
            // PostNullEvent(..., paused=true) - not a bare packetTime
            // refresh - same reason RunTCP/RunWriteEventsTCP's own copies
            // of this check need it: without a well-formed empty report
            // fed to the Reporter thread every spin, its own periodic
            // interval-boundary flush can fire against a ReportStruct this
            // loop never touched, producing a corrupted row once a pause
            // outlasts one interval. See WritePaused's own doc comment
            // (packet_ring.h) for why paused=true (not just an ordinary
            // idle report) also matters here.
            PostNullEvent(false, false, true);
            ack_poll(50000);  // 50ms - drains late ACKs without busy-spinning
            continue;
        }
#endif
        count_tp inburst = 0;
        time_tp startSend = 0;
        time_tp pacer_now = l4s_pacer.Now();
        // wire_paused (see its own declaration comment above) only ever
        // guards the send burst itself, never the ack_poll()/parse code
        // below - unlike the local-pause branch above (which can safely
        // stop touching the connection at all, since SIGUSR2 wakes it back
        // up independently of anything received on the wire), this
        // writer's only way to ever learn "resume" is a *future* ACK
        // clearing the flag, so it must keep polling and parsing normally
        // while wire_paused, just without sending any new data.
        while (!wire_paused && (inflight < packet_window) && (inburst < packet_burst) && (nextSend - pacer_now <= 0)) {
            ecn_tp new_ecn;
            time_tp sender_ts;
            time_tp echoed_ts;
            l4s_pacer.GetTimeInfo(sender_ts, echoed_ts, new_ecn);
            mBuf_UDP->l4s_data_type = L4SPKTDATA;
            mBuf_UDP->sender_ts = htonl(sender_ts);
            mBuf_UDP->echoed_ts = htonl(echoed_ts);
            mBuf_UDP->sender_seqno = htonl(seqnr);
            // Constant for the whole flow (l4s_pacer.GetGuid() never
            // changes after construction) but stamped on every packet,
            // same as the rest of this header - see flow_guid_lower/upper's
            // own doc comment in payloads.h for why (an outside observer
            // needs it on whichever packets it actually captures, not just
            // the first one).
            mBuf_UDP->l4s_payload_version = htons(L4S_PAYLOAD_VERSION);
            mBuf_UDP->l4s_payload_reserved = 0;
            mBuf_UDP->flow_guid_lower = htonl(static_cast<uint32_t>(l4s_pacer.GetGuid()));
            mBuf_UDP->flow_guid_upper = htonl(static_cast<uint32_t>(l4s_pacer.GetGuid() >> 32));
            if (startSend == 0) startSend = pacer_now;
            // perform write
            reportstruct->writecnt = 1;
            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
            reportstruct->sentTime = reportstruct->packetTime;
            // store datagram ID into buffer
            WritePacketID(reportstruct->packetID, &mBuf_UDP->seqno_ts);
            mBuf_UDP->seqno_ts.tv_sec = htonl(reportstruct->packetTime.tv_sec);
            mBuf_UDP->seqno_ts.tv_usec = htonl(reportstruct->packetTime.tv_usec);

	    reportstruct->err_readwrite = WriteSuccess;
	    reportstruct->emptyreport = false;
	    reportstruct->ce_count = l4s_pacer.Get_CECount();
	    reportstruct->l4s_lost_count = l4s_pacer.Get_LostCount();
	    {
		time_tp qdelay;
		size_tp qbytes;
		l4s_pacer.GetQueueInfo(qdelay, qbytes);
		reportstruct->l4s_qdelay_us = qdelay;
		reportstruct->l4s_qbytes = (int64_t)qbytes;
		reportstruct->l4s_rtt_us = l4s_pacer.GetSmoothedRtt();
	    }
	    // packet_window/inflight are this same pacing loop's own local
	    // variables (updated by GetCCInfo()/ACKReceived() below) - direct,
	    // RTT-independent measurements of the actual congestion window and
	    // its current utilization, unlike l4s_qdelay_us/l4s_qbytes above.
	    reportstruct->l4s_packet_window = packet_window;
	    reportstruct->l4s_inflight = inflight;
	    reportstruct->l4s_marking_prob = (int32_t)l4s_pacer.GetMarkingProbability();
	    reportstruct->l4s_cca_mode = (int32_t)l4s_pacer.GetL4SCcaMode();
	    reportstruct->l4sStatsValid = true;

	    // Relay this same local state to the peer, same as the fields
	    // above, in case it's a --reverse mode reader on the other end -
	    // see client_udp_l4s_fwd's own doc comment (include/payloads.h)
	    // for why the writer role always has this data regardless of
	    // which process (client or server CLI) is doing the writing.
	    mBuf_UDP->sender_qdelay_us = htonl((uint32_t)reportstruct->l4s_qdelay_us);
	    mBuf_UDP->sender_qbytes = htonl((uint32_t)reportstruct->l4s_qbytes);
	    mBuf_UDP->sender_rtt_us = htonl((uint32_t)reportstruct->l4s_rtt_us);
	    mBuf_UDP->sender_packet_window = htonl((uint32_t)reportstruct->l4s_packet_window);
	    mBuf_UDP->sender_inflight = htonl((uint32_t)reportstruct->l4s_inflight);
	    mBuf_UDP->sender_marking_prob = htonl((uint32_t)reportstruct->l4s_marking_prob);
	    mBuf_UDP->sender_cca_mode = htonl((uint32_t)reportstruct->l4s_cca_mode);

	    u_char tos = ((mSettings->mTOS & 0xFC) | new_ecn);
#if HAVE_DECL_SO_TXTIME
	    uint64_t delay_ns = isSendDelay(mSettings) ? (uint64_t)(mSettings->mSendDelay * 1e6) : 0;
#else
	    uint64_t delay_ns = 0;
#endif
	    int currLen = writemsg_delay_tos(mySocket, mSettings->mBuf, packet_size, delay_ns, tos);
	    if (currLen <= 0) {
		reportstruct->emptyreport = true;
		if (currLen == 0) {
		    reportstruct->err_readwrite = WriteTimeo;
		} else {
		    if (FATALUDPWRITERR(errno)) {
			reportstruct->err_readwrite = WriteErrFatal;
			WARN_REPORT_errno(1, "l4s write fatal");
			currLen = 0;
			break;
		    } else {
			//WARN_errno(1, "write n");
			currLen = 0;
			reportstruct->err_readwrite = WriteErrAccount;
		    }
		}
	    } else {
		inburst++;
		inflight++;
		seqnr++;
		// report packets
		reportstruct->packetLen = static_cast<unsigned long>(currLen);
		reportstruct->prevPacketTime = myReport->info.ts.prevpacketTime;
		if (!reportstruct->emptyreport) {
		    reportstruct->packetID++;
		    myReport->info.ts.prevpacketTime = reportstruct->packetTime;
		}
	    }
	    myReportPacket();
	}
	if (startSend != 0) {
            if (compRecv + packet_size * inburst * 1000000 / pacing_rate <= 0)
                nextSend = time_tp(startSend + 1);
            else
                nextSend = time_tp(startSend + compRecv + packet_size * inburst * 1000000 / pacing_rate);
            compRecv = 0;
        }

        time_tp waitTimeout = nextSend;
        pacer_now = l4s_pacer.Now();
        // A short, fixed poll cadence, not the (RTT-scaled, possibly much
        // longer) peerclose timeout itself - see L4S_ACK_POLL_INTERVAL_US's
        // own doc comment for why debounce needs polling more often than
        // the timeout it's confirming.
        if (inflight >= packet_window) waitTimeout = pacer_now + L4S_ACK_POLL_INTERVAL_US;  // units usec

        time_tp ack_timeout = waitTimeout - pacer_now;  // units usec;
        currLen = ack_poll(ack_timeout);
        pacer_now = l4s_pacer.Now();
        if (currLen >= (int)sizeof(struct udp_l4s_ack)) {
            // ecn_tp rcv_ecn = ecn_tp(reportstruct->tos & 0x3);
            time_tp timestamp;
            time_tp echoed_timestamp;
            last_acktime = pacer_now;
            consecutive_timeout_polls = 0;
            timestamp = ntohl(UDPAckBuf.rx_ts);
            echoed_timestamp = ntohl(UDPAckBuf.echoed_ts);
            count_tp pkts_rx = ntohl(UDPAckBuf.rx_cnt);
            count_tp pkts_ce = ntohl(UDPAckBuf.CE_cnt);
            count_tp pkts_lost = ntohl(UDPAckBuf.lost_cnt);
            bool l4s_err = (htons(UDPAckBuf.flags) & L4S_ECN_ERR);
            peerclose = (htons(UDPAckBuf.flags) & L4S_PKT_FIN);
            // --working-load=down's own wire-relayed pause state - see
            // wire_paused's own declaration comment above and L4S_PAUSE's
            // (payloads.h). Updated on every real ACK regardless of
            // reserved1 below (that gate is specifically about not
            // double-counting a retransmitted client_udp_testhdr into the
            // pacer's own stats, not about whether this flag byte is
            // trustworthy - the reader always zeroes/sets flags correctly
            // on both packet types it might send).
            wire_paused = (htons(UDPAckBuf.flags) & L4S_PAUSE) != 0;
            if (!UDPAckBuf.reserved1) {
                // To distinguish L4S ACK from retrnasmitted client_udp_testhdr
                // (reverse mode)
                l4s_pacer.PacketReceived(timestamp, echoed_timestamp);
                l4s_pacer.ACKReceived(pkts_rx, pkts_ce, pkts_lost, seqnr, l4s_err, inflight);
                // l4s_err is the receiver's own echoed m_r_error_L4S
                // (prague_cc.cpp's DataReceived/DataReceivedSequence) -
                // true means it saw this flow's data arrive as something
                // other than ECT(1) or CE (so also catches a re-marking
                // middlebox landing on ECT(0), not just a bleach down to
                // Not-ECT the way Bounceback's own narrower check does).
                if (!l4s_err && !l4sConfirmedLogged) {
                    l4sConfirmedLogged = true;
                    int len = snprintf(NULL, 0, "%sL4S ECN confirmed intact (server received your data unmolested)\n",
                                       mSettings->mTransferIDStr);
                    char *text = (char *)calloc(len + 1, sizeof(char));
                    if (text) {
                        snprintf(text, len, "%sL4S ECN confirmed intact (server received your data unmolested)\n",
                                 mSettings->mTransferIDStr);
                        PostReport(InitStringReport(text));
                        FREE_ARRAY(text);
                    }
                } else if (l4s_err && !l4sBleachLogged) {
                    l4sBleachLogged = true;
                    int len = snprintf(NULL, 0, "%sL4S ECN bleaching detected (server received your data marked incorrectly)\n",
                                       mSettings->mTransferIDStr);
                    char *text = (char *)calloc(len + 1, sizeof(char));
                    if (text) {
                        snprintf(text, len, "%sL4S ECN bleaching detected (server received your data marked incorrectly)\n",
                                 mSettings->mTransferIDStr);
                        PostReport(InitStringReport(text));
                        FREE_ARRAY(text);
                    }
                }
            }
        } else  // timeout, reset state
            if (inflight >= packet_window) {
                // See L4S_PEERCLOSE_MIN_TIMEOUT_US's own doc comment for
                // why this is RTT-scaled (clamped to [MIN,MAX]) rather
                // than the flat 1s this used to be, and why it's debounced
                // across L4S_PEERCLOSE_DEBOUNCE_COUNT consecutive polls
                // rather than acted on the first time it's crossed.
                time_tp peerclose_timeout_us = L4S_PEERCLOSE_RTT_MULTIPLIER * l4s_pacer.GetSmoothedRtt();
                if (peerclose_timeout_us < L4S_PEERCLOSE_MIN_TIMEOUT_US)
                    peerclose_timeout_us = L4S_PEERCLOSE_MIN_TIMEOUT_US;
                else if (peerclose_timeout_us > L4S_PEERCLOSE_MAX_TIMEOUT_US)
                    peerclose_timeout_us = L4S_PEERCLOSE_MAX_TIMEOUT_US;
                if (last_acktime - pacer_now + peerclose_timeout_us <= 0) {
                    consecutive_timeout_polls++;
                    if (consecutive_timeout_polls >= L4S_PEERCLOSE_DEBOUNCE_COUNT) peerclose = true;
                } else {
                    consecutive_timeout_polls = 0;
                }
                l4s_pacer.ResetCCInfo();
                inflight = 0;
            }
        pacer_now = l4s_pacer.Now();
        if (waitTimeout - pacer_now <= 0) {
            if (inflight > 0) compRecv += (waitTimeout - pacer_now);
        }
        l4s_pacer.GetCCInfo(pacing_rate, packet_window, packet_burst, packet_size);
    }
    FinishTrafficActions();
}
#endif

inline void Client::WritePacketID (intmax_t packetID, struct UDP_datagram * mBuf_UDP) {
    // store datagram ID into buffer
#ifdef HAVE_INT64_T
    // Pack signed 64bit packetID into unsigned 32bit id1 + unsigned
    // 32bit id2.  A legacy server reading only id1 will still be able
    // to reconstruct a valid signed packet ID number up to 2^31.
    uint32_t id1, id2;
    id1 = packetID & 0xFFFFFFFFLL;
    id2 = (packetID & 0xFFFFFFFF00000000LL) >> 32;

    mBuf_UDP->id = htonl(id1);
    mBuf_UDP->id2 = htonl(id2);

#ifdef HAVE_PACKET_DEBUG
    printf("id %" PRIdMAX " (0x%" PRIxMAX ") -> 0x%x, 0x%x\n", packetID, packetID, id1, id2);
#endif
#else
    mBuf_UDP->id = htonl((reportstruct->packetID));
#endif
}

inline void Client::WriteTcpTxHdr(struct ReportStruct *reportstruct, int burst_size, int burst_id) {
    struct TCP_burst_payload *mBuf_burst = reinterpret_cast<struct TCP_burst_payload *>(mSettings->mBuf);
    // store packet ID into buffer
    reportstruct->packetID += burst_size;
    mBuf_burst->start_tv_sec = htonl(myReport->info.ts.startTime.tv_sec);
    mBuf_burst->start_tv_usec = htonl(myReport->info.ts.startTime.tv_usec);

#ifdef HAVE_INT64_T
    // Pack signed 64bit packetID into unsigned 32bit id1 + unsigned
    // 32bit id2.  A legacy server reading only id1 will still be able
    // to reconstruct a valid signed packet ID number up to 2^31.
    uint32_t id1, id2;
    id1 = reportstruct->packetID & 0xFFFFFFFFLL;
    id2 = (reportstruct->packetID & 0xFFFFFFFF00000000LL) >> 32;

    mBuf_burst->seqno_lower = htonl(id1);
    mBuf_burst->seqno_upper = htonl(id2);

#ifdef HAVE_PACKET_DEBUG
    printf("id %" PRIdMAX " (0x%" PRIxMAX ") -> 0x%x, 0x%x\n", reportstruct->packetID, reportstruct->packetID, id1,
           id2);
#endif
#else
    mBuf_burst->seqno_lower = htonl((reportstruct->packetID));
    mBuf_burst->seqno_upper = htonl(0x0);
#endif
    mBuf_burst->send_tt.write_tv_sec = htonl(reportstruct->packetTime.tv_sec);
    mBuf_burst->send_tt.write_tv_usec = htonl(reportstruct->packetTime.tv_usec);
    mBuf_burst->burst_id = htonl((uint32_t)burst_id);
    mBuf_burst->burst_size = htonl((uint32_t)burst_size);
    reportstruct->frameID = burst_id;
    reportstruct->burstsize = burst_size;
    //    printf("**** Write tcp burst header size= %d id = %d\n", burst_size,
    //    burst_id);
#if HAVE_TCP_STATS
    // The server's reverse-mode writer relays its own gettcpinfo() sample
    // back to the reader here - bytes-in-flight/rtt are sender-side-only
    // TCP_INFO stats the reader can never observe locally for a
    // connection it's only receiving on. -1 sentinel (same convention as
    // the write-enhanced CSV output) when not available, not a real
    // negative measurement.
    if (isServerReverse(mSettings) && !isUDP(mSettings)) {
        if (reportstruct->tcpstats.isValid) {
            mBuf_burst->reverse_rtt = htonl((uint32_t)reportstruct->tcpstats.rtt);
#if HAVE_TCP_INFLIGHT
            mBuf_burst->reverse_bytes_in_flight = htonl((uint32_t)reportstruct->tcpstats.bytes_in_flight);
            mBuf_burst->reverse_packets_in_flight = htonl((uint32_t)reportstruct->tcpstats.packets_in_flight);
#else
            mBuf_burst->reverse_bytes_in_flight = htonl((uint32_t)-1);
            mBuf_burst->reverse_packets_in_flight = htonl((uint32_t)-1);
#endif
#if HAVE_TCP_STATS
            mBuf_burst->reverse_cwnd = htonl((uint32_t)reportstruct->tcpstats.cwnd);
            // retry_tot (cumulative, straight from this gettcpinfo() sample),
            // not retry - retry is a per-report-interval delta that only
            // ever gets computed by the reporter thread's own
            // reporter_handle_packet_tcpistats(), against a struct instance
            // this writer-side ReportStruct never goes through. Relaying
            // retry_tot instead and letting the reader side (see
            // reporter_handle_packet_server_tcp, Reporter.c) compute its own
            // delta mirrors exactly how the write side already turns its
            // own retry_tot into a per-interval count.
            mBuf_burst->reverse_retry = htonl((uint32_t)reportstruct->tcpstats.retry_tot);
            mBuf_burst->reverse_notsent = htonl((uint32_t)reportstruct->tcpstats.notsent_bytes);
            mBuf_burst->reverse_rtt_min = htonl((uint32_t)reportstruct->tcpstats.rtt_min);
            mBuf_burst->reverse_sndbuf = htonl((uint32_t)reportstruct->tcpstats.sndbuf_bytes);
            // Cumulative counters (see payloads.h's own doc comment) - same
            // "relay the raw _tot, reader computes its own delta" pattern
            // as reverse_retry above.
            mBuf_burst->reverse_sndbuf_limited = htonl((uint32_t)reportstruct->tcpstats.sndbuf_limited_tot);
            mBuf_burst->reverse_rwnd_limited = htonl((uint32_t)reportstruct->tcpstats.rwnd_limited_tot);
            mBuf_burst->reverse_busy_time = htonl((uint32_t)reportstruct->tcpstats.busy_time_tot);
#else
            mBuf_burst->reverse_cwnd = htonl((uint32_t)-1);
            mBuf_burst->reverse_retry = htonl((uint32_t)-1);
            mBuf_burst->reverse_notsent = htonl((uint32_t)-1);
            mBuf_burst->reverse_rtt_min = htonl((uint32_t)-1);
            mBuf_burst->reverse_sndbuf = htonl((uint32_t)-1);
            mBuf_burst->reverse_sndbuf_limited = htonl(0);
            mBuf_burst->reverse_rwnd_limited = htonl(0);
            mBuf_burst->reverse_busy_time = htonl(0);
#endif
            // Not gated on HAVE_TCP_STATS - write_time is plain wall-clock
            // syscall timing (see payloads.h's own doc comment), unrelated
            // to TCP_INFO. Only gated on --tcp-write-times actually being
            // active, same "0 means never measured" convention as the
            // reportstruct field itself.
            mBuf_burst->reverse_write_time =
                htonl(isTcpWriteTimes(mSettings) ? (uint32_t)reportstruct->write_time : (uint32_t)-1);
        } else {
            mBuf_burst->reverse_rtt = htonl((uint32_t)-1);
            mBuf_burst->reverse_bytes_in_flight = htonl((uint32_t)-1);
            mBuf_burst->reverse_packets_in_flight = htonl((uint32_t)-1);
            mBuf_burst->reverse_cwnd = htonl((uint32_t)-1);
            mBuf_burst->reverse_retry = htonl((uint32_t)-1);
            mBuf_burst->reverse_notsent = htonl((uint32_t)-1);
            mBuf_burst->reverse_rtt_min = htonl((uint32_t)-1);
            mBuf_burst->reverse_sndbuf = htonl((uint32_t)-1);
            mBuf_burst->reverse_write_time = htonl((uint32_t)-1);
            mBuf_burst->reverse_sndbuf_limited = htonl(0);
            mBuf_burst->reverse_rwnd_limited = htonl(0);
            mBuf_burst->reverse_busy_time = htonl(0);
        }
    }
#endif
}

// See payloads.h
void Client::WriteTcpTxBBHdr(struct ReportStruct *reportstruct, uint32_t bbid, int final, bool includeKey, bool includeCca) {
    struct bounceback_hdr *mBuf_bb = reinterpret_cast<struct bounceback_hdr *>(mSettings->mBuf);
    // store packet ID into buffer
    uint32_t flags = HEADER_BOUNCEBACK;
    uint32_t bbflags = 0x0;
    // Signal (in the same leading flags word Listener.cpp already decodes
    // before mode-dispatch, not a bounceback-specific bbflags bit) that a
    // permit key follows this first bounce's own bbsize-counted bytes -
    // see RunBounceBackTCP, which actually writes the key bytes right
    // after this header+payload succeeds. Only the first bounce needs
    // this: the server validates once at connection setup, same one-time
    // convention every other test type already uses, not per round trip.
    // includeKey is computed by the caller (permitKeySent tracking in
    // RunBounceBackTCP) rather than re-derived here from bbid==1 - bbid is
    // the scheduling tick, not a monotonic per-request counter, and a
    // multi-request burst within one tick would otherwise set this flag
    // (and RunBounceBackTCP would resend the actual key bytes) on every
    // request in that burst instead of just the very first one ever.
    if (includeKey) {
        flags |= HEADER_KEYCHECK;
    }
    mBuf_bb->flags = htonl(flags);
    if (isTripTime(mSettings)) {
        bbflags |= HEADER_BBCLOCKSYNCED;
    }
    if (mSettings->mTOS) {
        bbflags |= HEADER_BBTOS;
        mBuf_bb->tos = htons((mSettings->mTOS & 0xFF));
    }
    if (isTcpQuickAck(mSettings)) {
        bbflags |= HEADER_BBQUICKACK;
    }
    mBuf_bb->bbRunTime = 0x0;
    if (final) {
        bbflags |= HEADER_BBSTOP;
    }
    if ((mSettings->mBounceBackReplyBytes > 0) && (mSettings->mBounceBackReplyBytes != mSettings->mBounceBackBytes)) {
        bbflags |= HEADER_BBREPLYSIZE;
    }
    if (includeCca) {
        bbflags |= HEADER_BBCCA;
    }
    mBuf_bb->bbflags = htons(bbflags);
    mBuf_bb->bbsize = htonl(mSettings->mBounceBackBytes);
    mBuf_bb->bbid = htonl(bbid);
    mBuf_bb->bbclientTx_ts.sec = htonl(reportstruct->packetTime.tv_sec);
    mBuf_bb->bbclientTx_ts.usec = htonl(reportstruct->packetTime.tv_usec);
    mBuf_bb->bbserverRx_ts.sec = -1;
    mBuf_bb->bbserverRx_ts.usec = -1;
    mBuf_bb->bbserverTx_ts.sec = -1;
    mBuf_bb->bbserverTx_ts.usec = -1;
    mBuf_bb->bbhold = htonl(mSettings->mBounceBackHold);
    mBuf_bb->bbreplysize = htonl(mSettings->mBounceBackReplyBytes);
}

#if HAVE_UDP_L4S
// See payloads.h's struct bounceback_udp_hdr doc comment for the wire-format
// deltas from WriteTcpTxBBHdr/bounceback_hdr - no includeCca (--tcp-cca is a
// TCP-only concept) and no HEADER_BBQUICKACK (TCP_QUICKACK is a TCP-only
// socket option).
void Client::WriteUdpTxBBHdr(struct ReportStruct *reportstruct, uint32_t bbid, int final, bool includeKey) {
    struct bounceback_udp_hdr *mBuf_bb = reinterpret_cast<struct bounceback_udp_hdr *>(mSettings->mBuf);
    uint32_t flags = HEADER_BOUNCEBACK;
    uint32_t bbflags = 0x0;
    // Leading struct UDP_datagram (id=bbid + send timestamp) every UDP
    // wire format here starts with - see bounceback_udp_hdr's own doc
    // comment (include/payloads.h) for why this is mandatory, not
    // decorative: Listener::apply_client_settings_udp()'s hdr->base.flags
    // read (which has to run before any bounceback-specific parsing even
    // knows this is a bounceback packet) only lines up with this struct's
    // own flags field because both sit right after this same 16 bytes.
    WritePacketID(bbid, &mBuf_bb->seqno_ts);
    mBuf_bb->seqno_ts.tv_sec = htonl(reportstruct->packetTime.tv_sec);
    mBuf_bb->seqno_ts.tv_usec = htonl(reportstruct->packetTime.tv_usec);
    // Same one-time-at-connection-setup HEADER_KEYCHECK convention as
    // WriteTcpTxBBHdr - see that function's own doc comment.
    if (includeKey) {
        flags |= HEADER_KEYCHECK;
    }
    mBuf_bb->flags = htonl(flags);
    if (isTripTime(mSettings)) {
        bbflags |= HEADER_BBCLOCKSYNCED;
    }
    if (mSettings->mTOS) {
        bbflags |= HEADER_BBTOS;
        mBuf_bb->tos = htons((mSettings->mTOS & 0xFF));
    }
    mBuf_bb->bbRunTime = 0x0;
    if (final) {
        bbflags |= HEADER_BBSTOP;
    }
    if ((mSettings->mBounceBackReplyBytes > 0) && (mSettings->mBounceBackReplyBytes != mSettings->mBounceBackBytes)) {
        bbflags |= HEADER_BBREPLYSIZE;
    }
    // Tells the server whether to mark its own reply ECT(1) too - see
    // HEADER_BBL4S's own doc comment (payloads.h) for why this can't be
    // inferred server-side from the listener thread's own settings.
    if (isUDPL4S(mSettings)) {
        bbflags |= HEADER_BBL4S;
    }
    mBuf_bb->bbflags = htons(bbflags);
    mBuf_bb->bbsize = htonl(mSettings->mBounceBackBytes);
    mBuf_bb->bbid = htonl(bbid);
    mBuf_bb->bbclientTx_ts.sec = htonl(reportstruct->packetTime.tv_sec);
    mBuf_bb->bbclientTx_ts.usec = htonl(reportstruct->packetTime.tv_usec);
    mBuf_bb->bbserverRx_ts.sec = -1;
    mBuf_bb->bbserverRx_ts.usec = -1;
    mBuf_bb->bbserverTx_ts.sec = -1;
    mBuf_bb->bbserverTx_ts.usec = -1;
    mBuf_bb->bbhold = htonl(mSettings->mBounceBackHold);
    mBuf_bb->bbreplysize = htonl(mSettings->mBounceBackReplyBytes);
}
#endif // HAVE_UDP_L4S

inline bool Client::InProgress(void) {
    // Read the next data block from
    // the file if it's file input
    if (isFileInput(mSettings)) {
        Extractor_getNextDataBlock(readAt, mSettings);
        return Extractor_canRead(mSettings) != 0;
    }
    // fprintf(stderr, "DEBUG: SI=%d PC=%d T=%d A=%d\n", sInterupted, peerclose,
    // (isModeTime(mSettings) && mEndTime.before(reportstruct->packetTime)),
    // (isModeAmount(mSettings) && (mSettings->mAmount <= 0)));
    return !(sInterupted || peerclose || (isModeTime(mSettings) && mEndTime.before(reportstruct->packetTime)) ||
             (isModeAmount(mSettings) && (mSettings->mAmount <= 0)));
}

inline void Client::tcp_shutdown(void) {
    if ((mySocket != INVALID_SOCKET) && isConnected()) {
        int rc = shutdown(mySocket, SHUT_WR);
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Client calls shutdown() SHUTW_WR on tcp socket %d", mySocket);
#endif
        WARN_REPORT_errno(rc == SOCKET_ERROR, "shutdown");
        if (!rc && !isFullDuplex(mSettings)) AwaitServerCloseEvent();
    }
}

/*
 * Common things to do to finish a traffic thread
 *
 * Notes on the negative packet count or seq no:
 * A negative packet id is used to tell the server
 * this UDP stream is terminating.  The server will remove
 * the sign.  So a decrement will be seen as increments by
 * the server (e.g, -1000, -1001, -1002 as 1000, 1001, 1002)
 * If the retries weren't decrement here the server can get out
 * of order packets per these retries actually being received
 * by the server (e.g. -1000, -1000, -1000)
 */
void Client::FinishTrafficActions() {
    disarm_itimer();
    // Shutdown the TCP socket's writes as the event for the server to end its
    // traffic loop
    if (!isUDP(mSettings)) {
        if (!isIgnoreShutdown(mSettings)) {
            tcp_shutdown();
        }
        now.setnow();
        reportstruct->packetTime.tv_sec = now.getSecs();
        reportstruct->packetTime.tv_usec = now.getUsecs();
        if (one_report) {
            /*
             *  For TCP and if not doing interval or enhanced reporting (needed
             * for write accounting), then report the entire transfer as one big
             * packet
             *
             */
            reportstruct->packetLen = totLen;
            reportstruct->err_readwrite = WriteSuccess;
            myReportPacket();
        }
    } else if (!isBounceBack(mSettings)) {
        // stop timing
        now.setnow();
        reportstruct->packetTime.tv_sec = now.getSecs();
        reportstruct->packetTime.tv_usec = now.getUsecs();
        reportstruct->sentTime = reportstruct->packetTime;
        // send a final terminating datagram
        // Don't count in the mTotalLen. The server counts this one,
        // but didn't count our first datagram, so we're even now.
        // The negative datagram ID signifies termination to the server.
        struct UDP_datagram *mBuf_UDP = reinterpret_cast<struct UDP_datagram *>(mSettings->mBuf);
        WritePacketID(-reportstruct->packetID, mBuf_UDP);
        mBuf_UDP->tv_sec = htonl(reportstruct->packetTime.tv_sec);
        mBuf_UDP->tv_usec = htonl(reportstruct->packetTime.tv_usec);
        int len = write(mySocket, mSettings->mBuf, mSettings->mBufLen);
#ifdef HAVE_THREAD_DEBUG
        thread_debug("UDP client sent final packet per negative seqno %ld", -reportstruct->packetID);
#endif
        if (len > 0) {
            reportstruct->packetLen = len;
            myReportPacket();
        }
        reportstruct->packetLen = 0;
    }
    // Bounceback (UDP) skips the generic "send a negative-packetID
    // terminating datagram + report it" block above entirely - it isn't
    // a continuous UDP stream (that negative-packetID convention is
    // meaningless to the bounceback protocol; the datagram it sends
    // there isn't even shaped like a valid bounceback request), and it
    // already sent its own real end-of-test signal
    // (WriteUdpTxBBHdr(...,0x0,1,false), RunBounceBackUDP) before ever
    // calling this function. Reporting that generic termination event
    // was actively harmful, not just redundant: it reused reportstruct's
    // own sentTimeRX/sentTimeTX fields, last written by the previous
    // *real* bounceback reply and never cleared, paired against a fresh
    // sentTime/packetTime stamped just above - under --trip-times, this
    // one leftover event's own OWD computation (Reporter.c) mixed a
    // stale server timestamp with a fresh client one, producing a
    // spurious ~1-second-offset outlier (e.g. "-999.808ms") that
    // corrupted the whole run's own OWD min/max/avg and histogram -
    // confirmed via a live per-sample debug trace, present only on the
    // final (21st of 21) sample, TCP bounceback unaffected since its own
    // FinishTrafficActions() branch never emits an equivalent extra
    // event for a bounceback run (gated by one_report, already false
    // there).
    bool do_close = EndJob(myJob, reportstruct);
    if (isIsochronous(mSettings) && (myReport->info.schedule_error.cnt > 2)) {
        WARN_REPORT_FMT(1,
                         "%sIsoch schedule errors (mean/min/max/stdev) = "
                         "%0.3f/%0.3f/%0.3f/%0.3f ms\n",
                         mSettings->mTransferIDStr,
                         ((myReport->info.schedule_error.sum / myReport->info.schedule_error.cnt) * 1e-3),
                         (myReport->info.schedule_error.min * 1e-3), (myReport->info.schedule_error.max * 1e-3),
                         (1e-3 * (sqrt(myReport->info.schedule_error.m2 / (myReport->info.schedule_error.cnt - 1)))));
    }
    if (isUDP(mSettings) && !isMulticast(mSettings) && !isNoUDPfin(mSettings)) {
        /*
         *  For UDP, there is a final handshake between the client and the
         * server, do that now (unless requested no to)
         */
        AwaitServerFinPacket();
    }
    if (do_close) {
#if HAVE_THREAD_DEBUG
        thread_debug("client close sock=%d", mySocket);
#endif
        int rc = close(mySocket);
        WARN_errno(rc == SOCKET_ERROR, "client close");
    }
    Iperf_remove_host(mSettings);
    FreeReport(myJob);
    if (framecounter) DELETE_PTR(framecounter);
}

/* -------------------------------------------------------------------
 * Await for the server's fin packet which also has the server
 * stats to displayed on the client.  Attempt to re-transmit
 * until the fin is received
 * ------------------------------------------------------------------- */
#define RETRYTIMER 10000                       // units of us
#define RETRYCOUNT (2 * 1000000 / RETRYTIMER)  // 2 seconds worth of retries
void Client::AwaitServerFinPacket() {
    int rc;
    fd_set readSet;
    struct timeval timeout;
    int ack_success = 0;
    int count = RETRYCOUNT;
    static int read_warn_rate_limiter = 3;  // rate limit read warn msgs
    while (--count >= 0) {
        // wait until the socket is readable, or our timeout expires
        FD_ZERO(&readSet);
        FD_SET(mySocket, &readSet);
        timeout.tv_sec = 0;
        timeout.tv_usec = RETRYTIMER;
        rc = select(mySocket + 1, &readSet, NULL, NULL, &timeout);
        FAIL_errno(rc == SOCKET_ERROR, "select", mSettings);
        // rc= zero means select's read timed out
        if (rc == 0) {
            // try to trigger another FIN by resending a negative seq no
            struct UDP_datagram* mBuf_UDP = reinterpret_cast<struct UDP_datagram*>(mSettings->mBuf);
            WritePacketID(-(++reportstruct->packetID), mBuf_UDP);
            // write data
            rc = write(mySocket, mSettings->mBuf, mSettings->mBufLen);
            WARN_errno(rc < 0, "write-fin");
#ifdef HAVE_THREAD_DEBUG
            thread_debug("UDP client retransmit final packet per negative seqno %ld", -reportstruct->packetID);
#endif
        } else {
            // socket ready to read - this is the server's final stats
            // relay packet (parsed below into the client's "Server
            // Report"). kDefault_UDPTxBufLen is also MINMBUFALLOCSIZE's
            // floor (payloads.h), so mSettings->mBuf is guaranteed to be
            // at least this large regardless of how small -l was set.
            rc = read(mySocket, mSettings->mBuf, kDefault_UDPTxBufLen);

            // dump any 2.0.13 client acks sent at the start of traffic
            if (rc == sizeof(client_hdr_ack)) {
                struct client_hdr_ack *ack = reinterpret_cast<struct client_hdr_ack *>(mSettings->mBuf);
                if (ntohl(ack->typelen.type) == CLIENTHDRACK) {
                    // printf("**** dump stale ack \n");
                    continue;
                }
            }
            // only warn when threads is small, too many warnings are too much
            // outputs
            if (rc < 0 && (--read_warn_rate_limiter > 0)) {
                WARN_REPORT_errno(1, "Read UDP fin");
            }
            if (rc > 0) {
                ack_success = 1;
#ifdef HAVE_THREAD_DEBUG
                thread_debug("UDP client received server relay report ack (%d)", -reportstruct->packetID);
#endif
                if (mSettings->mReportMode != kReport_CSV) {
                    PostReport(InitServerRelayUDPReport(
                        mSettings,
                        reinterpret_cast<server_hdr *>(reinterpret_cast<UDP_datagram *>(mSettings->mBuf) + 1)));
                }
                break;
            }
        }
    }
    if ((!ack_success) && (mSettings->mReportMode != kReport_CSV))
        WARN_REPORT_FMT(1, warn_no_ack, mySocket, (isModeTime(mSettings) ? 10 : 1));
}

// isFirst indicates first event occurred per wait_tick
void Client::PostNullEvent(bool isFirst, bool select_retry, bool paused) {
    assert(myReport != NULL);
    // push a nonevent into the packet ring
    // this will cause the reporter to process
    // up to this event
    struct ReportStruct report_nopacket;
    memset(&report_nopacket, 0, sizeof(struct ReportStruct));
    now.setnow();
    report_nopacket.packetTime.tv_sec = now.getSecs();
    report_nopacket.packetTime.tv_usec = now.getUsecs();
    report_nopacket.emptyreport = true;
    report_nopacket.scheduled = isFirst;
    report_nopacket.packetID = 0;
    // paused (SIGUSR1-driven, see RunTCP/RunWriteEventsTCP's own callers)
    // takes priority over select_retry - both would otherwise resolve to
    // the exact same WriteNoAccount/WriteSelectRetry shape a genuine
    // backpressure stall already uses, making a deliberate pause
    // indistinguishable from an intermittent network outage in the CSV
    // output (see WritePaused's own doc comment, packet_ring.h).
    report_nopacket.err_readwrite = (paused ? WritePaused : (select_retry ? WriteSelectRetry : WriteNoAccount));
    // Carry forward UDP bounceback's own running loss-attribution
    // counters (see struct ReportStruct's own doc comment,
    // packet_ring.h) - a no-op zero/zero/zero for every other caller of
    // this function, but for RunBounceBackUDP specifically this is what
    // lets a run that ends on a string of losses (no further successful
    // reply to carry fresh numbers through the normal success path)
    // still report accurate final totals: RunBounceBackUDP updates
    // reportstruct's own copies of these three fields on every send/
    // reply, and this NullEvent (already posted on every timeout/retry
    // path) just needs to relay whatever reportstruct's own latest
    // values already are.
    report_nopacket.bbRequestsSent = reportstruct->bbRequestsSent;
    report_nopacket.bbRepliesReceived = reportstruct->bbRepliesReceived;
    report_nopacket.bbServerReceivedCount = reportstruct->bbServerReceivedCount;
    reportstruct->packetTime = report_nopacket.packetTime;  // needed for the InProgress loop test
    myReportPacket(&report_nopacket);
#if HAVE_TCP_STATS
    // ReportPacket flags the interval's TCP_INFO sample request on whichever
    // packet crosses the sample time - when that's this throwaway null event
    // (e.g. bounceback's per-tick PostNullEvent lands right on the interval
    // boundary), hand the request to the real reportstruct so the next
    // write's mygetTcpInfo() still takes it.
    if (report_nopacket.tcpstats.needTcpInfoSample) reportstruct->tcpstats.needTcpInfoSample = true;
#endif
}

// The client end timer is based upon the final fin, fin-ack w/the server
// A way to detect this is to hang a recv and wait for the zero byte
// return indicating the socket is closed for recv per the server
// closing it's socket
#define MINAWAITCLOSEUSECS 2000000
void Client::AwaitServerCloseEvent() {
    // the await detection can take awhile so post a non event ahead of it
    PostNullEvent(false, false);
    unsigned int amount_usec =
        (isModeTime(mSettings) ? static_cast<int>(mSettings->mAmount * 10000) : MINAWAITCLOSEUSECS);
    if (amount_usec < MINAWAITCLOSEUSECS) amount_usec = MINAWAITCLOSEUSECS;
    SetSocketOptionsReceiveTimeout(mSettings, amount_usec);
    int rc;
    while ((rc = recv(mySocket, mSettings->mBuf, mSettings->mBufLen, 0)) > 0) {
    };
    if (rc < 0) WARN_REPORT_errno(1, "client await server close");

    if (rc == 0) {
        connected = false;
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Client detected server close %d", mySocket);
#endif
    }
}

int Client::SendFirstPayload() {
    int pktlen = 0;
    if (!isConnectOnly(mSettings)) {
        if (isUDP(mSettings) && (mSettings->sendfirst_pacing > 0)) {
            delay_loop(mSettings->sendfirst_pacing);
        }
        if (myReport && !TimeZero(myReport->info.ts.startTime) && !(mSettings->mMode == kTest_TradeOff)) {
            reportstruct->packetTime = myReport->info.ts.startTime;
        } else {
            now.setnow();
            reportstruct->packetTime.tv_sec = now.getSecs();
            reportstruct->packetTime.tv_usec = now.getUsecs();
        }

        if (isTxStartTime(mSettings)) {
            pktlen = Settings_GenerateClientHdr(mSettings, (void *)mSettings->mBuf, mSettings->txstart_epoch);
        } else if (isTxHoldback(mSettings)) {
            // Relay the relative holdback duration itself (not an
            // absolute time) - see HEADER_EPOCH_DELAY's own doc comment
            // (payloads.h) for why this exists alongside --txstart-time's
            // absolute-epoch relay: no client/server clock sync required.
            // Known minor limitation: --trip-times reuses this exact same
            // wire field (hdr->start_fq.start_tv_sec/usec) for its own,
            // unrelated clock-sync timestamp - if both --txdelay-time and
            // --trip-times are set on the same connection, the server
            // receives the holdback duration here instead of a real send
            // timestamp, silently breaking trip-time's clock-sync check.
            // Not worth a dedicated wire field for this combination alone
            // (--txdelay-time's real use case is a plain -R/--full-duplex
            // "load" phase, not a latency-sensitive trip-time one) - flag
            // rather than fix.
            pktlen = Settings_GenerateClientHdr(mSettings, (void *)mSettings->mBuf, mSettings->txholdback_timer);
        } else {
            pktlen = Settings_GenerateClientHdr(mSettings, (void *)mSettings->mBuf, reportstruct->packetTime);
        }
        if (pktlen > 0) {
            if (isUDP(mSettings)) {
                struct client_udp_testhdr *tmphdr = reinterpret_cast<struct client_udp_testhdr *>(mSettings->mBuf);
                struct UDP_datagram* mBuf_UDP = reinterpret_cast<struct UDP_datagram*>(mSettings->mBuf);
                WritePacketID(reportstruct->packetID, mBuf_UDP);
                tmphdr->seqno_ts.tv_sec = htonl(reportstruct->packetTime.tv_sec);
                tmphdr->seqno_ts.tv_usec = htonl(reportstruct->packetTime.tv_usec);
                udp_payload_minimum = pktlen;
#if HAVE_DECL_CMSG_FIRSTHDR
                struct msghdr msg;
                struct iovec iov[1];
                unsigned char cmsg[CMSG_SPACE(sizeof(int))];
                struct cmsghdr *cmsgptr = NULL;

                memset(&iov, 0, sizeof(iov));
                memset(&cmsg, 0, sizeof(cmsg));
                memset(&msg, 0, sizeof(struct msghdr));

                iov[0].iov_base = mSettings->mBuf;
                iov[0].iov_len = (pktlen > mSettings->mBufLen) ? pktlen : mSettings->mBufLen;
                msg.msg_iov = iov;
                msg.msg_iovlen = 1;
                msg.msg_control = cmsg;
                msg.msg_controllen = sizeof(cmsg);
                cmsgptr = CMSG_FIRSTHDR(&msg);
                cmsgptr->cmsg_level = IPPROTO_IP;
                cmsgptr->cmsg_type = IP_TOS;
                cmsgptr->cmsg_len = CMSG_LEN(sizeof(u_char));
#if HAVE_UDP_L4S
                u_char tos = isUDPL4S(mSettings) ? ((mSettings->mTOS & 0xFC) | ecn_l4s_id) : (mSettings->mTOS);
#else
                u_char tos = (mSettings->mTOS);
#endif
                memcpy(CMSG_DATA(cmsgptr), (u_char *)&tos, sizeof(u_char));
                msg.msg_controllen = CMSG_SPACE(sizeof(u_char));
#if HAVE_DECL_MSG_DONTWAIT
                pktlen = sendmsg(mySocket, &msg, MSG_DONTWAIT);
#else
                pktlen = sendmsg(mySocket, &msg, 0);
#endif
#else  // have cmsg
#if HAVE_DECL_MSG_DONTWAIT
                pktlen = send(mySocket, mSettings->mBuf, (pktlen > mSettings->mBufLen) ? pktlen : mSettings->mBufLen,
                              MSG_DONTWAIT);
#else
                pktlen =
                    send(mySocket, mSettings->mBuf, (pktlen > mSettings->mBufLen) ? pktlen : mSettings->mBufLen, 0);
#endif  // no cmsg
#endif
                apply_first_udppkt_delay = true;
            } else {
                // Set the send timeout for the very first write which has the
                // test exchange
                int sosndtimer = DEFAULT_TESTEXCHANGETIMEOUT;  // in usecs
                SetSocketOptionsSendTimeout(mSettings, sosndtimer);
#if HAVE_DECL_TCP_NODELAY
                if (!isNoDelay(mSettings) && isPeerVerDetect(mSettings) && isTripTime(mSettings)) {
                    int optflag = 1;
                    int rc;
                    // Disable Nagle to reduce latency of this intial message
                    if ((rc = setsockopt(mSettings->mSock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char *>(&optflag),
                                         sizeof(int))) < 0) {
                        WARN_errno(rc < 0, "tcpnodelay");
                    }
                }
#endif
#if HAVE_DECL_MSG_DONTWAIT
                pktlen = send(mySocket, mSettings->mBuf, pktlen, MSG_DONTWAIT);
#else
                pktlen = send(mySocket, mSettings->mBuf, pktlen, 0);
#endif
                SetSocketOptionsSendTimeout(mSettings, mSettings->sosndtimer);
                if (isPeerVerDetect(mSettings) && !isServerReverse(mSettings)) {
                    PeerXchange();
                }
                if (!isFileInput(mSettings)) {
                    int buflen = (mSettings->mBufLen < (int)sizeof(struct client_tcp_testhdr))
                                     ? mSettings->mBufLen
                                     : sizeof(struct client_tcp_testhdr);
                    if (isTripTime(mSettings)) {
                        memset(mSettings->mBuf, 0xA5, buflen);
                    } else {
                        pattern(mSettings->mBuf,
                                buflen);  // reset the pattern in the payload
                                          // for future writes
                    }
                }
#if HAVE_DECL_TCP_NODELAY
                if (!isNoDelay(mSettings) && isPeerVerDetect(mSettings) && isTripTime(mSettings)) {
                    int optflag = 0;
                    int rc;
                    // Disable Nagle to reduce latency of this intial message
                    if ((rc = setsockopt(mSettings->mSock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<char *>(&optflag),
                                         sizeof(int))) < 0) {
                        WARN_errno(rc < 0, "tcpnodelay");
                    }
                }
#endif
            }
            WARN_errno(pktlen < 0, "send_hdr");
        }
    }
    return pktlen;
}

void Client::PeerXchange() {
    int n;
    client_hdr_ack ack;
    /*
     * Hang read and see if this is a header ack message
     */
    int readlen = isTripTime(mSettings) ? sizeof(struct client_hdr_ack)
                                        : (sizeof(struct client_hdr_ack) - sizeof(struct client_hdr_ack_ts));
    if ((n = recvn(mySocket, reinterpret_cast<char *>(&ack), readlen, 0)) == readlen) {
        if (ntohl(ack.typelen.type) == CLIENTHDRACK) {
            mSettings->peer_version_u = ntohl(ack.version_u);
            mSettings->peer_version_l = ntohl(ack.version_l);
            if (isTripTime(mSettings)) {
                Timestamp now;
                Timestamp senttx(ntohl(ack.ts.sent_tv_sec), ntohl(ack.ts.sent_tv_usec));
                Timestamp sentrx(ntohl(ack.ts.sentrx_tv_sec), ntohl(ack.ts.sentrx_tv_usec));
                Timestamp acktx(ntohl(ack.ts.ack_tv_sec), ntohl(ack.ts.ack_tv_usec));
                Timestamp ackrx(now.getSecs(), now.getUsecs());
                double str = (sentrx.get() - senttx.get()) * 1e3;
                double atr = (now.get() - acktx.get()) * 1e3;
                double rtt = str + atr;
                double halfrtt = rtt / 2.0;
                WARN_REPORT_FMT(1,
                                 "%sClock sync check (ms): RTT/Half=(%0.3f/%0.3f) "
                                 "OWD-send/ack/asym=(%0.3f/%0.3f/%0.3f)\n",
                                 mSettings->mTransferIDStr, rtt, halfrtt, str, atr, (str - atr));
            }
        }
    } else {
        WARN_REPORT_errno(1, "recvack");
    }
}

/*
 * BarrierClient allows for multiple stream clients to be syncronized
 */
#define BARRIER_MIN 100  // units is seconds to inform the server
bool Client::BarrierClient(struct BarrierMutex *barrier) {
    bool last = false;
#ifdef HAVE_THREAD
    assert(barrier != NULL);
    Timestamp now;
    Condition_Lock(barrier->await);
    if (--barrier->count <= 0) {
        last = true;
        // last one wake's up everyone else
        Condition_Broadcast(&barrier->await);
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Barrier BROADCAST on condition %p", (void *)&barrier->await);
#endif
    } else {
#ifdef HAVE_THREAD_DEBUG
        thread_debug("Barrier WAIT on condition %p count=%d", (void *)&barrier->await, barrier->count);
#endif
        if (isModeTime(mSettings)) {
            int barrier_wait_secs = int(mSettings->mAmount / 100);  // convert from 10 ms to seconds
            if (barrier_wait_secs <= 0) barrier_wait_secs = 1;
            Condition_TimedWait(&barrier->await, barrier_wait_secs);
        } else {
            Condition_Wait(&barrier->await);
        }
    }
    Condition_Unlock(barrier->await);
#ifdef HAVE_THREAD_DEBUG
    thread_debug("Barrier EXIT on condition %p", (void *)&barrier->await);
#endif
    mSettings->barrier_time = now.delta_usec();
    if (mSettings->barrier_time < BARRIER_MIN) {
        mSettings->barrier_time = 0;
    }
#else
    last = true;
#endif  // HAVE_THREAD
    return last;
}
