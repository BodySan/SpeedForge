#!/usr/bin/env python3
#
# ---------------------------------------------------------------
# * Copyright (c) 2014-2026 Robert J. McMahon
# * All Rights Reserved.
# *---------------------------------------------------------------
# Redistribution and use in source and binary forms, with or without modification, are permitted
# provided that the following conditions are met:
#
# Redistributions of source code must retain the above copyright notice, this list of conditions
# and the following disclaimer.  Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in the documentation and/or other
# materials provided with the distribution.  Neither the name of Broadcom
# Corporation, Robert J. McMahon, nor the names of
# contributors may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
# FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
# IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
# OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
"""
Wasserstein-1 (earth mover's distance) latency regression detector for
iperf2 --histograms output.

Why W1 instead of a KS-style two-sample test: KS is the max CDF deviation,
which concentrates statistical power near the median and is weakest in the
tails - exactly where latency regressions live. It also assumes continuous,
untied data, which binned histograms violate, and with iperf2's typical
per-interval sample counts (1e5+) any two-sample test becomes hypersensitive
- everything is "significant" and the distinction between statistical and
practical difference disappears.

W1 on binned data reduces to sum(|CDF_a - CDF_b|) * binwidth, so it's cheap
to compute directly from the histogram iperf2 already prints. It's in units
of time (the same units as the histogram bins), so a result is directly
interpretable ("distributions differ by N us of mass-weighted displacement"),
it responds proportionally to tail shifts rather than saturating, and being
a distance rather than a p-value, it charts naturally: compute W1 between
each interval and a frozen baseline, then run an EWMA or CUSUM control
statistic over that series and set limits from a calibration run's own
in-control variation rather than an asymptotic null (which sidesteps the
large-n significance inflation problem entirely).

Usage:
    # Compute W1 for every interval in a run against a frozen baseline
    # histogram (by default, the baseline file's *final* aggregate line):
    ./latency_w1.py --baseline calibration.log --compare run.log

    # Isolate tail behavior (conditional distribution above P90), useful
    # when the median is stable but the tail is what's degrading:
    ./latency_w1.py --baseline calibration.log --compare run.log --tail-quantile 0.90

    # Estimate a control limit from a calibration run's own interval-to-
    # interval variation (no --compare needed):
    ./latency_w1.py --baseline calibration.log --calibrate

See doc/latency_w1.md (if present) or run with --help for all options.
"""

import argparse
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# Matches a line iperf2's histogram_print() (src/histogram.c) emits, e.g.:
#   [  1] 0.00-1.00 sec T8-PDF: bin(w=100us):cnt(1784)=1:1782,2:1,4:1 (...)
#   [  1] 0.00-2.00 sec T8(f)-PDF: bin(w=100us):cnt(3569)=1:3567,2:1,4:1 (...)
# The trailing "(ci_lower/ci_upper/...)" and optional "(max ms/timestamp)"
# parenthesized groups aren't needed here, so the regex only anchors on
# what precedes them and captures the comma-separated bin:count list up to
# the first space or open-paren.
HIST_LINE_RE = re.compile(
    r"\[\s*(?P<id>\d+)\]\s+"
    r"(?P<start>[\d.]+)-(?P<end>[\d.]+)\s+sec\s+"
    r"(?P<name>\S+?)(?P<final>\(f\))?-PDF:\s*"
    r"bin\(w=(?P<binwidth>\d+)(?P<unit>us|ms)\):cnt\((?P<population>\d+)\)="
    r"(?P<bins>[0-9:,]*)"
)


@dataclass
class HistogramInterval:
    start: float
    end: float
    name: str
    final: bool
    binwidth_us: float
    population: int
    bins: Dict[int, int] = field(default_factory=dict)

    def cdf(self, up_to_bin: int) -> float:
        """Fraction of population in bins [1, up_to_bin]."""
        if self.population <= 0:
            return 0.0
        total = sum(c for ix, c in self.bins.items() if ix <= up_to_bin)
        return total / self.population

    def max_bin(self) -> int:
        return max(self.bins) if self.bins else 0

    def quantile(self, q: float) -> float:
        """Return the latency (in binwidth units, i.e. bin_index * binwidth_us)
        at which the empirical CDF first reaches q. Returns the top of the
        last populated bin if q is never reached (e.g. q=1.0)."""
        if self.population <= 0 or not self.bins:
            return 0.0
        running = 0
        for ix in sorted(self.bins):
            running += self.bins[ix]
            if running / self.population >= q:
                return ix * self.binwidth_us
        return max(self.bins) * self.binwidth_us

    def tail(self, quantile: float) -> "HistogramInterval":
        """Return a new HistogramInterval containing only the conditional
        distribution above the given quantile (renormalized to its own
        population), isolating tail behavior from bulk jitter."""
        if self.population <= 0:
            return HistogramInterval(self.start, self.end, self.name, self.final, self.binwidth_us, 0, {})
        cutoff_value = self.quantile(quantile)
        cutoff_bin = int(round(cutoff_value / self.binwidth_us))
        tail_bins = {ix: c for ix, c in self.bins.items() if ix > cutoff_bin}
        tail_population = sum(tail_bins.values())
        return HistogramInterval(self.start, self.end, self.name, self.final, self.binwidth_us, tail_population, tail_bins)


def parse_line(line: str) -> Optional[HistogramInterval]:
    m = HIST_LINE_RE.search(line)
    if not m:
        return None
    binwidth = float(m.group("binwidth"))
    if m.group("unit") == "ms":
        binwidth *= 1000.0  # normalize everything to microseconds
    bins: Dict[int, int] = {}
    bins_str = m.group("bins")
    if bins_str:
        for tok in bins_str.split(","):
            idx_str, cnt_str = tok.split(":")
            bins[int(idx_str)] = int(cnt_str)
    return HistogramInterval(
        start=float(m.group("start")),
        end=float(m.group("end")),
        name=m.group("name"),
        final=bool(m.group("final")),
        binwidth_us=binwidth,
        population=int(m.group("population")),
        bins=bins,
    )


def parse_file(path: str, name_filter: Optional[str] = None) -> List[HistogramInterval]:
    intervals = []
    with open(path) as f:
        for line in f:
            iv = parse_line(line)
            if iv is None:
                continue
            if name_filter and iv.name != name_filter:
                continue
            intervals.append(iv)
    return intervals


def wasserstein1(a: HistogramInterval, b: HistogramInterval) -> float:
    """W1 distance in microseconds between two histograms on a shared bin grid.

    On binned data this is exactly sum(|CDF_a(bin) - CDF_b(bin)|) * binwidth
    - the discrete analogue of the standard integral(|CDF_a - CDF_b|) dx
    identity for the 1-Wasserstein distance.
    """
    if a.binwidth_us != b.binwidth_us:
        raise ValueError(
            f"bin width mismatch: baseline={a.binwidth_us}us vs comparison={b.binwidth_us}us "
            "(re-run both sides with the same --histogram-bin-size)"
        )
    if a.population <= 0 or b.population <= 0:
        return 0.0
    max_bin = max(a.max_bin(), b.max_bin())
    cdf_a = cdf_b = 0.0
    w1 = 0.0
    bins_a, bins_b = a.bins, b.bins
    for ix in range(1, max_bin + 1):
        cdf_a += bins_a.get(ix, 0) / a.population
        cdf_b += bins_b.get(ix, 0) / b.population
        w1 += abs(cdf_a - cdf_b) * a.binwidth_us
    return w1


def ewma_series(values: List[float], lam: float) -> List[float]:
    out = []
    prev = values[0] if values else 0.0
    for v in values:
        prev = lam * v + (1 - lam) * prev
        out.append(prev)
    return out


def cusum_series(values: List[float], target: float, slack: float):
    """Two-sided CUSUM. Returns (upper, lower) series; an alarm is upper[i]
    or lower[i] exceeding whatever decision interval the caller chooses."""
    upper: List[float] = []
    lower: List[float] = []
    c_pos = c_neg = 0.0
    for v in values:
        c_pos = max(0.0, c_pos + (v - target) - slack)
        c_neg = max(0.0, c_neg - (v - target) - slack)
        upper.append(c_pos)
        lower.append(c_neg)
    return upper, lower


def pick_baseline(intervals: List[HistogramInterval]) -> HistogramInterval:
    """Frozen reference: the final (whole-run aggregate) histogram by
    default, per the recommendation to freeze from a known-good calibration
    window rather than a sliding reference (otherwise slow drift becomes
    invisible)."""
    finals = [iv for iv in intervals if iv.final]
    if finals:
        return finals[-1]
    if not intervals:
        raise ValueError("no histogram lines found in baseline file")
    return intervals[-1]


def resolve_histogram_name(path: str, requested: Optional[str]) -> str:
    """A log can contain more than one histogram type at once (latency T8,
    jitter J8, frame F8, bounceback RTT, ...); mixing them into one W1
    series would be meaningless. If the caller didn't pin down a name with
    --histogram-name, use whichever name appears first in the baseline file
    and apply that same name to both files so the two sides always line up."""
    if requested:
        return requested
    all_intervals = parse_file(path, None)
    if not all_intervals:
        raise ValueError(f"no histogram lines found in {path}")
    names = sorted({iv.name for iv in all_intervals})
    if len(names) > 1:
        print(
            f"note: {path} contains multiple histogram types {names}; "
            f"defaulting to {names[0]!r} - pass --histogram-name to pick a different one",
            file=sys.stderr,
        )
    return names[0]


def cmd_compare(args):
    histogram_name = resolve_histogram_name(args.baseline, args.histogram_name)
    baseline_intervals = parse_file(args.baseline, histogram_name)
    baseline = pick_baseline(baseline_intervals)
    compare_intervals = [iv for iv in parse_file(args.compare, histogram_name) if not iv.final]

    if args.tail_quantile is not None:
        baseline = baseline.tail(args.tail_quantile)
        compare_intervals = [iv.tail(args.tail_quantile) for iv in compare_intervals]

    if not compare_intervals:
        print("no per-interval histogram lines found in --compare file", file=sys.stderr)
        return 1

    w1_values = [wasserstein1(baseline, iv) for iv in compare_intervals]
    ewma = ewma_series(w1_values, args.ewma_lambda)
    cusum_upper, cusum_lower = cusum_series(w1_values, args.cusum_target, args.cusum_slack)

    header = f"{'interval':>16}  {'W1(us)':>10}  {'EWMA(us)':>10}  {'CUSUM+':>10}  {'CUSUM-':>10}  {'P50(us)':>9}  {'P99(us)':>9}"
    print(header)
    print("-" * len(header))
    alarmed = False
    for iv, w1, e, cu, cl in zip(compare_intervals, w1_values, ewma, cusum_upper, cusum_lower):
        alarm = (args.limit is not None) and (e > args.limit or cu > args.limit or cl > args.limit)
        alarmed = alarmed or alarm
        marker = "  <-- ALARM" if alarm else ""
        print(
            f"{iv.start:6.2f}-{iv.end:6.2f}  {w1:10.2f}  {e:10.2f}  {cu:10.2f}  {cl:10.2f}  "
            f"{iv.quantile(0.50):9.1f}  {iv.quantile(0.99):9.1f}{marker}"
        )

    if args.limit is None:
        print(
            "\nNo --limit given, so no ALARM column is evaluated - run with "
            "--calibrate against a baseline file to estimate one from "
            "in-control run-to-run variation.",
            file=sys.stderr,
        )
    return 1 if alarmed else 0


def cmd_calibrate(args):
    """Characterize in-control variation from a calibration-only run: W1
    between each interval and the run's own final aggregate. The spread of
    these values is the noise floor a control limit should sit above."""
    histogram_name = resolve_histogram_name(args.baseline, args.histogram_name)
    intervals = parse_file(args.baseline, histogram_name)
    baseline = pick_baseline(intervals)
    per_interval = [iv for iv in intervals if not iv.final]
    if args.tail_quantile is not None:
        baseline = baseline.tail(args.tail_quantile)
        per_interval = [iv.tail(args.tail_quantile) for iv in per_interval]
    if not per_interval:
        print("no per-interval histogram lines found in --baseline file", file=sys.stderr)
        return 1
    w1_values = [wasserstein1(baseline, iv) for iv in per_interval]
    mean = sum(w1_values) / len(w1_values)
    variance = sum((v - mean) ** 2 for v in w1_values) / max(1, len(w1_values) - 1)
    stdev = variance**0.5
    suggested_limit = mean + 3 * stdev
    print(f"in-control W1 samples: n={len(w1_values)}")
    print(f"  mean   = {mean:.2f} us")
    print(f"  stdev  = {stdev:.2f} us")
    print(f"  max    = {max(w1_values):.2f} us")
    print(f"suggested --limit (mean + 3*stdev): {suggested_limit:.2f}")
    return 0


def build_argparser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--baseline", required=True, help="iperf2 log file to draw the frozen reference histogram from")
    p.add_argument("--compare", help="iperf2 log file with the per-interval histograms to test against the baseline")
    p.add_argument("--calibrate", action="store_true", help="estimate a control limit from --baseline's own in-control variation instead of comparing a run")
    p.add_argument("--histogram-name", default=None, help="only use histogram lines whose name matches this (e.g. T8 for latency, J8 for jitter, F8 for frame); default: first name seen")
    p.add_argument("--tail-quantile", type=float, default=None, help="if set, compute W1 on the conditional distribution above this quantile (e.g. 0.90) instead of the full distribution, isolating tail behavior from bulk jitter")
    p.add_argument("--ewma-lambda", type=float, default=0.2, help="EWMA smoothing factor (default 0.2)")
    p.add_argument("--cusum-target", type=float, default=0.0, help="CUSUM target/reference value in us (default 0, i.e. any positive W1 accumulates)")
    p.add_argument("--cusum-slack", type=float, default=0.0, help="CUSUM slack/allowance in us (default 0)")
    p.add_argument("--limit", type=float, default=None, help="control limit in us for EWMA/CUSUM alarms; estimate one with --calibrate first")
    return p


def main(argv=None):
    args = build_argparser().parse_args(argv)
    if args.calibrate:
        return cmd_calibrate(args)
    if not args.compare:
        print("--compare is required unless --calibrate is given", file=sys.stderr)
        return 2
    return cmd_compare(args)


if __name__ == "__main__":
    sys.exit(main())
