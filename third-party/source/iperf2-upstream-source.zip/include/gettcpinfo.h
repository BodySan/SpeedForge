/*---------------------------------------------------------------
 * Copyright (c) 2021 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * gettcpinfo.c
 * Suppport for tcp info in a portable way
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#ifndef GETTCPINFO_H
#define GETTCPINFO_H

#include "headers.h"

#define HAVE_TCP_INFLIGHT                                                                        \
    (HAVE_TCP_STATS && HAVE_STRUCT_TCP_INFO_TCPI_DSACK_DUPS && HAVE_STRUCT_TCP_INFO_TCPI_LOST && \
     HAVE_STRUCT_TCP_INFO_TCPI_SACKED && HAVE_STRUCT_TCP_INFO_TCPI_UNACKED)

// TCP bounceback's CE=cnt(%) column needs both tcpi_delivered_ce and
// tcpi_delivered - without them the human-readable report drops the
// column entirely rather than printing a meaningless -1 every row.
#define HAVE_TCP_BB_CE \
    (HAVE_TCP_STATS && HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED_CE && HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED)

#ifdef __cplusplus
extern "C" {
#endif

struct iperf_tcpstats {
    bool isValid;
    bool needTcpInfoSample;
    uint32_t rtt;
    double connecttime;
    // Live, currently-autotuned send socket buffer size (getsockopt
    // SOL_SOCKET/SO_SNDBUF, src/tcp_window_size.c's own
    // getsock_tcp_windowsize() does the same lookup) - NOT part of
    // TCP_INFO, so unconditional on HAVE_TCP_STATS unlike the fields
    // below; only gated on SO_SNDBUF existing at all (basic sockets API,
    // present everywhere iperf2 builds). In KB, same longstanding
    // divide-by-1024 convention as cwnd/notsent_bytes below. -1 when
    // SO_SNDBUF isn't available or the getsockopt call fails. This is the
    // kernel's own live buffer allocation, not the sysctl net.ipv4.tcp_wmem
    // min/default/max range that bounds its autotuning.
    intmax_t sndbuf_bytes;
#if HAVE_TCP_STATS
    intmax_t cwnd;
    uint32_t cwnd_packets;
    uint32_t rttvar;
    uint32_t retry;
    uint32_t retry_prev;
    uint32_t retry_tot;
    uint32_t mss_negotiated;
    uint32_t packets_in_flight;
    intmax_t bytes_in_flight;
    // Darwin/iOS-only approximation of the field above (compat/gettcpinfo.c's
    // TCP_CONNECTION_INFO branch) - Apple's public tcp_connection_info
    // struct has no equivalent to Linux's tcpi_unacked/tcpi_sacked/
    // tcpi_lost (true in-flight accounting is private-API-only on Darwin,
    // confirmed directly with Apple's networking team, July 2026). The
    // closest public figure is tcpi_snd_sbbytes: everything still sitting
    // in the send socket buffer, i.e. unsent-plus-unacked combined, not a
    // pure in-flight count - an upper bound on bytes_in_flight, not the
    // real number. Kept as its own field rather than aliased into
    // bytes_in_flight so a Darwin build can't silently be read as having
    // the same precision as Linux's. -1 when unavailable, same convention
    // as notsent_bytes/rtt_min below.
    intmax_t sndbuf_occupied_bytes;
    // Bytes already written to the socket's send buffer but not yet put on
    // the wire (Linux tcpi_notsent_bytes, kernel 4.6+ - what --tcp-write-
    // prefetch/TCP_NOTSENT_LOWAT actually bounds) - distinct from
    // bytes_in_flight (unacked bytes genuinely in flight on the network).
    // -1 when HAVE_STRUCT_TCP_INFO_TCPI_NOTSENT_BYTES isn't available.
    intmax_t notsent_bytes;
    // Kernel's own continuously-updated minimum RTT for this connection
    // (Linux tcpi_min_rtt, kernel 4.11+) - tracked at full per-ACK
    // granularity, not just once per report interval like rtt above, so
    // it's a more accurate "best RTT observed" baseline than an app-side
    // running min of the already-smoothed per-interval rtt samples would
    // be. Used for TCP's own queueing-vs-network delay decomposition (rtt
    // minus this baseline), the same role PragueCC's own m_rtt_min plays
    // for UDP-L4S's Load Delay. -1 when
    // HAVE_STRUCT_TCP_INFO_TCPI_MIN_RTT isn't available. intmax_t, not
    // uint32_t, so that -1 prints as -1 (not a wrapped 4294967295) like
    // every other "-1 when unavailable" field in this struct.
    intmax_t rtt_min;
    // Cumulative microseconds this connection has spent limited by its own
    // send buffer (Linux tcpi_sndbuf_limited, kernel 4.9+) - the kernel's
    // own direct answer to "was throughput capped by SO_SNDBUF/
    // TCP_NOTSENT_LOWAT this interval", complementing write_time's
    // per-write blocking measurement (ReportStruct.write_time) with a
    // cumulative, kernel-tracked figure. Same raw-cumulative/_prev/delta
    // convention as retry_tot/retry_prev/retry above - _tot and _prev
    // are the raw counter and its last-seen snapshot, the bare field is
    // this interval's delta (computed in Reporter.c, not here). 0 when
    // HAVE_STRUCT_TCP_INFO_TCPI_SNDBUF_LIMITED isn't available (an
    // unavailable cumulative counter can't produce a meaningful negative
    // sentinel the way a point-in-time sample can - see this field's own
    // CSV/wire relay comments for how that's surfaced instead). _tot/_prev
    // are uint64_t, matching the kernel's own tcpi_* width (a connection
    // held open past ~71 minutes would wrap a uint32_t cumulative
    // microsecond counter); the delta itself (this field) stays uint32_t -
    // no realistic report interval accumulates anywhere near 2^32us
    // (~71 minutes) of limited-time in a single interval.
    uint32_t sndbuf_limited;
    uint64_t sndbuf_limited_prev;
    uint64_t sndbuf_limited_tot;
    // Same convention, for time limited by the peer's advertised receive
    // window (Linux tcpi_rwnd_limited, kernel 4.9+) - a receiver-side cap,
    // distinct from sndbuf_limited's local one.
    uint32_t rwnd_limited;
    uint64_t rwnd_limited_prev;
    uint64_t rwnd_limited_tot;
    // Same convention, for total time this connection had data queued to
    // send at all (Linux tcpi_busy_time, kernel 4.9+) - the denominator
    // sndbuf_limited/rwnd_limited are naturally compared against (time
    // spent limited as a fraction of time spent actually busy, not of
    // wall-clock interval time, which would also count idle gaps).
    uint32_t busy_time;
    uint64_t busy_time_prev;
    uint64_t busy_time_tot;
    // TCP bounceback only (see src/Reporter.c's reporter_handle_packet_
    // tcpistats/reporter_transfer_protocol_client_bb_tcp) - the same CE-
    // mark congestion signaling this codebase's UDP-L4S transport already
    // reports (ce/ceperc), but sourced from mainline Linux's own ECN-
    // capable TCP CCAs (e.g. --tcp-cca prague, kernel 4.19+) via struct
    // tcp_info's tcpi_delivered_ce (cumulative CE-marked segments
    // delivered) and tcpi_delivered (cumulative segments delivered, the
    // percent's denominator) - see this file's own 2011 doc comment from
    // Neal Cardwell suggesting exactly this. Same raw-cumulative/_prev/
    // delta convention as sndbuf_limited_tot/_prev/sndbuf_limited above -
    // _tot/_prev are the raw kernel counter and its last-seen snapshot,
    // the bare field is this interval's delta (computed in Reporter.c).
    // 0 when HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED_CE isn't available - same
    // "unavailable cumulative counter can't produce a meaningful negative
    // sentinel" reasoning as sndbuf_limited_tot; the CSV/report layer
    // (Locale.c/ReportOutputs.c) is what actually surfaces "CE data
    // unavailable" as -1, distinct from "0 CE marks observed, counters
    // valid".
    uint32_t ce_marks;
    uint64_t ce_marks_prev;
    uint64_t ce_marks_tot;
    // Same convention, for tcpi_delivered (cumulative segments delivered)
    // - the denominator ce_marks is naturally compared against to form
    // ce_percent = 100.0 * ce_marks / delivered, mirroring UDP-L4S's own
    // ce/ceperc pairing. 0 when HAVE_STRUCT_TCP_INFO_TCPI_DELIVERED isn't
    // available.
    uint32_t delivered;
    uint64_t delivered_prev;
    uint64_t delivered_tot;
#endif
};

#if WIN32
void gettcpinfo(SOCKET sock, struct iperf_tcpstats *sample);
#else
void gettcpinfo(int sock, struct iperf_tcpstats *sample);
#endif
void tcpstats_copy(struct iperf_tcpstats *stats_dst, struct iperf_tcpstats *stats_src);

#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif
