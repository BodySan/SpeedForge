/*---------------------------------------------------------------
 * Copyright (c) 2022 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * Header file for dscp parsing
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * ------------------------------------------------------------------- */

/*
 *      7  6  5  4  3  2  1  0
 *    +--+--+--+--+--+--+--+--+
 *    |     DSCP        | ECN |
 *    +--+--+--+--+--+--+--+--+
 *
 */

#ifndef DSCP_H
#define DSCP_H
#ifdef __cplusplus
extern "C" {
#endif

// DSCP bits
#define DSCP_SHIFT 2
#define DSCP_BITMASK 0xFC
#define ECN_BITMASK 0x03
#define DSCP_VALUE(value) (int)((value & DSCP_BITMASK) >> DSCP_SHIFT)
#define ECN_VALUE(value) (int)(value & ECN_BITMASK)

int parse_ipqos(const char *cp);
const char *iptos2str(int iptos);
#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif /* DSCP_H */
