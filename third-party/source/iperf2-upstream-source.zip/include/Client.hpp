/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 * Client.hpp
 * by Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * A client thread initiates a connect to the server and handles
 * sending and receiving data, then closes the socket.
 * -------------------------------------------------------------------
 */

#ifndef CLIENT_H
#define CLIENT_H

#include "Settings.hpp"
#include "Timestamp.hpp"
#include "isochronous.hpp"
#include "iperf_multicast_api.h"
#include "Mutex.h"
#if HAVE_UDP_L4S
#include "prague_cc.h"
#endif
#ifndef WIN32
#include <atomic>
// Set by main.cpp's SIGUSR1/SIGUSR2 handlers (defined there), consumed by
// a working-load thread's own write loop below (RunTCP/RunWriteEventsTCP/
// RunUDPL4S, gated on isWorkingLoadThread(mSettings) - see
// FLAG_WORKING_LOAD_THREAD's own doc comment, Settings.hpp) to pause/
// resume its sends without tearing the connection down. Two distinct
// signals (pause/resume), not one toggle - POSIX signals aren't queued,
// so a second SIGUSR1 arriving before the first is handled would be
// silently coalesced/dropped; a toggle built on that could desync from
// what the sender thinks the state is, where two distinct absolute-state
// signals stay idempotent regardless of any drop.
//
// std::atomic<int>, not a plain volatile sig_atomic_t (the convention
// sReloadPermitKeyFile, util.h, still uses) - confirmed via a real device
// repro that plain volatile is NOT enough here: it only guarantees the
// signal handler's own write is visible to *that same thread's* later
// execution (the traditional C signal-handler-safety guarantee), not that
// a *different* thread (the working-load thread's own polling loop,
// running on a different CPU core) ever observes it in bounded time.
// x86's own strong memory ordering (TSO) happens to paper over this - a
// desktop Linux repro of this exact feature worked perfectly - but ARM's
// weak memory model has no such guarantee without an explicit barrier,
// and every Android device this app runs on is ARM: the write from
// Sig_PauseWorkingLoad landed in the signal-handling thread's own store
// buffer and was never observed to propagate to the working-load thread's
// own core within an entire 60-second test window, live-verified via a
// real device (SIGUSR1 delivered, correct pid confirmed independently via
// `ps`, zero effect on the CSV output - tcppaused stayed 0 throughout).
//
// Declared here rather than util.h (where sReloadPermitKeyFile lives) -
// util.h is transitively reachable from inside Thread.h's own
// extern "C" { ... } block (Thread.h includes Condition.h, which includes
// util.h, all before Thread.h's own closing brace), and std::atomic is a
// C++ template - it can't have C linkage, so a declaration placed there
// fails to compile ("template with C linkage") regardless of how it's
// guarded within util.h's own file. Client.hpp is never included from
// inside anyone else's extern "C" block, so this is safe here.
extern std::atomic<int> sWorkingLoadPaused;
#endif
/* ------------------------------------------------------------------- */
class Client {
   public:
    // stores server hostname, port, UDP/TCP mode, and UDP rate
    Client(thread_Settings *inSettings);

    // destroy the client object
    ~Client();

    // Set up the traffic thread and invokes
    // appropriate traffic loop per the protocol
    // and type of traffic
    void Run(void);

    // For things like dual tests a server needs to be started by the client,
    // The code in src/launch.cpp will invoke this
    int StartSynch(void);
    void TxDelay(void);
    void ConnectPeriodic(void);
    bool my_connect(bool close_on_fail);
    void mySockInit(void);
    bool isConnected(void) const;
    int SendFirstPayload(void);
    bool BarrierClient(struct BarrierMutex *);
    void RunBounceBackTCP(void);
#if HAVE_UDP_L4S
    void RunBounceBackUDP(void);
#endif
    struct ReportHeader *myJob;

   private:
    inline void WritePacketID(intmax_t, struct UDP_datagram * mBuf_UDP);
    inline void WriteTcpTxHdr(struct ReportStruct *, int, int);
    inline void WriteTcpTxBBHdr(struct ReportStruct *, uint32_t, int, bool, bool);
#if HAVE_UDP_L4S
    inline void WriteUdpTxBBHdr(struct ReportStruct *, uint32_t, int, bool);
    inline int ReadUdpBBReplyWithRxTos(u_char &rxtos);
#endif
    inline int myWrite(int inSock, const void *inBuf, int inLen);
    inline int myWriten(int inSock, const void *inBuf, int inLen, int *count);
#if HAVE_TCP_STATS
    inline void mygetTcpInfo(void);
#endif
    inline double get_delay_target(void);
    void InitTrafficLoop(void);
    void SetReportStartTime(void);
    inline void SetFullDuplexReportStartTime(void);
    void FinishTrafficActions(void);
    void AwaitServerFinPacket(void);
    bool InProgress(void);
    void PostNullEvent(bool isFirst, bool select_retry, bool paused = false);
    void AwaitServerCloseEvent(void);
    inline void tcp_shutdown(void);
    bool connected;
    ReportStruct scratchpad;
    ReportStruct *reportstruct;
    double delay_lower_bounds;
    intmax_t totLen;
    bool one_report;
    bool apply_first_udppkt_delay;
    int udp_payload_minimum;
    void myReportPacket(void);
    void myReportPacket(struct ReportStruct *);
    // TCP plain
    void RunTCP(void);
    // TCP version which supports rate limiting per -b
    void RunRateLimitedTCP(void);
    void RunNearCongestionTCP(void);
    bool AwaitSelectWrite(void);
#if HAVE_DECL_TCP_NOTSENT_LOWAT
    void RunWriteEventsTCP(void);
#endif
    // UDP traffic with isochronous and vbr support
    void RunUDPIsochronous(void);
    // UDP plain
    void RunUDP(void);
    void RunUDPBurst(void);
#if HAVE_UDP_L4S
    void RunUDPL4S(void);
    int ack_poll(time_tp ack_timeout);
    struct udp_l4s_ack UDPAckBuf;
#endif
#if HAVE_SENDMMSG
    // UDP traffic in bursts using sendmmsg
    void RunUDPBurstMMSG(void);
#endif
    // client connect
    void PeerXchange(void);
    thread_Settings *mSettings;
#if WIN32
    SOCKET mySocket;
#else
    int mySocket;
#endif
    struct ReporterData *myReport;
    Timestamp mEndTime;
    Timestamp lastPacketTime;
    Timestamp now;
    char *readAt;
    Timestamp connect_done, connect_start;
    Isochronous::FrameCounter *framecounter;
    bool isburst;
    bool mysock_init_done;
    bool peerclose;
    Timestamp write_start;
    struct markov_graph *markov_graph_len;

#if HAVE_DECL_SO_MAX_PACING_RATE
    Timestamp PacingStepTime;
#endif
};  // end class Client

#endif  // CLIENT_H
