/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * sha256.h
 * -------------------------------------------------------------------
 * Minimal, self-contained SHA-256 and HMAC-SHA256 (FIPS 180-4 / RFC
 * 2104), written directly from the published specs rather than linked
 * from a crypto library - iperf2 has no OpenSSL/libcrypto dependency
 * today (see configure.ac) and this exists solely for permit-key's
 * own HMAC1 wire format (Settings.cpp/Listener.cpp), not as a
 * general-purpose crypto API.
 * ------------------------------------------------------------------- */
#ifndef SHA256_H
#define SHA256_H
#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>
#include <stdint.h>

#define SHA256_DIGEST_LENGTH 32
#define SHA256_BLOCK_LENGTH 64

typedef struct {
    uint32_t state[8];
    uint64_t bitlen;
    unsigned char buffer[SHA256_BLOCK_LENGTH];
    size_t buflen;
} SHA256_CTX;

void sha256_init(SHA256_CTX *ctx);
void sha256_update(SHA256_CTX *ctx, const unsigned char *data, size_t len);
void sha256_final(SHA256_CTX *ctx, unsigned char digest[SHA256_DIGEST_LENGTH]);
void sha256(const unsigned char *data, size_t len, unsigned char digest[SHA256_DIGEST_LENGTH]);

// RFC 2104 HMAC, keyed with SHA-256 as the underlying hash.
void hmac_sha256(const unsigned char *key, size_t keylen,
                  const unsigned char *data, size_t datalen,
                  unsigned char digest[SHA256_DIGEST_LENGTH]);

#ifdef __cplusplus
} /* end extern "C" */
#endif
#endif /* SHA256_H */
