/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * Server.hpp
 * by Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * A server thread is initiated for each connection accept() returns.
 * Handles sending and receiving data, and then closes socket.
 * ------------------------------------------------------------------- */

#ifndef SERVER_H
#define SERVER_H

#include "Settings.hpp"
#include "util.h"
#include "Timestamp.hpp"
#ifndef WIN32
#include <atomic>
// See Client.hpp's own copy of this declaration for the full doc comment
// (why std::atomic and not volatile sig_atomic_t, why it's declared here
// rather than util.h, why the same variable is used here at all - a
// --working-load=down TCP reader thread is a Client-app-process-spawned
// thread that runs through this Server class's own RunTCP() read loop
// despite being neither a literal client nor a literal server in the
// network sense - see clientside_client_reverse/server_spawn, Launch.cpp -
// so it shares the exact same process, and thus the exact same signal
// handler and sWorkingLoadPaused flag, as any client-writer working-load
// thread; pausing it needs no wire-protocol relay at all, just gating
// this read loop the same way the write loops already are).
extern std::atomic<int> sWorkingLoadPaused;
#endif

/* ------------------------------------------------------------------- */
class Server {
   public:
    // stores server socket, port and TCP/UDP mode
    Server(thread_Settings *inSettings);

    // destroy the server object
    ~Server();

    // accepts connection and receives data
    void RunUDP(void);
#if HAVE_UDP_L4S
    void RunUDPL4S(void);
#endif
    void RunTCP(void);
    void RunBounceBackTCP(void);
#if HAVE_UDP_L4S
    void RunBounceBackUDP(void);
#endif
    static void Sig_Int(int inSigno);

   private:
    thread_Settings *mSettings;
    Timestamp mEndTime;
    Timestamp now;
    ReportStruct scratchpad;
    ReportStruct *reportstruct;
#if HAVE_UDP_L4S
    // RunBounceBackUDP/ProcessBounceBackUDP's own strictly-incrementing
    // packetID source - see ProcessBounceBackUDP's own doc comment for why
    // this can't just reuse the wire-level bbid.
    intmax_t mBBRequestSeqNo = 0;
    // One-shot guards, not counters - see HEADER_BBREQ_BLEACHED/
    // HEADER_BBREQ_CONFIRMED's own doc comments (payloads.h). Only ever
    // needs to fire once each per connection; mutually exclusive in
    // practice (a given request is either bleached or not) but tracked
    // as two independent flags rather than one tri-state, matching the
    // style every other one-shot guard in this file already uses.
    bool mReqBleachLogged = false;
    bool mReqConfirmedLogged = false;
    // Same one-shot-guard idea, RunUDPL4S's own (the continuous Capacity
    // stream, not Bounceback) - see that log site's own doc comment,
    // Server.cpp, for why this needs a separate pair rather than reusing
    // the two above.
    bool mL4sConfirmedLogged = false;
    bool mL4sBleachLogged = false;
#endif

    void InitKernelTimeStamping(void);
    bool InitTrafficLoop(void);
#if HAVE_RECVMMSG
    ssize_t recvmulti(int, void *,  size_t, int );
#endif
    inline void SetFullDuplexReportStartTime(void);
    inline void SetReportStartTime();
    bool ReadBBWithRXTimestamp();
#if HAVE_UDP_L4S
    bool ProcessBounceBackUDP(int rxlen, bool tosKnown = true);
#endif
    int ReadWithRxTimestamp(void);
    bool ReadPacketID(int);
    void L2_processing(void);
    int L2_quintuple_filter(void);
    void udp_isoch_processing(int);
    bool InProgress(void);
    int SkipFirstPayload(void);
    void ClientReverseFirstRead(void);
    void PostNullEvent(bool paused = false);
    inline bool WriteBB(void);
    Timestamp connect_done;
    bool peerclose;
    bool isburst;
#if WIN32
    SOCKET mySocket;
    SOCKET myDropSocket;
#else
    int mySocket;
    int myDropSocket;
#endif
    struct ReportHeader *myJob;
    struct ReporterData *myReport;
    struct markov_graph *markov_graph_len;
#if HAVE_DECL_SO_TIMESTAMP
    // Structures needed for recvmsg
    // Use to get kernel timestamps of packets
    struct sockaddr_storage srcaddr;
    struct iovec iov[1];
    struct msghdr message;
    char *ctrl;
    struct cmsghdr *cmsg;
#if HAVE_DECL_MSG_CTRUNC
    bool ctrunc_warn_enable;
#endif
#endif
#if defined(HAVE_LINUX_FILTER_H) && defined(HAVE_AF_PACKET)
    struct ether_header *eth_hdr;
    struct iphdr *ip_hdr;
    struct udphdr *udp_hdr;
#endif
#if HAVE_RECVMMSG
    char* mBuf_curr;
    bool init_buf_idx;
    bool initialized_mm;
    int nextindex;
    struct mmsghdr *msghdr;
    struct iovec *iovmm;
    int count;
#endif /* HAVE_RECVMMSG */
}; // end class Server

#endif  // SERVER_H
