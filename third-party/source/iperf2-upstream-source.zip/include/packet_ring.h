/*---------------------------------------------------------------
 * Copyright (c) 2019 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * packet_ring.h
 * Suppport for packet rings between threads
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#ifndef PACKETRINGC_H
#define PACKETRINGC_H

#include "Condition.h"
#include "gettcpinfo.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ACKRING_DEFAULTSIZE 100

enum ReadWriteExtReturnVals {
    ReadSuccess = 0,
    ReadTimeo,
    ReadTimeoFatal,
    ReadErrLen,
    ReadNoAccount,
    ReadWrongSrcPort,
    WriteSuccess,
    WriteSelectRetry,
    WriteErrAccount,
    WriteErrFatal,
    WriteTimeo,
    WriteNoAccount,
    // SIGUSR1-paused working-load thread (Client.cpp's RunTCP/
    // RunWriteEventsTCP, sWorkingLoadPaused) - a deliberate null event,
    // same shape as WriteNoAccount (doesn't touch WriteCnt/WriteErr), but
    // tallied into its own separate Paused/totPaused counters
    // (Reporter.c/Reporter.h) so the CSV output can tell "no writes
    // because a technician paused this stream" apart from "no writes
    // because of backpressure/an intermittent network outage" - both
    // would otherwise show an identical zero-byte interval.
    WritePaused,
    NullEvent
};

enum edgeLevel { LOW = 0, HIGH = 1 };

struct ReportStruct {
    intmax_t packetID;
    intmax_t packetLen;
    struct timeval packetTime;
    struct timeval prevPacketTime;
    struct timeval sentTime;
    struct timeval prevSentTime;
    enum ReadWriteExtReturnVals err_readwrite;
    bool emptyreport;
    int l2errors;
    int l2len;
    int expected_l2len;
    u_char tos;
    // isochStartTime is overloaded: first write timestamp of the frame or burst
    // w/trip-times or very first read w/o trip-times reporter calculation will
    // compute latency accordingly
    struct timeval isochStartTime;
    uint32_t prevframeID;
    uint32_t frameID;
    uint32_t burstsize;
    uint32_t burstperiod;
    uint32_t remaining;
    bool transit_ready;
    int writecnt;
    intmax_t writeLen;
    intmax_t recvLen;
    long write_time;
    bool scheduled;
    long sched_err;
    struct timeval sentTimeRX;
    struct timeval sentTimeTX;
    // UDP bounceback per-direction loss attribution (RunBounceBackUDP,
    // Client.cpp/Server.cpp) - the client's own running totals as of
    // *this* event, not a per-interval delta like most other fields
    // here. Carried on every event (a successful reply, or the
    // just-gave-up-on-this-one NullEvent posted after a bounded read
    // timeout - see PostNullEvent's own doc comment for why it copies
    // these three fields specifically), so whichever event happens to
    // be the last one processed before the run's own final report
    // always has the latest known values, including a run that ends on
    // a string of losses with no further successful reply to carry
    // fresh numbers. bbRequestsSent: total requests this client has
    // written so far. bbRepliesReceived: total replies this client has
    // actually gotten back. bbServerReceivedCount: the server's own
    // running received-count, as of the most recent reply that echoed
    // it (struct bounceback_udp_hdr.bbRequestsRx, payloads.h) - stays
    // at its last known value across any trailing losses, same
    // "freeze at the last real reading" reasoning bbowdto/bbowdfro use
    // for a stale-vs-missing sample. See reporter_transfer_protocol_
    // client_udp_bb's own doc comment (Reporter.c) for how these three
    // combine into request-direction vs reply-direction loss counts.
    uint32_t bbRequestsSent;
    uint32_t bbRepliesReceived;
    uint32_t bbServerReceivedCount;
    struct iperf_tcpstats tcpstats;
#if defined(HAVE_DECL_SO_MAX_PACING_RATE)
    intmax_t FQPacingRate;
#endif
    int32_t ce_count;
    int32_t ce_rxcount;
    // UDP L4S write-side only (PragueCC::Get_LostCount(), src/prague_cc.cpp)
    // - delta in the server-echoed lost-packet count since the last ACK,
    // same "accumulate into a running total, diffed per report interval"
    // contract as ce_count above (see reporter_handle_packet_client/
    // reporter_transfer_protocol_client_udp, Reporter.c). Signed: unlike CE
    // marks this can legitimately be negative (a packet presumed lost can
    // still arrive late and get reclassified as merely reordered - see
    // Get_LostCount()'s own doc comment, prague_cc.h).
    int32_t l4s_lost_count;
    // UDP L4S only (PragueCC::GetQueueInfo(), src/prague_cc.cpp) - sender-
    // side queueing delay estimate and its Little's Law (L = lambda*W) queue
    // occupancy in bytes. Both read 0 before the first RTT sample lands,
    // same as GetQueueInfo()'s own "no data yet" value - not distinguished
    // from a genuine zero-queueing reading, since both mean "nothing to
    // report queued up" from the app's point of view.
    int32_t l4s_qdelay_us;
    int64_t l4s_qbytes;
    // Raw smoothed RTT (PragueCC::GetSmoothedRtt(), src/prague_cc.cpp) -
    // the value l4s_qdelay_us is itself derived from (srtt - rtt_min). Kept
    // alongside it so the app can show actual RTT next to the derived
    // delay estimate rather than only ever showing the latter in isolation.
    int32_t l4s_rtt_us;
    // PragueCC's own congestion window (packets) and actual in-flight
    // packet count - tracked directly by the CC algorithm's packet
    // send/ACK accounting (Client::RunUDPL4S's pacing loop), completely
    // independent of the srtt-rtt_min-derived queueing estimate above.
    // Lets a reader directly compare "how full is the window" against the
    // RTT-derived Load Delay estimate, the same way TCP's CWND/inFlight
    // bar does - per Koen De Schepper's review,
    // doc/email_koen_littles_law_review.txt.
    int32_t l4s_packet_window;
    int32_t l4s_inflight;
    // PragueCC::GetMarkingProbability() - see that getter's own doc
    // comment for why this differs from ce_count/cePercent.
    int32_t l4s_marking_prob;
    // PragueCC::GetL4SCcaMode() - l4s_cca_prague (0) or l4s_cca_reno (1),
    // see l4s_cca_tp's own doc comment (prague_cc.h) for what this
    // controls. Same isValid/relay contract as the other l4s_* fields
    // below.
    int32_t l4s_cca_mode;
    // Whether l4s_qdelay_us/l4s_qbytes/l4s_rtt_us/l4s_packet_window/
    // l4s_inflight/l4s_marking_prob/l4s_cca_mode above are real data this
    // packet. True
    // unconditionally for the writer role (Client::RunUDPL4S always has
    // its own local PragueCC state). For the reader role (Server::
    // RunUDPL4S), true only when the packet just parsed carried the
    // writer's relayed sender_* fields (client_udp_l4s_fwd) - same
    // "known-valid snapshot, not garbage" contract as iperf_tcpstats.
    // isValid serves for TCP's own reverse_* relay.
    bool l4sStatsValid;
};

struct PacketRing {
    // producer and consumer
    // must be an atomic type, e.g. int, so reads/writes can't be torn.
    // Cross-thread accesses (producer reading consumer, consumer reading
    // producer, and the publishing write on each side) go through
    // __atomic_load_n()/__atomic_store_n() with acquire/release ordering in
    // packet_ring.c -- this also guarantees the corresponding pr->data[]
    // slot write/read is ordered correctly relative to the index, which
    // plain int reads/writes alone would not guarantee on weak memory-model
    // architectures (ARM, RISC-V, POWER, ...). Same-thread reads of a
    // field's own owning thread (e.g. producer reading pr->producer) stay
    // plain reads since there's no concurrent writer to race with.
    int producer;
    int consumer;
    int maxcount;
    bool consumerdone;
    int awaitcounter;
    int dropcount; // reports dropped because the ring was full with mutex_enable
                   // false (no consumer thread to wait on, see packetring_enqueue())
    bool mutex_enable;
    int bytes;
    enum edgeLevel uplevel;
    enum edgeLevel downlevel;

    // Use a condition variables
    // o) awake_producer - producer waits for the consumer thread to
    //    make space or end (signaled by the consumer)
    // o) awake_consumer - signal the consumer thread to to run
    //    (signaled by the producer)
    struct Condition *awake_producer;
    struct Condition *awake_consumer;
    struct ReportStruct *data;
};

extern struct PacketRing *packetring_init(int count, struct Condition *awake_consumer,
                                          struct Condition *awake_producer);
extern bool packetring_enqueue(struct PacketRing *pr, struct ReportStruct *metapacket);
extern struct ReportStruct *packetring_dequeue(struct PacketRing *pr);
extern void packetring_free(struct PacketRing *pr);
#ifdef HAVE_THREAD_DEBUG
extern int packetring_getcount(struct PacketRing *pr);
#endif

#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif  // PACKETRINGC_H
