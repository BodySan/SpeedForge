#include "config.h"
#define IPERF_VERSION VERSION
#define IPERF_VERSION_DATE "29 September 2026"
#define IPERF_VERSION_MAJORHEX 0x00020002
#define IPERF_VERSION_MINORHEX 0x00020003
#ifdef HAVE_PROFESSIONAL
#define IPERF_BRANCH "professional"
#else
#define IPERF_BRANCH "community"
#endif
// The "(compiled by ...)" tag is professional-build only (helps gauge who is
// building --enable-professional); community builds never show it.
// IPERF_BUILD_USER is set by configure (portable /bin/sh at configure
// time, not make's $(shell ...), which is a GNU Make extension that
// silently expands to empty under BSD make). If either it or
// HAVE_PROFESSIONAL is missing, the tag is omitted entirely rather than
// printing a placeholder value.
// IPERF_BUILD_FOR (--with-build-for=NAME at configure time) is only
// #defined at all when actually given a value - unlike IPERF_BUILD_USER,
// which configure always defines (even if empty), this one is left
// genuinely undefined for an ordinary build so the ", for X" suffix is
// omitted entirely rather than appearing empty. A build tagged this way
// (e.g. a white-labeled/OEM build for a specific customer) gets its own
// distinct version string, and therefore its own distinct
// compute_version_based_vendor_id() result (Listener.cpp/ReportOutputs.c) -
// see doc/PERMIT_KEY_NOTES.
#if defined(HAVE_PROFESSIONAL) && defined(IPERF_BUILD_USER) && defined(IPERF_BUILD_FOR)
#define IPERF_BUILD_USER_TAG " (compiled by " IPERF_BUILD_USER ", for " IPERF_BUILD_FOR ")"
#elif defined(HAVE_PROFESSIONAL) && defined(IPERF_BUILD_USER)
#define IPERF_BUILD_USER_TAG " (compiled by " IPERF_BUILD_USER ")"
#else
#define IPERF_BUILD_USER_TAG ""
#endif

// Server startup banner ("Server listening on...", Locale.c/ReportOutputs.c)
// gets a "(professional edition) " tag inserted right after "Server " -
// professional-build only, same as IPERF_BUILD_USER_TAG above; community
// builds stay exactly as they always have (empty string, not just an
// unset/no-op flag), since the tag text itself isn't even compiled in.
#ifdef HAVE_PROFESSIONAL
#define IPERF_SERVER_EDITION_TAG "(professional edition) "
#else
#define IPERF_SERVER_EDITION_TAG ""
#endif

#if (IPERF_VERSION_MINORHEX & 0xF) == 0
#define IPERF_VERSION_SUFFIX "-dev"
#elif (IPERF_VERSION_MINORHEX & 0xF) == 1
#define IPERF_VERSION_SUFFIX "-rc"
#elif (IPERF_VERSION_MINORHEX & 0xF) == 2
#define IPERF_VERSION_SUFFIX "-rc2"
#elif (IPERF_VERSION_MINORHEX & 0xF) == 3
#define IPERF_VERSION_SUFFIX ""
#elif (IPERF_VERSION_MINORHEX & 0xF) == 4
#define IPERF_VERSION_SUFFIX "-private"
#elif (IPERF_VERSION_MINORHEX & 0xF) == 5
#define IPERF_VERSION_SUFFIX "-master"
#else
#define IPERF_VERSION_SUFFIX "-unk"
#endif
/*
 * 	case 0:
 *	    sprintf(report->peerversion + strlen(report->peerversion) -
 *1,"-dev)"); break; case 1: sprintf(report->peerversion +
 *strlen(report->peerversion) - 1,"-rc)"); break; case 2:
 *	    sprintf(report->peerversion + strlen(report->peerversion) -
 *1,"-rc2)"); break; case 3: break; case 4: sprintf(report->peerversion +
 *strlen(report->peerversion) - 1,"-private)"); break; case 5:
 *	    sprintf(report->peerversion + strlen(report->peerversion) -
 *1,"-master)"); break; default: sprintf(report->peerversion +
 *strlen(report->peerversion) - 1, "-unk)");
 */
