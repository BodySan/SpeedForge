#ifndef PRAGUE_CC_H
#define PRAGUE_CC_H

#include <stdint.h>

typedef uint64_t size_tp;    // size in Bytes
typedef uint64_t window_tp;  // fractional window size in µBytes (to match time
                             // in µs, for easy Bytes/second rate calculations)
typedef uint64_t rate_tp;    // rate in Bytes/second
typedef int32_t time_tp;     // timestamp or interval in microseconds, timestamps have a fixed
                             // but no meaningful reference, so use only for intervals beteen 2
                             // timestamps signed because it can wrap around, and we need to
                             // compare both ways (< 0 and > 0)
typedef int32_t count_tp;    // count in packets (or frames), signed because it
                             // can wrap around, and we need to compare both ways
enum ecn_tp : uint8_t { ecn_not_ect = 0, ecn_l4s_id = 1, ecn_ect0 = 2, ecn_ce = 3 };
// 2 bits in the IP header, only values 0-3 are valid, and 1 (0b01) and 3 (0b11)
// are L4S valid
typedef uint8_t fps_tp;  // frames per second: any value from 1 till 255 can be
                         // used, 0 must be used for bulk
typedef int64_t prob_tp;
enum cs_tp { cs_init, cs_cong_avoid, cs_in_loss, cs_in_cwr };
enum cca_tp { cca_prague_win, cca_prague_rate, cca_cubic };  // which CC algorithm is active
// User-facing choice of CE-mark response, distinct from cca_tp above (an
// internal pacing-vs-window loss-recovery state, unrelated to this
// selection). l4s_cca_reno suppresses ONLY the CE-triggered decrease in
// ACKReceived() - the loss-triggered decrease (already a flat window/2 or
// rate/2 halving, textbook Reno AIMD) and the alpha/CE-count bookkeeping
// both stay unconditional in either mode, so a Reno run's CE stats remain
// directly comparable to a Prague run over the same path. Wire ECT(1)/L4S
// marking (GetTimeInfo()) is independent of this choice too - Reno mode
// still marks packets L4S-capable, it just doesn't react to CE itself.
enum l4s_cca_tp { l4s_cca_prague, l4s_cca_reno };

static const count_tp PRAGUE_INITWIN = 10;          // Prague initial window size
static const size_tp PRAGUE_MINMTU = 150;           // Prague minmum MTU suze
static const size_tp PRAGUE_INITMTU = 1400;         // Prague initial MTU size
static const rate_tp PRAGUE_INITRATE = 12500;       // Prague initial rate 12500 Byte/s (equiv. 100kbps)
static const rate_tp PRAGUE_MINRATE = 12500;        // Prague minimum rate 12500 Byte/s (equiv. 100kbps)
static const rate_tp PRAGUE_MAXRATE = 12500000000;  // Prague maximum rate 12500000000 Byte/s (equiv. 100Gbps)

struct PragueState {
    uint64_t  m_guid;     // random per-flow identifier, generated once at
                          // construction (see PragueCC's ctor) - not used
                          // by iperf2 itself, exists so an out-of-band
                          // observer with real Wi-Fi MAC-layer visibility
                          // (e.g. an AP-adjacent monitoring device) can
                          // correlate the packets/AMPDUs it sees on the
                          // air back to this specific flow. See this
                          // field's own wire-format counterpart,
                          // client_udp_l4s_fwd.flow_guid_lower/upper in
                          // payloads.h.
    time_tp m_start_ref;  // used to have a start time of 0
                          // parameters
    rate_tp m_init_rate;
    window_tp m_init_window;
    rate_tp   m_min_rate;
    rate_tp   m_max_rate;
    size_tp   m_max_packet_size;
    time_tp   m_frame_interval;
    time_tp   m_frame_budget;
// both-end variables
    time_tp   m_ts_remote;     // to keep the frozen timestamp from the peer, and echo it back defrosted
    time_tp   m_rtt;           // last reported rtt (only for stats)
    time_tp   m_rtt_min;       // minimum report rtt (for cubic)
    time_tp   m_srtt;          // our own measured and smoothed RTT (smoothing factor = 1/8)
    time_tp   m_vrtt;          // our own virtual RTT = max(srtt, 25ms)
// receiver-end variables (to be echoed to sender)
    time_tp   m_r_prev_ts;            // used to see if an ack isn't older than the previous ack
    count_tp  m_r_packets_received;   // as a receiver, keep counters to echo back
    count_tp  m_r_packets_CE;
    count_tp  m_r_packets_CE_prev;
    count_tp  m_r_packets_lost;
    bool      m_r_error_L4S;          // as a receiver, check L4S-ECN validity to echo back an error
// sender-end variables
    time_tp   m_cc_ts;
    count_tp  m_packets_received;     // latest known receiver end counters
    count_tp  m_packets_CE;
    count_tp  m_packets_CE_prev;
    count_tp  m_packets_lost;
    count_tp  m_packets_lost_prev;
    count_tp  m_packets_sent;
    bool      m_error_L4S;            // latest known receiver-end error state
    // sender-end cubic variabls
    time_tp m_cubic_epoch_start;
    window_tp m_cubic_last_max_fracwin;
    uint32_t m_cubic_K;
    window_tp m_cubic_origin_fracwin;
    // for alpha calculation, keep the previous alpha variables' state
    time_tp m_alpha_ts;
    count_tp m_alpha_packets_received;
    count_tp m_alpha_packets_CE;
    count_tp m_alpha_packets_lost;
    count_tp m_alpha_packets_sent;
    // for loss and recovery calculation
    time_tp m_loss_ts;
    cca_tp m_loss_cca;
    window_tp m_lost_window;
    rate_tp m_lost_rate;
    count_tp m_lost_rtts_to_growth;
    count_tp m_loss_packets_lost;
    count_tp m_loss_packets_sent;
    // for congestion experienced and window reduction (cwr) calculation
    time_tp m_cwr_ts;
    count_tp m_cwr_packets_sent;
    // state updated for the actual congestion control variables
    cs_tp m_cc_state;
    cca_tp m_cca_mode;
    // User-facing Prague/Reno choice (see l4s_cca_tp's own doc comment) -
    // set once at construction, read-only afterward, unlike m_cca_mode
    // above which changes at runtime as its own internal state machine.
    l4s_cca_tp m_l4s_cca_mode;
    count_tp m_rtts_to_growth;  // virtual rtts before going into growth mode
    prob_tp m_alpha;
    rate_tp m_pacing_rate;
    window_tp m_fractional_window;
    count_tp m_packet_burst;
    size_tp m_packet_size;
    count_tp m_packet_window;
};

class PragueCC : private PragueState {
   public:
    PragueCC(size_tp max_packet_size = PRAGUE_INITMTU,  // use MTU detection, or a low enough value.
                                                        // Can be updated on the fly (todo)
             fps_tp fps = 0,                            // only used for video; frames per second, 0 must
                                                        // be used for bulk transfer
             time_tp frame_budget = 0,                  // only used for video; over what time [µs] you want to
                                                        // pace the frame (max 1000000/fps [µs])
             rate_tp init_rate = PRAGUE_INITRATE, count_tp init_window = PRAGUE_INITWIN,
             rate_tp min_rate = PRAGUE_MINRATE, rate_tp max_rate = PRAGUE_MAXRATE,
             l4s_cca_tp l4s_cca_mode = l4s_cca_prague);  // Prague (default) or Reno CE-mark response - see
                                                          // l4s_cca_tp's own doc comment

    ~PragueCC();

    time_tp Now();  // will have to return a monotonic increasing signed int 32
                    // which will wrap around (after 4000 seconds)

    bool PacketReceived(            // call this when a packet is received from peer,
                                    // returns false if the old packet is ignored
        time_tp timestamp,          // timestamp from peer, freeze and keep this time
        time_tp echoed_timestamp);  // echoed_timestamp can be used to calculate
                                    // the RTT

    bool ACKReceived(               // call this when an ACK is received from peer, returns
                                    // false if the old ack is ignored
        count_tp packets_received,  // echoed_packet counter
        count_tp packets_CE,        // echoed CE counter
        count_tp packets_lost,      // echoed lost counter
        count_tp packets_sent,      // local counter of packets sent up to now, an
                                    // RTT is reached if remote ACK
                                    // packets_received+packets_lost
        bool error_L4S,             // receiver found a bleached/error ECN; stop using
                                    // L4S_id on the sending packets!
        count_tp &inflight);        // how many packets are in flight after the ACKed);

    // can this be combined with ACKReceived?
    /*bool FrameACKReceived(     // call this when a frame ACK is received from
       peer count_tp packets_received, // echoed_packet counter count_tp
       packets_CE,       // echoed CE counter count_tp packets_lost,     //
       echoed lost counter bool error_L4S);           // receiver found a
       bleached/error ECN; stop using L4S_id on the sending packets!*/

    void DataReceived(           // call this when a data packet is received as a
                                 // receiver and you can identify lost packets
        ecn_tp ip_ecn,           // IP.ECN field value
        count_tp packets_lost);  // packets skipped; can be optionally -1 to
                                 // potentially undo a previous cwindow reduction

    void DataReceivedSequence(    // call this every time when a data packet with
                                  // a sequence number is received as a receiver
        ecn_tp ip_ecn,            // IP.ECN field value
        count_tp packet_seq_nr);  // sequence number of the received packet

    void ResetCCInfo();  // call this when there is a RTO detected

    void GetTimeInfo(               // when the any-app needs to send a packet
        time_tp &timestamp,         // Own timestamp to echo by peer
        time_tp &echoed_timestamp,  // defrosted timestamp echoed to peer
        ecn_tp &ip_ecn);            // ecn field to be set in the IP header

    void GetCCInfo(               // when the sending-app needs to send a packet
        rate_tp &pacing_rate,     // rate to pace the packets
        count_tp &packet_window,  // the congestion window in number of packets
        count_tp &packet_burst,   // number of packets that can be paced at once
                                  // (<250µs)
        size_tp &packet_size);    // the packet size to transmit

    void GetACKInfo(                 // when the receiving-app needs to send a packet
        count_tp &packets_received,  // packet counter to echo
        count_tp &packets_CE,        // CE counter to echo
        count_tp &packets_lost,      // lost counter to echo (if used)
        bool &error_L4S);            // bleached/error ECN status to echo

    void GetCCInfoVideo(         // when the sending app needs to send a frame
        rate_tp &pacing_rate,    // rate to pace the packets
        size_tp &frame_size,     // the size of a single frame in Bytes
        count_tp &frame_window,  // the congestion window in number of frames
        count_tp &packet_burst,  // number of packets that can be paced at once
                                 // (<250µs)
        size_tp &packet_size);   // the packet size to transmit

    void GetStats(PragueState &stats)  // For logging purposes
    {
        stats = *this;  // makes a copy of the internal state and parameters
    }

    void GetQueueInfo(               // sender-side queueing estimate - call any
                                     // time after the first RTT sample lands
        time_tp &queueing_delay,    // estimated bottleneck queueing delay [us]:
                                     // m_srtt minus m_rtt_min, i.e. the smoothed
                                     // RTT above and beyond the best (assumed
                                     // queue-empty) RTT ever observed. 0 before
                                     // the first sample or if there's no queue.
        size_tp &queue_bytes);      // Little's Law (L = lambda*W) estimate of
                                     // bytes sitting in the bottleneck queue:
                                     // current pacing rate [Bytes/s] * queueing_delay [s].

    time_tp GetSmoothedRtt() const { return m_srtt; }  // [us] - the raw value
                                     // GetQueueInfo() subtracts m_rtt_min from
                                     // to get queueing_delay; exposed on its
                                     // own so the app can show actual RTT
                                     // alongside the derived delay estimate
                                     // (see doc/email_koen_littles_law_review.txt -
                                     // seeing the raw number lets a reader
                                     // sanity-check the derived one instead of
                                     // only ever seeing it pre-subtracted).

    // EWMA-smoothed CE-marking probability the congestion control algorithm
    // itself reacts to (see prague_cc.cpp's alpha update, ALPHA_SHIFT=4
    // smoothing) - distinct from the app's own cePercent (a raw, unsmoothed
    // marks/packets ratio over just the current report interval, computed
    // outside this class). Raw prob_tp scale (0..1<<PROB_SHIFT, PROB_SHIFT=20
    // in prague_cc.cpp) rather than pre-divided to a 0.0-1.0 double, so a
    // caller can pick its own precision instead of this getter baking in a
    // lossy conversion.
    prob_tp GetMarkingProbability() const { return m_alpha; }

    // Which CE-mark response this flow was constructed with (l4s_cca_prague
    // or l4s_cca_reno) - read-only, set once at construction. Lets a caller
    // (Client::RunUDPL4S's per-packet report block) surface which variant
    // is actually active without re-deriving it from mSettings at the
    // report call site.
    l4s_cca_tp GetL4SCcaMode() const { return m_l4s_cca_mode; }

    int32_t Get_CECountServer();
    int32_t Get_CECount();

    // Delta in the echoed lost-packet counter (ACKReceived's own
    // packets_lost, m_packets_lost) since the last call - same "call once
    // per outgoing report, get what's new since last time" contract as
    // Get_CECount() above, so Client::RunUDPL4S can attach it to
    // ReportStruct.l4sLostCount right next to ce_count. Unlike CE marks,
    // m_packets_lost is NOT monotonic (see ACKReceived's own "CAN go down"
    // comment - a packet presumed lost can still arrive late, reclassified
    // as merely reordered), so this can legitimately return a negative
    // delta - not clamped to a minimum the way Get_CECount() clamps a
    // (theoretically impossible) negative CE delta to 1. The caller's own
    // running total (Reporter.c's stats->total.Lost) already accumulates
    // signed deltas and self-corrects downward the same way.
    int32_t Get_LostCount();

    uint64_t GetGuid() const { return m_guid; }  // see m_guid's own doc comment above

    const PragueState* GetStatePtr() // For logging purposes
    {
        return this;  // gives a const pointer for reading the live state
    }
};
#endif  // PRAGUE_CC_H
