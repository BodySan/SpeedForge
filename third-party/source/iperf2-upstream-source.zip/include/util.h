/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003
 * The Board of Trustees of the University of Illinois
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software (Iperf) and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the names of the University of Illinois, NCSA,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 * National Laboratory for Applied Network Research
 * National Center for Supercomputing Applications
 * University of Illinois at Urbana-Champaign
 * http://www.ncsa.uiuc.edu
 * ________________________________________________________________
 *
 * util.h
 * by Mark Gates <mgates@nlanr.net>
 * -------------------------------------------------------------------
 * various C utility functions.
 * ------------------------------------------------------------------- */

#ifndef UTIL_H
#define UTIL_H

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern volatile int sInterupted;

// Per-thread companion to sInterupted, set only by this thread's own
// test-duration timer expiring (see set_itimer()/disarm_itimer() below).
// Needed because setitimer()/ITIMER_REAL is process-wide: without a
// per-thread flag, a per-thread timer_create()+SIGEV_THREAD_ID delivery
// still only tells you *a* SIGALRM landed on *this* thread, and
// InProgress() checks (Client.cpp, Server.cpp) need to distinguish "my
// own timeout fired" from "someone sent this process SIGINT/SIGTERM"
// (sInterupted, still checked and still meant to be process-wide).
#if defined(_MSC_VER)
#define IPERF_THREAD_LOCAL __declspec(thread)
#else
#define IPERF_THREAD_LOCAL __thread
#endif
extern IPERF_THREAD_LOCAL volatile int tInterupted;

// Set by main.cpp's SIGHUP handler, consumed by Listener::Run()'s own accept
// loop (single-threaded - see Listener.cpp's load_permit_key_file()) to
// reload --permit-key-file without a server restart. sig_atomic_t, not
// plain int, since this is the one flag actually read/cleared from within
// a signal-handler-adjacent context rather than just set by one.
#ifndef WIN32
extern volatile sig_atomic_t sReloadPermitKeyFile;
#endif

#define WARNBUFSIZE 256

/* -------------------------------------------------------------------
 * set/getsockopt wrappers for SO_RCVBUF and SO_SNDBUF; TCP_MAXSEG
 * socket.c
 * ------------------------------------------------------------------- */
int setsock_tcp_windowsize(int inSock, int inTCPWin, int inSend);
int getsock_tcp_windowsize(int inSock, int inSend);

bool setsock_blocking(int fd, bool blocking);
#if HAVE_DECL_TCP_WINDOW_CLAMP
int getsock_tcp_windowclamp(int inSock);
int setsock_tcp_windowclamp(int inSock, int clampsize);
#endif
#if HAVE_DECL_TCP_NOTSENT_LOWAT
int getsock_tcp_notsent_low_watermark(int inSock);
int setsock_tcp_notsent_low_watermark(int inSock, int clampsize);
#endif
int recvn(int inSock, char *outBuf, int inLen, int flags);
int writen(int inSock, const void *inBuf, int inLen, int *count);
int writemsg_delay_tos(int inSock, const void *inBuf, int inLen, uint64_t delay_ns, int tos_value);
int writemsg_tos(int inSock, const void *inBuf, int inLen, int tos_value);
int writemsg_delay(int inSock, const void *inBuf, int inLen, uint64_t delay_ns);

void disarm_itimer(void);
int set_itimer(uintmax_t);
/* -------------------------------------------------------------------
 * signal handlers
 * signal.c
 * ------------------------------------------------------------------- */
typedef void Sigfunc(int);
void sig_exit(int inSigno);

typedef Sigfunc *SigfuncPtr;

SigfuncPtr my_signal(int inSigno, SigfuncPtr inFunc);

#ifdef WIN32

#ifdef HAVE_SIGNAL_H
#define _NSIG NSIG
#else
/* under windows, emulate unix signals */
enum { SIGINT, SIGTERM, SIGPIPE, _NSIG };
#endif

BOOL WINAPI sig_dispatcher(DWORD type);

#endif

/* -------------------------------------------------------------------
 * error handlers
 * error.c
 * ------------------------------------------------------------------- */
void warn(const char *inMessage, const char *inFile, int inLine);
void warn_errno(const char *inMessage, const char *inFile, int inLine);
int errno_decode(char *decoded_text, size_t len);

#define FAIL_exit(cond, msg)               \
    do {                                   \
        if (cond) {                        \
            warn(msg, __FILE__, __LINE__); \
            exit(1);                       \
        }                                  \
    } while (0)

#if defined(HAVE_POSIX_THREAD) || defined(HAVE_WIN32_THREAD)
#define FAIL(cond, msg, settings)          \
    do {                                   \
        if (cond) {                        \
            warn(msg, __FILE__, __LINE__); \
            thread_stop(settings);         \
        }                                  \
    } while (0)
#else
#define FAIL(cond, msg, settings)          \
    do {                                   \
        if (cond) {                        \
            warn(msg, __FILE__, __LINE__); \
            exit(1);                       \
        }                                  \
    } while (0)
#endif

#define WARN(cond, msg)                    \
    do {                                   \
        if (cond) {                        \
            warn(msg, __FILE__, __LINE__); \
        }                                  \
    } while (0)

#if defined(HAVE_POSIX_THREAD) || defined(HAVE_WIN32_THREAD)
#define FAIL_errno(cond, msg, settings)          \
    do {                                         \
        if (cond) {                              \
            warn_errno(msg, __FILE__, __LINE__); \
            thread_stop(settings);               \
        }                                        \
    } while (0)
#else
#define FAIL_errno(cond, msg, settings)          \
    do {                                         \
        if (cond) {                              \
            warn_errno(msg, __FILE__, __LINE__); \
            exit(1);                             \
        }                                        \
    } while (0)
#endif

#define WARN_errno(cond, msg)                    \
    do {                                         \
        if (cond) {                              \
            warn_errno(msg, __FILE__, __LINE__); \
        }                                        \
    } while (0)

// WARN_REPORT/WARN_REPORT_errno: same "cond, msg" call shape and message
// wording as WARN/WARN_errno, but instead of a direct, unsynchronized
// fprintf(stderr, ...) from whichever thread happens to hit this, builds
// the same text and hands it to the Reporter thread via
// PostReport(InitErrorReport(...)) - see packetring_enqueue()'s own doc
// comment (packet_ring.c) for the general "stdio that isn't fatal belongs
// on the Reporter thread" rule this follows. A traffic thread's own
// blocking stderr write, sitting directly in a per-packet/per-request hot
// loop, adds unpredictable latency straight into the timing measurements
// the test itself is making - confirmed live: a WARN() call sitting in
// Client::RunBounceBackUDP's read path was itself capable of skewing the
// very RTT numbers a bug fix at that same call site was trying to report
// on. Use these instead of WARN/WARN_errno for anything that can fire
// from inside a traffic thread's own per-packet/per-request loop, not
// just genuine one-time setup/connect/teardown calls (those are fine as
// plain WARN/WARN_errno - they only ever fire once per connection).
//
// PFX variants take the message-prefix string explicitly, for call sites
// with no mSettings in scope (plain C helpers like socket_io.c, or classes
// with no thread_Settings member like isochronous.cpp's FrameCounter) -
// pass "" for no prefix, matching plain WARN's own unprefixed output.
// The plain WARN_REPORT/WARN_REPORT_errno below are a convenience for
// Client.cpp/Server.cpp call sites, which already have mSettings and use
// mTransferIDStr as the prefix on every other PostReport() message.
//
// Both require PostReport()/InitErrorReport() (include/Reporter.h) visible
// at the call site - already true everywhere WARN_REPORT is used, since
// those files already call PostReport() directly elsewhere.
// Silently drops the message (not the underlying cond-gated action - the
// caller's own logic around this macro is unaffected either way) if the
// calloc fails, same fail-open convention already used at every other
// PostReport(InitStringReport/InitErrorReport(...)) call site in this
// codebase - an allocation failure this small, this late in a run, isn't
// worth adding a new error path for.
#define WARN_REPORT_PFX(cond, msg, prefix)                                             \
    do {                                                                               \
        if (cond) {                                                                    \
            int _wr_len = snprintf(NULL, 0, "%s%s failed\n", (prefix), (msg));         \
            char *_wr_text = (char *)calloc(_wr_len + 1, sizeof(char));                \
            if (_wr_text) {                                                            \
                snprintf(_wr_text, _wr_len + 1, "%s%s failed\n", (prefix), (msg));     \
                PostReport(InitErrorReport(_wr_text));                                 \
                FREE_ARRAY(_wr_text);                                                  \
            }                                                                          \
        }                                                                              \
    } while (0)

#define WARN_REPORT(cond, msg) WARN_REPORT_PFX(cond, msg, mSettings->mTransferIDStr)

#define WARN_REPORT_errno_PFX(cond, msg, prefix)                                                  \
    do {                                                                                          \
        if (cond) {                                                                               \
            char _wr_errstr[256];                                                                 \
            errno_decode(_wr_errstr, sizeof(_wr_errstr));                                         \
            int _wr_len = snprintf(NULL, 0, "%s%s failed: %s\n", (prefix), (msg), _wr_errstr);    \
            char *_wr_text = (char *)calloc(_wr_len + 1, sizeof(char));                           \
            if (_wr_text) {                                                                       \
                snprintf(_wr_text, _wr_len + 1, "%s%s failed: %s\n", (prefix), (msg), _wr_errstr); \
                PostReport(InitErrorReport(_wr_text));                                             \
                FREE_ARRAY(_wr_text);                                                              \
            }                                                                                      \
        }                                                                                          \
    } while (0)

#define WARN_REPORT_errno(cond, msg) WARN_REPORT_errno_PFX(cond, msg, mSettings->mTransferIDStr)

// WARN_REPORT_FMT: same PostReport(InitErrorReport(...))-via-Reporter-thread
// delivery as WARN_REPORT/WARN_REPORT_errno above, but for a message that
// needs to interpolate a value (a count, a computed number) rather than
// the fixed "<msg> failed[: <errno>]" shape those two always produce.
// Takes a full printf-style format string (the caller supplies any
// mSettings->mTransferIDStr prefix themselves via %s, same convention as
// every other PostReport() message in this codebase - there's no way to
// splice an automatic prefix in ahead of arbitrary caller-supplied
// varargs). Exists so an interpolated message doesn't have to fall back
// to hand-rolling this same snprintf/calloc/PostReport/FREE_ARRAY
// sequence at the call site - see WARN_REPORT's own doc comment above for
// why that direct-fprintf-vs-Reporter-thread distinction matters in a
// traffic thread to begin with.
#define WARN_REPORT_FMT(cond, ...)                                       \
    do {                                                                 \
        if (cond) {                                                      \
            int _wr_len = snprintf(NULL, 0, __VA_ARGS__);                \
            char *_wr_text = (char *)calloc(_wr_len + 1, sizeof(char));  \
            if (_wr_text) {                                              \
                snprintf(_wr_text, _wr_len + 1, __VA_ARGS__);            \
                PostReport(InitErrorReport(_wr_text));                   \
                FREE_ARRAY(_wr_text);                                    \
            }                                                            \
        }                                                                \
    } while (0)

/* -------------------------------------------------------------------
 * initialize buffer to a pattern
 * ------------------------------------------------------------------- */
void pattern(char *outBuf, int inBytes);

/* -------------------------------------------------------------------
 * input and output numbers, converting with kilo, mega, giga
 * stdio.c
 * ------------------------------------------------------------------- */
double byte_atof(const char *inString);
double bitorbyte_atof(const char *inString);
intmax_t byte_atoi(const char *inString);
uintmax_t bitorbyte_atoi(const char *inString);
void byte_snprintf(char *outString, int inLen, double inNum, char inFormat);
void make_lower(char *s);
/*
 * Time macros for C-code (not the include Timestamp.hpp)
 */
#define rMillion 1000000

#ifdef HAVE_CLOCK_GETTIME
#define TimeGetNow(timeval)                  \
    do {                                     \
        struct timespec t1;                  \
        clock_gettime(CLOCK_REALTIME, &t1);  \
        timeval.tv_sec = t1.tv_sec;          \
        timeval.tv_usec = t1.tv_nsec / 1000; \
    } while (0)
#else
#define TimeGetNow(timeval)           \
    do {                              \
        gettimeofday(&timeval, NULL); \
    } while (0)
#endif

#define TimeZero(timeval) ((timeval.tv_sec == 0) && (timeval.tv_usec == 0))

#define TimeDifference(left, right) ((left.tv_sec - right.tv_sec) + (left.tv_usec - right.tv_usec) / ((double)rMillion))

#define TimeDifferenceUsec(left, right) ((1e6 * (left.tv_sec - right.tv_sec)) + (double)(left.tv_usec - right.tv_usec))

#define TimeDouble(timeval) (timeval.tv_sec + timeval.tv_usec / ((double)rMillion))

#define TimeAdd(left, right)           \
    do {                               \
        left.tv_usec += right.tv_usec; \
        if (left.tv_usec > rMillion) { \
            left.tv_usec -= rMillion;  \
            left.tv_sec++;             \
        }                              \
        left.tv_sec += right.tv_sec;   \
    } while (0)

#define TimeAddIntUsec(left, right)      \
    do {                                 \
        left.tv_usec += right % 1000000; \
        if (left.tv_usec > rMillion) {   \
            left.tv_usec -= rMillion;    \
            left.tv_sec++;               \
        }                                \
        left.tv_sec += right / 1000000;  \
    } while (0)

/* -------------------------------------------------------------------
 * redirect the stdout to a specified file
 * stdio.c
 * ------------------------------------------------------------------- */
void redirect(const char *inOutputFileName);

/* -------------------------------------------------------------------
 * delete macro
 * ------------------------------------------------------------------- */
#define DELETE_PTR(ptr)    \
    do {                   \
        if (ptr != NULL) { \
            delete ptr;    \
            ptr = NULL;    \
        }                  \
    } while (false)

#define DELETE_ARRAY(ptr)  \
    do {                   \
        if (ptr != NULL) { \
            delete[] ptr;  \
            ptr = NULL;    \
        }                  \
    } while (false)

#define FREE_ARRAY(ptr)    \
    do {                   \
        if (ptr != NULL) { \
            free(ptr);     \
            ptr = NULL;    \
        }                  \
    } while (false)

// Readn and write error macros
// Define fatal and nonfatal write errors
#ifdef WIN32
#define FATALTCPREADERR(errno) (WSAGetLastError() != WSAEWOULDBLOCK)
// WSAECONNREFUSED excluded for the same reason as the POSIX branch below -
// see that macro's own doc comment.
#define FATALUDPREADERR(errno) \
    (((errno = WSAGetLastError()) != WSAEWOULDBLOCK) && (errno != WSAECONNRESET) && (errno != WSAECONNREFUSED))
#define FATALTCPWRITERR(errno) ((errno = WSAGetLastError()) != WSAETIMEDOUT)
#define NONFATALTCPWRITERR(errno) ((errno = WSAGetLastError()) == WSAETIMEDOUT)
#define FATALUDPWRITERR(errno) (((errno = WSAGetLastError()) != WSAETIMEDOUT) && (errno != WSAECONNREFUSED))
#define FATALTCPCONNECTERR(errno) \
    (((errno = WSAGetLastError()) != WSAETIMEDOUT) && (errno != WSAECONNREFUSED) && (errno != WSAEWOULDBLOCK))
#else
#define FATALTCPREADERR(errno) ((errno != EAGAIN) && (errno != EWOULDBLOCK) && (errno != EINTR))
// ECONNREFUSED excluded, matching FATALUDPWRITERR below - a connected UDP
// socket surfaces a queued ICMP Destination-Port-Unreachable as
// ECONNREFUSED on its next read/write, same as a real one, but this also
// fires for the well-known transient case where the *server's* listening
// socket briefly has nothing bound to it while Listener::udp_accept()
// hands its socket off to a newly-accepted flow and reopens a fresh one
// (see that function's own doc comment, and ticket 357). Before this
// exclusion, a single unlucky datagram landing in that gap made
// Server::ReadWithRxTimestamp() (reused by a --reverse client's own
// reader role) set peerclose=true - misreading a transient ICMP blip as
// the peer gracefully closing the connection, permanently ending the
// read loop. Most exercised by --full-duplex UDP-L4S, which starts two
// independent new connections to the same server microseconds apart
// (Launch.cpp's clientside_client_fullduplex_udp) - see the regression
// test this shipped alongside for a concurrent-connection repro.
#define FATALUDPREADERR(errno) ((errno != EAGAIN) && (errno != EWOULDBLOCK) && (errno != EINTR) && (errno != ECONNREFUSED))
#define FATALTCPWRITERR(errno) (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR)
#define NONFATALTCPWRITERR(errno) (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
#define FATALUDPWRITERR(errno) \
    ((errno != EAGAIN) && (errno != EWOULDBLOCK) && (errno != EINTR) && (errno != ECONNREFUSED) && (errno != ENOBUFS))
#define FATALTCPCONNECTERR(errno) \
    ((errno != EAGAIN) && (errno != EWOULDBLOCK) && (errno != EINTR) && (errno != ECONNREFUSED))
#endif

#define IPERF_SOCKET_ERROR_NONFATAL -2

#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif /* UTIL_H */
