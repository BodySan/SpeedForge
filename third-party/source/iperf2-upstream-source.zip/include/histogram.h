/*---------------------------------------------------------------
 * Copyright (c) 1999,2000,2001,2002,2003,2023 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * histogram.h
 * Suppport for isochonronous traffic testing
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#ifndef HISTOGRAMC_H
#define HISTOGRAMC_H

// --histogram-baseline name=path, repeatable - one iperf2 run can have
// several active histograms at once (bbrtt, jitter, write, frame-latency,
// latency, and BOUNCEBACK's own OWD-TX/OWD-RX pair under --trip-times),
// each with its own distinct myname (e.g. " BB8"), so a single baseline
// path alone would be ambiguous about which histogram it's meant for -
// the name is what makes each --histogram-baseline argument unique.
// Parsed into this singly-linked list at Settings_Interpret() time
// (Settings.cpp); Settings_FindHistogramBaseline() walks it by name once
// each relevant histogram is initialized (Reports.c) to resolve its own
// struct histogram.baseline_path, if any.
struct histogram_baseline {
    char *name;
    char *path;
    struct histogram_baseline *next;
};

struct histogram {
    unsigned int id;
    unsigned int *mybins;
    unsigned int bincount;
    unsigned int binwidth;
    unsigned int populationcnt;
    bool Omit;
    bool final;
    int maxbin;
    int fmaxbin;
    double maxval;
    double fmaxval;
    struct timeval maxts;
    struct timeval fmaxts;
    float offset;
    unsigned int cntloweroutofbounds;
    unsigned int cntupperoutofbounds;
    char *myname;
    char *outbuf;
    float units;
    double ci_lower;
    double ci_upper;
    struct histogram *prev;
    // Resolved (if any) by the caller right after histogram_init(), via
    // Settings_FindHistogramBaseline(inSettings->mHistogramBaselines,
    // name) - see histogram_baseline's own doc comment above. NULL means
    // no baseline configured for this histogram; histogram_print_csv()
    // only attempts to load/compare against it when this is set AND
    // h->final (see this struct's own baseline_path/
    // histogram_emd_against_baseline doc comments below) - a baseline
    // comparison is a whole-run statistic, not something meaningful
    // per-interval.
    const char *baseline_path;
    // --histogram-baseline-save name=path counterpart to baseline_path
    // above - resolved the same way, against
    // inSettings->mHistogramBaselineSaves instead. A standalone CLI
    // capability for capturing a golden reference directly (e.g. from a
    // scripted calibration run), independent of baseline_path/-load - the
    // two can be used together (compare against an existing baseline and
    // save this run as a new one in the same invocation) or separately.
    // Deliberately native-CLI-only: the Android app never sets this
    // itself, since its own "save as golden" is a user-driven UI action
    // taken *after* a run already completed (see BounceBackHistogramChart/
    // IperfViewModel.saveGoldenHistogram()), not something to request
    // up front via a launch argument.
    const char *baseline_save_path;
};

extern struct histogram *histogram_init(unsigned int bincount, unsigned int binwidth, float offset, float units,
                                        double ci_lower, double ci_upper, unsigned int id, char *name, bool omit);
extern void histogram_delete(struct histogram *h);
extern int histogram_insert(struct histogram *h, float value, struct timeval *ts);
extern void histogram_clear(struct histogram *h);
extern void histogram_add(struct histogram *to, struct histogram *from);
extern void histogram_print(struct histogram *h, double, double);
// CSV counterpart to histogram_print() - same bin-delta/percentile/outlier
// computation, but emits one reportCSV_client_bb_histogram_format row
// (Locale.c/h) instead of the human-readable "BB8(f)-PDF: bin(w=...)"
// text line, so -y C mode gets a real, parseable histogram row instead of
// silently emitting nothing (tcp_output_write_bb_csv() never called
// histogram_print() at all - only the non-CSV tcp_output_write_bb() did).
// timestr/csv_peer/transferid are the same pre-formatted values the
// caller's own summary row already uses (see ReportOutputs.c's
// _print_stats_csv_timestr()/stats->csv_peer/stats->common->transferID),
// passed in rather than recomputed here so histogram.c stays decoupled
// from struct TransferInfo.
extern void histogram_print_csv(struct histogram *h, double start, double end, const char *timestr,
                                const char *csv_peer, int transferid);
#endif  // HISTOGRAMC_H
