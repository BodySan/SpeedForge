/*---------------------------------------------------------------
 * Copyright (c) 2019 Broadcom Corporation
 * Copyright (c) 2014-2026 Robert J. McMahon
 * All Rights Reserved.
 *---------------------------------------------------------------
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 *
 * Redistributions of source code must retain the above
 * copyright notice, this list of conditions and
 * the following disclaimers.
 *
 *
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimers in the documentation and/or other materials
 * provided with the distribution.
 *
 *
 * Neither the name of Broadcom Corporation, Robert J. McMahon,
 * nor the names of its contributors may be used to endorse
 * or promote products derived from this Software without
 * specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE CONTIBUTORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * ________________________________________________________________
 *
 * payloads.h
 * Iperf 2 packet or socket payloads/protocols
 *
 * by Robert J. McMahon (rjmcmahon@rjmcmahon.com)
 * -------------------------------------------------------------------
 */
#ifndef PAYLOADSC_H
#define PAYLOADSC_H

#ifdef __cplusplus
extern "C" {
#endif
/*
 * Message header flags
 */

#define TAPBYTESSLOP 512
#define TCP_CCA_NAME_MAX 32

/* key for permit */
#define HEADER_KEYCHECK 0x10000000
#define HEADER_KEYL1 0x01000000
#define HEADER_KEYL2 0x02000000
#define HEADER_KEYLEN_MASK 0x0000FFFE  // Lower bit used by V1 hdr
#define DEFAULT_PERMITKEY_LEN 16
#define MIN_PERMITKEY_LEN 4
#define MAX_PERMITKEY_LEN 128
// Default path for a bare --permit-key-file (no value given), same
// optional-argument convention as --permit-key. See Settings.cpp's
// OPT_PERMIT_KEY_FILE and Listener.cpp's load_permit_key_file().
#define DEFAULT_PERMITKEYFILE_PATH "/etc/iperf2/permit-keys.env"

/*
 * base flags, keep compatible with older versions
 */
#define HEADER_VERSION1 0x80000000
#define HEADER_EXTEND 0x40000000
#define HEADER_UDPTESTS 0x20000000
// reserved for keycheck flag    0x10000000
#define HEADER_SEQNO64B 0x08000000
#define HEADER_VERSION2 0x04000000
#define HEADER_V2PEERDETECT 0x02000000
#define HEADER_UDPAVOID2 0x02000000
#define HEADER_UDPAVOID1 0x01000000
#define HEADER_BOUNCEBACK 0x00800000

#define HEADER32_SMALL_TRIPTIMES 0x00020000
#define HEADER_LEN_BIT 0x00010000
// Header length is encoded/decoded with HEADER_KEYLEN_MASK (above); the
// 16-bit width is required since len can exceed 255. MAX_HEADER_LEN is
// the sanity ceiling applied to the decoded value.
#define MAX_HEADER_LEN 256
#define SERVER_HEADER_EXTEND 0x40000000
#define RUN_NOW 0x00000001
#define HEADER16_SMALL_TRIPTIMES 0x0002  // use is 16 bits and not 32 bits

// Num threads highest bit indicates sync id
#define HEADER_HASTRANSFERID 0x80000000
#define HEADER_TRANSFERIDMASK 0xFFF00000
#define HEADER_TRANSFERIDSHIFT 20

// Bounceback flag
#define HEADER_BBQUICKACK 0x8000
#define HEADER_BBCLOCKSYNCED 0x4000  // used in the bb header only
#define HEADER_BBTOS 0x2000
#define HEADER_BBSTOP 0x1000
#define HEADER_BBREPLYSIZE 0x0800
// Client requested --tcp-cca; a 2-byte length + name suffix follows the
// first bounce's own bbsize-counted bytes (and the permit-key suffix, if
// also present) - same one-time-at-connection-setup convention as
// HEADER_KEYCHECK's own suffix, see RunBounceBackTCP/Listener.cpp. The
// regular (non-bounceback) TCP header carries CCA inline via cca_field
// instead - bounceback_hdr has no room for a variable-length field, so
// this reuses the client_udp_testhdr/permitKey era's "external suffix,
// gated by a flag bit" pattern instead.
#define HEADER_BBCCA 0x0400
// UDP bounceback only (bounceback_udp_hdr, never bounceback_hdr - TCP has
// no per-packet ECN marking choice to signal). Set on every request when
// the client is running --udp-l4s, so the server's reply direction can
// mirror the same marked/unmarked choice back per-request - the listener
// thread's own isUDPL4S(mSettings) can't be used for this server-side,
// since --dual-transport's auxiliary UDP listener (Launch.cpp,
// listeners_init) is unconditionally UDPL4S regardless of what any given
// client's request actually asked for; UDP has no per-connection thread
// the way TCP's accept() gives it one, so the wire is the only place this
// can travel per-request. See Client::WriteUdpTxBBHdr (sets it) and
// Server::ProcessBounceBackUDP (reads it).
#define HEADER_BBL4S 0x0200
// Server sets this on a reply when the request it's replying to had
// HEADER_BBL4S set but arrived with a real (received, not payload-level)
// TOS byte showing Not-ECT instead of ECT(1)/CE - i.e. some middlebox on
// the client->server path stripped the ECN marking bits. One-shot signal
// only (see Server::ProcessBounceBackUDP/Client::RunBounceBackUDP), not a
// counter - the client logs it once via PostReport(InitStringReport())
// the first time it sees this bit set, same "post to the Reporter thread,
// don't printf/WARN from a traffic thread" rule every other one-shot
// message in this codebase already follows.
#define HEADER_BBREQ_BLEACHED 0x0100
// The affirmative counterpart to HEADER_BBREQ_BLEACHED above - set instead
// (never both) when the request arrived with its ECT(1)/CE marking still
// intact. Without this, "bit never set" conflates two different things:
// "confirmed fine" and "never got a clean read yet" (e.g. still waiting
// on the first tosKnown request). Same one-shot-log rule as
// HEADER_BBREQ_BLEACHED.
#define HEADER_BBREQ_CONFIRMED 0x0080

// newer flags available per HEADER_EXTEND
// Below flags are used to pass test settings in *every* UDP packet
// and not just during the header exchange
// upper flags (16 bit)
#define HEADER_ISOCH 0x0001
#define HEADER_L2ETHPIPV6 0x0002
#define HEADER_L2LENCHECK 0x0004
#define HEADER_NOUDPFIN 0x0008
#define HEADER_TRIPTIME 0x0010
// Client requests UDP rx latency histograms be enabled on the server
// (professional edition client only, see HAVE_PROFESSIONAL)
#define HEADER_HISTOGRAM 0x0020
#define HEADER_ISOCH_SETTINGS 0x0040
#define HEADER_UNITS_PPS 0x0080
#define HEADER_BWSET 0x0100
#define HEADER_FQRATESET 0x0200
#define HEADER_REVERSE 0x0400
#define HEADER_FULLDUPLEX 0x0800
#define HEADER_EPOCH_START 0x1000
#define HEADER_PERIODICBURST 0x2000
#define HEADER_WRITEPREFETCH 0x4000
#define HEADER_TCPQUICKACK 0x8000

// lower flags (16 bit)
#define HEADER_CCA 0x8000
#define HEADER_BARRIER_TIME 0x4000
#define HEADER_UDPL4S 0x2000
// Client requests --tcp-write-times be active on the server's own
// reverse-mode/full-duplex writer thread too (see Client::RunWriteEventsTCP/
// RunTCP's write_time sampling, src/Client.cpp) - a plain boolean flag, no
// associated value (unlike HEADER_WRITEPREFETCH's byte count), since
// write-times just turns wall-clock syscall timing on/off. Without this,
// the server never learns the client wants it, and reverse-mode
// tcpwritetimeus stays -1 regardless of the client's own --tcp-write-times
// flag (that flag only ever governs the client's own local settings struct,
// never reaches the server on its own).
#define HEADER_TCPWRITETIMES 0x0001
// Client requests --txdelay-time be honored on the server's own reverse-
// mode/full-duplex writer thread too, using the SAME relative duration
// (reuses hdr->start_fq.start_tv_sec/usec, the same wire field
// HEADER_EPOCH_START already uses for --txstart-time's absolute epoch -
// the two are mutually exclusive client-side, Settings.cpp's own
// "--txstart-time and --txdelay-time are mutually exclusive" check, so
// there's never a need for both interpretations of that field at once).
// Unlike HEADER_EPOCH_START's absolute epoch, a relative delay needs no
// synchronized client/server clocks to land both ends' traffic start
// within about one connection-setup round trip of each other - see
// Client::StartSynch's own isServerReverse+isTxHoldback block for the
// server-side reverse-writer thread's own relative sleep.
#define HEADER_EPOCH_DELAY 0x0002

// later features
#define HDRXACKMAX 2500000  // default 2.5 seconds, units microseconds
#define HDRXACKMIN 10000    // default 10 ms, units microsecond

// L4S ACK Flags
#define L4S_ECN_ERR 0x0001
#define L4S_PKT_FIN 0x0002
// SIGUSR1/SIGUSR2-driven pause/resume relay for a --working-load=down UDP
// L4S stream (Server::RunUDPL4S/Client::RunUDPL4S, src/Server.cpp/
// src/Client.cpp) - see FLAG_WORKING_LOAD_THREAD's own doc comment
// (Settings.hpp) for why this relay exists at all: unlike the client-
// writer direction (a local SIGUSR1 to the client process is enough),
// this direction's writer is a thread the *server* spawns in a different
// process, unreachable by any local signal. The reader (a client-app-
// process-spawned thread, same process as the SIGUSR1 handler, already
// known to be a working-load thread via isWorkingLoadThread(mSettings))
// sets this bit on every ACK it sends back while genuinely paused,
// clearing it once resumed - a level-triggered "am I paused right now"
// signal, not an edge-triggered pause/resume pair the way the local
// SIGUSR1/SIGUSR2 signals themselves are. That distinction matters:
// SIGUSR1/SIGUSR2 need to be two distinct absolute-state signals because
// POSIX signals aren't queued and a dropped one would permanently desync
// sender and receiver, but a single flag re-sent on every ACK is
// naturally self-healing against an occasional dropped ACK (UDP itself
// already tolerates that) - the writer's own paused state is always just
// "whatever the most recently *received* ACK said," never something it
// has to remember correctly forever.
#define L4S_PAUSE 0x0004

enum L4SDataType {
    L4SPKTDATA = 0x1,
};

// Versions the *L4S payload format itself* (client_udp_l4s_fwd's trailing
// fields below HEADER_UDPL4S/l4s_data_type), separate from the general
// iperf release version already exchanged in client_hdrext.version_u/l -
// that pair says "what iperf release is my peer," not "what shape is this
// specific struct," and nothing currently checks it before relying on a
// new field. Still 1 - the UDP-L4S protocol hasn't shipped in a release
// yet, so there's no deployed peer to stay backward compatible with; the
// sender_* fields below (added alongside this comment) are just part of
// the v1 struct rather than needing their own version bump/gate. Bump this
// if a real compatibility boundary ever needs drawing post-release.
#define L4S_PAYLOAD_VERSION 1

/*
 * Structures used for test messages which
 * are exchanged between the client and the Server/Listener
 */
enum MsgType { CLIENTHDR = 0x1, CLIENTHDRACK, CLIENTTCPHDR, SERVERHDR, SERVERHDRACK };

#define MINIPERFPAYLOAD 18
// Minimum IPv4 frame size = 18 (Ethernet) + 20 (IPv4) + 8 (UDP) + 18 (payload)
// = 64 bytes Minimum IPv6 frame size = 18 (Ethernet) + 40 (IPv6) + 8 (UDP) + 18
// (payload) = 84 bytes

/*
 * Structures below will be passed as network i/o
 * between the client, listener and server
 * and must be packed by the compilers
 * Align on 32 bits (4 bytes)
 */
#pragma pack(push, 4)
struct UDP_datagram {
    // used to reference the 4 byte ID number we place in UDP datagrams
    // Support 64 bit seqno on machines that support them
    uint32_t id;
    uint32_t tv_sec;
    uint32_t tv_usec;
    uint32_t id2;
};

struct hdr_typelen {
    int32_t type;
    int32_t length;
};

struct TCP_datagram {
    // used to reference write ids and timestamps in TCP payloads
    struct hdr_typelen typelen;
    uint32_t id;
    uint32_t id2;
    uint32_t tv_sec;
    uint32_t tv_usec;
    uint32_t reserved1;
    uint32_t reserved2;
};

/*
 * The client_hdr structure is sent from clients
 * to servers to alert them of things that need
 * to happen. Order must be perserved in all
 * future releases for backward compatibility.
 * 1.7 has flags, numThreads, mPort, and bufferlen
 */
struct client_hdr_v1 {
    /*
     * flags is a bitmap for different options
     * the most significant bits are for determining
     * which information is available. So 1.7 uses
     * 0x80000000 and the next time information is added
     * the 1.7 bit will be set and 0x40000000 will be
     * set signifying additional information. If no
     * information bits are set then the header is ignored.
     * The lowest order diferentiates between dualtest and
     * tradeoff modes, wheither the speaker needs to start
     * immediately or after the audience finishes.
     */
    int32_t flags;
    int32_t numThreads;
    int32_t mPort;
    int32_t mBufLen;
    int32_t mWinBand;
    int32_t mAmount;
};

//
// Payload used for the bounce back feature
//
// Notes:
//    o) flags is standard iperf 2 flags for test exchange info
//    o) burst size is the payload size and size of bounce back write
//    o) burst id is a running seq no
//    o) send is the write timestamp
//    o) bb_r2w_hold is an optional delay value between the read and bb write,
//    typically expected as zero o) triptimes will support OWD measurements in
//    each direction (useful for asymmetry testing) o) min payload
//         - seven 32b or 28 bytes with round trip only,
//	   - eleven 32b or 44 bytes when including trip-times support
//    o) no need for a bb read timestamp to be passed in the payload
//    o) OWD calculations require e2e clock sync and --trip-times cli option
//    o) no need to copy bb payload as rx buffer with be used for bounce back
//    write o) single threaded design o) these are packed, be careful that the
//    union doesn't break this
//

struct bb_ts {
    uint32_t sec;
    uint32_t usec;
};
struct bounceback_hdr {
    uint32_t flags;
    uint32_t bbsize;
    uint32_t bbid;
    uint16_t bbflags;
    uint16_t tos;
    uint32_t bbRunTime;  // units 10 ms
    struct bb_ts bbclientTx_ts;
    struct bb_ts bbserverRx_ts;
    struct bb_ts bbserverTx_ts;
    uint32_t bbhold;  // up to here is mandatory
    uint32_t bbrtt;
    struct bb_ts bbread_ts;
    uint32_t bbreplysize;
};

//
// Payload used for the discrete (stop-and-wait) UDP-L4S bounce back
// feature - same request/reply RPS measurement as struct bounceback_hdr
// above, but carried as a vanilla/generic ECT(1)-marked UDP datagram
// instead of a TCP byte stream, so it can be A/B compared directly
// against TCP bounceback. See Client::RunBounceBackUDP/WriteUdpTxBBHdr
// (src/Client.cpp) and Server::RunBounceBackUDP (src/Server.cpp) for the
// write/read sides, and Listener::apply_client_settings_udp_bounceback
// (src/Listener.cpp) for the connection-setup parse. Wire semantics stay
// generic L4S only (ECT(1)/CE, writemsg_delay_tos()/ReadWithRxTimestamp())
// - no Fi-Wi or other vendor-specific trailer/extension.
//
// Deltas from bounceback_hdr (see that struct's own doc comment for the
// shared rationale):
//    o) leads with the same struct UDP_datagram every other UDP wire
//       format in this codebase starts with (see client_udp_testhdr) -
//       unlike TCP, where a bare struct bounceback_hdr can start directly
//       with its own flags field, EVERY UDP datagram here (including the
//       very first one, which doubles as the connect-time settings
//       exchange - see Listener::apply_client_settings_udp()'s
//       hdr->base.flags read, which is only correct because base.flags
//       sits right after that same 16-byte prefix) carries this id/
//       timestamp prefix. Getting this wrong is a real trap: a
//       bounceback_udp_hdr without it still round-trips fine locally
//       (the client writes and reads its own layout consistently) but
//       silently misaligns with the *generic* UDP-side flags parse that
//       has to run before any bounceback-specific code even knows this is
//       a bounceback packet.
//    o) the whole request - this header, zero-fill payload up to bbsize,
//       and (first request only) an optional permit-key suffix (2-byte
//       network-order length + key bytes, same convention as every other
//       permit-key suffix in this codebase) - is one UDP datagram/one
//       sendto(), unlike TCP bounceback's separate myWriten()/recvn()
//       calls. So there's no equivalent of TCP bounceback's HEADER_BBCCA
//       suffix: --tcp-cca is a TCP-only concept (Settings.cpp rejects/
//       warns on --tcp-cca + -u + --bounceback) and doesn't apply here.
//    o) no bbrtt/bbread_ts fields - dead even in bounceback_hdr (RTT is
//       computed by the reporter from timestamps, never sent on the wire)
//    o) bbflags never carries HEADER_BBQUICKACK - TCP_QUICKACK is a
//       TCP-only socket option
//
struct bounceback_udp_hdr {
    struct UDP_datagram seqno_ts;  // id (=bbid) + send timestamp, see above
    uint32_t flags;
    uint32_t bbsize;
    uint32_t bbid;
    uint16_t bbflags;
    uint16_t tos;
    uint32_t bbRunTime;  // units 10 ms, reserved/unused (parity w/ bounceback_hdr)
    struct bb_ts bbclientTx_ts;
    struct bb_ts bbserverRx_ts;
    struct bb_ts bbserverTx_ts;
    uint32_t bbhold;
    uint32_t bbreplysize;
    // Server's own running count of valid bounceback requests received
    // from this client so far (this connection's lifetime, not just this
    // one request) - echoed on every reply so the client can attribute
    // an unanswered request to a specific direction: bbRequestsRx vs the
    // client's own sent count tells you how many requests never reached
    // the server at all (request-direction loss); bbRequestsRx vs the
    // client's own received-reply count tells you how many the server
    // received and (presumably) replied to, but the reply itself never
    // made it back (reply-direction loss). A plain running count, not a
    // "highest bbid seen" high-water mark - bbid alone can't distinguish
    // "this exact request was received" from "a later one was received
    // instead", since a gap in bbid could mean either the marked request
    // or some other one was the one actually lost. Appended at the end
    // (not inserted mid-struct) so an older peer that doesn't know this
    // field yet still parses everything before it correctly - see
    // RunBounceBackUDP's own doc comment (Client.cpp/Server.cpp) for how
    // an all-zero value from an older peer degrades gracefully (loss
    // attribution just reports "0 received," not a crash or a
    // misparsed packet).
    uint32_t bbRequestsRx;
};

struct client_hdrext_isoch_settings {
    int32_t FPSl;
    int32_t FPSu;
    int32_t Meanl;
    int32_t Meanu;
    int32_t Variancel;
    int32_t Varianceu;
    int32_t BurstIPGl;
    int32_t BurstIPGu;
};

// reserved's only meaning today - carries --cca's prague/reno choice
// (under --udp-l4s), valid iff upperflags & HEADER_UDPL4S (see Settings.cpp's
// HEADER_UDPL4S send/read-back sites). No new HEADER_* bit needed since
// it's a single byte of enum data riding in a header client_hdrext already
// carries whenever UDP L4S is in play - see l4s_cca_tp, prague_cc.h, for
// what the value actually controls.
#define UDP_L4S_CCA_WIRE_PRAGUE 0
#define UDP_L4S_CCA_WIRE_RENO 1

struct client_hdrext {
    int32_t type;
    int32_t length;
    int16_t upperflags;
    int16_t lowerflags;
    uint32_t version_u;
    uint32_t version_l;
    uint16_t reserved;
    uint16_t tos;
    uint32_t lRate;
    uint32_t uRate;
    uint32_t TCPWritePrefetch;
    uint32_t barrier_usecs;
};

struct client_hdrext_starttime_fq {
    uint32_t start_tv_sec;
    uint32_t start_tv_usec;
    uint32_t fqratel;
    uint32_t fqrateu;
};

/*
 * TCP Isoch/burst payload structure
 *
 *                 0      7 8     15 16    23 24    31
 *                +--------+--------+--------+--------+
 *            1   |        type                       |
 *                +--------+--------+--------+--------+
 *            2   |        len                        |
 *                +--------+--------+--------+--------+
 *            3   |        flags                      |
 *                +--------+--------+--------+--------+
 *            4   |        reserved                   |
 *                +--------+--------+--------+--------+
 *            5   |        isoch burst period (us)    |
 *                +--------+--------+--------+--------+
 *            6   |        isoch start timestamp (s)  |
 *                +--------+--------+--------+--------+
 *            7   |        isoch start timestamp (us) |
 *                +--------+--------+--------+--------+
 *            8   |        burst id                   |
 *                +--------+--------+--------+--------+
 *            9   |        burtsize                   |
 *                +--------+--------+--------+--------+
 *           10   |        burst bytes remaining      |
 *                +--------+--------+--------+--------+
 *           11   |        seqno lower                |
 *                +--------+--------+--------+--------+
 *           12   |        seqno upper                |
 *                +--------+--------+--------+--------+
 *           13   |        tv_sec (write)             |
 *                +--------+--------+--------+--------+
 *           14   |        tv_usec (write)            |
 *                +--------+--------+--------+--------+
 *           15   |        tv_sec (read)              |
 *                +--------+--------+--------+--------+
 *           16   |        tv_usec (read)             |
 *                +--------+--------+--------+--------+
 *           17   |        tv_sec (write-ack)         |
 *                +--------+--------+--------+--------+
 *           18   |        tv_usec (write-ack)        |
 *                +--------+--------+--------+--------+
 *           19   |        tv_sec (read-ack)          |
 *                +--------+--------+--------+--------+
 *           20   |        tv_usec (read-ack)         |
 *                +--------+--------+--------+--------+
 *           21   |        reserved                   |
 *                +--------+--------+--------+--------+
 *           22   |        reserved                   |
 *                +--------+--------+--------+--------+
 *           23   |        reserved                   |
 *                +--------+--------+--------+--------+
 *           24   |        reserved                   |
 *                +--------+--------+--------+--------+
 *
 */
struct TCP_oneway_triptime {
    uint32_t write_tv_sec;
    uint32_t write_tv_usec;
    uint32_t read_tv_sec;
    uint32_t read_tv_usec;
};

struct TCP_burst_payload {
    uint32_t flags;
    struct hdr_typelen typelen;
    uint32_t start_tv_sec;
    uint32_t start_tv_usec;
    struct TCP_oneway_triptime send_tt;
    // Populated only by the server's reverse-mode writer thread
    // (isServerReverse, see Client::WriteTcpTxHdr) with its own
    // gettcpinfo() sample's cumulative retry_tot (not a per-interval
    // delta - the reader computes that itself, see
    // reporter_handle_packet_server_tcp in Reporter.c) - see reverse_rtt
    // et al below for why this needs relaying at all. Was "reserved0".
    uint32_t reverse_retry;
    uint32_t burst_period_us;
    uint32_t burst_id;
    uint32_t burst_size;
    uint32_t seqno_lower;
    uint32_t seqno_upper;
    struct TCP_oneway_triptime writeacktt;
    // Populated only by the server's reverse-mode writer thread
    // (isServerReverse, see Client::WriteTcpTxHdr) with its own
    // gettcpinfo() sample - the receiving reader can't observe these
    // sender-side-only TCP_INFO stats locally in reverse mode, so the
    // writer relays them here. Previously unused reserved fields, so
    // any peer that doesn't know to look for this (i.e. every existing
    // reader before this feature) is unaffected.
    uint32_t reverse_bytes_in_flight;
    uint32_t reverse_rtt;
    uint32_t reverse_packets_in_flight;  // HAVE_TCP_INFLIGHT only, same as reverse_bytes_in_flight
    uint32_t reverse_cwnd;  // HAVE_TCP_STATS only, same convention. Was "reserved4".
    // Bytes written to the socket but not yet sent (tcpi_notsent_bytes) -
    // same relay convention as reverse_cwnd above. Grows the struct rather
    // than reusing a reserved field (none left) - safe as long as both
    // sides of a connection are rebuilt *and restarted* together (a
    // running process keeps its old in-memory code even after the binary
    // on disk is replaced - confirmed the hard way debugging reverse_cwnd).
    uint32_t reverse_notsent;
    // Kernel's own continuously-updated minimum RTT (tcpi_min_rtt) - same
    // relay convention as reverse_cwnd/reverse_notsent above. Backs TCP's
    // "excess RTT above kernel-tracked minimum" reading on the reader
    // side (rtt minus this baseline, deliberately NOT split any further
    // into a "queueing vs network" decomposition - see
    // IperfViewModel.tcpExcessRttAcc's own doc comment for why), the same
    // role PragueCC's own m_rtt_min plays for UDP-L4S's Load Delay.
    uint32_t reverse_rtt_min;
    // Live, currently-autotuned send socket buffer size (SO_SNDBUF, KB -
    // see iperf_tcpstats.sndbuf_bytes) - same relay convention as
    // reverse_cwnd/reverse_notsent/reverse_rtt_min above.
    uint32_t reverse_sndbuf;
    // Per-write blocking time (microseconds, ReportStruct.write_time) -
    // wall-clock time spent inside the write()/writev() syscall itself,
    // i.e. send-side backpressure/buffer-sojourn delay, measured only when
    // --tcp-write-times is active (isTcpWriteTimes()). Distinct from (and
    // never included in) TCP's own rtt/reverse_rtt above - the kernel's
    // RTT clock only starts once a byte is actually transmitted, so this
    // covers the earlier stage: how long a byte sat waiting to be sent at
    // all. Same relay convention as reverse_cwnd/reverse_notsent/
    // reverse_rtt_min/reverse_sndbuf above; (uint32_t)-1 when
    // --tcp-write-times isn't active.
    uint32_t reverse_write_time;
    // Cumulative tcpi_sndbuf_limited/tcpi_rwnd_limited/tcpi_busy_time
    // (microseconds, kernel 4.9+ - see iperf_tcpstats.sndbuf_limited_tot
    // et al's own doc comment) - same relay convention as reverse_cwnd/
    // reverse_notsent/reverse_rtt_min/reverse_sndbuf above: the raw
    // cumulative counter, not a delta (the reader computes that itself,
    // same as reverse_retry). 0 when unavailable - unlike the other
    // reverse_* fields above, these can't use (uint32_t)-1 as an
    // "unavailable" sentinel since 0xFFFFFFFF is itself a plausible
    // cumulative microsecond count; 0 is indistinguishable from "just
    // started" either way, which is the same ambiguity a genuinely-zero
    // reading would have, so it's an acceptable sentinel here.
    uint32_t reverse_sndbuf_limited;
    uint32_t reverse_rwnd_limited;
    uint32_t reverse_busy_time;
};

/*
 * UDP Full Isoch payload structure
 *
 *                 0      7 8     15 16    23 24    31
 *                +--------+--------+--------+--------+
 *      0x00  1   |          seqno lower              |
 *                +--------+--------+--------+--------+
 *      0x04  2   |             tv_sec                |
 *                +--------+--------+--------+--------+
 *      0x08  3   |             tv_usec               |
 *                +--------+--------+--------+--------+
 *            4   |          seqno upper              |
 *                +--------+--------+--------+--------+
 *            5   |         flags (v1)                |
 *                +--------+--------+--------+--------+
 *            6   |         numThreads (v1)           |
 *                +--------+--------+--------+--------+
 *            7   |         mPort (v1)                |
 *                +--------+--------+--------+--------+
 *            8   |         bufferLen (v1)            |
 *                +--------+--------+--------+--------+
 *            9   |         mWinBand (v1)             |
 *                +--------+--------+--------+--------+
 *            10  |         mAmount (v1)              |
 *                +--------+--------+--------+--------+
 *            11  |   up flags      |   low flags     |
 *                +--------+--------+--------+--------+
 *            12  |        iperf version major        |
 *                +--------+--------+--------+--------+
 *            13  |        iperf version minor        |
 *                +--------+--------+--------+--------+
 *            14  |        reserved          |  TOS   |
 *                +--------+--------+--------+--------+
 *            15  |        rate                       |
 *                +--------+--------+--------+--------+
 *            16  |        rate units                 |
 *                +--------+--------+--------+--------+
 *            17  |        realtime   (0.13)          |
 *                +--------+--------+--------+--------+
 *            18  |        isoch burst period (us)    |
 *                +--------+--------+--------+--------+
 *            19  |        isoch start timestamp (s)  |
 *                +--------+--------+--------+--------+
 *            20  |        isoch start timestamp (us) |
 *                +--------+--------+--------+--------+
 *            21  |        isoch prev frameid         |
 *                +--------+--------+--------+--------+
 *            22  |        isoch frameid              |
 *                +--------+--------+--------+--------+
 *            23  |        isoch burtsize             |
 *                +--------+--------+--------+--------+
 *            24  |        isoch bytes remaining      |
 *                +--------+--------+--------+--------+
 *            25  |        isoch reserved             |
 *                +--------+--------+--------+--------+
 *            26  |        reserved (0.14 start)      |
 *                +--------+--------+--------+--------+
 *            28  |        start tv_sec  (0.14)       |
 *                +--------+--------+--------+--------+
 *            29  |        start tv_usec              |
 *                +--------+--------+--------+--------+
 *            27  |        fqratel                    |
 *                +--------+--------+--------+--------+
 *            28  |        fqrateu                    |
 *                +--------+--------+--------+--------+
 *            29  |        FPSl                       |
 *                +--------+--------+--------+--------+
 *            30  |        FPSu                       |
 *                +--------+--------+--------+--------+
 *            31  |        Meanl                      |
 *                +--------+--------+--------+--------+
 *            32  |        Meanu                      |
 *                +--------+--------+--------+--------+
 *            33  |        Variancel                  |
 *                +--------+--------+--------+--------+
 *            34  |        Varianceu                  |
 *                +--------+--------+--------+--------+
 *            35  |        BurstIPGl                  |
 *                +--------+--------+--------+--------+
 *            36  |        BurstIPG                   |
 *                +--------+--------+--------+--------+
 *
 */
struct isoch_payload {
    uint32_t burstperiod;  // period units microseconds
    uint32_t start_tv_sec;
    uint32_t start_tv_usec;
    uint32_t prevframeid;
    uint32_t frameid;
    uint32_t burstsize;
    uint32_t remaining;
    uint32_t reserved;
};

/*
 * UDP Foward L4S payload structure
 *
 *                 0      7 8     15 16    23 24    31
 *                +--------+--------+--------+--------+
 *      0x00  1   |          seqno lower              |
 *                +--------+--------+--------+--------+
 *      0x04  2   |             tv_sec                |
 *                +--------+--------+--------+--------+
 *      0x08  3   |             tv_usec               |
 *                +--------+--------+--------+--------+
 *            4   |          seqno upper              |
 *                +--------+--------+--------+--------+
 *            5   |         flags (v1)                |
 *                +--------+--------+--------+--------+
 *            6   |         numThreads (v1)           |
 *                +--------+--------+--------+--------+
 *            7   |         mPort (v1)                |
 *                +--------+--------+--------+--------+
 *            8   |         bufferLen (v1)            |
 *                +--------+--------+--------+--------+
 *            9   |         mWinBand (v1)             |
 *                +--------+--------+--------+--------+
 *            10  |         mAmount (v1)              |
 *                +--------+--------+--------+--------+
 *            11  |               type                |
 *                +--------+--------+--------+--------+
 *            12  |              length               |
 *                +--------+--------+--------+--------+
 *            13  |   up flags      |   low flags     |
 *                +--------+--------+--------+--------+
 *            14  |        iperf version major        |
 *                +--------+--------+--------+--------+
 *            15  |        iperf version minor        |
 *                +--------+--------+--------+--------+
 *            16  |  l4s_data_type  |       tos       |
 *                +--------+--------+--------+--------+
 *            17  |          sender timestamp (A)     |
 *                +--------+--------+--------+--------+
 *            18  |          echoed timestamp (B)     |
 *                +--------+--------+--------+--------+
 *            19  |          sender seqno (A)         |
 *                +--------+--------+--------+--------+
 *            20  | l4s_payload_ver |    reserved     |
 *                +--------+--------+--------+--------+
 *            21  |          flow guid lower           |
 *                +--------+--------+--------+--------+
 *            22  |          flow guid upper           |
 *                +--------+--------+--------+--------+
 *            23  |         sender qdelay (us)        |
 *                +--------+--------+--------+--------+
 *            24  |         sender qbytes             |
 *                +--------+--------+--------+--------+
 *            25  |         sender rtt (us)           |
 *                +--------+--------+--------+--------+
 *            26  |         sender packet window      |
 *                +--------+--------+--------+--------+
 *            27  |         sender inflight           |
 *                +--------+--------+--------+--------+
 *            28  |         sender marking prob       |
 *                +--------+--------+--------+--------+
 */
struct client_udp_l4s_fwd {
    struct UDP_datagram seqno_ts;
    struct client_hdr_v1 base;
    struct hdr_typelen typelen;
    int16_t upperflags;
    int16_t lowerflags;
    uint32_t version_u;
    uint32_t version_l;
    uint16_t l4s_data_type;
    uint16_t tos;
    uint32_t sender_ts;
    uint32_t echoed_ts;
    uint32_t sender_seqno;
    // v1 (L4S_PAYLOAD_VERSION) additions below - see that define's own doc
    // comment. l4s_payload_reserved keeps the struct's 4-byte alignment
    // (l4s_payload_version is 2 bytes) without adding an unlabeled gap.
    uint16_t l4s_payload_version;
    uint16_t l4s_payload_reserved;
    uint32_t flow_guid_lower;
    uint32_t flow_guid_upper;
    // The writer's own local PragueCC state (src/prague_cc.cpp), stamped on
    // every packet the same way sender_ts/echoed_ts/sender_seqno above
    // already are - lets a --reverse mode reader (Server::RunUDPL4S) show
    // the same RTT/Load-Delay/window/inflight/marking-probability meters a
    // forward-mode run shows, instead of always reading -1 there. Same
    // relay idea as TCP_burst_payload's own reverse_* fields (see that
    // struct's doc comment above) - the writer always knows its own state
    // regardless of which process (client CLI or server CLI) is playing
    // the writer role in a given test direction. sender_qbytes is
    // truncated to 32 bits (Little's Law queue-byte estimate for one UDP
    // flow's window never approaches 2^31) rather than carried as the
    // local int64_t field's full width, to avoid a second htonl half for a
    // magnitude that will never use it.
    uint32_t sender_qdelay_us;
    uint32_t sender_qbytes;
    uint32_t sender_rtt_us;
    uint32_t sender_packet_window;
    uint32_t sender_inflight;
    uint32_t sender_marking_prob;
    // Same relay idea as the sender_* fields above, for --cca's prague/reno
    // choice under --udp-l4s (l4s_cca_prague=0/l4s_cca_reno=1, see l4s_cca_tp's own doc
    // comment) - lets a --reverse mode reader show which variant the
    // actual writer is using, not just its own local setting.
    uint32_t sender_cca_mode;
};

/*
 * UDP L4S ACK payload structure
 *
 *                 0      7 8     15 16    23 24    31
 *                +--------+--------+--------+--------+
 *      0X00  1   | uint16_t flags  |   reserved      |
 *                +--------+--------+--------+--------+
 *      0x04  2   |        receiver timestamp (B)     |
 *                +--------+--------+--------+--------+
 *      0x06  4   |          echoed timestamp (A)     |
 *                +--------+--------+--------+--------+
 *      0x08  5   |            pkt rx count (B)       |
 *                +--------+--------+--------+--------+
 *            6   |   pkt CE count (B,N) (CE==0x3)++  |
 *                +--------+--------+--------+--------+
 *            7   |          pkt lost count (A,B)     |
 *                +--------+--------+--------+--------+
 *            8   |        reserved                   |
 *                +--------+--------+--------+--------+
 */
struct udp_l4s_ack {
    uint16_t flags;  // L4S_ECN_ERR bit, receiver found a bleached/error ECN;
                     // stop using L4S_id on the sending packets!
    uint16_t l4sreserved;
    int32_t rx_ts;      // timestamp from peer, freeze and keep this time
    int32_t echoed_ts;  // echoed_timestamp can be used to calculate the RTT
    int32_t rx_cnt;     // echoed_packet counter
    int32_t CE_cnt;     // echoed CE counter
    int32_t lost_cnt;   // echoed lost counter
    int32_t reserved1;
};

struct cca_field {
    uint16_t cca_length;
    char value[TCP_CCA_NAME_MAX];
};

struct permitKey {
    uint16_t length;
    char value[MAX_PERMITKEY_LEN];
};

struct client_udp_testhdr {
    struct UDP_datagram seqno_ts;
    struct client_hdr_v1 base;
    struct client_hdrext extend;
    struct isoch_payload isoch;
    struct client_hdrext_starttime_fq start_fq;
    struct client_hdrext_isoch_settings isoch_settings;
    // Unconditional (not #if HAVE_PROFESSIONAL) despite --permit-key
    // enforcement itself being professional-only (see
    // ModalOptions_CommonBailChecks, Settings.cpp): a professional-edition
    // client (e.g. the Android app) always sends this field over the wire
    // regardless of what edition the server is. Gating it out of the
    // community edition's struct layout made the two editions disagree on
    // this header's size/offsets, so a community-edition UDP server would
    // misparse everything a professional client sent - not just fail to
    // enforce the key, but actually break the handshake. The struct layout
    // must be edition-invariant; only whether a server can *require*/
    // populate a real key stays gated (correctly) in Settings.cpp.
    struct permitKey permitkey;
};

struct client_udpsmall_testhdr {
    struct UDP_datagram seqno_ts;
    uint16_t flags;
    uint32_t start_tv_sec;
    uint32_t start_tv_usec;
};

struct client_hdr_ack_ts {
    uint32_t sent_tv_sec;
    uint32_t sent_tv_usec;
    uint32_t sentrx_tv_sec;
    uint32_t sentrx_tv_usec;
    uint32_t ack_tv_sec;
    uint32_t ack_tv_usec;
};

struct client_hdr_ack {
    struct hdr_typelen typelen;
    uint32_t flags;
    uint32_t version_u;
    uint32_t version_l;
    uint32_t reserved1;
    uint32_t reserved2;
    struct client_hdr_ack_ts ts;
};

/*
 * TCP first payload structure
 *
 *                 0      7 8     15 16    23 24    31
 *                +--------+--------+--------+--------+
 *      0x00  1   |         flags (v1)                |
 *                +--------+--------+--------+--------+
 *            2   |         numThreads (v1)           |
 *                +--------+--------+--------+--------+
 *            3   |         mPort (v1)                |
 *                +--------+--------+--------+--------+
 *            4   |         bufferLen (v1)            |
 *                +--------+--------+--------+--------+
 *            5   |         mWinBand (v1)             |
 *                +--------+--------+--------+--------+
 *            6   |         mAmount (v1)              |
 *                +--------+--------+--------+--------+
 *            7   |        type (0.13)                |
 *                +--------+--------+--------+--------+
 *            8   |        len  (0.13)                |
 *                +--------+--------+--------+--------+
 *            9   |        flags (0.13)               |
 *                +--------+--------+--------+--------+
 *            10  |        iperf version major        |
 *                +--------+--------+--------+--------+
 *            11  |        iperf version minor        |
 *                +--------+--------+--------+--------+
 *            12  |        reserved          | TOS    |
 *                +--------+--------+--------+--------+
 *            13  |        rate                       |
 *                +--------+--------+--------+--------+
 *            14  |        rate units                 |
 *                +--------+--------+--------+--------+
 *            15  |        write prefetch   (0.13)    |
 *                +--------+--------+--------+--------+
 *            16  |        barrier wait (usecs)       |
 *                +--------+--------+--------+--------+
 *            17  |        start tv_sec (0.14)        |
 *                +--------+--------+--------+--------+
 *            18  |        start tv_usec              |
 *                +--------+--------+--------+--------+
 *            19  |        fqratel                    |
 *                +--------+--------+--------+--------+
 *            20  |        fqrateu                    |
 *                +--------+--------+--------+--------+
 *            21  |        FPSl                       |
 *                +--------+--------+--------+--------+
 *            22  |        FPSu                       |
 *                +--------+--------+--------+--------+
 *            23  |        Meanl                      |
 *                +--------+--------+--------+--------+
 *            24  |        Meanu                      |
 *                +--------+--------+--------+--------+
 *            25  |        Variancel                  |
 *                +--------+--------+--------+--------+
 *            26  |        Varianceu                  |
 *                +--------+--------+--------+--------+
 *            27  |        BurstIPGl                  |
 *                +--------+--------+--------+--------+
 *            28  |        BurstIPG                   |
 *                +--------+--------+--------+--------+
 *            29  | CCAS len value ...
 *                +--------+--------+--------+--------+
 */
struct client_tcp_testhdr {
    struct client_hdr_v1 base;
    struct client_hdrext extend;
    struct client_hdrext_starttime_fq start_fq;
    struct client_hdrext_isoch_settings isoch_settings;
    struct cca_field cca;
    struct permitKey permitkey;
};

/*
 * The server_hdr structure facilitates the server
 * report of jitter and loss on the client side.
 * It piggy_backs on the existing clear to close
 * packet.
 */
struct server_hdr_v1 {
    /*
     * flags is a bitmap for different options
     * the most significant bits are for determining
     * which information is available. So 1.7 uses
     * 0x80000000 and the next time information is added
     * the 1.7 bit will be set and 0x40000000 will be
     * set signifying additional information. If no
     * information bits are set then the header is ignored.
     */
    int32_t flags;
    int32_t total_len1;
    int32_t total_len2;
    int32_t stop_sec;
    int32_t stop_usec;
    int32_t error_cnt;
    int32_t outorder_cnt;
    int32_t datagrams;
    int32_t jitter1;
    int32_t jitter2;
};

struct server_hdr_extension {
    int32_t minTransit1;
    int32_t minTransit2;
    int32_t maxTransit1;
    int32_t maxTransit2;
    int32_t sumTransit1;
    int32_t sumTransit2;
    int32_t meanTransit1;
    int32_t meanTransit2;
    int32_t m2Transit1;
    int32_t m2Transit2;
    int32_t vdTransit1;
    int32_t vdTransit2;
    int32_t cntTransit;
    int32_t cntIPG;
    int32_t IPGsum;
};

// Extension for 64bit datagram counts
struct server_hdr_extension2 {
    int32_t error_cnt2;
    int32_t outorder_cnt2;
    int32_t datagrams2;
};

struct server_hdr {
    struct server_hdr_v1 base;
    struct server_hdr_extension extend;
    struct server_hdr_extension2 extend2;
};

#pragma pack(pop)

#define SIZEOF_UDPHDRMSG_V1 (sizeof(struct client_hdrv1) + sizeof(struct UDP_datagram))
#define SIZEOF_UDPHDRMSG_EXT (sizeof(struct client_udp_testhdr))
#define SIZEOF_TCPHDRMSG_V1 (sizeof(struct client_hdr_v1))
#define SIZEOF_TCPHDRMSG_EXT (sizeof(struct client_tcp_testhdr))
// Guaranteed floor for any thread_Settings::mBuf allocation (see
// Settings_Copy() and main.cpp): must never be smaller than
// kDefault_UDPTxBufLen (headers.h), since Client.cpp's UDP fin/relay-ack
// read relies on mBuf being at least that large.
#define MINMBUFALLOCSIZE (int) ((sizeof(struct client_tcp_testhdr) + TAPBYTESSLOP) > kDefault_UDPTxBufLen ? sizeof(struct client_tcp_testhdr) + TAPBYTESSLOP : kDefault_UDPTxBufLen)
#define MINTRIPTIMEPAYLOAD (int)(sizeof(struct client_udp_testhdr) - sizeof(struct client_hdrext_isoch_settings))
#ifdef __cplusplus
} /* end extern "C" */
#endif

#endif  // PAYLOADS
